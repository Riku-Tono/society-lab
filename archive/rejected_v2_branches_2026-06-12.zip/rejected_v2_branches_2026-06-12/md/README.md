# MOAT × SocietyLab × RivalryCA — Cross-World Discriminability Harness

3つの独立したシステムを「測定装置 × 世界」の構図で統合した実験基盤。

## 構図

MOAT Stage 2d の本質は世界ではなく測定装置(2条件のトラジェクトリから
linear + RFF 分類器の AUC で識別可能性を測る装置)である。SocietyLab と
RivalryCA はどちらも観測可能メトリクスの時系列を吐く世界なので、
`WorldAdapter` 1枚で MOAT の分類器スタックを3世界すべてに適用できる。

| world   | H_B                  | H_Q                  | 問い |
|---------|----------------------|----------------------|------|
| moat    | B方向ドリフト        | Q方向共分散ノイズ    | 既存 Stage 2d の SRA 残差識別 |
| society | 解釈ナッジ ON        | 解釈ナッジ OFF       | 3%のナッジは集団観測量に痕跡を残すか |
| rivalry | 非対称 LIKES(競争)  | 対称 LIKES(両想い)  | 圧力場の統計だけから関係構造が漏れるか |

rivalry では rivalry_rate / pair_rate(答えそのもの)を特徴量から除外し、
pressure_entropy / avg_pressure / peace_rate / collapse_risk / 密度のみ使用。

## ファイル

- `society_lab.py` / `moat_stage2d.py` / `rivalry_ca.py` — 元の3ファイル(無改変、リネームのみ)
- `bridge.py` — WorldAdapter 3種、繰り返しランダム分割による AUC + 95% CI、
  時間窓 (early/mid/late/full) 分析、ConfigurableSocietyLab(ナッジを条件化)
- `run_bridge.py` — CLI

## 使い方

```bash
python run_bridge.py --quick                  # スモークテスト(数分)
python run_bridge.py                          # 標準 (n_ep=60, n_boot=25)
python run_bridge.py --world society --n-ep 120 --n-boot 50
```

JSON が `bridge_results.json` に保存される。

## スモークテスト初見 (--quick, n_ep=16)

- moat: early 0.74 → late 0.91(SRA 適応で識別性が増大する方向)
- society: 全窓 ~0.87(3%ナッジでも集団統計に検出可能な痕跡)
- rivalry: ~1.00(rivalry_rate 抜きでも圧力場だけで構造が完全に漏れる)

注意: n_ep=16 は統計的に弱く AUC は楽観的に出やすい。主張に使うなら
n_ep ≥ 60、できれば 120 を推奨。

## 拡張ポイント

1. **rivalry を難化** — 対称/非対称の中間構造(例: 1ペアだけ非対称)で
   識別がどこまで保てるかの相転移を探す。AUC=1.0 は問題が易しすぎる証拠。
2. **society の条件追加** — `ConfigurableSocietyLab(nudge_scale=3.0)` で
   strong 条件、scale を掃引して検出閾値曲線を描く。
3. **Stage 2e 接続** — moat の early→late drift がすでに曲線として出るので、
   窓数を増やせば「適応ループ内の AUC 推移」がそのまま得られる。
4. **leakage 統制** — shuffled-label control を bootstrap_auc に1行追加すれば
   ヌル分布が得られる(AUC ~0.5 になることの確認)。

---

## 検証層 (validation layer)

```bash
python run_validation.py --quick          # 全6検証 (~3分)
python run_validation.py --n-ep 120 --n-boot 50   # 本番
python run_validation.py --only null society_sweep
```

出力: `results/raw/`(生JSON)、`results/summaries/validation_summary.json`、`results/plots/`(PNG)

### 検証結果の初見 (--quick, n_ep=16) — 重要な発見を含む

**1. null対照が仕事をした。** auc_score の max(a,1-a) 折返しにより
null 平均は 0.5 ではなく ~0.65-0.68 に出る(小標本で顕著)。

| world   | real AUC | null 97.5% | null超え |
|---------|----------|-----------|---------|
| moat    | 0.940    | 0.802     | **YES** |
| society | 0.822    | 0.826     | **no**  |
| rivalry | 1.000    | 0.882     | **YES** |

**society の「0.87」は n_ep=16 では null を超えない。** 前回の予告編の
興奮は時期尚早だった。独立シードの nudge sweep でも scale=0〜3.0 で
曲線はCI内で平坦(検出閾値 = 推定不能)。3%ナッジの信号は、存在する
としても n_ep=16 では seed ノイズに埋もれる。**n_ep≥120 での再測定が必須。**

**2. rivalry の AUC=1.0 はリークではなく場の感度。** LOFO でどの特徴量を
抜いても 1.0(信号が全特徴量に冗長に分散)。難易度スイープでは
競争種存在量 s=0.02(生存セルの約2%)ですでに AUC≈0.99。識別の崖は
s<0.02 にあり、相転移ではなく「圧力場が構造差に対して桁違いに敏感」が
正解。次は観測ノイズ注入で検出限界曲線を引くのが筋。

**3. oracle 問題は解決(意外な方向で)。** 対称KL最大化の数値探索 oracle は
v_B と平均 0.13°(最大 0.25°)で一致。つまり旧 `vb_oracle = vB` は
手抜きではなく**解析的に最適だった**。名前は盛っていなかった。

**4. multi-seed**: moat 0.79-0.93(seed揺れあり)、society 0.81-0.88、
rivalry 全seed 1.0。moat の worst-seed 0.788 は n_ep 増で締まるはず。

### society LOFO (参考)
識別を最も支えるのは d_project_success (Δ-0.076)、d_crisis (Δ-0.054)、
d_problem_detected (Δ-0.045)。ただし上記の通り society の信号自体が
null 境界上なので、この監査は n_ep≥120 で再実行のこと。
