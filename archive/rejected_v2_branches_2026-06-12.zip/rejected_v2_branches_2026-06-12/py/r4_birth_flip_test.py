import sys, statistics, json
sys.path.insert(0, '/mnt/data')
from causal_society_v2 import CausalSociety, clamp

T=80

class BirthFlipSociety(CausalSociety):
    def __init__(self, seed:int, nudge_scale:float=0.0):
        super().__init__(seed, nudge_scale)
        self.birth_flip = None  # (year,k)
        self._birth_counter = 0
        self.birth_flip_fired = False
    def step(self):
        self.year += 1
        y = self.year
        self._support_counter = 0
        self._birth_counter = 0
        self.problems = []
        self._resource(y)
        self._council(y)
        self._dialogue(y)
        self._demography(y)
        self._decay(y)
    def _demography(self, y:int):
        ap = self.alive_people
        alive_ids = {p.id: p for p in ap}
        for p in ap:
            p.age += 1
            if p.hunger > 0.6:
                p.health = clamp(p.health - 0.06 * p.hunger)
            else:
                p.health = clamp(p.health + 0.02)
            risk = (max(0.0, (p.age - 68) / 50.0) * 0.5
                    + 0.20 * max(0.0, p.hunger - 0.5)
                    + 0.25 * max(0.0, 0.30 - p.health))
            if self.h.u(y, 'death', p.id) < risk:
                p.alive = False
                self.rec('death')
                for cid in p.confidants:
                    if cid in alive_ids and alive_ids[cid].alive:
                        self._receive_memory(alive_ids[cid], 'death', 0.7)
        food_ok = self.food > 0.5 * self.population
        for p in list(self.alive_people):
            if not (16 <= p.age <= 45):
                continue
            chance = 0.085 * (1.0 if food_ok else 0.4) * (0.6 + 0.8 * self.coop)
            hit = self.h.u(y, 'birth', p.id) < min(0.14, chance)
            self._birth_counter += 1
            if self.birth_flip == (y, self._birth_counter):
                hit = not hit
                self.birth_flip_fired = True
            if hit:
                child = self._make_person(self._next_id, age=0)
                child.confidants = [p.id] + child.confidants[:2]
                self._next_id += 1
                self.people.append(child)
                self.rec('birth')

def run_base(seed, scale=0.0):
    soc=CausalSociety(seed, nudge_scale=scale)
    rows=[]
    for _ in range(T):
        if soc.population>0: soc.step()
        rows.append(soc.metrics())
    return rows, soc.summary()

def run_flip(seed, fy, fk, scale=0.0):
    soc=BirthFlipSociety(seed, nudge_scale=scale)
    soc.birth_flip=(fy,fk)
    rows=[]
    for _ in range(T):
        if soc.population>0: soc.step()
        rows.append(soc.metrics())
    return rows, soc.summary(), soc.birth_flip_fired

def experiment(year_key='placebo', kmax=6, y0=20, yrange=30, seeds=range(1000,1100)):
    diffs=[]; fired=0; details=[]
    for seed in seeds:
        r0,s0=run_base(seed,0.0)
        probe=CausalSociety(seed,0.0)
        fy=y0 + int(probe.h.u(year_key,'year') * yrange)
        fk=1 + int(probe.h.u(year_key,'k') * kmax)
        rows, sm, did=run_flip(seed,fy,fk,0.0)
        if did:
            fired+=1
            d=sm['final_population']-s0['final_population']
            diffs.append(d)
            details.append({'seed':seed,'fy':fy,'fk':fk,'pop_diff':d,'abs':abs(d), 'base':s0['final_population'], 'flip':sm['final_population']})
    absd=[abs(x) for x in diffs]
    return {'params':dict(year_key=year_key,kmax=kmax,y0=y0,yrange=yrange), 'fired':fired, 'n':len(diffs),
            'mean_abs':sum(absd)/len(absd) if absd else 0, 'median_abs':statistics.median(absd) if absd else 0,
            'max_abs':max(absd) if absd else 0, 'zero':sum(1 for x in absd if x==0), 'pos':sum(1 for x in diffs if x>0), 'neg':sum(1 for x in diffs if x<0), 'diffs':diffs, 'details':details}

if __name__=='__main__':
    configs=[
        ('placebo',6,20,30),
        ('birth_placebo',6,20,30),
        ('placebo',10,20,30),
        ('birth_placebo',10,20,30),
        ('placebo',6,1,79),
    ]
    outs=[]
    for c in configs:
        out=experiment(*c)
        outs.append(out)
        print(out['params'], 'fired', out['fired'], 'mean_abs', round(out['mean_abs'],3), 'median_abs', out['median_abs'], 'max_abs', out['max_abs'], 'zero', out['zero'], 'pos/neg', out['pos'], out['neg'])
    open('/mnt/data/r4_birth_flip_results.json','w').write(json.dumps(outs,indent=2))
