import importlib.util, statistics, json, sys
from pathlib import Path


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def run_one(mod, seed, *, state_isolation=False, flip_year=3):
    # base and intervention must both use same model class/options except the forced birth intervention
    kwargs = {"nudge_scale": 0.0}
    if state_isolation:
        kwargs["state_isolation"] = True
    base = mod.CausalSociety(seed, **({"nudge_scale": 0.0} if not state_isolation else {"nudge_scale": 0.0, "state_isolation": True}))
    inte = mod.CausalSociety(seed, **kwargs)
    state = {"key": None, "calls": 0}
    for y in range(1, 81):
        if y == flip_year:
            orig_u = inte.h.u
            def hacked_u(*key):
                # Force exactly the first birth RNG call in this year to produce a birth.
                # This matches the previous R4 birth-force protocol.
                if state["key"] is None and len(key) >= 2 and key[0] == y and key[1] == "birth":
                    state["key"] = key
                    state["calls"] += 1
                    return 0.0
                return orig_u(*key)
            inte.h.u = hacked_u
            base.step(); inte.step()
            inte.h.u = orig_u
        else:
            base.step(); inte.step()
    return {
        "seed": seed,
        "abs_pop_diff": abs(base.population - inte.population),
        "signed_pop_diff": inte.population - base.population,
        "forced_key": state["key"],
        "forced_calls": state["calls"],
        "base_pop": base.population,
        "inte_pop": inte.population,
        "base_births": base.count("birth"),
        "inte_births": inte.count("birth"),
        "inte_isolated_births": inte.count("birth_isolated") if hasattr(inte, "count") else None,
    }


def summarize(rows):
    diffs = [r["abs_pop_diff"] for r in rows]
    return {
        "mean_abs_pop_diff": statistics.mean(diffs),
        "median_abs_pop_diff": statistics.median(diffs),
        "max_abs_pop_diff": max(diffs),
        "zero_count": sum(d == 0 for d in diffs),
        "flip_applied_count": sum(r["forced_key"] is not None for r in rows),
        "flip_skipped_count": sum(r["forced_key"] is None for r in rows),
        "raw_diffs": diffs,
        "rows": rows,
    }


def run_condition(mod_path, name, *, state_isolation=False):
    mod = load(mod_path, name)
    rows = [run_one(mod, seed, state_isolation=state_isolation) for seed in range(1000, 1100)]
    return summarize(rows)

if __name__ == "__main__":
    res = {
        "v20_original_birth_force": run_condition('/mnt/data/causal_society_v2(1).py', 'v20_orig', state_isolation=False),
        "v21_childid_birth_force": run_condition('/mnt/data/causal_society_v2_1.py', 'v21_child', state_isolation=False),
        "v21_state_isolation_birth_force": run_condition('/mnt/data/causal_society_v2_1_stateiso.py', 'v21_iso', state_isolation=True),
    }
    Path('/mnt/data/r4_state_isolation_compare_results.json').write_text(json.dumps(res, indent=2, default=str))
    compact = {k: {kk: vv for kk, vv in v.items() if kk not in ('rows','raw_diffs')} for k, v in res.items()}
    print(json.dumps(compact, indent=2))
