"""
plots.py — 検証結果の可視化 (results/plots/ に PNG を保存)
"""

from __future__ import annotations

from typing import Dict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from validation import ResultPaths


def plot_null_controls(res: Dict, paths: ResultPaths) -> None:
    worlds = list(res.keys())
    fig, axes = plt.subplots(1, len(worlds), figsize=(5 * len(worlds), 4))
    if len(worlds) == 1:
        axes = [axes]
    for ax, w in zip(axes, worlds):
        d = res[w]
        ax.hist(d["null_distribution"], bins=15, color="#9bb7d4",
                edgecolor="white", label="null (shuffled labels)")
        ax.axvline(d["real_auc"]["mean_auc"], color="#d44", lw=2,
                   label=f"real AUC = {d['real_auc']['mean_auc']:.3f}")
        ax.axvline(d["null_p975"], color="#555", ls="--", lw=1,
                   label=f"null 97.5% = {d['null_p975']:.3f}")
        ax.set_title(f"{w}  (p_emp={d['empirical_p_value']:.3f})")
        ax.set_xlabel("AUC")
        ax.legend(fontsize=8)
    fig.suptitle("Shuffled-label control: real AUC vs null distribution")
    fig.tight_layout()
    fig.savefig(paths.plots / "null_controls.png", dpi=140)
    plt.close(fig)


def plot_lofo(res: Dict, paths: ResultPaths) -> None:
    for w, d in res.items():
        names = list(d["leave_one_out"].keys())
        deltas = [d["leave_one_out"][n]["delta_vs_full"] for n in names]
        solos = [d["solo_auc"][n] for n in names]
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        colors = ["#d44" if v < -0.02 else "#9bb7d4" for v in deltas]
        ax1.barh(names, deltas, color=colors)
        ax1.axvline(0, color="#333", lw=0.8)
        ax1.set_title(f"{w}: ΔAUC when feature removed\n"
                      f"(full AUC = {d['full_auc']['mean_auc']:.3f})")
        ax1.set_xlabel("ΔAUC (negative = feature was carrying signal)")
        ax2.barh(names, solos, color="#7aa46a")
        ax2.axvline(0.5, color="#333", lw=0.8, ls="--")
        ax2.set_xlim(0.4, 1.02)
        ax2.set_title(f"{w}: solo-feature AUC")
        ax2.set_xlabel("AUC using only this feature (mean+std)")
        fig.tight_layout()
        fig.savefig(paths.plots / f"lofo_{w}.png", dpi=140)
        plt.close(fig)


def _plot_curve(curve: Dict, xlabel: str, title: str, fname: str,
                paths: ResultPaths, null_hi: float | None = None) -> None:
    xs = sorted(float(k) for k in curve.keys())
    mean = [curve[str(x)]["mean_auc"] for x in xs]
    lo = [curve[str(x)]["ci_low"] for x in xs]
    hi = [curve[str(x)]["ci_high"] for x in xs]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(xs, mean, "o-", color="#d44", label="mean AUC")
    ax.fill_between(xs, lo, hi, color="#d44", alpha=0.18, label="95% interval")
    if null_hi is not None:
        ax.axhline(null_hi, color="#555", ls="--", lw=1,
                   label=f"null CI upper (x=0) = {null_hi:.3f}")
    ax.axhline(0.5, color="#999", ls=":", lw=1)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("AUC")
    ax.set_ylim(0.4, 1.03)
    ax.set_title(title)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(paths.plots / fname, dpi=140)
    plt.close(fig)


def plot_rivalry_sweep(res: Dict, paths: ResultPaths) -> None:
    null_hi = res["curve"]["0.0"]["ci_high"] if "0.0" in res["curve"] else None
    _plot_curve(res["curve"], "asymmetry_strength (competitor abundance)",
                "RivalryCA: AUC vs asymmetry strength",
                "rivalry_sweep.png", paths, null_hi)


def plot_society_sweep(res: Dict, paths: ResultPaths) -> None:
    _plot_curve(res["curve"], "nudge_scale",
                "SocietyLab: AUC vs interpretation nudge scale",
                "society_sweep.png", paths,
                res.get("null_ci_high_at_scale0"))


def plot_multi_seed(res: Dict, paths: ResultPaths) -> None:
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for i, (w, d) in enumerate(res.items()):
        vals = list(d["per_seed_auc"].values())
        ax.scatter([i] * len(vals), vals, color="#9bb7d4", zorder=3)
        ci = d["seed_bootstrap_ci"]
        ax.errorbar([i], [d["mean_over_seeds"]],
                    yerr=[[d["mean_over_seeds"] - ci[0]], [ci[1] - d["mean_over_seeds"]]],
                    fmt="o", color="#d44", capsize=5, zorder=4,
                    label="seed bootstrap CI" if i == 0 else None)
    ax.set_xticks(range(len(res)))
    ax.set_xticklabels(list(res.keys()))
    ax.axhline(0.5, color="#999", ls=":", lw=1)
    ax.set_ylabel("full-window AUC")
    ax.set_title("Multi-seed aggregation (dots = individual base seeds)")
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(paths.plots / "multi_seed.png", dpi=140)
    plt.close(fig)


def plot_oracle(res: Dict, paths: ResultPaths) -> None:
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    keys = ["oracle", "vB"]
    means = [res[f"auc_{k}"]["mean_auc"] for k in keys]
    los = [res[f"auc_{k}"]["ci_low"] for k in keys]
    his = [res[f"auc_{k}"]["ci_high"] for k in keys]
    ax.bar(keys, means, color=["#7aa46a", "#9bb7d4"])
    ax.errorbar(keys, means,
                yerr=[np.subtract(means, los), np.subtract(his, means)],
                fmt="none", ecolor="#333", capsize=6)
    ax.set_ylim(0.4, 1.03)
    ax.set_ylabel("AUC")
    ax.set_title("Searched oracle vs vB policy\n"
                 f"mean angle(oracle, v_B) = "
                 f"{res['mean_angle_oracle_vs_vB_deg']:.2f}°")
    fig.tight_layout()
    fig.savefig(paths.plots / "oracle_comparison.png", dpi=140)
    plt.close(fig)
