import json, statistics, multiprocessing as mp, importlib.util, sys

MOD_PATH='/mnt/data/causal_society_v2_1.py'

def load_base():
    spec=importlib.util.spec_from_file_location('cs_v21_wide_worker', MOD_PATH)
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod); return mod

def pop_stats(vals):
    return {'mean': round(statistics.mean(vals),3) if vals else 0, 'median': statistics.median(vals) if vals else 0, 'max': max(vals) if vals else 0, 'zero_count': sum(1 for v in vals if v==0)}

def stat(vals):
    return {'mean': round(statistics.mean(vals),6) if vals else 0, 'median': round(statistics.median(vals),6) if vals else 0, 'min': round(min(vals),6) if vals else 0, 'max': round(max(vals),6) if vals else 0, 'count': len(vals)}

def worker(args):
    seed, cond, scale = args
    mod=load_base(); Orig=mod.CausalSociety; ACTIONS=mod.ACTIONS; clamp=mod.clamp
    class WideMargin(Orig):
        def __init__(self,*a, action_scale=0.0, **kw):
            super().__init__(*a, **kw)
            self.action_scale=action_scale
            self.margins=[]; self.flip_margins=[]; self.first_flips=[]
        def _support_nudge(self, person, proposer, action):
            return 0.0
        def _wide_base_scores(self, y, pr, fear_avg):
            scores={}
            for act in ACTIONS:
                s=0.10 + 0.05*self.h.u(y,'prop',pr.id,act)
                # original terms
                if act=='store_food' and ('storage_damage' in self.problems or self.count('famine')>self.count('_seen_famine')):
                    s += 0.12
                if act=='dig_well' and 'water_shortage' in self.problems:
                    s += 0.12
                if act=='hold_ritual':
                    s += 0.18*fear_avg
                # strengthened bias terms
                s += 0.12*pr.bias['practical']*(act!='hold_ritual')
                s += 0.12*pr.bias['spiritual']*(act=='hold_ritual')
                # crisis-action strengthened mapping
                if act=='store_food' and ('storage_damage' in self.problems or self.count('famine')>0):
                    s += 0.28
                if act=='dig_well' and 'water_shortage' in self.problems:
                    s += 0.28
                if act=='hold_ritual' and fear_avg > 0.30:
                    s += 0.22
                # proposer preference
                strongest=max(pr.bias, key=pr.bias.get)
                if (strongest=='practical' and act in ('store_food','dig_well')) or (strongest=='spiritual' and act=='hold_ritual'):
                    s += 0.06
                scores[act]=s
            return scores
        def _council(self, y:int)->None:
            ap=self.alive_people
            if not ap: return
            fear_avg=self._avg('fear')
            if not self.problems and fear_avg<0.30: return
            self.rec('council_formed')
            proposers=sorted(ap, key=lambda p:(-p.voice,p.id))[:2]
            used=set()
            for pr in proposers:
                base_scores=self._wide_base_scores(y,pr,fear_avg)
                available=[act for act in ACTIONS if act not in used]
                if not available: continue
                sorted_av=sorted(available, key=lambda act:base_scores[act], reverse=True)
                action_no=sorted_av[0]
                margin=base_scores[sorted_av[0]] - (base_scores[sorted_av[1]] if len(sorted_av)>1 else 0.0)
                scores=base_scores.copy()
                for act in available:
                    nud=self._action_nudge(pr.last_interp, act)*self.action_scale
                    if nud: self.nudge_fired += 1
                    scores[act] += nud
                action=max(available, key=lambda act:scores[act])
                self.margins.append(margin)
                if action != action_no:
                    self.flip_margins.append(margin)
                    if len(self.first_flips)<5:
                        self.first_flips.append({'year':y,'proposer_id':pr.id,'interp':pr.last_interp,'margin':round(margin,6),'action_no_nudge':action_no,'action_with_nudge':action})
                used.add(action); self.rec('proposal_made')
                supporters=[]
                for p in ap:
                    if p is pr: continue
                    chance=(0.16+0.30*self.coop+0.12*p.bias['practical']*(action!='hold_ritual')+0.12*p.bias['spiritual']*(action=='hold_ritual')+0.10*p.fear*(action=='hold_ritual'))
                    hit=self.h.u(y,'support',p.id,pr.id,action)<clamp(chance)
                    self._support_counter += 1
                    if hit:
                        supporters.append(p); self.rec('proposal_supported')
                threshold=max(4,int(self.population*0.22))
                if len(supporters)>=threshold:
                    self.rec('project_started'); self._project(y,pr,action,supporters)
            self.counts['_seen_famine']=self.count('famine')
    class WideMatched(WideMargin):
        def _action_nudge(self, interp, action):
            real=Orig._action_nudge(self, interp, action)
            if real==0: return 0.0
            # random sign per micro gate, same magnitude as real nudge (not meaning aligned)
            sign=1.0 if self.h.u(self.year,'wide_matched_sign',interp,action)<0.5 else -1.0
            return sign*0.03
    Cls = WideMargin if cond=='real' else WideMatched
    base=WideMargin(seed,nudge_scale=0.0, action_scale=0.0)
    inte=Cls(seed,nudge_scale=0.0, action_scale=scale)
    for _ in range(80):
        base.step(); inte.step()
    bm, im = base.metrics(), inte.metrics()
    return {
        'seed': seed,
        'abs_pop_diff': abs(im['pop']-bm['pop']), 'pop_diff': im['pop']-bm['pop'],
        'num_proposals': len(inte.margins), 'num_action_flips': len(inte.flip_margins), 'action_changed': bool(inte.flip_margins),
        'margins': inte.margins, 'flipped_margins': inte.flip_margins,
        'base_project_started': bm['started'], 'base_project_success': bm['success'],
        'inte_project_started': im['started'], 'inte_project_success': im['success'],
        'project_started_diff': im['started']-bm['started'], 'project_success_diff': im['success']-bm['success'],
        'granary_diff': im['granary']-bm['granary'], 'well_diff': im['well']-bm['well'], 'food_diff': round(im['food']-bm['food'],4),
        'death_diff': im['death']-bm['death'], 'birth_diff': im['birth']-bm['birth'],
        'base_final': bm, 'inte_final': im, 'first_flips': inte.first_flips
    }

def summarize(rows, threshold):
    all_m=[m for r in rows for m in r['margins']]
    flip_m=[m for r in rows for m in r['flipped_margins']]
    changed=[r for r in rows if r['action_changed']]
    def avg(field, rs=None):
        rs=changed if rs is None else rs
        return round(statistics.mean([r[field] for r in rs]),3) if rs else 0
    return {
        'total_seeds':len(rows), 'seeds_with_action_changed':len(changed), 'action_changed_rate':round(len(changed)/len(rows),3),
        'total_action_flips':sum(r['num_action_flips'] for r in rows), 'total_proposals':sum(r['num_proposals'] for r in rows),
        'flip_per_proposal_rate': round(sum(r['num_action_flips'] for r in rows)/max(1,sum(r['num_proposals'] for r in rows)),3),
        'margin_stats': stat(all_m), 'flipped_margin_stats': stat(flip_m),
        'margin_below_0.03_ratio': round(sum(1 for m in all_m if m<0.03)/len(all_m),3) if all_m else 0,
        'margin_below_effective_nudge_ratio': round(sum(1 for m in all_m if m<threshold)/len(all_m),3) if all_m else 0,
        'pop_diff_all': pop_stats([r['abs_pop_diff'] for r in rows]),
        'pop_diff_action_changed_only': pop_stats([r['abs_pop_diff'] for r in changed]),
        'base_project_started_avg': round(statistics.mean([r['base_project_started'] for r in rows]),3),
        'base_project_success_avg': round(statistics.mean([r['base_project_success'] for r in rows]),3),
        'inte_project_started_avg': round(statistics.mean([r['inte_project_started'] for r in rows]),3),
        'inte_project_success_avg': round(statistics.mean([r['inte_project_success'] for r in rows]),3),
        'downstream_diffs_action_changed': {
            'project_started_diff': avg('project_started_diff'), 'project_success_diff': avg('project_success_diff'),
            'granary_diff': avg('granary_diff'), 'well_diff': avg('well_diff'), 'food_diff': avg('food_diff'),
            'death_diff': avg('death_diff'), 'birth_diff': avg('birth_diff')},
        'examples': [r['first_flips'][0] for r in changed[:5] if r['first_flips']]
    }

def main():
    seeds=list(range(1000,1110)); scales=[1.0,0.5,0.25]
    tasks=[]
    for cond in ['real','matched']:
        for scale in scales:
            for seed in seeds: tasks.append((seed,cond,scale))
    with mp.Pool(processes=8) as pool:
        results=pool.map(worker,tasks)
    out={}; i=0
    for cond_name in ['real_wide_action_only','matched_wide_action_placebo']:
        out[cond_name]={}
        for scale in scales:
            rows=results[i:i+len(seeds)]; i+=len(seeds)
            out[cond_name][str(scale)]=summarize(rows,0.03*scale)
            s=out[cond_name][str(scale)]
            print(cond_name, 'scale', scale, 'changed', s['action_changed_rate'], 'flips', s['total_action_flips'], 'pop', s['pop_diff_all']['mean'], 'base_started', s['base_project_started_avg'])
    with open('/mnt/data/wide_margin_results.json','w') as f: json.dump(out,f,indent=2,ensure_ascii=False)

if __name__=='__main__': main()
