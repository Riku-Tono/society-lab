"""
v2_experiments.py — CausalSociety v2 の検証
============================================

v1.4で潰した地雷をv2が踏んでいないか、同じ計器で測り直す。

E0: 健全性 — baseline人口が崩壊も爆発もしないか
E1: 100seed ON/OFF — 分岐率・効果量・侵入チャネル
    (比較対象: v1.4結合 38%/平均2.95/最大14, v1.4分離 25%/平均0.52/最大2)
E2: プラセボ — 「支持判定を1個だけ反転」(内容を持たない同位置摂動)
    ハッシュ乱数なので簿記経路は存在せず、これは純粋な
    「同じ侵入口から入る無意味摂動」との効果比較になる
E3: 因果階段 — 効果最大seedのチャネル別初差分年
E4: bridge AUC — 3%ナッジは観測量から検出可能になったか (会話の最初の問い)
"""

from __future__ import annotations

import json
import sys
import time

import numpy as np

sys.path.insert(0, ".")
from causal_society_v2 import CausalSociety
from bridge import bootstrap_auc, featurize
from moat_stage2d import Stage2dCfg, mean_auc, split_eval

CHANNELS = ("supported", "started", "success", "failure", "food", "pop",
            "death", "birth", "memory_shared", "crisis", "granary", "well", "coop")
HARD = tuple(c for c in CHANNELS if c != "supported")
T = 80


def run(seed: int, scale: float, flip=None):
    soc = CausalSociety(seed, nudge_scale=scale)
    if flip is not None:
        soc.support_flip = flip
    rows = []
    for _ in range(T):
        if soc.population > 0:
            soc.step()
        rows.append(soc.metrics())
    return rows, soc.summary()


def first_diffs(r1, r0):
    return {c: next((i + 1 for i in range(T) if r1[i][c] != r0[i][c]), None)
            for c in CHANNELS}


def classify(fd):
    if any(fd[c] is not None for c in HARD):
        return "diverged"
    return "support_only" if fd["supported"] is not None else "identical"


def main():
    t0 = time.time()
    out = {}

    # ---- E0 健全性 ----
    pops = []
    for s in range(2000, 2020):
        _, sm = run(s, 1.0)
        pops.append(sm["final_population"])
    print(f"E0 健全性: baseline最終人口 min={min(pops)} median={sorted(pops)[10]} "
          f"max={max(pops)} (初期24-40)")
    out["e0_final_pops"] = pops

    # ---- E1 100seed ON/OFF ----
    cache0 = {}
    det, cats = [], {"diverged": 0, "support_only": 0, "identical": 0}
    for seed in range(1000, 1100):
        r1, s1 = run(seed, 1.0)
        r0, s0 = run(seed, 0.0)
        cache0[seed] = (r0, s0)
        fd = first_diffs(r1, r0)
        cat = classify(fd)
        cats[cat] += 1
        if cat == "diverged":
            det.append({
                "seed": seed,
                "pop_diff": s1["final_population"] - s0["final_population"],
                "infra_diff": (s1["granary"] + s1["well"]) - (s0["granary"] + s0["well"]),
                "first_diff": fd,
            })
    pds = [abs(d["pop_diff"]) for d in det]
    infra = [abs(d["infra_diff"]) for d in det]
    sup_first = sum(1 for d in det
                    if d["first_diff"]["supported"] is not None
                    and d["first_diff"]["supported"]
                    == min(v for v in d["first_diff"].values() if v is not None))
    print(f"\nE1: diverged={cats['diverged']} support_only={cats['support_only']} "
          f"identical={cats['identical']}")
    if pds:
        print(f"    |人口差|: 平均={sum(pds)/len(pds):.2f} 最大={max(pds)}"
              f"   |インフラ差|: 平均={sum(infra)/len(infra):.2f} 最大={max(infra)}")
        print(f"    支持(supported)が最初のチャネル: {sup_first}/{len(det)}")
        signed = [d["pop_diff"] for d in det]
        print(f"    人口差の符号: +{sum(1 for v in signed if v>0)} "
              f"/ -{sum(1 for v in signed if v<0)} / 0:{sum(1 for v in signed if v==0)}")
    out["e1"] = {"cats": cats, "details": det}

    # ---- E2 プラセボ (支持判定1個フリップ) ----
    n_div, n_fired, p_pds = 0, 0, []
    for seed in range(1000, 1100):
        r0, s0 = cache0[seed]
        probe = CausalSociety(seed)
        fy = 20 + int(probe.h.u("placebo", "year") * 30)
        fk = 1 + int(probe.h.u("placebo", "k") * 6)   # 年内の早い判定を狙う
        soc = CausalSociety(seed, nudge_scale=0.0)
        soc.support_flip = (fy, fk)
        rows = []
        for _ in range(T):
            if soc.population > 0:
                soc.step()
            rows.append(soc.metrics())
        if not soc.flip_fired:
            continue
        n_fired += 1
        fd = first_diffs(rows, r0)
        if classify(fd) == "diverged":
            n_div += 1
            p_pds.append(abs(soc.summary()["final_population"] - s0["final_population"]))
    mean_pd = sum(p_pds) / len(p_pds) if p_pds else 0.0
    print(f"\nE2 プラセボ(支持1個反転): 発火={n_fired}/100  diverged={n_div}/{n_fired} "
          f"|人口差| 平均={mean_pd:.2f} 最大={max(p_pds) if p_pds else 0}")
    out["e2"] = {"fired": n_fired, "diverged": n_div, "abs_pop_diffs": p_pds}

    # ---- E3 因果階段 (効果最大seed) ----
    print("\nE3 因果階段 (効果量上位3seed):")
    for d in sorted(det, key=lambda x: -abs(x["pop_diff"]))[:3]:
        ladder = sorted((y, c) for c, y in d["first_diff"].items() if y is not None)
        print(f"  seed{d['seed']}: pop_diff={d['pop_diff']:+d} infra_diff={d['infra_diff']:+d}")
        print("    " + " → ".join(f"Y{y}:{c}" for y, c in ladder[:9]))
    out["e3_top"] = sorted(det, key=lambda x: -abs(x["pop_diff"]))[:3]

    # ---- E4 bridge AUC: ナッジは検出可能になったか ----
    def feats(rows):
        prev = {c: 0 for c in ("supported", "success", "failure", "death", "birth")}
        X = []
        for r in rows:
            row = [r["pop"] / 40.0, r["food"] / 120.0, r["coop"],
                   r["granary"] / 5.0, r["well"] / 5.0]
            for c in prev:
                row.append(r[c] - prev[c])
                prev[c] = r[c]
            X.append(row)
        return np.array(X)

    eps_B = [feats(run(1000 + i, 1.0)[0]) for i in range(40)]
    eps_Q = [feats(cache0[1000 + i][0]) for i in range(40)]
    XB = featurize(eps_B, 0, T, raw=False)
    XQ = featurize(eps_Q, 0, T, raw=False)
    rng = np.random.default_rng(7)
    clf = Stage2dCfg(train_steps=120, rff_dim=80)
    real = bootstrap_auc(XB, XQ, rng, clf, 20)
    X = np.r_[XB, XQ]
    null_vals = []
    for _ in range(20):
        perm = rng.permutation(len(X))
        null_vals.append(mean_auc(split_eval(X[perm][:40], X[perm][40:], rng, clf)))
    null975 = float(np.percentile(null_vals, 97.5))
    print(f"\nE4 bridge AUC: real={real['mean_auc']:.3f} "
          f"[{real['ci_low']:.3f}, {real['ci_high']:.3f}]  "
          f"null97.5%={null975:.3f}  "
          f"検出可能={'YES' if real['mean_auc'] > null975 else 'no'}")
    print(f"    (v1.4では real 0.822 vs null97.5% 0.826 で検出不能だった)")
    out["e4"] = {"real": real, "null_p975": null975,
                 "detectable": bool(real["mean_auc"] > null975)}

    json.dump(out, open("v2_results.json", "w"), indent=2, ensure_ascii=False)
    print(f"\n{time.time()-t0:.0f}s — wrote v2_results.json")


if __name__ == "__main__":
    main()
