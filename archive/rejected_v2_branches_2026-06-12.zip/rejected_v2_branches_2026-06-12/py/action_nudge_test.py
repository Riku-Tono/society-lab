import importlib.util, json, statistics, sys
from typing import Dict, List

MOD_PATH = '/mnt/data/causal_society_v2_1.py'
spec = importlib.util.spec_from_file_location('cs_v21_action', MOD_PATH)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)
Base = mod.CausalSociety

class ActionOnlyReal(Base):
    """Only proposer/action-choice nudges are active; support nudges disabled."""
    def _support_nudge(self, person, proposer, action: str) -> float:
        return 0.0

class ActionMatchedPlacebo(ActionOnlyReal):
    """Same action-nudge gates as the real model, but sign is randomized."""
    def _action_nudge(self, interp: str, action: str) -> float:
        real = Base._action_nudge(self, interp, action)
        if real == 0.0:
            return 0.0
        sign = 1.0 if self.h.u(self.year, 'matched_action_placebo_sign', interp, action) < 0.5 else -1.0
        return sign * 0.03

class ActionZeroPlacebo(ActionOnlyReal):
    """Sanity check: disables action nudges too, so should match baseline exactly."""
    def _action_nudge(self, interp: str, action: str) -> float:
        return 0.0

def run_pair(seed: int, cls, years: int = 80) -> Dict:
    base = Base(seed, nudge_scale=0.0)
    inte = cls(seed, nudge_scale=1.0)
    for _ in range(years):
        base.step()
        inte.step()
    bm, im = base.metrics(), inte.metrics()
    return {
        'seed': seed,
        'pop_diff': im['pop'] - bm['pop'],
        'abs_pop_diff': abs(im['pop'] - bm['pop']),
        'granary_diff': im['granary'] - bm['granary'],
        'well_diff': im['well'] - bm['well'],
        'coop_diff': round(im['coop'] - bm['coop'], 5),
        'supported_diff': im['supported'] - bm['supported'],
        'started_diff': im['started'] - bm['started'],
        'success_diff': im['success'] - bm['success'],
        'nudge_fired': inte.nudge_fired,
    }

def summarize(rows: List[Dict]) -> Dict:
    absd = [r['abs_pop_diff'] for r in rows]
    signed = [r['pop_diff'] for r in rows]
    return {
        'mean_abs_pop_diff': round(statistics.mean(absd), 3),
        'median_abs_pop_diff': statistics.median(absd),
        'max_abs_pop_diff': max(absd),
        'zero_count': sum(1 for x in absd if x == 0),
        'positive_count': sum(1 for x in signed if x > 0),
        'negative_count': sum(1 for x in signed if x < 0),
        'mean_supported_diff': round(statistics.mean([r['supported_diff'] for r in rows]), 3),
        'mean_started_diff': round(statistics.mean([r['started_diff'] for r in rows]), 3),
        'mean_success_diff': round(statistics.mean([r['success_diff'] for r in rows]), 3),
        'mean_granary_diff': round(statistics.mean([r['granary_diff'] for r in rows]), 3),
        'mean_well_diff': round(statistics.mean([r['well_diff'] for r in rows]), 3),
        'mean_coop_diff': round(statistics.mean([r['coop_diff'] for r in rows]), 5),
        'mean_nudge_fired': round(statistics.mean([r['nudge_fired'] for r in rows]), 3),
        'raw_abs_pop_diffs': absd,
        'rows': rows,
    }

def main():
    seeds = list(range(1000, 1100))
    conditions = {
        'real_action_only_vs_baseline': ActionOnlyReal,
        'matched_action_placebo_vs_baseline': ActionMatchedPlacebo,
        'zero_action_sanity_vs_baseline': ActionZeroPlacebo,
        'real_full_nudge_vs_baseline': Base,
    }
    out = {}
    for name, cls in conditions.items():
        rows = [run_pair(s, cls) for s in seeds]
        out[name] = summarize(rows)
        print(name, out[name]['mean_abs_pop_diff'], out[name]['median_abs_pop_diff'], out[name]['zero_count'])
    with open('/mnt/data/action_nudge_results.json', 'w') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

if __name__ == '__main__':
    main()
