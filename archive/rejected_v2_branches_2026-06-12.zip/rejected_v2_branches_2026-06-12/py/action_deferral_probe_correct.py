import json, statistics, importlib.util, sys
from typing import List
MOD_PATH='/mnt/data/causal_society_v2_1.py'

def load_base():
    spec=importlib.util.spec_from_file_location('cs_v21_defprobe',MOD_PATH)
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod); return mod
mod=load_base(); Base=mod.CausalSociety; ACTIONS=mod.ACTIONS; clamp=mod.clamp
class DeferSoc(Base):
    def __init__(self,*a,action_scale=0.0,defer_margin=0.0,matched=False,**kw):
        super().__init__(*a,**kw); self.action_scale=action_scale; self.defer_margin=defer_margin; self.matched=matched; self.margins=[]; self.flip_margins=[]; self.deferred_count=0
    def _support_nudge(self,person,proposer,action): return 0.0
    def _action_nudge_eff(self, interp, action):
        real=Base._action_nudge(self,interp,action)
        if not self.matched: return real
        if real==0.0: return 0.0
        sign=1.0 if self.h.u(self.year,'matched_action_placebo_sign',interp,action)<0.5 else -1.0
        return sign*0.03
    def _council(self,y):
        ap=self.alive_people
        if not ap: return
        fear_avg=self._avg('fear')
        if not self.problems and fear_avg<0.30: return
        self.rec('council_formed')
        proposers=sorted(ap,key=lambda p:(-p.voice,p.id))[:2]; used=set()
        for pr in proposers:
            base_scores={}
            for act in ACTIONS:
                s=0.10+0.05*self.h.u(y,'prop',pr.id,act)
                if act=='store_food' and ('storage_damage' in self.problems or self.count('famine')>self.count('_seen_famine')): s+=0.12
                if act=='dig_well' and 'water_shortage' in self.problems: s+=0.12
                if act=='hold_ritual': s+=0.18*fear_avg
                s+=0.10*pr.bias['practical']*(act!='hold_ritual')
                s+=0.10*pr.bias['spiritual']*(act=='hold_ritual')
                base_scores[act]=s
            available=[act for act in ACTIONS if act not in used]
            if not available: continue
            sorted_avail=sorted(available,key=lambda act:base_scores[act],reverse=True)
            action_no=sorted_avail[0]
            margin=base_scores[sorted_avail[0]]-(base_scores[sorted_avail[1]] if len(sorted_avail)>1 else 0.0)
            self.margins.append(margin)
            if margin < self.defer_margin:
                self.deferred_count+=1; continue
            scores=base_scores.copy()
            for act in available:
                nud=self._action_nudge_eff(pr.last_interp,act)*self.action_scale
                if nud: self.nudge_fired+=1
                scores[act]+=nud
            action=max(available,key=lambda act:scores[act])
            if action_no != action: self.flip_margins.append(margin)
            used.add(action); self.rec('proposal_made')
            supporters=[]
            for p in ap:
                if p is pr: continue
                chance=(0.16+0.30*self.coop+0.12*p.bias['practical']*(action!='hold_ritual')+0.12*p.bias['spiritual']*(action=='hold_ritual')+0.10*p.fear*(action=='hold_ritual'))
                hit=self.h.u(y,'support',p.id,pr.id,action)<clamp(chance)
                self._support_counter+=1
                if hit: supporters.append(p); self.rec('proposal_supported')
            threshold=max(4,int(self.population*0.22))
            if len(supporters)>=threshold:
                self.rec('project_started'); self._project(y,pr,action,supporters)
        self.counts['_seen_famine']=self.count('famine')

def run(seed, scale, defer, matched=False):
    base=DeferSoc(seed,nudge_scale=0.0,action_scale=0.0,defer_margin=defer,matched=False)
    inte=DeferSoc(seed,nudge_scale=0.0,action_scale=scale,defer_margin=defer,matched=matched)
    for _ in range(80): base.step(); inte.step()
    bm,im=base.metrics(),inte.metrics()
    return {'abs_pop_diff':abs(im['pop']-bm['pop']),'flips':len(inte.flip_margins),'changed':bool(inte.flip_margins),'deferred':inte.deferred_count,'seen':len(inte.margins),'started_diff':im['started']-bm['started'],'success_diff':im['success']-bm['success'],'well_diff':im['well']-bm['well'],'granary_diff':im['granary']-bm['granary'],'base_started':bm['started'],'base_success':bm['success']}

def summarize(rows):
    changed=[r for r in rows if r['changed']]
    def mean(xs): return round(statistics.mean(xs),3) if xs else 0
    return {'n':len(rows),'changed_rate':round(len(changed)/len(rows),3),'flips':sum(r['flips'] for r in rows),'pop_mean':mean([r['abs_pop_diff'] for r in rows]),'pop_median':statistics.median([r['abs_pop_diff'] for r in rows]),'zero_count':sum(1 for r in rows if r['abs_pop_diff']==0),'defer_rate':round(sum(r['deferred'] for r in rows)/max(1,sum(r['seen'] for r in rows)),3),'base_started_avg':mean([r['base_started'] for r in rows]),'base_success_avg':mean([r['base_success'] for r in rows]),'started_diff_changed':mean([r['started_diff'] for r in changed]),'success_diff_changed':mean([r['success_diff'] for r in changed]),'well_diff_changed':mean([r['well_diff'] for r in changed]),'granary_diff_changed':mean([r['granary_diff'] for r in changed])}

if __name__=='__main__':
    seeds=list(range(1000,1100)); out={}
    for defer in [0.03,0.05,0.06,0.08]:
      out[str(defer)]={}
      for scale in [1.0,0.5,0.25]:
        for label,matched in [('real',False),('matched',True)]:
          rows=[run(s,scale,defer,matched) for s in seeds]
          out[str(defer)][f'{label}_{scale}']=summarize(rows)
          print('defer',defer,'scale',scale,label,out[str(defer)][f'{label}_{scale}'])
    open('/mnt/data/action_deferral_probe_correct_results.json','w').write(json.dumps(out,indent=2,ensure_ascii=False))
