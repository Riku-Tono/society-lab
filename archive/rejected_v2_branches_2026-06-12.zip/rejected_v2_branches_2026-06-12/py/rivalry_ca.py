"""
rivalry_ca_fixed.py
===================

Standalone RivalryCA prototype.

This file keeps the cellular automaton independent from SocietyLab. It emits
only observable field metrics:

- rivalry_rate
- pressure_entropy
- pair_rate
- avg_pressure
- peace_rate
- collapse_risk

Key fixes from the integrated draft:

- Birth from dead cells is handled explicitly.
- global_pressure is recomputed from the finished next grid.
- witnessed pair detection requires a mutual pair, not one-way liking.
- rivalry is measured as competition for the same liked kind, not as a
  personal jealousy variable.
"""

from __future__ import annotations

import random
from collections import Counter
from dataclasses import dataclass
from math import log2


KINDS = ("A", "B", "C", "D")

# Asymmetric enough to create competition, while still allowing mutual pairs.
LIKES = {"A": "B", "B": "A", "C": "A", "D": "B"}


@dataclass
class CACell:
    alive: bool = False
    kind: str = "A"
    pressure: float = 0.0
    age: int = 0


class RivalryCA:
    """Relationship-pressure cellular automaton.

    Pressure is a local field value computed from observable neighborhood
    structure. It is not an agent psychology variable.
    """

    def __init__(self, width: int = 48, height: int = 24, seed: int = 42):
        self.w = width
        self.h = height
        self.rng = random.Random(seed)
        self.gen = 0
        self.global_pressure = 0.0
        self.kind_mutation_rate = 0.015
        self.rare_birth_bias = 0.18
        self.grid = [[CACell() for _ in range(width)] for _ in range(height)]

    def randomize(self, density: float = 0.30, base_pressure: float = 0.05) -> None:
        for row in self.grid:
            for cell in row:
                cell.alive = self.rng.random() < density
                cell.kind = self.rng.choice(KINDS)
                cell.pressure = (
                    base_pressure + self.rng.random() * 0.15 if cell.alive else 0.0
                )
                cell.age = 0
        self._recompute_global_pressure()

    def _neighbor_coords(self, x: int, y: int) -> list[tuple[int, int]]:
        return [
            ((x + dx) % self.w, (y + dy) % self.h)
            for dy in (-1, 0, 1)
            for dx in (-1, 0, 1)
            if not (dx == 0 and dy == 0)
        ]

    def _alive_neighbors(self, x: int, y: int) -> list[CACell]:
        return [
            self.grid[ny][nx]
            for nx, ny in self._neighbor_coords(x, y)
            if self.grid[ny][nx].alive
        ]

    @staticmethod
    def _mutual(a: CACell, b: CACell) -> bool:
        return LIKES[a.kind] == b.kind and LIKES[b.kind] == a.kind

    def _relation(self, cell: CACell, ns: list[CACell]) -> dict[str, float | bool | int]:
        crush = LIKES[cell.kind]
        liked = [n for n in ns if n.kind == crush]
        mutual = any(self._mutual(cell, n) for n in liked)

        # A witnessed pair is a mutual pair among neighbors, excluding the cell.
        witnessed_pair = any(
            self._mutual(a, b)
            for i, a in enumerate(ns)
            for b in ns[i + 1 :]
        )

        # Competition means another nearby kind points toward the same target
        # kind as this cell. This is intentionally narrower than "any repeated
        # target in the neighborhood" so the field does not saturate.
        competitors = [
            n for n in ns
            if LIKES[n.kind] == crush and n.kind != cell.kind
        ]
        competition = len(competitors) > 0

        return {
            "liked_count": len(liked),
            "mutual": mutual,
            "witnessed_pair": witnessed_pair,
            "competition": competition,
            "competitor_count": len(competitors),
        }

    def _local_pressure(self, cell: CACell, ns: list[CACell]) -> float:
        n = len(ns)
        rel = self._relation(cell, ns)

        if rel["mutual"] and rel["competition"]:
            return 0.18
        if rel["mutual"]:
            return 0.04
        if rel["liked_count"] and rel["competition"]:
            return min(0.78, 0.50 + 0.10 * int(rel["competitor_count"]))
        if rel["competition"]:
            return 0.48
        if rel["witnessed_pair"]:
            return 0.32
        if n > 3:
            return min(0.75, 0.18 * (n - 3))
        return 0.05

    def _birth_kind(self, ns: list[CACell]) -> str:
        if self.rng.random() < self.rare_birth_bias:
            counts = self.kind_counts()
            weights = [1.0 / (1.0 + counts[k]) for k in KINDS]
            return self.rng.choices(KINDS, weights=weights)[0]

        kinds = Counter(n.kind for n in ns)
        if not kinds:
            return self.rng.choice(KINDS)
        top_count = kinds.most_common(1)[0][1]
        tied = [kind for kind, count in kinds.items() if count == top_count]
        return self.rng.choice(tied)

    def _maybe_mutate_kind(self, kind: str) -> str:
        if self.rng.random() < self.kind_mutation_rate:
            choices = [k for k in KINDS if k != kind]
            return self.rng.choice(choices)
        return kind

    def _birth_pressure(self, ns: list[CACell]) -> float:
        if not ns:
            return self.global_pressure * 0.30
        inherited = sum(n.pressure for n in ns) / len(ns)
        kind_pressure = 0.08 if len({n.kind for n in ns}) > 1 else 0.03
        return min(1.0, inherited * 0.55 + kind_pressure)

    def step(self) -> None:
        self.gen += 1
        next_grid = [[CACell() for _ in range(self.w)] for _ in range(self.h)]

        for y in range(self.h):
            for x in range(self.w):
                cell = self.grid[y][x]
                ns = self._alive_neighbors(x, y)
                n = len(ns)

                if cell.alive:
                    local_r = self._local_pressure(cell, ns)
                    new_p = min(
                        1.0,
                        cell.pressure * 0.70
                        + local_r * 0.25
                        + self.global_pressure * 0.05,
                    )
                    rel = self._relation(cell, ns)

                    if new_p > 0.88 and self.rng.random() < 0.18:
                        self._burst_into(next_grid, x, y, new_p)
                        continue

                    if rel["mutual"]:
                        survives = 1 <= n <= 5
                    elif new_p > 0.62:
                        survives = n in (2, 3) and self.rng.random() < 0.80
                    else:
                        survives = n in (2, 3)

                    if survives:
                        next_grid[y][x] = CACell(
                            True,
                            self._maybe_mutate_kind(cell.kind),
                            new_p,
                            cell.age + 1,
                        )

                else:
                    # Proper B3 birth from dead cells.
                    if n == 3:
                        next_grid[y][x] = CACell(
                            True,
                            self._birth_kind(ns),
                            self._birth_pressure(ns),
                            0,
                        )

        self.grid = next_grid
        self._recompute_global_pressure()

    def _burst_into(
        self,
        next_grid: list[list[CACell]],
        x: int,
        y: int,
        pressure: float,
    ) -> None:
        for nx, ny in self._neighbor_coords(x, y):
            if self.rng.random() >= 0.42:
                continue
            current = next_grid[ny][nx]
            if current.alive and current.pressure > pressure:
                continue
            next_grid[ny][nx] = CACell(
                True,
                self.rng.choice(KINDS),
                min(1.0, pressure * 0.60 + 0.20),
                0,
            )

    def _recompute_global_pressure(self) -> None:
        alive = [c for row in self.grid for c in row if c.alive]
        self.global_pressure = (
            sum(c.pressure for c in alive) / len(alive) if alive else 0.0
        )

    def population(self) -> int:
        return sum(1 for row in self.grid for c in row if c.alive)

    def kind_counts(self) -> dict[str, int]:
        counts = {kind: 0 for kind in KINDS}
        for row in self.grid:
            for cell in row:
                if cell.alive:
                    counts[cell.kind] += 1
        return counts

    def metrics(self) -> dict[str, float | int]:
        alive = [
            (x, y, self.grid[y][x])
            for y in range(self.h)
            for x in range(self.w)
            if self.grid[y][x].alive
        ]
        pop = len(alive)
        if pop == 0:
            return {
                "generation": self.gen,
                "ca_population": 0,
                "rivalry_rate": 0.0,
                "pair_rate": 0.0,
                "pressure_entropy": 0.0,
                "avg_pressure": 0.0,
                "peace_rate": 0.0,
                "collapse_risk": 0.0,
            }

        pair_count = 0
        rivalry_count = 0
        for x, y, cell in alive:
            ns = self._alive_neighbors(x, y)
            rel = self._relation(cell, ns)
            if rel["mutual"]:
                pair_count += 1
            if rel["competition"]:
                rivalry_count += 1

        buckets = Counter(min(9, int(c.pressure * 10)) for _, _, c in alive)
        total = sum(buckets.values())
        entropy = -sum((v / total) * log2(v / total) for v in buckets.values() if v)
        high_pressure = sum(1 for _, _, c in alive if c.pressure > 0.65)
        peaceful = sum(1 for _, _, c in alive if c.pressure < 0.2)

        return {
            "generation": self.gen,
            "ca_population": pop,
            "rivalry_rate": round(rivalry_count / pop, 3),
            "pair_rate": round(pair_count / pop, 3),
            "pressure_entropy": round(entropy, 3),
            "avg_pressure": round(self.global_pressure, 3),
            "peace_rate": round(peaceful / pop, 3),
            "collapse_risk": round(high_pressure / pop, 3),
            **{f"kind_{k}": v for k, v in self.kind_counts().items()},
        }


def run_ca(seed: int = 42, steps: int = 80, density: float = 0.32) -> list[dict]:
    ca = RivalryCA(width=44, height=22, seed=seed)
    ca.randomize(density=density, base_pressure=0.08)
    history = []
    for _ in range(steps):
        ca.step()
        history.append(ca.metrics())
        if ca.population() == 0:
            break
    return history


def smoke_test(seeds: list[int] | None = None, steps: int = 60) -> None:
    if seeds is None:
        seeds = [42, 123, 777, 2024, 9999]

    print(
        f"{'Seed':>6} | {'Steps':>5} | {'Pop':>5} | "
        f"{'AvgRival':>8} | {'AvgPair':>7} | {'AvgPressure':>11}"
    )
    print("-" * 62)
    for seed in seeds:
        hist = run_ca(seed=seed, steps=steps)
        avg_rival = sum(m["rivalry_rate"] for m in hist) / max(1, len(hist))
        avg_pair = sum(m["pair_rate"] for m in hist) / max(1, len(hist))
        avg_pressure = sum(m["avg_pressure"] for m in hist) / max(1, len(hist))
        pop = hist[-1]["ca_population"] if hist else 0
        print(
            f"{seed:>6} | {len(hist):>5} | {pop:>5} | "
            f"{avg_rival:>8.3f} | {avg_pair:>7.3f} | {avg_pressure:>11.3f}"
        )


if __name__ == "__main__":
    smoke_test()
