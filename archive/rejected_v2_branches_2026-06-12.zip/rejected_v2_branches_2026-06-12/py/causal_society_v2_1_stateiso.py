"""
causal_society_v2.py — SocietyLab v2 (因果経路装置としての再構築)
==================================================================

v1.4 の解剖 (100seedスキャン → 外科的介入 → プラセボ → RNGストリーム分離)
から得た3つの教訓を、そのまま設計仕様に変換したもの。

教訓1: 単一PRNGは簿記アーティファクトを生む (1ドローで100/100分岐)
  → 対策: ハッシュ乱数 (反実仮想結合)。
    全ドローを u = hash(seed, year, person, purpose) で引く。
    「消費順」という概念が存在しないため、介入が他人のサイコロを
    動かすことが構造的に不可能。ON/OFF間の差分は定義上すべて
    モデル状態を経由した因果経路である。

教訓2: 分離後の効果量は≤2人に潰れた。v1.4は全状態が毎年減衰し
  摂動を吸収する自己安定系で、増幅器はカオスだけだった。
  → 対策: 蓄積する遅い変数 (現実対応のある増幅器)。
    - インフラ: 穀倉(granary) は食料容量と腐敗率を恒久的に変え、
      井戸(well) は干ばつ確率と被害を恒久的に下げる。
      プロジェクト1本の成否が軌道を持続的に曲げる。
    - 協力規範(coop): 成功で上昇し支持率と成功率に正帰還、
      失敗とblame解釈で下降する負のスパイラルも持つ。半減期は長い。

教訓3: 「経路が発生したか」は事後解釈ではなくログで示す。
  → 対策: v1.4と同じイベント語彙 (proposal_supported / project_* /
    death / birth / memory_shared / crisis) を維持し、
    支持 → プロジェクト → インフラ/食料 → 飢餓/健康 → 死亡/出生
    の階段をチャネル別初差分年で機械的に抽出できるようにする。

解釈ナッジは v1.4 と同じ意味論 (±0.03 × scale、行動ナッジと支持ナッジ)
を保持する。問いを変えないため。
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Dict, Tuple, Union

ACTIONS = ("store_food", "dig_well", "hold_ritual")
BIASES = ("practical", "spiritual", "blame")


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return lo if x < lo else hi if x > hi else x


class HashRng:
    """反実仮想結合乱数。各マイクロイベントが自分専用のサイコロを持つ。"""

    def __init__(self, seed: int):
        self.seed = seed

    def u(self, *key) -> float:
        s = "|".join(str(k) for k in (self.seed,) + key)
        h = hashlib.blake2b(s.encode(), digest_size=8).digest()
        return int.from_bytes(h, "big") / 2.0 ** 64


@dataclass
class Person:
    id: str
    age: int
    health: float = 0.9
    hunger: float = 0.1
    fear: float = 0.1
    voice: float = 0.05
    alive: bool = True
    bias: dict = field(default_factory=dict)
    last_interp: str = "none"
    memories: list = field(default_factory=list)   # [kind, intensity, interp]
    confidants: list = field(default_factory=list)


class CausalSociety:
    def __init__(self, seed: int, nudge_scale: float = 1.0, state_isolation: bool = False):
        self.h = HashRng(seed)
        self.seed = seed
        self.scale = nudge_scale
        self.state_isolation = state_isolation
        self._isolated_births: list[Person] = []
        self.year = 0
        self.counts: dict[str, int] = {}
        self.nudge_fired = 0

        pop0 = 24 + int(self.h.u("init", "pop") * 17)      # 24..40
        self.pop0 = pop0
        self.people: list[Person] = []
        for i in range(pop0):
            self.people.append(self._make_person(i, age=int(self.h.u("init", "age", i) * 52) + 4))
        # v2.1: no global child counter. Child IDs are stable under counterfactuals.
        self._birth_slots: Dict[Tuple[str, int], int] = {}

        self.food = pop0 * 3.0
        self.granary = 0          # 蓄積インフラ1 (容量・腐敗)
        self.well = 0             # 蓄積インフラ2 (干ばつ耐性)
        self.coop = 0.5           # 協力規範 (遅い変数, 正負の帰還)
        self.problems: list[str] = []
        # プラセボ用フック: (year, k) を指定すると k番目の支持判定を反転する
        self.support_flip: tuple[int, int] | None = None
        self._support_counter = 0
        self.flip_fired = False

    # ------------------------------------------------------------------
    def _make_person(self, idx: Union[int, str], age: int) -> Person:
        # Initial persons preserve the exact v2.0 ID and confidence distribution.
        if isinstance(idx, int):
            pid = f"p{idx:03d}"
            conf_span = max(1, idx + 20)
        else:
            # Child IDs are deterministic content-addressed IDs.  For child
            # confidants, use a fixed pool so their social dice do not depend on
            # a global birth counter.  The parent is prepended at birth below.
            pid = idx
            conf_span = max(1, self.pop0 + 20)
        bias = {b: 0.15 + 0.55 * self.h.u("init", "bias", pid, b) for b in BIASES}
        conf = sorted({f"p{int(self.h.u('init', 'conf', pid, k) * conf_span):03d}"
                       for k in range(3)} - {pid})
        return Person(id=pid, age=age, bias=bias, confidants=conf,
                      voice=0.03 + 0.09 * self.h.u("init", "voice", pid))

    def _get_birth_slot(self, parent_id: str, y: int) -> int:
        # One birth opportunity per parent-year in this model. The explicit slot
        # keeps the key extensible without using a global counter.
        key = (parent_id, y)
        if key not in self._birth_slots:
            self._birth_slots[key] = 0
        return self._birth_slots[key]

    def _make_child_id(self, parent_id: str, y: int, slot: int) -> str:
        s = f"{self.seed}|child|{parent_id}|{y}|{slot}"
        h = hashlib.blake2b(s.encode(), digest_size=8).hexdigest()[:12]
        return f"c_{h}"

    def rec(self, ev: str, n: int = 1) -> None:
        self.counts[ev] = self.counts.get(ev, 0) + n

    def count(self, ev: str) -> int:
        return self.counts.get(ev, 0)

    @property
    def alive_people(self) -> list[Person]:
        return [p for p in self.people if p.alive]

    @property
    def population(self) -> int:
        return len(self.alive_people)

    def _avg(self, attr: str) -> float:
        ap = self.alive_people
        return sum(getattr(p, attr) for p in ap) / len(ap) if ap else 0.0

    # ------------------------------------------------------------------
    def step(self) -> None:
        self.year += 1
        y = self.year
        self._support_counter = 0
        self.problems = []
        self._resource(y)
        self._council(y)
        self._dialogue(y)
        self._demography(y)
        self._decay(y)

    # ---- 資源と危機 ---------------------------------------------------
    def _resource(self, y: int) -> None:
        ap = self.alive_people
        workers = sum(1 for p in ap if 14 <= p.age <= 70)
        factor = 0.85 + 0.30 * self.h.u(y, "harvest")
        drought_p = max(0.03, 0.10 - 0.02 * self.well)
        if self.h.u(y, "drought") < drought_p:
            sev = (0.35 + 0.30 * self.h.u(y, "dsev")) * (0.85 ** self.well)
            factor *= (1.0 - sev)
            self.problems.append("water_shortage")
            self.rec("crisis")
            for p in ap:
                p.fear = clamp(p.fear + 0.10 * sev + 0.04)
        if self.h.u(y, "storage") < 0.06 / (1.0 + 0.6 * self.granary):
            self.problems.append("storage_damage")
            self.food *= 0.82

        harvest = workers * 1.18 * factor
        capacity = self.pop0 * 3.0 + 18.0 * self.granary
        rot = self.food * 0.05 / (1.0 + 0.6 * self.granary)
        self.food = min(capacity, self.food + harvest - rot)

        need = self.population * 1.0
        if self.food >= need:
            self.food -= need
            shortage = 0.0
        else:
            shortage = 1.0 - self.food / max(need, 1e-9)
            self.food = 0.0
        if shortage > 0.12:
            self.rec("famine")
        for p in ap:
            p.hunger = clamp(p.hunger * 0.55 + shortage)
            if shortage > 0.12:
                p.fear = clamp(p.fear + 0.5 * shortage)

    # ---- 評議会: 提案 → 支持 → プロジェクト ---------------------------
    def _action_nudge(self, interp: str, action: str) -> float:
        if interp == "spiritual" and action == "hold_ritual":
            return 0.03
        if interp == "practical" and action in ("store_food", "dig_well"):
            return 0.03
        return 0.0

    def _support_nudge(self, person: Person, proposer: Person, action: str) -> float:
        interp = person.last_interp
        if interp == "none":
            return 0.0
        if interp in ("spiritual", "practical"):
            return self._action_nudge(interp, action)
        if interp == "blame":
            return -0.03 if proposer.voice >= 0.08 else 0.03
        return 0.0

    def _council(self, y: int) -> None:
        ap = self.alive_people
        if not ap:
            return
        fear_avg = self._avg("fear")
        if not self.problems and fear_avg < 0.30:
            return
        self.rec("council_formed")
        proposers = sorted(ap, key=lambda p: (-p.voice, p.id))[:2]
        used: set[str] = set()
        for pr in proposers:
            scores = {}
            for a in ACTIONS:
                s = 0.10 + 0.05 * self.h.u(y, "prop", pr.id, a)
                if a == "store_food" and ("storage_damage" in self.problems
                                          or self.count("famine") > self.count("_seen_famine")):
                    s += 0.12
                if a == "dig_well" and "water_shortage" in self.problems:
                    s += 0.12
                if a == "hold_ritual":
                    s += 0.18 * fear_avg
                s += 0.10 * pr.bias["practical"] * (a != "hold_ritual")
                s += 0.10 * pr.bias["spiritual"] * (a == "hold_ritual")
                nud = self._action_nudge(pr.last_interp, a) * self.scale
                if nud:
                    self.nudge_fired += 1
                s += nud
                scores[a] = s
            action = max((a for a in ACTIONS if a not in used),
                         key=lambda a: scores[a], default=None)
            if action is None:
                continue
            used.add(action)
            self.rec("proposal_made")
            supporters = []
            for p in ap:
                if p is pr:
                    continue
                chance = (0.16 + 0.30 * self.coop
                          + 0.12 * p.bias["practical"] * (action != "hold_ritual")
                          + 0.12 * p.bias["spiritual"] * (action == "hold_ritual")
                          + 0.10 * p.fear * (action == "hold_ritual"))
                nud = self._support_nudge(p, pr, action) * self.scale
                if nud:
                    self.nudge_fired += 1
                chance = clamp(chance + nud)
                hit = self.h.u(y, "support", p.id, pr.id, action) < chance
                self._support_counter += 1
                if self.support_flip == (y, self._support_counter):
                    hit = not hit
                    self.flip_fired = True
                if hit:
                    supporters.append(p)
                    self.rec("proposal_supported")
            threshold = max(4, int(self.population * 0.22))
            if len(supporters) >= threshold:
                self.rec("project_started")
                self._project(y, pr, action, supporters)
        self.counts["_seen_famine"] = self.count("famine")

    def _project(self, y: int, pr: Person, action: str, sup: list[Person]) -> None:
        sc = 0.48 + 0.30 * self.coop + 0.004 * len(sup)
        if action == "hold_ritual":
            sc += 0.18
        if self.h.u(y, "project", action) < clamp(sc, 0.05, 0.95):
            self.rec("project_success")
            self.coop = clamp(self.coop + 0.05)
            pr.voice = clamp(pr.voice + 0.03)
            if action == "store_food":
                self.granary += 1            # 恒久的な容量・腐敗改善
            elif action == "dig_well":
                self.well += 1               # 恒久的な干ばつ耐性
            else:
                for p in self.alive_people:
                    p.fear = clamp(p.fear * 0.70)
        else:
            self.rec("project_failure")
            self.coop = clamp(self.coop - 0.07)
            pr.voice = clamp(pr.voice * 0.85)
            for p in sup:
                p.fear = clamp(p.fear + 0.08)
                self._receive_memory(p, "failure", 0.55)

    # ---- 語りの層: 記憶の受領と伝播 -----------------------------------
    def _receive_memory(self, p: Person, kind: str, intensity: float) -> None:
        interp = max(BIASES, key=lambda b: p.bias[b])
        p.last_interp = interp
        if interp == "blame":
            p.bias["blame"] = clamp(p.bias["blame"] + 0.02)   # blame蓄積
        if interp == "spiritual":
            p.fear = clamp(p.fear + 0.02)
        p.memories.append([kind, intensity, interp])
        if len(p.memories) > 6:
            p.memories.pop(0)

    def _dialogue(self, y: int) -> None:
        ap = self.alive_people
        alive_ids = {p.id: p for p in ap}
        for p in ap:
            if not p.memories:
                continue
            if self.h.u(y, "share", p.id) >= 0.35 + 0.30 * p.fear:
                continue
            targets = [alive_ids[c] for c in p.confidants if c in alive_ids]
            if not targets:
                idx = int(self.h.u(y, "shareto", p.id) * len(ap))
                targets = [ap[min(idx, len(ap) - 1)]]
            listener = targets[int(self.h.u(y, "pick", p.id) * len(targets))
                               if len(targets) > 1 else 0]
            if listener is p:
                continue
            kind, inten, _ = max(p.memories, key=lambda m: m[1])
            self.rec("memory_shared")
            self._receive_memory(listener, kind, inten * 0.8)

    # ---- 人口動態 ------------------------------------------------------
    def _demography(self, y: int) -> None:
        ap = self.alive_people
        alive_ids = {p.id: p for p in ap}
        for p in ap:
            p.age += 1
            if p.hunger > 0.6:
                p.health = clamp(p.health - 0.06 * p.hunger)
            else:
                p.health = clamp(p.health + 0.02)
            risk = (max(0.0, (p.age - 68) / 50.0) * 0.5
                    + 0.20 * max(0.0, p.hunger - 0.5)
                    + 0.25 * max(0.0, 0.30 - p.health))
            if self.h.u(y, "death", p.id) < risk:
                p.alive = False
                self.rec("death")
                for cid in p.confidants:
                    if cid in alive_ids and alive_ids[cid].alive:
                        self._receive_memory(alive_ids[cid], "death", 0.7)
        food_ok = self.food > 0.5 * self.population
        for p in list(self.alive_people):
            if not (16 <= p.age <= 45):
                continue
            chance = 0.085 * (1.0 if food_ok else 0.4) * (0.6 + 0.8 * self.coop)
            slot = self._get_birth_slot(p.id, y)
            if self.h.u(y, "birth", p.id, y, slot) < min(0.14, chance):
                child_id = self._make_child_id(p.id, y, slot)
                if not any(q.id == child_id for q in self.people) and not any(q.id == child_id for q in self._isolated_births):
                    child = self._make_person(child_id, age=0)
                    child.confidants = [p.id] + child.confidants[:2]
                    if self.state_isolation:
                        # Deliberately do not add this child to society state.
                        # It should not affect population, resources, council, death, birth, memory, or confidants.
                        self._isolated_births.append(child)
                        self.rec("birth_isolated")
                    else:
                        self.people.append(child)
                        self.rec("birth")

    # ---- 減衰 (速い変数のみ。coopとインフラは遅い/不変) ----------------
    def _decay(self, y: int) -> None:
        for p in self.alive_people:
            p.fear = clamp(p.fear * 0.88)
            p.voice = clamp(p.voice * 0.985)
            for m in p.memories:
                m[1] *= 0.85
            p.memories = [m for m in p.memories if m[1] >= 0.08]
        self.coop = 0.5 + (self.coop - 0.5) * 0.995     # 半減期 ~140年

    # ---- 観測 -----------------------------------------------------------
    def metrics(self) -> dict:
        return {
            "pop": self.population,
            "food": round(self.food, 4),
            "granary": self.granary,
            "well": self.well,
            "coop": round(self.coop, 5),
            "supported": self.count("proposal_supported"),
            "started": self.count("project_started"),
            "success": self.count("project_success"),
            "failure": self.count("project_failure"),
            "death": self.count("death"),
            "birth": self.count("birth"),
            "memory_shared": self.count("memory_shared"),
            "crisis": self.count("crisis"),
        }

    def summary(self) -> dict:
        m = self.metrics()
        m["final_population"] = self.population
        m["nudge_fired"] = self.nudge_fired
        return m
