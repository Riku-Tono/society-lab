#!/usr/bin/env python
"""
run_validation.py — 研究用検証層の実行

使い方:
    python run_validation.py --quick                # 全6検証を軽量実行
    python run_validation.py                        # 標準 (n_ep=60)
    python run_validation.py --only null lofo       # 一部だけ
    python run_validation.py --n-ep 120 --n-boot 50 # 本番

出力:
    results/raw/        各検証の生 JSON
    results/summaries/  validation_summary.json (横断サマリ)
    results/plots/      PNG 図版
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from bridge import BridgeCfg
from moat_stage2d import Stage2dCfg
from validation import (
    ResultPaths,
    lofo_audit,
    multi_seed,
    oracle_comparison,
    rivalry_sweep,
    run_null_controls,
    society_sweep,
)
import plots

STEPS = ("null", "lofo", "rivalry_sweep", "society_sweep", "multi_seed", "oracle")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-ep", type=int, default=60)
    parser.add_argument("--T", type=int, default=60)
    parser.add_argument("--n-boot", type=int, default=25)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--only", nargs="+", choices=STEPS, default=list(STEPS))
    parser.add_argument("--results", type=Path, default=Path("results"))
    args = parser.parse_args()

    cfg = BridgeCfg(seed=args.seed, n_ep=args.n_ep, T=args.T, n_boot=args.n_boot)
    n_null, seeds = 60, (42, 123, 777, 2024, 9999)
    if args.quick:
        cfg = BridgeCfg(seed=args.seed, n_ep=16, T=args.T, n_boot=10,
                        clf=Stage2dCfg(train_steps=80, rff_dim=60))
        n_null, seeds = 30, (42, 123, 777)

    paths = ResultPaths(root=args.results)
    paths.ensure()
    summary: dict = {"config": {"seed": cfg.seed, "n_ep": cfg.n_ep,
                                "T": cfg.T, "n_boot": cfg.n_boot,
                                "quick": args.quick}}
    t0 = time.time()

    if "null" in args.only:
        print("\n[1/6] shuffled-label control")
        r = run_null_controls(cfg, paths, n_null=n_null)
        plots.plot_null_controls(r, paths)
        summary["null_controls"] = {
            w: {"real": d["real_auc"]["mean_auc"], "null_mean": d["null_mean"],
                "null_p975": d["null_p975"], "p_emp": d["empirical_p_value"],
                "signal": d["signal_above_null"]}
            for w, d in r.items()}

    if "lofo" in args.only:
        print("\n[2/6] leave-one-feature-out audit")
        r = lofo_audit(cfg, paths)
        plots.plot_lofo(r, paths)
        summary["lofo"] = {
            w: {"full": d["full_auc"]["mean_auc"],
                "most_critical": min(d["leave_one_out"],
                                     key=lambda k: d["leave_one_out"][k]["delta_vs_full"]),
                "strongest_solo": max(d["solo_auc"], key=d["solo_auc"].get)}
            for w, d in r.items()}

    if "rivalry_sweep" in args.only:
        print("\n[3/6] rivalry difficulty sweep")
        r = rivalry_sweep(cfg, paths)
        plots.plot_rivalry_sweep(r, paths)
        summary["rivalry_sweep"] = {s: v["mean_auc"] for s, v in r["curve"].items()}

    if "society_sweep" in args.only:
        print("\n[4/6] society nudge sweep")
        r = society_sweep(cfg, paths)
        plots.plot_society_sweep(r, paths)
        summary["society_sweep"] = {
            "curve": {s: v["mean_auc"] for s, v in r["curve"].items()},
            "detection_threshold": r["estimated_detection_threshold"]}

    if "multi_seed" in args.only:
        print("\n[5/6] multi-seed aggregation")
        r = multi_seed(cfg, paths, base_seeds=seeds)
        plots.plot_multi_seed(r, paths)
        summary["multi_seed"] = {
            w: {"mean": d["mean_over_seeds"], "ci": d["seed_bootstrap_ci"],
                "worst_seed": d["min_seed_auc"]}
            for w, d in r.items()}

    if "oracle" in args.only:
        print("\n[6/6] MOAT oracle comparison")
        r = oracle_comparison(cfg, paths)
        plots.plot_oracle(r, paths)
        summary["oracle"] = {
            "mean_angle_deg": r["mean_angle_oracle_vs_vB_deg"],
            "auc_oracle": r["auc_oracle"]["mean_auc"],
            "auc_vB": r["auc_vB"]["mean_auc"]}

    summary["runtime_sec"] = round(time.time() - t0, 1)
    (paths.summaries / "validation_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"\nDone in {summary['runtime_sec']}s")
    print(f"raw:       {paths.raw}/")
    print(f"summaries: {paths.summaries}/validation_summary.json")
    print(f"plots:     {paths.plots}/")


if __name__ == "__main__":
    main()
