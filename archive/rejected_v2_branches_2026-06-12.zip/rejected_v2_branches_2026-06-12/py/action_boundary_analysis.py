import importlib.util, json, statistics, sys
from typing import Dict, List

MOD_PATH = '/mnt/data/causal_society_v2_1.py'
spec = importlib.util.spec_from_file_location('cs_v21_boundary', MOD_PATH)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)
Base = mod.CausalSociety
ACTIONS = mod.ACTIONS
clamp = mod.clamp

class ActionOnlyTracked(Base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.action_change_events = []
        self.proposal_events = []
    def _support_nudge(self, person, proposer, action):
        return 0.0
    def _council(self, y: int) -> None:
        ap = self.alive_people
        if not ap:
            return
        fear_avg = self._avg('fear')
        if not self.problems and fear_avg < 0.30:
            return
        self.rec('council_formed')
        proposers = sorted(ap, key=lambda p: (-p.voice, p.id))[:2]
        used = set()
        for pr in proposers:
            base_scores = {}
            for a in ACTIONS:
                s = 0.10 + 0.05 * self.h.u(y, 'prop', pr.id, a)
                if a == 'store_food' and ('storage_damage' in self.problems or self.count('famine') > self.count('_seen_famine')):
                    s += 0.12
                if a == 'dig_well' and 'water_shortage' in self.problems:
                    s += 0.12
                if a == 'hold_ritual':
                    s += 0.18 * fear_avg
                s += 0.10 * pr.bias['practical'] * (a != 'hold_ritual')
                s += 0.10 * pr.bias['spiritual'] * (a == 'hold_ritual')
                base_scores[a] = s
            available = [a for a in ACTIONS if a not in used]
            if not available:
                continue
            action_no_nudge = max(available, key=lambda a: base_scores[a])
            scores = base_scores.copy()
            nudges = {}
            for a in available:
                nud = self._action_nudge(pr.last_interp, a) * self.scale
                nudges[a] = nud
                if nud:
                    self.nudge_fired += 1
                scores[a] += nud
            action = max(available, key=lambda a: scores[a])
            event = {
                'year': y,
                'proposer_id': pr.id,
                'interp': pr.last_interp,
                'action_no_nudge': action_no_nudge,
                'action_with_nudge': action,
                'base_scores': {k: round(v, 5) for k, v in base_scores.items() if k in available},
                'nudges': {k: round(v, 5) for k, v in nudges.items()},
                'scores': {k: round(v, 5) for k, v in scores.items() if k in available},
                'granary_before': self.granary,
                'well_before': self.well,
                'food_before': round(self.food, 4),
                'coop_before': round(self.coop, 5),
            }
            if action_no_nudge != action:
                self.action_change_events.append(event)
            self.proposal_events.append(event)
            used.add(action)
            self.rec('proposal_made')
            supporters = []
            for p in ap:
                if p is pr:
                    continue
                chance = (0.16 + 0.30 * self.coop
                          + 0.12 * p.bias['practical'] * (action != 'hold_ritual')
                          + 0.12 * p.bias['spiritual'] * (action == 'hold_ritual')
                          + 0.10 * p.fear * (action == 'hold_ritual'))
                nud = self._support_nudge(p, pr, action) * self.scale
                if nud:
                    self.nudge_fired += 1
                chance = clamp(chance + nud)
                hit = self.h.u(y, 'support', p.id, pr.id, action) < chance
                self._support_counter += 1
                if self.support_flip == (y, self._support_counter):
                    hit = not hit
                    self.flip_fired = True
                if hit:
                    supporters.append(p)
                    self.rec('proposal_supported')
            threshold = max(4, int(self.population * 0.22))
            if len(supporters) >= threshold:
                self.rec('project_started')
                self._project(y, pr, action, supporters)
                if self.action_change_events and self.action_change_events[-1] is event:
                    event['project_started_after_flip'] = True
                    event['supporters'] = len(supporters)
            elif self.action_change_events and self.action_change_events[-1] is event:
                event['project_started_after_flip'] = False
                event['supporters'] = len(supporters)
        self.counts['_seen_famine'] = self.count('famine')

class ActionMatchedTracked(ActionOnlyTracked):
    def _action_nudge(self, interp, action):
        real = Base._action_nudge(self, interp, action)
        if real == 0.0:
            return 0.0
        sign = 1.0 if self.h.u(self.year, 'matched_action_placebo_sign', interp, action) < 0.5 else -1.0
        return sign * 0.03

def run_detailed(seed: int, cls) -> Dict:
    base = Base(seed, nudge_scale=0.0)
    inte = cls(seed, nudge_scale=1.0)
    first_metric_diff = None
    for y in range(1, 81):
        base.step(); inte.step()
        if first_metric_diff is None:
            bm, im = base.metrics(), inte.metrics()
            for k in ['started','success','granary','well','food','coop','pop','death','birth']:
                if bm[k] != im[k]:
                    first_metric_diff = {'year': y, 'metric': k, 'base': bm[k], 'inte': im[k]}
                    break
    bm, im = base.metrics(), inte.metrics()
    return {
        'seed': seed,
        'pop_diff': im['pop'] - bm['pop'],
        'abs_pop_diff': abs(im['pop'] - bm['pop']),
        'action_changed': len(inte.action_change_events) > 0,
        'num_action_flips': len(inte.action_change_events),
        'first_action_change': inte.action_change_events[0] if inte.action_change_events else None,
        'first_metric_diff': first_metric_diff,
        'granary_diff': im['granary'] - bm['granary'],
        'well_diff': im['well'] - bm['well'],
        'food_diff': round(im['food'] - bm['food'], 4),
        'coop_diff': round(im['coop'] - bm['coop'], 5),
        'project_started_diff': im['started'] - bm['started'],
        'project_success_diff': im['success'] - bm['success'],
        'death_diff': im['death'] - bm['death'],
        'birth_diff': im['birth'] - bm['birth'],
        'final_inte_granary': im['granary'],
        'final_inte_well': im['well'],
        'final_inte_food': im['food'],
        'final_inte_started': im['started'],
        'final_inte_success': im['success'],
        'nudge_fired': inte.nudge_fired,
    }

def stats(vals):
    return {'mean': round(statistics.mean(vals), 3) if vals else 0, 'median': statistics.median(vals) if vals else 0, 'max': max(vals) if vals else 0, 'zero_count': sum(1 for v in vals if v == 0)}

def summarize(rows: List[Dict]) -> Dict:
    changed = [r for r in rows if r['action_changed']]
    not_changed = [r for r in rows if not r['action_changed']]
    def mean_field(rs, f): return round(statistics.mean([r[f] for r in rs]), 3) if rs else 0
    return {
        'total_seeds': len(rows),
        'seeds_with_action_changed': len(changed),
        'action_change_rate': round(len(changed)/len(rows), 3),
        'total_action_flips': sum(r['num_action_flips'] for r in rows),
        'pop_diff_all_seeds': stats([r['abs_pop_diff'] for r in rows]),
        'pop_diff_only_action_changed_seeds': stats([r['abs_pop_diff'] for r in changed]),
        'pop_diff_no_action_changed_seeds': stats([r['abs_pop_diff'] for r in not_changed]),
        'downstream_diffs_for_action_changed_seeds': {
            'avg_granary_diff': mean_field(changed,'granary_diff'),
            'avg_well_diff': mean_field(changed,'well_diff'),
            'avg_food_diff': mean_field(changed,'food_diff'),
            'avg_project_started_diff': mean_field(changed,'project_started_diff'),
            'avg_project_success_diff': mean_field(changed,'project_success_diff'),
            'avg_death_diff': mean_field(changed,'death_diff'),
            'avg_birth_diff': mean_field(changed,'birth_diff'),
        },
        'action_flip_project_started_count': sum(1 for r in changed if r['first_action_change'] and r['first_action_change'].get('project_started_after_flip')),
        'example_action_change_events': [r['first_action_change'] for r in changed[:5]],
        'rows': rows,
    }

def main():
    seeds = list(range(1000, 1100))
    conditions = {
        'real_action_only': ActionOnlyTracked,
        'matched_action_placebo': ActionMatchedTracked,
    }
    out = {}
    for name, cls in conditions.items():
        rows = [run_detailed(s, cls) for s in seeds]
        out[name] = summarize(rows)
        print(name, out[name]['seeds_with_action_changed'], out[name]['pop_diff_all_seeds'])
    with open('/mnt/data/action_boundary_results.json','w') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

if __name__ == '__main__':
    main()
