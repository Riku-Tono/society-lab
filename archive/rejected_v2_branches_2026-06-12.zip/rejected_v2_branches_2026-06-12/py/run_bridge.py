#!/usr/bin/env python
"""
run_bridge.py — MOAT × SocietyLab × RivalryCA 統合ハーネス CLI

使い方:
    python run_bridge.py                          # 3世界すべて (標準設定)
    python run_bridge.py --world society          # 1世界だけ
    python run_bridge.py --quick                  # 高速スモークテスト
    python run_bridge.py --n-ep 120 --n-boot 50   # 本気の統計

出力:
    各世界 × 時間窓 (early/mid/late/full) の AUC + 95% CI を表示し、
    JSON を --out に保存する。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from bridge import BridgeCfg, WORLDS, run_all
from moat_stage2d import Stage2dCfg


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", choices=[*WORLDS, "all"], default="all")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-ep", type=int, default=60)
    parser.add_argument("--T", type=int, default=60)
    parser.add_argument("--n-boot", type=int, default=25)
    parser.add_argument("--quick", action="store_true",
                        help="n_ep=16, n_boot=10, 軽量分類器で高速確認")
    parser.add_argument("--out", type=Path, default=Path("bridge_results.json"))
    args = parser.parse_args()

    cfg = BridgeCfg(seed=args.seed, n_ep=args.n_ep, T=args.T, n_boot=args.n_boot)
    if args.quick:
        cfg = BridgeCfg(
            seed=args.seed, n_ep=16, T=args.T, n_boot=10,
            clf=Stage2dCfg(train_steps=80, rff_dim=60),
        )

    worlds = list(WORLDS) if args.world == "all" else [args.world]

    print("MOAT × SocietyLab × RivalryCA — Cross-World Discriminability Harness")
    print("=" * 72)
    results = run_all(cfg, worlds)

    args.out.write_text(json.dumps(results, indent=2, ensure_ascii=False))
    print(f"\nWrote {args.out}")


if __name__ == "__main__":
    main()
