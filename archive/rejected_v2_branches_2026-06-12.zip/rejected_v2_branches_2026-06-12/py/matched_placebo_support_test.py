import importlib.util, json, statistics, os, sys
from typing import Dict, List

MOD_PATH = '/mnt/data/causal_society_v2_1.py'
spec = importlib.util.spec_from_file_location('cs_v21', MOD_PATH)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)
Base = mod.CausalSociety

class SupportOnlyReal(Base):
    """Only support nudges are active; proposer/action-choice nudges are disabled."""
    def _action_nudge(self, interp: str, action: str) -> float:
        # Disable action-choice nudge in _council. _support_nudge below uses the
        # original semantic mapping explicitly, so support nudges still exist.
        return 0.0
    def _support_nudge(self, person, proposer, action: str) -> float:
        interp = person.last_interp
        if interp == 'none':
            return 0.0
        if interp == 'spiritual' and action == 'hold_ritual':
            return 0.03
        if interp == 'practical' and action in ('store_food', 'dig_well'):
            return 0.03
        if interp == 'blame':
            return -0.03 if proposer.voice >= 0.08 else 0.03
        return 0.0

class SupportMatchedPlacebo(SupportOnlyReal):
    """Same nonzero support-nudge gates as SupportOnlyReal, but sign is random.

    The random sign is counterfactually coupled by seed/year/person/proposer/action
    and does not consume RNG.
    """
    def _support_nudge(self, person, proposer, action: str) -> float:
        # First ask whether the real model would have had a support nudge here.
        real = SupportOnlyReal._support_nudge(self, person, proposer, action)
        if real == 0.0:
            return 0.0
        # Deterministic placebo sign independent from the semantic sign.
        sign = 1.0 if self.h.u(self.year, 'matched_placebo_sign', person.id, proposer.id, action) < 0.5 else -1.0
        return sign * 0.03

class FullMatchedPlacebo(Base):
    """Full model action nudges remain real; support nudge signs randomized.

    This is less clean than support-only, but useful as context because the v2
    intervention includes both action and support nudges.
    """
    def _support_nudge(self, person, proposer, action: str) -> float:
        real = Base._support_nudge(self, person, proposer, action)
        if real == 0.0:
            return 0.0
        sign = 1.0 if self.h.u(self.year, 'matched_placebo_sign', person.id, proposer.id, action) < 0.5 else -1.0
        return sign * 0.03


def run_pair(seed: int, cls, scale: float = 1.0, years: int = 80) -> Dict:
    base = Base(seed, nudge_scale=0.0)
    inte = cls(seed, nudge_scale=scale)
    for _ in range(years):
        base.step()
        inte.step()
    bm, im = base.metrics(), inte.metrics()
    return {
        'seed': seed,
        'pop_diff': im['pop'] - bm['pop'],
        'abs_pop_diff': abs(im['pop'] - bm['pop']),
        'granary_diff': im['granary'] - bm['granary'],
        'well_diff': im['well'] - bm['well'],
        'coop_diff': round(im['coop'] - bm['coop'], 5),
        'supported_diff': im['supported'] - bm['supported'],
        'started_diff': im['started'] - bm['started'],
        'success_diff': im['success'] - bm['success'],
        'nudge_fired': inte.nudge_fired,
    }

def summarize(rows: List[Dict]) -> Dict:
    absd = [r['abs_pop_diff'] for r in rows]
    signed = [r['pop_diff'] for r in rows]
    return {
        'mean_abs_pop_diff': round(statistics.mean(absd), 3),
        'median_abs_pop_diff': statistics.median(absd),
        'max_abs_pop_diff': max(absd),
        'zero_count': sum(1 for x in absd if x == 0),
        'positive_count': sum(1 for x in signed if x > 0),
        'negative_count': sum(1 for x in signed if x < 0),
        'mean_supported_diff': round(statistics.mean([r['supported_diff'] for r in rows]), 3),
        'mean_started_diff': round(statistics.mean([r['started_diff'] for r in rows]), 3),
        'mean_success_diff': round(statistics.mean([r['success_diff'] for r in rows]), 3),
        'mean_granary_diff': round(statistics.mean([r['granary_diff'] for r in rows]), 3),
        'mean_well_diff': round(statistics.mean([r['well_diff'] for r in rows]), 3),
        'mean_coop_diff': round(statistics.mean([r['coop_diff'] for r in rows]), 5),
        'mean_nudge_fired': round(statistics.mean([r['nudge_fired'] for r in rows]), 3),
        'raw_abs_pop_diffs': absd,
        'rows': rows,
    }

def main():
    seeds = list(range(1000, 1100))
    conditions = {
        'real_full_nudge_vs_baseline': Base,
        'real_support_only_vs_baseline': SupportOnlyReal,
        'matched_support_placebo_vs_baseline': SupportMatchedPlacebo,
        'full_action_real_support_matched_placebo_vs_baseline': FullMatchedPlacebo,
    }
    out = {}
    for name, cls in conditions.items():
        rows = [run_pair(s, cls) for s in seeds]
        out[name] = summarize(rows)
        print(name, out[name]['mean_abs_pop_diff'], out[name]['median_abs_pop_diff'], out[name]['zero_count'])
    with open('/mnt/data/matched_placebo_support_results.json', 'w') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

if __name__ == '__main__':
    main()
