"""
validation.py — 研究用検証層
=============================

目的: 「面白い結果」ではなく「本当に信号が存在するか」の検証。

実装する6つの検証:
  1. shuffled-label control   ラベルを壊した時の null AUC 分布
  2. leave-one-feature-out    どの特徴量が識別を支えているかの監査
  3. rivalry difficulty sweep asymmetry_strength ∈ [0,1] の AUC 曲線
  4. society nudge sweep      nudge_scale の AUC 曲線と検出閾値
  5. multi-seed aggregation   base seed 横断の AUC 集約 + bootstrap CI
  6. MOAT oracle 改善         B/Q 分離度 (対称KL) を最大化する方向探索

統計上の注意 (重要):
  moat_stage2d.auc_score は max(a, 1-a) で折り返すため、null 分布の
  平均は 0.5 ではなく 0.5 より上に出る (小標本ほど顕著)。
  したがって「null ≈ 0.5 のはず」ではなく、実測 null 分布のパーセン
  タイルと real AUC を比較するのが正しい。本モジュールはそれを行う。

rivalry の asymmetry_strength の操作化:
  LIKES 構造は離散辞書なので構造自体の連続補間は core 改造が必要。
  代わりに strength = 競争種 (C/D) の存在量として実装する。
  s=1 で元の非対称世界、s=0 で A↔B 両想いのみの世界に連続収束。
  初期配置 / 誕生 / 突然変異の3経路で C/D を確率 (1-s) で棄却。
  注: 高圧バースト (_burst_into) は全種から復活させるため、s=0 でも
  ごく稀に C/D が一時侵入する。これは残留ノイズとして許容し記録する。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Sequence

import numpy as np

from bridge import (
    RIVALRY_FIELD_KEYS,
    SOCIETY_DELTA_EVENTS,
    BridgeCfg,
    ConfigurableSocietyLab,
    MoatWorld,
    RivalryWorld,
    SocietyWorld,
    WORLDS,
    bootstrap_auc,
    featurize,
)
from moat_stage2d import Stage2dCfg, mean_auc, sample_geom, split_eval, world_step
from rivalry_ca import RivalryCA

Array = np.ndarray


# ---------------------------------------------------------------------------
# 出力ディレクトリ
# ---------------------------------------------------------------------------

@dataclass
class ResultPaths:
    root: Path = Path("results")

    @property
    def raw(self) -> Path:
        return self.root / "raw"

    @property
    def summaries(self) -> Path:
        return self.root / "summaries"

    @property
    def plots(self) -> Path:
        return self.root / "plots"

    def ensure(self) -> None:
        for p in (self.raw, self.summaries, self.plots):
            p.mkdir(parents=True, exist_ok=True)

    def save_raw(self, name: str, obj: object) -> None:
        (self.raw / f"{name}.json").write_text(
            json.dumps(obj, indent=2, ensure_ascii=False))


# ---------------------------------------------------------------------------
# 共通: エピソード生成
# ---------------------------------------------------------------------------

def gen_world_eps(world_name: str, cfg: BridgeCfg) -> tuple[list, list]:
    world = WORLDS[world_name](cfg)
    eps_B = [world.run_episode(cfg.seed + i, "B") for i in range(cfg.n_ep)]
    eps_Q = [world.run_episode(cfg.seed + i, "Q") for i in range(cfg.n_ep)]
    return eps_B, eps_Q


def full_window_feats(world_name: str, cfg: BridgeCfg,
                      eps_B: list, eps_Q: list) -> tuple[Array, Array]:
    raw = WORLDS[world_name].featurize_raw
    XB = featurize(eps_B, 0, cfg.T, raw)
    XQ = featurize(eps_Q, 0, cfg.T, raw)
    return XB, XQ


# ---------------------------------------------------------------------------
# 1. shuffled-label control
# ---------------------------------------------------------------------------

def shuffled_label_null(XB: Array, XQ: Array, rng: np.random.Generator,
                        clf_cfg: Stage2dCfg, n_null: int) -> List[float]:
    """ラベルとデータの対応を破壊した null AUC 分布。"""
    X = np.r_[XB, XQ]
    n_b = len(XB)
    vals = []
    for _ in range(n_null):
        perm = rng.permutation(len(X))
        Xp = X[perm]
        vals.append(mean_auc(split_eval(Xp[:n_b], Xp[n_b:], rng, clf_cfg)))
    return vals


def run_null_controls(cfg: BridgeCfg, paths: ResultPaths,
                      worlds: Sequence[str] = ("moat", "society", "rivalry"),
                      n_null: int = 40) -> Dict:
    rng = np.random.default_rng(cfg.seed + 7)
    out = {}
    for wname in worlds:
        print(f"  [null] {wname}: generating episodes...")
        eps_B, eps_Q = gen_world_eps(wname, cfg)
        XB, XQ = full_window_feats(wname, cfg, eps_B, eps_Q)
        real = bootstrap_auc(XB, XQ, rng, cfg.clf, cfg.n_boot)
        null_vals = shuffled_label_null(XB, XQ, rng, cfg.clf, n_null)
        null_arr = np.array(null_vals)
        # real AUC が null の何パーセンタイルを超えるか (経験的 p 値)
        p_emp = float(np.mean(null_arr >= real["mean_auc"]))
        out[wname] = {
            "real_auc": real,
            "null_distribution": null_vals,
            "null_mean": float(null_arr.mean()),
            "null_p975": float(np.percentile(null_arr, 97.5)),
            "empirical_p_value": p_emp,
            "signal_above_null": bool(real["mean_auc"] > np.percentile(null_arr, 97.5)),
            "note": "auc_score は max(a,1-a) 折返しのため null 平均は 0.5 を上回る",
        }
        print(f"  [null] {wname}: real={real['mean_auc']:.3f}  "
              f"null_mean={out[wname]['null_mean']:.3f}  "
              f"null_97.5%={out[wname]['null_p975']:.3f}  "
              f"p_emp={p_emp:.3f}  "
              f"signal={'YES' if out[wname]['signal_above_null'] else 'no'}")
    paths.save_raw("null_controls", out)
    return out


# ---------------------------------------------------------------------------
# 2. leave-one-feature-out audit
# ---------------------------------------------------------------------------

def lofo_audit(cfg: BridgeCfg, paths: ResultPaths,
               worlds: Sequence[str] = ("society", "rivalry"),
               n_boot: int | None = None) -> Dict:
    """特徴量を1つずつ除去して full-window AUC の低下を測る。

    featurize(mean+std) の場合、特徴 j は列 j と j+F の2列に対応する。
    """
    nb = n_boot or max(8, cfg.n_boot // 2)
    rng = np.random.default_rng(cfg.seed + 13)
    out = {}
    for wname in worlds:
        world_cls = WORLDS[wname]
        names = list(world_cls.feature_names)
        F = len(names)
        print(f"  [lofo] {wname}: generating episodes...")
        eps_B, eps_Q = gen_world_eps(wname, cfg)
        XB, XQ = full_window_feats(wname, cfg, eps_B, eps_Q)
        base = bootstrap_auc(XB, XQ, rng, cfg.clf, nb)
        rows = {}
        for j, fname in enumerate(names):
            keep = [c for c in range(XB.shape[1]) if c % F != j]
            r = bootstrap_auc(XB[:, keep], XQ[:, keep], rng, cfg.clf, nb)
            rows[fname] = {
                "auc_without": r["mean_auc"],
                "delta_vs_full": round(r["mean_auc"] - base["mean_auc"], 4),
            }
            print(f"  [lofo] {wname}: -{fname:<22} "
                  f"AUC={r['mean_auc']:.3f}  Δ={rows[fname]['delta_vs_full']:+.3f}")
        # 単独特徴量での AUC (支配特徴の同定)
        solo = {}
        for j, fname in enumerate(names):
            cols = [c for c in range(XB.shape[1]) if c % F == j]
            r = bootstrap_auc(XB[:, cols], XQ[:, cols], rng, cfg.clf, nb)
            solo[fname] = r["mean_auc"]
        out[wname] = {"full_auc": base, "leave_one_out": rows, "solo_auc": solo}
    paths.save_raw("lofo_audit", out)
    return out


# ---------------------------------------------------------------------------
# 3. rivalry difficulty sweep
# ---------------------------------------------------------------------------

class TunableRivalryCA(RivalryCA):
    """competitor_weight = asymmetry_strength s ∈ [0,1]。

    C/D (競争を生む種) を確率 (1-s) で棄却し A/B に置換する。
    s=1 で元の RivalryCA と同一構造、s=0 で両想いペアのみの世界。
    """

    def __init__(self, *args, competitor_weight: float = 1.0, **kwargs):
        super().__init__(*args, **kwargs)
        self.cw = float(competitor_weight)

    def _filter_kind(self, kind: str) -> str:
        if kind in ("C", "D") and self.rng.random() > self.cw:
            return self.rng.choice(("A", "B"))
        return kind

    def randomize(self, density: float = 0.30, base_pressure: float = 0.05) -> None:
        super().randomize(density=density, base_pressure=base_pressure)
        for row in self.grid:
            for cell in row:
                if cell.alive:
                    cell.kind = self._filter_kind(cell.kind)
        self._recompute_global_pressure()

    def _birth_kind(self, ns) -> str:
        return self._filter_kind(super()._birth_kind(ns))

    def _maybe_mutate_kind(self, kind: str) -> str:
        return self._filter_kind(super()._maybe_mutate_kind(kind))


def rivalry_episode(seed: int, strength: float, T: int) -> Array:
    ca = TunableRivalryCA(width=44, height=22, seed=seed, competitor_weight=strength)
    ca.randomize(density=0.32, base_pressure=0.08)
    area = ca.w * ca.h
    rows = []
    for _ in range(T):
        if ca.population() > 0:
            ca.step()
        m = ca.metrics()
        rows.append([float(m[k]) for k in RIVALRY_FIELD_KEYS]
                    + [m["ca_population"] / area])
    return np.array(rows)


def rivalry_sweep(cfg: BridgeCfg, paths: ResultPaths,
                  strengths: Sequence[float] = (0.0, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0),
                  ) -> Dict:
    """AUC(s) = world(s) vs world(0) の識別可能性。

    baseline (s=0) は独立シード系列で1回だけ生成して共有する。
    s=0 の点は seed ノイズのみ → 組み込み陰性対照。
    """
    rng = np.random.default_rng(cfg.seed + 23)
    print("  [rivalry-sweep] baseline (s=0) episodes...")
    base_eps = [rivalry_episode(cfg.seed + 10000 + i, 0.0, cfg.T)
                for i in range(cfg.n_ep)]
    XQ = featurize(base_eps, 0, cfg.T, raw=False)
    curve = {}
    for s in strengths:
        eps = [rivalry_episode(cfg.seed + i, s, cfg.T) for i in range(cfg.n_ep)]
        XB = featurize(eps, 0, cfg.T, raw=False)
        r = bootstrap_auc(XB, XQ, rng, cfg.clf, cfg.n_boot)
        curve[str(s)] = r
        print(f"  [rivalry-sweep] s={s:<5} AUC={r['mean_auc']:.3f} "
              f"[{r['ci_low']:.3f}, {r['ci_high']:.3f}]")
    out = {
        "parametrization": "asymmetry_strength = C/D (競争種) の存在量。"
                           "構造辞書の補間ではない点に注意。",
        "baseline": "strength=0.0, 独立シード系列",
        "curve": curve,
    }
    paths.save_raw("rivalry_sweep", out)
    return out


# ---------------------------------------------------------------------------
# 4. society nudge sweep
# ---------------------------------------------------------------------------

def society_episode(seed: int, scale: float, T: int) -> Array:
    lab = ConfigurableSocietyLab(seed=seed, nudge_scale=scale)
    prev = {e: 0 for e in SOCIETY_DELTA_EVENTS}
    rows = []
    for _ in range(T):
        if lab.population > 0:
            lab.step()
        row = [
            lab.population / max(1, lab.initial_population),
            lab._avg("fear"),
            lab._avg("hunger"),
            lab._avg("voice_weight"),
            lab.food.stock / max(1e-6, lab.initial_food_stock),
        ]
        for e in SOCIETY_DELTA_EVENTS:
            c = lab.log.count(e)
            row.append(float(c - prev[e]))
            prev[e] = c
        rows.append(row)
    return np.array(rows)


def society_sweep(cfg: BridgeCfg, paths: ResultPaths,
                  scales: Sequence[float] = (0.0, 0.25, 0.5, 1.0, 2.0, 3.0),
                  ) -> Dict:
    """AUC(scale) = nudge_scale=s vs scale=0 (独立シード) の識別可能性。

    s=0 点は seed ノイズのみ → 陰性対照。検出閾値 = null 上限を初めて
    超える scale として推定する。
    """
    rng = np.random.default_rng(cfg.seed + 31)
    print("  [society-sweep] baseline (scale=0) episodes...")
    base_eps = [society_episode(cfg.seed + 10000 + i, 0.0, cfg.T)
                for i in range(cfg.n_ep)]
    XQ = featurize(base_eps, 0, cfg.T, raw=False)
    curve = {}
    for s in scales:
        eps = [society_episode(cfg.seed + i, s, cfg.T) for i in range(cfg.n_ep)]
        XB = featurize(eps, 0, cfg.T, raw=False)
        r = bootstrap_auc(XB, XQ, rng, cfg.clf, cfg.n_boot)
        curve[str(s)] = r
        print(f"  [society-sweep] scale={s:<5} AUC={r['mean_auc']:.3f} "
              f"[{r['ci_low']:.3f}, {r['ci_high']:.3f}]")
    # 検出閾値: s=0 の CI 上限を、CI 下限が超える最小 scale
    null_hi = curve["0.0"]["ci_high"]
    threshold = None
    for s in scales:
        if s > 0 and curve[str(s)]["ci_low"] > null_hi:
            threshold = s
            break
    out = {"curve": curve, "null_ci_high_at_scale0": null_hi,
           "estimated_detection_threshold": threshold}
    paths.save_raw("society_sweep", out)
    print(f"  [society-sweep] 推定検出閾値 scale ≈ {threshold}")
    return out


# ---------------------------------------------------------------------------
# 5. multi-seed aggregation
# ---------------------------------------------------------------------------

def multi_seed(cfg: BridgeCfg, paths: ResultPaths,
               base_seeds: Sequence[int] = (42, 123, 777, 2024, 9999),
               worlds: Sequence[str] = ("moat", "society", "rivalry"),
               n_boot_inner: int = 8, n_boot_outer: int = 2000) -> Dict:
    """base seed ごとに full-window AUC を出し、seed 横断で bootstrap CI。

    各 seed のエピソード対は同一 seed 系列で生成されるため、seed 間の
    比較は paired。outer bootstrap は seed のリサンプリングで行う。
    """
    out = {}
    for wname in worlds:
        per_seed = {}
        for bs in base_seeds:
            c = BridgeCfg(seed=bs, n_ep=cfg.n_ep, T=cfg.T,
                          n_boot=n_boot_inner, clf=cfg.clf)
            rng = np.random.default_rng(bs + 5)
            eps_B, eps_Q = gen_world_eps(wname, c)
            XB, XQ = full_window_feats(wname, c, eps_B, eps_Q)
            r = bootstrap_auc(XB, XQ, rng, c.clf, n_boot_inner)
            per_seed[str(bs)] = r["mean_auc"]
            print(f"  [multi-seed] {wname} seed={bs}: AUC={r['mean_auc']:.3f}")
        vals = np.array(list(per_seed.values()))
        brng = np.random.default_rng(cfg.seed + 99)
        boots = [float(vals[brng.integers(0, len(vals), len(vals))].mean())
                 for _ in range(n_boot_outer)]
        out[wname] = {
            "per_seed_auc": per_seed,
            "mean_over_seeds": float(vals.mean()),
            "seed_bootstrap_ci": [float(np.percentile(boots, 2.5)),
                                  float(np.percentile(boots, 97.5))],
            "min_seed_auc": float(vals.min()),
        }
        ci = out[wname]["seed_bootstrap_ci"]
        print(f"  [multi-seed] {wname}: mean={vals.mean():.3f} "
              f"CI=[{ci[0]:.3f}, {ci[1]:.3f}]  worst_seed={vals.min():.3f}")
    paths.save_raw("multi_seed", out)
    return out


# ---------------------------------------------------------------------------
# 6. MOAT oracle 改善 (B/Q 分離度最大化の方向探索)
# ---------------------------------------------------------------------------

def _residual_covs(d: Array, v_b: Array, v_q: Array,
                   cfg: Stage2dCfg) -> tuple[Array, Array]:
    """行動を方向 d に集中させた時の中立残差 (B_est=I) の共分散。

    H_B: e = δ_B (v_B·u) v_B + w  →  Σ_B = σ²I + δ_B²(v_BᵀC_u v_B) v_B v_Bᵀ
    H_Q: e = w'                   →  Σ_Q = σ²I + d_q v_q v_qᵀ  (行動非依存)
    """
    vp = np.array([-d[1], d[0]])
    Cu = (cfg.input_energy * (1 - cfg.min_de)) * np.outer(d, d) \
       + (cfg.input_energy * cfg.min_de) * np.outer(vp, vp)
    g = float(v_b @ Cu @ v_b)
    sig_b = cfg.sigma_w ** 2 * np.eye(2) + cfg.delta_b ** 2 * g * np.outer(v_b, v_b)
    dq = cfg.delta_b ** 2 * cfg.input_energy * 0.5
    sig_q = cfg.sigma_w ** 2 * np.eye(2) + dq * np.outer(v_q, v_q)
    return sig_b, sig_q


def _sym_kl(s0: Array, s1: Array) -> float:
    i0, i1 = np.linalg.inv(s0), np.linalg.inv(s1)
    kl01 = 0.5 * (np.trace(i1 @ s0) - 2 + np.log(np.linalg.det(s1) / np.linalg.det(s0)))
    kl10 = 0.5 * (np.trace(i0 @ s1) - 2 + np.log(np.linalg.det(s0) / np.linalg.det(s1)))
    return float(kl01 + kl10)


def discriminative_direction(v_b: Array, v_q: Array, cfg: Stage2dCfg,
                             n_grid: int = 360) -> tuple[Array, float]:
    """対称 KL を最大化する行動方向の数値探索。"""
    best_d, best_v = v_b, -np.inf
    for th in np.linspace(0, np.pi, n_grid, endpoint=False):
        d = np.array([np.cos(th), np.sin(th)])
        v = _sym_kl(*_residual_covs(d, v_b, v_q, cfg))
        if v > best_v:
            best_v, best_d = v, d
    return best_d, best_v


def _run_dir_ep(rng, cfg: Stage2dCfg, hyp: str, v_b, v_q, d: Array) -> Array:
    """方向 d に集中した固定方策の中立残差エピソード。"""
    dq = 0.0 if hyp == "B" else cfg.delta_b ** 2 * cfg.input_energy * 0.5
    B_true = (np.eye(2) + cfg.delta_b * np.outer(v_b, v_b)) if hyp == "B" else np.eye(2)
    vp = np.array([-d[1], d[0]])
    Cu = (cfg.input_energy * (1 - cfg.min_de)) * np.outer(d, d) \
       + (cfg.input_energy * cfg.min_de) * np.outer(vp, vp)
    x = rng.normal(size=2) * 0.1
    res = []
    for _ in range(cfg.T):
        u = rng.multivariate_normal(np.zeros(2), Cu)
        x_next = world_step(rng, cfg, hyp, x, B_true, v_q, dq, u)
        res.append(x_next - x - u)
        x = x_next
    return np.array(res)


def oracle_comparison(cfg: BridgeCfg, paths: ResultPaths) -> Dict:
    """探索 oracle vs vB policy を分離して比較する。

    探索 oracle が解析的に v_B に一致するなら、それは
    「vb_oracle = vB は手抜きではなく最適だった」という結果になる。
    一致しないなら旧 vb_oracle は名前負けだったことになる。
    """
    moat_cfg = Stage2dCfg(seed=cfg.seed, T=cfg.T)
    rng = np.random.default_rng(cfg.seed + 41)
    eps = {"oracle": ([], []), "vB": ([], [])}
    angles = []
    for i in range(cfg.n_ep):
        v_b, v_q = sample_geom(rng, moat_cfg)
        d_star, _ = discriminative_direction(v_b, v_q, moat_cfg)
        angles.append(float(np.degrees(np.arccos(
            np.clip(abs(d_star @ v_b), 0, 1)))))
        for hyp, idx in (("B", 0), ("Q", 1)):
            eps["oracle"][idx].append(_run_dir_ep(rng, moat_cfg, hyp, v_b, v_q, d_star))
            eps["vB"][idx].append(_run_dir_ep(rng, moat_cfg, hyp, v_b, v_q, v_b))
    out = {"mean_angle_oracle_vs_vB_deg": float(np.mean(angles)),
           "max_angle_oracle_vs_vB_deg": float(np.max(angles))}
    for key in ("oracle", "vB"):
        XB = featurize(eps[key][0], 0, cfg.T, raw=True)
        XQ = featurize(eps[key][1], 0, cfg.T, raw=True)
        out[f"auc_{key}"] = bootstrap_auc(XB, XQ, rng, cfg.clf, cfg.n_boot)
        print(f"  [oracle] {key:<6} AUC={out[f'auc_{key}']['mean_auc']:.3f} "
              f"[{out[f'auc_{key}']['ci_low']:.3f}, {out[f'auc_{key}']['ci_high']:.3f}]")
    print(f"  [oracle] 探索方向と v_B の平均角度: "
          f"{out['mean_angle_oracle_vs_vB_deg']:.2f}° "
          f"(最大 {out['max_angle_oracle_vs_vB_deg']:.2f}°)")
    out["interpretation"] = (
        "角度 ≈ 0° なら旧 vb_oracle (=vB) は解析的に正当化される。"
        "角度が大きいなら旧 oracle は名前負けで、探索版を採用すべき。")
    paths.save_raw("oracle_comparison", out)
    return out
