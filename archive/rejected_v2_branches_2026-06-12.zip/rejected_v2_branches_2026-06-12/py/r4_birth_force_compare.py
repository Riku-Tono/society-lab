import importlib.util, statistics, json, os, types, sys
from pathlib import Path

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

def run_one(mod, seed, flip_year=3):
    base = mod.CausalSociety(seed, nudge_scale=0.0)
    inte = mod.CausalSociety(seed, nudge_scale=0.0)
    forced_key = None
    forced_calls = 0
    for y in range(1, 81):
        if y == flip_year:
            orig_u = inte.h.u
            state = {"done": False, "key": None, "calls": 0}
            def hacked_u(*key):
                # Force exactly the first birth RNG call in this year to birth.
                if (not state["done"]) and len(key) >= 2 and key[0] == y and key[1] == "birth":
                    state["done"] = True
                    state["key"] = key
                    state["calls"] += 1
                    return 0.0
                return orig_u(*key)
            inte.h.u = hacked_u
            base.step(); inte.step()
            inte.h.u = orig_u
            forced_key = state["key"]
            forced_calls = state["calls"]
        else:
            base.step(); inte.step()
    return {
        "seed": seed,
        "abs_pop_diff": abs(base.population - inte.population),
        "signed_pop_diff": inte.population - base.population,
        "forced_key": forced_key,
        "forced_calls": forced_calls,
        "base_pop": base.population,
        "inte_pop": inte.population,
    }

def run(mod_path, name):
    mod = load(mod_path, name)
    rows = [run_one(mod, s) for s in range(1000,1100)]
    diffs = [r["abs_pop_diff"] for r in rows]
    return {
        "mean_abs_pop_diff": statistics.mean(diffs),
        "median_abs_pop_diff": statistics.median(diffs),
        "max_abs_pop_diff": max(diffs),
        "zero_count": sum(d==0 for d in diffs),
        "forced_count": sum(r["forced_key"] is not None for r in rows),
        "raw_diffs": diffs,
        "rows": rows,
    }

if __name__ == "__main__":
    res = {
        "v20": run('/mnt/data/causal_society_v2(1).py','v20'),
        "v21_childid_only": run('/mnt/data/causal_society_v2_1.py','v21'),
    }
    Path('/mnt/data/r4_birth_force_compare_results.json').write_text(json.dumps(res, indent=2, default=str))
    print(json.dumps({k:{kk:v for kk,v in val.items() if kk not in ('rows','raw_diffs')} for k,val in res.items()}, indent=2))
