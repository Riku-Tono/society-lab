from __future__ import annotations

import importlib.util
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


BASE_DIR = Path(__file__).parent
V14_PATH = BASE_DIR / "society_lab_v1_4.py"
V15_PATH = BASE_DIR / "society_lab_v1_5.py"
REPORT_PATH = BASE_DIR / "society_lab_v1_5_private_memory_report.md"

SEED = 1003
YEARS = 80
TARGET_EVENT = "project_failure:store_food"
TARGET_MEMORY_YEAR = 14


@dataclass
class PropagationEdge:
    year: int
    speaker_id: str
    speaker_name: str
    listener_id: str
    listener_name: str
    intensity: float
    generation: int
    interpretation: str
    source_role: str


def load_module(label: str, path: Path) -> ModuleType:
    module_name = label.replace(".", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def run_summary(module: ModuleType) -> dict[str, object]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    sim.run(years=YEARS)
    return sim.summary()


def build_instrumented_lab(module: ModuleType) -> type:
    class InstrumentedSocietyLab(module.SocietyLab):
        def __init__(self, *args: object, **kwargs: object) -> None:
            super().__init__(*args, **kwargs)
            self.target_edges: list[PropagationEdge] = []
            self.private_edges: list[PropagationEdge] = []

        def _dialogue_phase(self) -> None:
            for speaker in self.alive_people:
                memory = speaker.strongest_memory()
                if memory is None:
                    continue
                share_probability = (
                    0.05
                    + memory.intensity * 0.18
                    + speaker.fear * 0.15
                    + (0.12 if speaker.action == "share_memory" else 0.0)
                )
                private_failure = (
                    memory.event.startswith("project_failure")
                    and getattr(memory, "source_role", "self") == "proposer"
                )
                if private_failure:
                    share_probability *= 0.35
                if memory.generation >= 4:
                    share_probability *= 0.55
                if self.rng.random() > min(0.55, share_probability):
                    continue
                if private_failure:
                    listener_count = 1
                else:
                    listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
                listeners = [
                    self._person(person_id)
                    for person_id in speaker.top_trusted(listener_count)
                    if self._person(person_id).alive
                ]
                for listener in listeners:
                    distorted = self._distort_memory(memory, speaker, listener)
                    if memory.event == TARGET_EVENT and memory.year == TARGET_MEMORY_YEAR:
                        self.target_edges.append(
                            PropagationEdge(
                                year=self.year,
                                speaker_id=speaker.id,
                                speaker_name=speaker.name,
                                listener_id=listener.id,
                                listener_name=listener.name,
                                intensity=distorted.intensity,
                                generation=distorted.generation,
                                interpretation=distorted.interpretation,
                                source_role=getattr(memory, "source_role", "self"),
                            )
                        )
                    if private_failure:
                        self.private_edges.append(
                            PropagationEdge(
                                year=self.year,
                                speaker_id=speaker.id,
                                speaker_name=speaker.name,
                                listener_id=listener.id,
                                listener_name=listener.name,
                                intensity=distorted.intensity,
                                generation=distorted.generation,
                                interpretation=distorted.interpretation,
                                source_role=f"{memory.source_role}:{memory.event}:Y{memory.year}",
                            )
                        )
                    listener.remember(distorted)
                    self.log.record(
                        self.year,
                        "memory_shared",
                        [speaker.id, listener.id],
                        (
                            f"{speaker.name} told {listener.name} about "
                            f"{distorted.event} intensity={distorted.intensity:.2f} "
                            f"generation={distorted.generation}"
                        ),
                    )
                    self._adjust_trust(listener, speaker.id, 0.012)

    return InstrumentedSocietyLab


def run_instrumented(module: ModuleType) -> object:
    lab_class = build_instrumented_lab(module)
    sim = lab_class(seed=SEED, verbose=False)
    sim.run(years=YEARS)
    return sim


def death_year(sim: object, person_id: str) -> int | None:
    for entry in sim.log.entries:
        if entry.event_type == "death" and entry.persons and entry.persons[0] == person_id:
            return entry.year
    return None


def person_line(sim: object, person_id: str) -> str:
    person = sim._person(person_id)
    return (
        f"`{person_id}` {person.name}: alive={person.alive}, death_year={death_year(sim, person_id)}, "
        f"charisma={person.charisma:.3f}, incoming_trust={sim._incoming_trust(person_id):.3f}, "
        f"memories={len(person.memories)}, bias=({person.interpretation_bias.get('spiritual', 0.0):.4f}, "
        f"{person.interpretation_bias.get('practical', 0.0):.4f}, "
        f"{person.interpretation_bias.get('blame', 0.0):.4f})"
    )


def format_edge(edge: PropagationEdge) -> str:
    return (
        f"Y{edge.year}: {edge.speaker_id} {edge.speaker_name} -> "
        f"{edge.listener_id} {edge.listener_name} "
        f"(source_role={edge.source_role}, gen={edge.generation}, "
        f"intensity={edge.intensity:.2f}, interpretation={edge.interpretation})"
    )


def write_report(v14: ModuleType, v15: ModuleType, sim: object) -> None:
    v14_summary = run_summary(v14)
    v15_summary = run_summary(v15)
    keys = [
        "final_population",
        "final_food_stock",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "avg_bias_spiritual",
        "avg_bias_practical",
        "avg_bias_blame",
        "birth_count",
        "death_count",
        "memory_shared_count",
    ]
    role_counts = Counter(edge.source_role for edge in sim.target_edges)
    speaker_counts = Counter(f"{edge.speaker_id} {edge.speaker_name}" for edge in sim.target_edges)
    proposer_edges = [edge for edge in sim.target_edges if edge.source_role == "proposer"]
    p006_edges = [edge for edge in sim.target_edges if edge.speaker_id == "p006"]

    lines: list[str] = []
    lines.append("# society_lab v1.5 private proposer memory analysis")
    lines.append("")
    lines.append(f"Seed: {SEED}")
    lines.append(f"Run length: {YEARS} years")
    lines.append("")
    lines.append("## Change")
    lines.append("")
    lines.append("- Proposers now remember their own project failures.")
    lines.append("- Proposer failure memories use `source_role=\"proposer\"`.")
    lines.append("- Proposer failure memories share at 35% of normal probability and to one trusted listener.")
    lines.append("- No new interpretation tag was added.")
    lines.append("")
    lines.append("## v1.4 vs v1.5 Summary")
    lines.append("")
    lines.append("```text")
    for key in keys:
        lines.append(f"{key}: {v14_summary.get(key)} -> {v15_summary.get(key)}")
    lines.append("```")
    lines.append("")
    lines.append("## Target Memory Propagation")
    lines.append("")
    lines.append(f"Target: `{TARGET_EVENT}` from Year {TARGET_MEMORY_YEAR}")
    lines.append("")
    lines.append(f"- Total target transmissions: {len(sim.target_edges)}")
    lines.append(f"- By source_role: {dict(role_counts)}")
    lines.append("")
    lines.append("Top speakers:")
    lines.append("")
    for label, count in speaker_counts.most_common(8):
        lines.append(f"- {label}: {count}")
    lines.append("")
    lines.append("Proposer-private transmissions:")
    lines.append("")
    if proposer_edges:
        for edge in proposer_edges:
            lines.append(f"- {format_edge(edge)}")
    else:
        lines.append("- none")
    lines.append("")
    lines.append("p006 transmissions of the target memory:")
    lines.append("")
    if p006_edges:
        for edge in p006_edges:
            lines.append(f"- {format_edge(edge)}")
    else:
        lines.append("- none")
    lines.append("")
    lines.append("## All Private Proposer Transmissions")
    lines.append("")
    lines.append(f"- Total private proposer transmissions: {len(sim.private_edges)}")
    lines.append("")
    if sim.private_edges:
        for edge in sim.private_edges:
            lines.append(f"- {format_edge(edge)}")
    else:
        lines.append("- none")
    lines.append("")
    lines.append("## p006 Profile")
    lines.append("")
    lines.append(f"- {person_line(sim, 'p006')}")
    lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "v1.5 fixes the odd v1.4 behavior where the proposer did not remember the failed project. "
        "The proposer now carries a stronger, private failure memory."
    )
    lines.append("")
    lines.append(
        "The important caution is that this is not a small observational change. Even after avoiding "
        "extra random interpretation draws for proposer memory, v1.5 changes several seed outcomes. "
        "So v1.5 should be treated as an experimental branch until more carefully calibrated."
    )
    lines.append("")
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    v14 = load_module("society_lab_v1_4", V14_PATH)
    v15 = load_module("society_lab_v1_5", V15_PATH)
    sim = run_instrumented(v15)
    write_report(v14, v15, sim)
    print(f"Wrote {REPORT_PATH}")
    print(f"target_edges={len(sim.target_edges)}")


if __name__ == "__main__":
    main()
