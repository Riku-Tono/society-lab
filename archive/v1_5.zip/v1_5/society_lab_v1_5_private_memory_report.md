# society_lab v1.5 private proposer memory analysis

Seed: 1003
Run length: 80 years

## Change

- Proposers now remember their own project failures.
- Proposer failure memories use `source_role="proposer"`.
- Proposer failure memories share at 35% of normal probability and to one trusted listener.
- No new interpretation tag was added.

## v1.4 vs v1.5 Summary

```text
final_population: 18 -> 19
final_food_stock: 227.336 -> 250.69
proposal_count: 23 -> 31
project_success_count: 3 -> 1
project_failure_count: 9 -> 7
shared_narrative_count: 45 -> 43
network_split_count: 4 -> 6
narrative_divergence_count: 16 -> 17
interpretation_divergence_count: 4 -> 4
avg_bias_spiritual: 0.117 -> 0.1005
avg_bias_practical: 0.1206 -> 0.106
avg_bias_blame: 0.1333 -> 0.1056
birth_count: 18 -> 19
death_count: 35 -> 35
memory_shared_count: 323 -> 296
```

## Target Memory Propagation

Target: `project_failure:store_food` from Year 14

- Total target transmissions: 0
- By source_role: {}

Top speakers:


Proposer-private transmissions:

- none

p006 transmissions of the target memory:

- none

## All Private Proposer Transmissions

- Total private proposer transmissions: 4

- Y12: p029 メイ -> p007 ファラ (source_role=proposer:project_failure:hold_ritual:Y2, gen=1, intensity=0.59, interpretation=blame)
- Y56: p014 セナ -> p007 ファラ (source_role=proposer:project_failure:store_food:Y53, gen=1, intensity=0.67, interpretation=practical)
- Y73: p043 ノア -> p040 イシュ (source_role=proposer:project_failure:store_food:Y54, gen=1, intensity=0.51, interpretation=practical)
- Y76: p043 ノア -> p040 イシュ (source_role=proposer:project_failure:store_food:Y54, gen=1, intensity=0.52, interpretation=practical)

## p006 Profile

- `p006` シオン: alive=False, death_year=56, charisma=0.521, incoming_trust=0.449, memories=12, bias=(0.0569, 0.1529, 0.1561)

## Reading

v1.5 fixes the odd v1.4 behavior where the proposer did not remember the failed project. The proposer now carries a stronger, private failure memory.

The important caution is that this is not a small observational change. Even after avoiding extra random interpretation draws for proposer memory, v1.5 changes several seed outcomes. So v1.5 should be treated as an experimental branch until more carefully calibrated.
