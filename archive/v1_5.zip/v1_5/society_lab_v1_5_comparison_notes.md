# society_lab v1.5 comparison notes

## Change

v1.5 adds `source_role` to memories and gives project proposers a private failure memory.

The proposer failure memory:

- is stronger than supporter failure memory
- uses `source_role="proposer"`
- shares at 35% of normal probability
- shares with only one trusted listener
- does not add a new interpretation tag

## Main Finding

The concept is good, but the branch is not neutral.

Even after avoiding extra random interpretation draws for proposer memory, v1.5 changes several seed outcomes. This means v1.5 should be treated as an experimental branch, not as a quiet patch over v1.4.

## Seed 1003

```text
final_population: 18 -> 19
final_food_stock: 227.336 -> 250.69
proposal_count: 23 -> 31
project_success_count: 3 -> 1
project_failure_count: 9 -> 7
network_split_count: 4 -> 6
avg_bias_blame: 0.1333 -> 0.1056
birth_count: 18 -> 19
memory_shared_count: 323 -> 296
```

The old v1.4 Year14 `project_failure:store_food` memory does not exist in the same form in v1.5. The first v1.4/v1.5 log difference appears much earlier, at Year2:

```text
v1.4: Y02 p029 -> p007 shares project_failure:hold_ritual
v1.5: Y02 p031 -> p033 shares project_failure:hold_ritual
```

So v1.5 is not directly comparable as "v1.4 plus p006 remembering the same Year14 failure." It creates a different early history.

## Private Proposer Transmission Check

In seed 1003, private proposer memories were shared only 4 times:

```text
Y12: p029 -> p007, project_failure:hold_ritual from Year2
Y56: p014 -> p007, project_failure:store_food from Year53
Y73: p043 -> p040, project_failure:store_food from Year54
Y76: p043 -> p040, project_failure:store_food from Year54
```

This suggests the privacy rule is working. Proposer failure memories do not become public rumor easily.

## Reading

v1.5 is conceptually strong:

> proposers remember failure, but mostly privately.

But it is also dynamically strong:

> adding private proposer memory changes the early memory ecology.

The safe conclusion is:

> v1.5 is worth keeping as an experimental branch, but v1.4 remains the stable interpretation-analysis baseline.

