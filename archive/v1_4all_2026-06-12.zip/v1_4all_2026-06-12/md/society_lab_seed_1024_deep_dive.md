# society_lab seed 1024 deep dive

Focus: why v1.3 collapses while v1.4 survives with higher population.

## First Log Difference

```text
v1.3: Y38 proposal_supported [p004,p014] サナ supported move_camp
v1.4: Y38 proposal_supported [p004,p008] サナ supported store_food
```

## Yearly Delta

| year | pop | food | birth | death | failure | memshare | blame |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 23->23 (+0) | 31.579->31.579 (+0.000) | 3->3 (+0) | 0->0 (+0) | 0->0 (+0) | 3->3 (+0) | 0.111->0.111 (+0.000) |
| 20 | 23->23 (+0) | 38.137->38.137 (+0.000) | 3->3 (+0) | 0->0 (+0) | 0->0 (+0) | 41->41 (+0) | 0.116->0.116 (+0.000) |
| 30 | 23->23 (+0) | 54.691->54.691 (+0.000) | 5->5 (+0) | 2->2 (+0) | 2->2 (+0) | 77->77 (+0) | 0.120->0.120 (+0.000) |
| 38 | 22->23 (+1) | 69.657->69.657 (+0.000) | 6->6 (+0) | 4->3 (-1) | 3->3 (+0) | 113->112 (-1) | 0.121->0.119 (-0.002) |
| 40 | 21->21 (+0) | 65.881->70.297 (+4.416) | 6->6 (+0) | 5->5 (+0) | 3->3 (+0) | 118->116 (-2) | 0.122->0.126 (+0.003) |
| 45 | 21->22 (+1) | 59.990->64.558 (+4.568) | 6->9 (+3) | 5->7 (+2) | 3->3 (+0) | 138->139 (+1) | 0.122->0.123 (+0.001) |
| 50 | 18->22 (+4) | 53.998->46.740 (-7.258) | 6->10 (+4) | 8->8 (+0) | 4->3 (-1) | 165->149 (-16) | 0.132->0.122 (-0.010) |
| 55 | 17->20 (+3) | 52.182->19.893 (-32.289) | 6->10 (+4) | 9->10 (+1) | 4->4 (+0) | 179->158 (-21) | 0.133->0.120 (-0.013) |
| 60 | 13->18 (+5) | 63.615->38.967 (-24.648) | 6->10 (+4) | 13->12 (-1) | 4->4 (+0) | 186->172 (-14) | 0.138->0.117 (-0.020) |
| 65 | 11->19 (+8) | 77.806->58.203 (-19.603) | 6->13 (+7) | 15->14 (-1) | 4->4 (+0) | 194->176 (-18) | 0.132->0.123 (-0.009) |
| 70 | 9->20 (+11) | 118.771->66.494 (-52.277) | 6->17 (+11) | 17->17 (+0) | 4->4 (+0) | 198->187 (-11) | 0.136->0.119 (-0.017) |
| 75 | 9->20 (+11) | 154.128->70.427 (-83.701) | 6->19 (+13) | 17->19 (+2) | 4->4 (+0) | 201->195 (-6) | 0.136->0.114 (-0.022) |
| 80 | 7->19 (+12) | 191.765->86.711 (-105.054) | 6->19 (+13) | 19->20 (+1) | 4->4 (+0) | 205->200 (-5) | 0.135->0.113 (-0.022) |

First year with population/birth gap >= 4: Year 46

## Window Diffs

### Years 38-45

| event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| birth | 0 | 3 | 3 |
| death | 2 | 4 | 2 |

Project result differences:
| project event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |

Memory-share differences:
| memory event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| project_success:dig_well | 13 | 8 | -5 |
| project_success:store_food | 3 | 7 | 4 |
| death | 6 | 8 | 2 |
| project_failure:dig_well | 5 | 4 | -1 |
| project_failure:move_camp | 1 | 2 | 1 |

### Years 46-55

| event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| birth | 0 | 1 | 1 |
| death | 4 | 3 | -1 |

Project result differences:
| project event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| project_failure:hold_ritual:water_shortage | 0 | 1 | 1 |
| project_failure:dig_well:water_shortage | 1 | 0 | -1 |

Memory-share differences:
| memory event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| project_success:dig_well | 11 | 0 | -11 |
| death | 15 | 10 | -5 |
| project_success:store_food | 10 | 5 | -5 |
| project_failure:hold_ritual | 0 | 3 | 3 |
| project_failure:move_camp | 4 | 1 | -3 |
| project_failure:dig_well | 1 | 0 | -1 |

### Years 56-70

| event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| birth | 0 | 7 | 7 |
| death | 8 | 7 | -1 |

Project result differences:
| project event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| project_success:store_food:water_shortage | 0 | 1 | 1 |

Memory-share differences:
| memory event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| project_success:store_food | 0 | 9 | 9 |
| project_success:dig_well | 7 | 0 | -7 |
| death | 12 | 18 | 6 |
| project_failure:hold_ritual | 0 | 2 | 2 |

### Years 71-80

| event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| birth | 0 | 2 | 2 |
| death | 2 | 3 | 1 |

Project result differences:
| project event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |

Memory-share differences:
| memory event | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| death | 3 | 10 | 7 |
| project_success:dig_well | 4 | 0 | -4 |
| project_success:store_food | 0 | 3 | 3 |

## Event Windows

### v1.3 Years 38-42

```text
Y38 problem_detected [] storage_damage severity=0.31
Y38 council_formed [] council_formed: problems=storage_damage
Y38 proposal_made [p008] ルト proposed store_food for storage_damage
Y38 proposal_made [p014] レン proposed move_camp for storage_damage
Y38 proposal_supported [p001,p014] ハナ supported move_camp
Y38 proposal_supported [p004,p014] サナ supported move_camp
Y38 proposal_supported [p005,p008] ミラ supported store_food
Y38 proposal_supported [p006,p014] ダン supported move_camp
Y38 proposal_supported [p007,p014] リオ supported move_camp
Y38 proposal_supported [p011,p014] ルト supported move_camp
Y38 proposal_supported [p013,p014] シオン supported move_camp
Y38 proposal_supported [p014,p008] レン supported store_food
Y38 proposal_supported [p015,p014] エリン supported move_camp
Y38 proposal_supported [p021,p014] タロ supported move_camp
Y38 proposal_supported [p024,p014] ユラ supported move_camp
Y38 project_started [p014,p001,p004,p006,p007,p011,p013,p015,p021,p024] project_started: move_camp for storage_damage supporters=9
Y38 project_failure [p014,p001,p004,p006,p007,p011,p013,p015,p021,p024] project_failure: move_camp for storage_damage chance=0.74
Y38 memory_shared [p009,p006] オルン told ダン about death intensity=0.67 generation=2
Y38 memory_shared [p017,p009] セナ told オルン about death intensity=0.68 generation=1
Y38 memory_shared [p021,p001] タロ told ハナ about project_success:dig_well intensity=0.78 generation=5
Y38 death [p007] リオ died age=88 health=1.00
Y38 shared_narrative [p001,p004,p006,p011,p013,p015,p021,p024] shared_narrative detected: project_failure:move_camp, 8 persons, avg_intensity 0.55
Y38 narrative_divergence [] narrative_divergence: project_success:dig_well, versions 0.37 vs 0.82
Y39 memory_shared [p005,p020] ミラ told オルン about project_success:store_food intensity=0.50 generation=1
Y39 memory_shared [p011,p014] ルト told レン about project_success:dig_well intensity=0.98 generation=6
Y39 memory_shared [p014,p011] レン told ルト about project_success:dig_well intensity=1.00 generation=7
Y39 shared_narrative [p000,p001,p002,p003,p004,p006,p008,p009,p011,p014,p015,p016,p019,p020,p021] shared_narrative detected: project_success:dig_well, 15 persons, avg_intensity 0.60
Y39 shared_narrative [p001,p002,p003,p004,p005,p008,p009,p014,p015,p017,p019,p020,p021,p022] shared_narrative detected: project_failure:dig_well, 14 persons, avg_intensity 0.53
Y40 memory_shared [p001,p021] ハナ told タロ about project_success:dig_well intensity=1.00 generation=6
Y40 memory_shared [p005,p020] ミラ told オルン about project_success:store_food intensity=0.57 generation=1
Y40 death [p011] ルト died age=86 health=1.00
Y41 memory_shared [p004,p019] サナ told タロ about project_failure:dig_well intensity=0.58 generation=3
Y41 memory_shared [p004,p003] サナ told イシュ about project_failure:dig_well intensity=0.62 generation=3
Y41 memory_shared [p008,p003] ルト told イシュ about death intensity=0.57 generation=1
Y41 memory_shared [p013,p003] シオン told イシュ about death intensity=0.63 generation=1
Y41 memory_shared [p019,p004] タロ told サナ about project_failure:dig_well intensity=0.69 generation=4
Y41 memory_shared [p019,p014] タロ told レン about project_failure:dig_well intensity=0.62 generation=4
Y41 memory_shared [p024,p002] ユラ told レン about project_failure:move_camp intensity=0.50 generation=1
Y41 shared_narrative [p003,p006,p009,p013,p014,p016,p017,p019] shared_narrative detected: project_success:move_camp, 8 persons, avg_intensity 0.39
Y42 memory_shared [p001,p021] ハナ told タロ about project_success:dig_well intensity=1.00 generation=6
Y42 memory_shared [p006,p003] ダン told イシュ about death intensity=0.70 generation=3
Y42 shared_narrative [p000,p001,p003,p004,p005,p006,p008,p009,p013,p014,p015,p016,p017,p019,p020,p023] shared_narrative detected: death, 16 persons, avg_intensity 0.56
```

### v1.4 Years 38-42

```text
Y38 problem_detected [] storage_damage severity=0.31
Y38 council_formed [] council_formed: problems=storage_damage
Y38 proposal_made [p008] ルト proposed store_food for storage_damage
Y38 proposal_made [p014] レン proposed move_camp for storage_damage
Y38 proposal_supported [p001,p014] ハナ supported move_camp
Y38 proposal_supported [p004,p008] サナ supported store_food
Y38 proposal_supported [p005,p008] ミラ supported store_food
Y38 proposal_supported [p006,p014] ダン supported move_camp
Y38 proposal_supported [p007,p014] リオ supported move_camp
Y38 proposal_supported [p011,p014] ルト supported move_camp
Y38 proposal_supported [p013,p014] シオン supported move_camp
Y38 proposal_supported [p014,p008] レン supported store_food
Y38 proposal_supported [p015,p014] エリン supported move_camp
Y38 proposal_supported [p021,p014] タロ supported move_camp
Y38 proposal_supported [p024,p014] ユラ supported move_camp
Y38 project_started [p014,p001,p006,p007,p011,p013,p015,p021,p024] project_started: move_camp for storage_damage supporters=8
Y38 project_failure [p014,p001,p006,p007,p011,p013,p015,p021,p024] project_failure: move_camp for storage_damage chance=0.73
Y38 memory_shared [p011,p014] ルト told レン about project_success:dig_well intensity=0.85 generation=6
Y38 memory_shared [p024,p002] ユラ told レン about project_failure:move_camp intensity=0.60 generation=1
Y38 shared_narrative [p001,p002,p006,p007,p011,p013,p015,p021,p024] shared_narrative detected: project_failure:move_camp, 9 persons, avg_intensity 0.55
Y38 narrative_divergence [] narrative_divergence: project_success:dig_well, versions 0.37 vs 0.83
Y39 memory_shared [p006,p003] ダン told イシュ about death intensity=0.57 generation=3
Y39 memory_shared [p017,p009] セナ told オルン about death intensity=0.57 generation=1
Y39 memory_shared [p019,p004] タロ told サナ about project_failure:dig_well intensity=0.61 generation=2
Y39 death [p004] サナ died age=82 health=1.00
Y39 shared_narrative [p000,p001,p002,p003,p006,p007,p008,p009,p011,p014,p015,p016,p019,p020,p021] shared_narrative detected: project_success:dig_well, 15 persons, avg_intensity 0.59
Y39 shared_narrative [p001,p002,p003,p005,p007,p008,p009,p014,p015,p017,p019,p020,p021,p022] shared_narrative detected: project_failure:dig_well, 14 persons, avg_intensity 0.52
Y40 memory_shared [p003,p002] イシュ told レン about project_failure:dig_well intensity=0.89 generation=4
Y40 death [p015] エリン died age=85 health=1.00
Y41 memory_shared [p014,p011] レン told ルト about project_success:dig_well intensity=0.95 generation=7
Y41 memory_shared [p022,p001] ヴァル told ハナ about project_failure:dig_well intensity=0.41 generation=1
Y41 memory_shared [p022,p021] ヴァル told タロ about project_failure:dig_well intensity=0.42 generation=1
Y41 memory_shared [p023,p008] ノア told ルト about project_success:store_food intensity=0.75 generation=1
Y41 shared_narrative [p003,p006,p009,p013,p014,p016,p017,p019] shared_narrative detected: project_success:move_camp, 8 persons, avg_intensity 0.39
Y42 memory_shared [p005,p020] ミラ told オルン about project_success:store_food intensity=0.56 generation=1
Y42 memory_shared [p008,p003] ルト told イシュ about project_success:store_food intensity=0.84 generation=2
Y42 memory_shared [p016,p008] ハナ told ルト about death intensity=0.60 generation=1
Y42 birth [p021,p026] タロ had a child: ケイ
Y42 shared_narrative [p000,p001,p002,p003,p005,p006,p007,p008,p009,p011,p013,p014,p016,p017,p019,p020] shared_narrative detected: death, 16 persons, avg_intensity 0.56
Y42 shared_narrative [p003,p005,p008,p013,p014,p020,p023] shared_narrative detected: project_success:store_food, 7 persons, avg_intensity 0.62
```

### v1.3 Years 50-55

```text
Y50 problem_detected [] water_shortage severity=0.26
Y50 council_formed [] council_formed: problems=water_shortage
Y50 proposal_made [p008] ルト proposed dig_well for water_shortage
Y50 proposal_supported [p001,p008] ハナ supported dig_well
Y50 proposal_supported [p008,p008] ルト supported dig_well
Y50 proposal_supported [p013,p008] シオン supported dig_well
Y50 proposal_supported [p016,p008] ハナ supported dig_well
Y50 project_started [p008,p001,p008,p013,p016] project_started: dig_well for water_shortage supporters=4
Y50 project_failure [p008,p001,p008,p013,p016] project_failure: dig_well for water_shortage chance=0.40
Y50 memory_shared [p001,p021] ハナ told タロ about project_success:dig_well intensity=0.68 generation=6
Y50 memory_shared [p021,p001] タロ told ハナ about project_success:dig_well intensity=1.00 generation=7
Y50 memory_shared [p024,p002] ユラ told レン about project_failure:move_camp intensity=0.46 generation=1
Y50 memory_shared [p024,p013] ユラ told シオン about project_failure:move_camp intensity=0.37 generation=1
Y50 death [p004] サナ died age=93 health=1.00
Y50 shared_narrative [p003,p005,p008,p013,p020,p023] shared_narrative detected: project_success:store_food, 6 persons, avg_intensity 0.55
Y51 memory_shared [p001,p021] ハナ told タロ about project_success:dig_well intensity=1.00 generation=8
Y51 memory_shared [p001,p022] ハナ told ヴァル about project_success:dig_well intensity=1.00 generation=8
Y51 memory_shared [p013,p003] シオン told イシュ about project_success:dig_well intensity=0.78 generation=6
Y51 memory_shared [p017,p009] セナ told オルン about death intensity=0.51 generation=1
Y51 memory_shared [p023,p008] ノア told ルト about project_success:store_food intensity=0.57 generation=3
Y52 memory_shared [p006,p003] ダン told イシュ about death intensity=0.66 generation=3
Y52 memory_shared [p008,p023] ルト told ノア about project_success:store_food intensity=0.61 generation=2
Y52 memory_shared [p009,p006] オルン told ダン about death intensity=0.48 generation=2
Y52 death [p001] ハナ died age=84 health=1.00
Y52 shared_narrative [p000,p002,p003,p005,p006,p008,p009,p013,p016,p017,p019,p020,p021,p022,p023,p024,p025] shared_narrative detected: death, 17 persons, avg_intensity 0.55
Y52 narrative_divergence [] narrative_divergence: death, versions 0.34 vs 0.74
Y53 memory_shared [p003,p002] イシュ told レン about project_success:dig_well intensity=0.80 generation=6
Y53 memory_shared [p005,p020] ミラ told オルン about project_success:store_food intensity=0.43 generation=1
Y53 memory_shared [p008,p023] ルト told ノア about project_success:store_food intensity=0.66 generation=2
Y53 narrative_divergence [] narrative_divergence: project_success:dig_well, versions 0.33 vs 0.81
Y54 memory_shared [p006,p003] ダン told イシュ about death intensity=0.52 generation=3
Y54 shared_narrative [p000,p002,p003,p006,p008,p009,p013,p019,p020,p021,p022] shared_narrative detected: project_success:dig_well, 11 persons, avg_intensity 0.59
Y54 shared_narrative [p002,p003,p005,p008,p009,p013,p016,p017,p019,p020,p021,p022] shared_narrative detected: project_failure:dig_well, 12 persons, avg_intensity 0.45
Y55 memory_shared [p002,p003] レン told イシュ about project_success:dig_well intensity=0.74 generation=7
Y55 memory_shared [p025,p021] ゾル told タロ about death intensity=0.51 generation=1
Y55 shared_narrative [p003,p005,p008,p013,p020,p023] shared_narrative detected: project_success:store_food, 6 persons, avg_intensity 0.51
```

### v1.4 Years 50-55

```text
Y50 memory_shared [p013,p003] シオン told イシュ about death intensity=0.68 generation=1
Y51 problem_detected [] water_shortage severity=0.62
Y51 council_formed [] council_formed: problems=water_shortage
Y51 proposal_made [p003] イシュ proposed hold_ritual for water_shortage
Y51 proposal_made [p000] サナ proposed dig_well for water_shortage
Y51 proposal_made [p024] ユラ proposed move_camp for water_shortage
Y51 proposal_supported [p003,p024] イシュ supported move_camp
Y51 proposal_supported [p005,p003] ミラ supported hold_ritual
Y51 proposal_supported [p006,p003] ダン supported hold_ritual
Y51 proposal_supported [p022,p003] ヴァル supported hold_ritual
Y51 proposal_supported [p024,p003] ユラ supported hold_ritual
Y51 project_started [p003,p005,p006,p022,p024] project_started: hold_ritual for water_shortage supporters=4
Y51 project_failure [p003,p005,p006,p022,p024] project_failure: hold_ritual for water_shortage chance=0.46
Y51 authority_pattern [p003] authority_pattern: イシュ repeated support/success successes=2 supports=28
Y51 memory_shared [p003,p002] イシュ told レン about project_success:store_food intensity=0.78 generation=3
Y51 memory_shared [p023,p008] ノア told ルト about project_success:store_food intensity=0.62 generation=1
Y51 shared_narrative [p002,p003,p005,p008,p013,p020,p023] shared_narrative detected: project_success:store_food, 7 persons, avg_intensity 0.57
Y52 shared_narrative [p000,p001,p002,p003,p005,p006,p008,p009,p013,p016,p017,p019,p020,p021,p022,p023] shared_narrative detected: death, 16 persons, avg_intensity 0.50
Y53 memory_shared [p005,p020] ミラ told オルン about project_failure:hold_ritual intensity=0.69 generation=1
Y53 memory_shared [p024,p002] ユラ told レン about project_failure:hold_ritual intensity=0.70 generation=1
Y53 death [p001] ハナ died age=85 health=1.00
Y53 death [p005] ミラ died age=80 health=1.00
Y53 network_split [] network_split detected: cluster sizes [12, 4]
Y53 narrative_divergence [] narrative_divergence: death, versions 0.33 vs 0.74
Y53 interpretation_divergence [] interpretation_divergence: death -> {'spiritual': 15, 'practical': 11, 'blame': 11}
Y54 memory_shared [p027,p020] ヴァル told オルン about death intensity=0.51 generation=1
Y54 memory_shared [p029,p021] ファラ told タロ about death intensity=0.51 generation=1
Y54 shared_narrative [p000,p002,p003,p006,p008,p009,p019,p020,p021,p022] shared_narrative detected: project_success:dig_well, 10 persons, avg_intensity 0.44
Y54 shared_narrative [p002,p003,p008,p009,p017,p019,p020,p021,p022] shared_narrative detected: project_failure:dig_well, 9 persons, avg_intensity 0.43
Y55 memory_shared [p006,p003] ダン told イシュ about project_failure:hold_ritual intensity=0.64 generation=1
Y55 memory_shared [p023,p008] ノア told ルト about project_success:store_food intensity=0.55 generation=1
Y55 memory_shared [p028,p020] ダン told オルン about death intensity=0.57 generation=1
```

### v1.3 Years 60-65

```text
Y60 memory_shared [p006,p003] ダン told イシュ about death intensity=0.58 generation=3
Y60 memory_shared [p006,p002] ダン told レン about death intensity=0.43 generation=3
Y60 death [p019] タロ died age=101 health=1.00
Y61 problem_detected [] water_shortage severity=0.63
Y61 council_formed [] council_formed: problems=water_shortage
Y61 proposal_made [p021] タロ proposed dig_well for water_shortage
Y61 proposal_made [p008] ルト proposed hold_ritual for water_shortage
Y61 proposal_supported [p022,p021] ヴァル supported dig_well
Y61 memory_shared [p006,p003] ダン told イシュ about death intensity=0.38 generation=3
Y61 memory_shared [p008,p023] ルト told ノア about death intensity=0.58 generation=1
Y61 death [p016] ハナ died age=81 health=1.00
Y62 problem_detected [] water_shortage severity=0.49
Y62 council_formed [] council_formed: problems=water_shortage
Y62 proposal_made [p013] シオン proposed hold_ritual for water_shortage
Y62 proposal_supported [p022,p013] ヴァル supported hold_ritual
Y62 proposal_supported [p024,p013] ユラ supported hold_ritual
Y62 memory_shared [p008,p023] ルト told ノア about death intensity=0.66 generation=1
Y62 memory_shared [p025,p021] ゾル told タロ about project_success:dig_well intensity=0.30 generation=10
Y62 shared_narrative [p002,p003,p006,p008,p013,p017,p020,p021,p022,p023,p025] shared_narrative detected: death, 11 persons, avg_intensity 0.58
Y63 memory_shared [p002,p003] レン told イシュ about project_success:dig_well intensity=0.98 generation=7
Y63 memory_shared [p008,p023] ルト told ノア about death intensity=0.65 generation=1
Y63 memory_shared [p023,p008] ノア told ルト about death intensity=0.59 generation=2
Y63 death [p006] ダン died age=100 health=1.00
Y63 narrative_divergence [] narrative_divergence: project_success:dig_well, versions 0.30 vs 0.80
Y64 shared_narrative [p002,p003,p013,p021,p022,p025] shared_narrative detected: project_success:dig_well, 6 persons, avg_intensity 0.68
Y64 shared_narrative [p003,p008,p013,p017,p020,p021] shared_narrative detected: project_failure:dig_well, 6 persons, avg_intensity 0.36
Y65 problem_detected [] water_shortage severity=0.44
Y65 council_formed [] council_formed: problems=water_shortage
Y65 proposal_made [p025] ゾル proposed hold_ritual for water_shortage
Y65 proposal_made [p002] レン proposed dig_well for water_shortage
Y65 proposal_supported [p024,p002] ユラ supported dig_well
Y65 proposal_supported [p025,p025] ゾル supported hold_ritual
Y65 memory_shared [p025,p021] ゾル told タロ about project_success:dig_well intensity=0.76 generation=10
```

### v1.4 Years 60-65

```text
Y61 problem_detected [] water_shortage severity=0.28
Y61 council_formed [] council_formed: problems=water_shortage
Y61 proposal_made [p002] レン proposed move_camp for water_shortage
Y61 proposal_made [p021] タロ proposed store_food for water_shortage
Y61 proposal_made [p025] ゾル proposed dig_well for water_shortage
Y61 proposal_supported [p013,p021] シオン supported store_food
Y61 proposal_supported [p019,p021] タロ supported store_food
Y61 proposal_supported [p020,p021] オルン supported store_food
Y61 proposal_supported [p023,p025] ノア supported dig_well
Y61 proposal_supported [p029,p021] ファラ supported store_food
Y61 project_started [p021,p013,p019,p020,p029] project_started: store_food for water_shortage supporters=4
Y61 project_success [p021,p013,p019,p020,p029] project_success: store_food for water_shortage chance=0.47
Y61 death [p019] タロ died age=102 health=1.00
Y61 birth [p026,p030] ケイ had a child: ヴァル
Y61 network_split [] network_split detected: cluster sizes [8, 5]
Y62 memory_shared [p003,p002] イシュ told レン about project_success:store_food intensity=0.76 generation=5
Y62 memory_shared [p016,p008] ハナ told ルト about death intensity=0.41 generation=1
Y62 memory_shared [p023,p008] ノア told ルト about project_success:store_food intensity=0.46 generation=1
Y62 death [p000] サナ died age=90 health=1.00
Y62 birth [p024,p031] ユラ had a child: ゾル
Y62 shared_narrative [p002,p003,p008,p013,p016,p017,p020,p021,p022,p025,p026,p027,p028,p029] shared_narrative detected: death, 14 persons, avg_intensity 0.55
Y63 shared_narrative [p002,p003,p008,p013,p020,p023,p029] shared_narrative detected: project_success:store_food, 7 persons, avg_intensity 0.61
Y65 memory_shared [p025,p021] ゾル told タロ about death intensity=0.41 generation=1
Y65 birth [p028,p032] ダン had a child: ヴァル
Y65 network_split [] network_split detected: cluster sizes [8, 5, 4]
```

## Reading

Seed 1024 should not be treated as a simple first-diff project-memory case. The first support difference does not clearly enter a project in the same year. The important divergence is delayed: v1.3 loses births and population after the middle years, while v1.4 maintains a larger living population.

The window tables are the main evidence. If the birth/death gap opens without a matching project-memory path, 1024 belongs in a different `collapse avoidance` family rather than the 1003/1043 failure-memory family.