# society_lab seed 1003 extra supporter trace

Version: v1.4
Seed: 1003
Target event: Year 14, `store_food` for `water_shortage`

## Result

The extra supporter in v1.4 is:

```text
p019 ハナ
```

Year 14 support comparison:

```text
v1.3 supporters:
p001, p002, p011, p021, p024, p027, p031, p032, p034, p035

v1.4 supporters:
p001, p002, p011, p019, p021, p024, p027, p031, p032, p034, p035
```

So the first visible branch is not a mysterious mass shift. It is one additional supporter:

```text
p019 ハナ supported store_food
```

## p019 Profile

```text
name: ハナ
death_year: 28
final_age: 86
charisma: 0.478
food_skill: 0.559
incoming_trust: 0.0
trust_links: 8
final memory_count: 3
bias_spiritual: 0.0539
bias_practical: 0.1360
bias_blame: 0.1797
```

p019 does not look like a leader or social hub. Incoming trust is 0.0, charisma is moderate, and she dies relatively early in Year 28.

## Post-Year-14 Activity

```text
events_involved: 13
memory_shared_as_speaker: 3
memory_shared_as_listener: 0
proposal_supported_as_supporter: 1
project_started_participant: 1
project_failure_participant: 1
death_self: 1
```

Relevant events:

```text
Y14 proposal_supported [p019,p006] ハナ supported store_food
Y14 project_started [...,p019,...] project_started: store_food for water_shortage supporters=11
Y14 project_failure [...,p019,...] project_failure: store_food for water_shortage chance=0.60
Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1
Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1
Y28 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.48 generation=1
Y28 death [p019] ハナ died age=86 health=1.00
```

## Reading

p019 was probably not a great-person hinge.

The safer reading is:

> The extra supporter mattered because she became one more carrier of the failed store_food memory.

She later shared that failure memory three times, including twice with p004. That does not prove she caused the whole contraction, but it does show that the Year 14 difference was not merely cosmetic.

The branch has this shape:

```text
weak interpretation nudge
-> one extra supporter
-> one extra participant in failure
-> one extra memory carrier
-> several later memory transmissions
-> different event path and population trajectory
```

This supports a non-heroic reading of the model.

The important thing is not that p019 was special. The important thing is that participation changes memory ownership.

