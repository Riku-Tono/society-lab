# p013 to p030 trace seed 1003

## Overview

- relay roles: ['death_memory_holder', 'interpretation_moved_supporter', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer', 'supporter']
- memories received from source: 12
- relay transmissions to third people: 14
- interpretation changes after relay: 1
- third person counts: [('p007', 5), ('p026', 3), ('p037', 3), ('p029', 2), ('p016', 1)]

## Memories Received From Source

| year | memory_id | parent_memory_id | event | intensity | generation | interpretation |
| --- | --- | --- | --- | --- | --- | --- |
| 8 | m00042 | m00026 | project_failure:hold_ritual | 0.5388 | 3 | blame |
| 13 | m00069 | m00066 | project_failure:hold_ritual | 0.6335 | 3 | practical |
| 16 | m00110 | m00066 | project_failure:hold_ritual | 0.6489 | 3 | practical |
| 22 | m00139 | m00120 | project_failure:store_food | 0.7761 | 3 | practical |
| 33 | m00250 | m00161 | death | 0.5423 | 1 | practical |
| 34 | m00257 | m00161 | death | 0.5558 | 1 | practical |
| 36 | m00284 | m00271 | death | 0.7795 | 3 | blame |
| 37 | m00290 | m00271 | death | 0.7815 | 3 | blame |
| 42 | m00372 | m00317 | death | 0.7397 | 1 | blame |
| 49 | m00464 | m00379 | death | 0.6801 | 1 | blame |
| 52 | m00481 | m00379 | death | 0.6724 | 1 | blame |
| 59 | m00537 | m00379 | death | 0.4392 | 1 | practical |

## Rooted Received Summary

| root_memory_id | root_event | root_year | root_interpretation | received_memory_id | received_year | received_interpretation | branch_events_from_relay | third_person_events | third_person_holders | max_depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00042 | 8 | blame | 1 | 0 | [] | 0 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00069 | 13 | practical | 1 | 0 | [] | 0 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00110 | 16 | practical | 14 | 13 | ['p007', 'p016', 'p026', 'p029', 'p037'] | 6 |
| m00080 | project_failure:store_food | 14 | practical | m00139 | 22 | practical | 2 | 1 | ['p026'] | 1 |
| m00161 | death | 24 | practical | m00250 | 33 | practical | 1 | 0 | [] | 0 |
| m00161 | death | 24 | practical | m00257 | 34 | practical | 1 | 0 | [] | 0 |
| m00230 | death | 31 | blame | m00284 | 36 | blame | 1 | 0 | [] | 0 |
| m00230 | death | 31 | blame | m00290 | 37 | blame | 1 | 0 | [] | 0 |
| m00317 | death | 39 | blame | m00372 | 42 | blame | 1 | 0 | [] | 0 |
| m00379 | death | 42 | blame | m00464 | 49 | blame | 1 | 0 | [] | 0 |
| m00379 | death | 42 | blame | m00481 | 52 | blame | 1 | 0 | [] | 0 |
| m00379 | death | 42 | blame | m00537 | 59 | practical | 1 | 0 | [] | 0 |

## Relay Transmissions To Third People

| root_memory_id | received_memory_id | memory_id | year | event | holder_id | source_id | interpretation | depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | m00110 | m00112 | 16 | project_failure:hold_ritual | p026 | p030 | practical | 1 |
| m00011 | m00110 | m00119 | 18 | project_failure:hold_ritual | p026 | p030 | practical | 1 |
| m00011 | m00110 | m00125 | 19 | project_failure:hold_ritual | p016 | p026 | practical | 2 |
| m00011 | m00110 | m00234 | 32 | project_failure:hold_ritual | p029 | p016 | practical | 3 |
| m00011 | m00110 | m00308 | 39 | project_failure:hold_ritual | p029 | p016 | practical | 3 |
| m00011 | m00110 | m00251 | 33 | project_failure:hold_ritual | p007 | p029 | practical | 4 |
| m00011 | m00110 | m00457 | 48 | project_failure:hold_ritual | p007 | p029 | practical | 4 |
| m00011 | m00110 | m00283 | 36 | project_failure:hold_ritual | p037 | p007 | practical | 5 |
| m00011 | m00110 | m00468 | 50 | project_failure:hold_ritual | p037 | p007 | spiritual | 5 |
| m00011 | m00110 | m00534 | 58 | project_failure:hold_ritual | p037 | p007 | practical | 5 |
| m00011 | m00110 | m00311 | 39 | project_failure:hold_ritual | p007 | p037 | practical | 6 |
| m00011 | m00110 | m00386 | 43 | project_failure:hold_ritual | p007 | p037 | practical | 6 |
| m00011 | m00110 | m00458 | 48 | project_failure:hold_ritual | p007 | p037 | practical | 6 |
| m00080 | m00139 | m00169 | 26 | project_failure:store_food | p026 | p030 | practical | 1 |

## Interpretation Changes After Relay

| root_memory_id | from_memory_id | to_memory_id | year | holder_id | from_interpretation | to_interpretation | depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | m00110 | m00468 | 50 | p037 | practical | spiritual | 5 |

## Relay Support Near Source Memories Within 5 Years

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance | nearest_memory_gap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 11 | p030 | p001 | hold_ritual | storage_damage | 0.0 | 0.2428 | 2 |
| 15 | p008 | p030 | store_food | storage_damage | 0.0 | 0.2614 | 1 |
| 15 | p009 | p030 | store_food | storage_damage | 0.0 | 0.3617 | 1 |
| 15 | p011 | p030 | store_food | storage_damage | 0.0 | 0.2688 | 1 |
| 15 | p016 | p030 | store_food | storage_damage | 0.0 | 0.2685 | 1 |
| 15 | p017 | p030 | store_food | storage_damage | 0.0 | 0.2199 | 1 |
| 15 | p024 | p030 | store_food | storage_damage | 0.0 | 0.2884 | 1 |
| 15 | p030 | p030 | store_food | storage_damage | 0.0 | 0.237 | 1 |
| 15 | p032 | p030 | store_food | storage_damage | 0.0 | 0.2777 | 1 |
| 15 | p033 | p030 | store_food | storage_damage | 0.03 | 0.2522 | 1 |
| 15 | p034 | p030 | store_food | storage_damage | 0.0 | 0.265 | 1 |
| 15 | p037 | p030 | store_food | storage_damage | 0.0 | 0.2743 | 1 |
| 33 | p030 | p006 | dig_well | water_shortage | 0.03 | 0.2637 | 0 |
| 47 | p030 | p006 | move_camp | water_shortage | 0.03 | 0.2376 | 2 |
| 48 | p030 | p029 | store_food | storage_damage | 0.03 | 0.2823 | 1 |

## Relay Biography Focus

| year | bio_event | memory_id | parent_memory_id | speaker_id | listener_id | event | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 8 | memory_received | m00042 | m00026 | p013 |  | project_failure:hold_ritual |  |  |  |  |
| 11 | proposal_supported |  |  |  |  |  | p001 | hold_ritual | storage_damage | 0.0 |
| 13 | memory_received | m00069 | m00066 | p013 |  | project_failure:hold_ritual |  |  |  |  |
| 15 | proposal_supported |  |  |  |  |  | p030 | store_food | storage_damage | 0.0 |
| 15 | project_started |  |  |  |  |  | p030 | store_food | storage_damage |  |
| 15 | project_started |  |  |  |  |  | p030 | store_food | storage_damage |  |
| 15 | project_failure |  |  |  |  |  | p030 | store_food | storage_damage |  |
| 15 | project_failure |  |  |  |  |  | p030 | store_food | storage_damage |  |
| 16 | memory_received | m00110 | m00066 | p013 |  | project_failure:hold_ritual |  |  |  |  |
| 16 | memory_told | m00110 |  |  | p026 | project_failure:hold_ritual |  |  |  |  |
| 18 | memory_told | m00110 |  |  | p026 | project_failure:hold_ritual |  |  |  |  |
| 22 | memory_received | m00139 | m00120 | p013 |  | project_failure:store_food |  |  |  |  |
| 26 | memory_told | m00139 |  |  | p026 | project_failure:store_food |  |  |  |  |
| 33 | proposal_supported |  |  |  |  |  | p006 | dig_well | water_shortage | 0.03 |
| 33 | project_started |  |  |  |  |  | p006 | dig_well | water_shortage |  |
| 33 | project_success |  |  |  |  |  | p006 | dig_well | water_shortage |  |
| 33 | memory_received | m00250 | m00161 | p013 |  | death |  |  |  |  |
| 34 | memory_received | m00257 | m00161 | p013 |  | death |  |  |  |  |
| 36 | memory_received | m00284 | m00271 | p013 |  | death |  |  |  |  |
| 37 | memory_received | m00290 | m00271 | p013 |  | death |  |  |  |  |
| 42 | memory_received | m00372 | m00317 | p013 |  | death |  |  |  |  |
| 47 | proposal_supported |  |  |  |  |  | p006 | move_camp | water_shortage | 0.03 |
| 47 | project_started |  |  |  |  |  | p006 | move_camp | water_shortage |  |
| 47 | project_failure |  |  |  |  |  | p006 | move_camp | water_shortage |  |
| 48 | proposal_supported |  |  |  |  |  | p029 | store_food | storage_damage | 0.03 |
| 48 | project_started |  |  |  |  |  | p029 | store_food | storage_damage |  |
| 48 | project_failure |  |  |  |  |  | p029 | store_food | storage_damage |  |
| 49 | memory_received | m00464 | m00379 | p013 |  | death |  |  |  |  |
| 52 | memory_received | m00481 | m00379 | p013 |  | death |  |  |  |  |
| 59 | memory_received | m00537 | m00379 | p013 |  | death |  |  |  |  |
