# society_lab seed 1003 memory propagation

Version: v1.4
Seed: 1003
Target memory: `project_failure:store_food` from Year 14

## Source Event

Proposer: `p006`

Initial memory holders:

- `p001` ケイ (charisma=0.346, incoming_trust=0.669, blame_bias=0.1641)
- `p002` ノア (charisma=0.198, incoming_trust=0.862, blame_bias=0.0786)
- `p011` シオン (charisma=0.331, incoming_trust=0.193, blame_bias=0.1871)
- `p019` ハナ (charisma=0.478, incoming_trust=0.0, blame_bias=0.1797)
- `p021` メイ (charisma=0.051, incoming_trust=0.591, blame_bias=0.1577)
- `p024` ファラ (charisma=0.079, incoming_trust=0.0, blame_bias=0.1481)
- `p027` ユラ (charisma=0.041, incoming_trust=0.934, blame_bias=0.1981)
- `p031` カイ (charisma=0.232, incoming_trust=0.0, blame_bias=0.206)
- `p032` ゾル (charisma=0.233, incoming_trust=0.278, blame_bias=0.1703)
- `p034` イシュ (charisma=0.339, incoming_trust=0.0, blame_bias=0.1796)
- `p035` ルト (charisma=0.403, incoming_trust=0.0, blame_bias=0.144)

## Propagation Summary

- Transmission edges: 40
- Unique speakers: 14
- Unique listeners: 16
- Unique people touched by propagation: 20
- First share year: 14
- Last share year: 34

Transmission count by year:

- Year 14: 2
- Year 16: 2
- Year 17: 2
- Year 18: 2
- Year 19: 3
- Year 21: 5
- Year 22: 2
- Year 23: 4
- Year 24: 2
- Year 25: 3
- Year 26: 2
- Year 27: 2
- Year 28: 1
- Year 29: 3
- Year 30: 2
- Year 32: 1
- Year 33: 1
- Year 34: 1

Top speakers:

- p032 ゾル: 6
- p035 ルト: 5
- p021 メイ: 4
- p003 ハナ: 4
- p031 カイ: 3
- p001 ケイ: 3

Top listeners:

- p028 ゾル: 8
- p021 メイ: 5
- p011 シオン: 4
- p033 ファラ: 3
- p001 ケイ: 3
- p003 ハナ: 3

## Hana Branch

- Y21: p019 ハナ -> p004 オルン (gen=1, intensity=0.60, interpretation=practical)
- Y21: p019 ハナ -> p000 ゾル (gen=1, intensity=0.42, interpretation=practical)
- Y28: p019 ハナ -> p004 オルン (gen=1, intensity=0.48, interpretation=blame)

`p019` does not dominate the whole graph, but her branch is not isolated. She sends the Year 14 failure memory to `p004` and `p000` in Year 21, then sends it to `p004` again in Year 28. After receiving it, `p004` retells the same source memory to `p011` in Years 23, 25, and 26.

## Propagation Edges

- Y14: p002 ノア -> p032 ゾル (gen=1, intensity=0.54, interpretation=blame)
- Y14: p031 カイ -> p033 ファラ (gen=1, intensity=0.66, interpretation=practical)
- Y16: p001 ケイ -> p028 ゾル (gen=1, intensity=0.66, interpretation=spiritual)
- Y16: p002 ノア -> p032 ゾル (gen=1, intensity=0.54, interpretation=spiritual)
- Y17: p021 メイ -> p001 ケイ (gen=1, intensity=0.47, interpretation=blame)
- Y17: p021 メイ -> p023 メイ (gen=1, intensity=0.57, interpretation=blame)
- Y18: p028 ゾル -> p003 ハナ (gen=2, intensity=0.56, interpretation=spiritual)
- Y18: p033 ファラ -> p013 ファラ (gen=2, intensity=0.63, interpretation=practical)
- Y19: p001 ケイ -> p028 ゾル (gen=1, intensity=0.55, interpretation=spiritual)
- Y19: p031 カイ -> p033 ファラ (gen=1, intensity=0.54, interpretation=practical)
- Y19: p035 ルト -> p021 メイ (gen=1, intensity=0.52, interpretation=practical)
- Y21: p001 ケイ -> p028 ゾル (gen=1, intensity=0.46, interpretation=practical)
- Y21: p019 ハナ -> p004 オルン (gen=1, intensity=0.60, interpretation=practical)
- Y21: p019 ハナ -> p000 ゾル (gen=1, intensity=0.42, interpretation=practical)
- Y21: p021 メイ -> p001 ケイ (gen=2, intensity=0.58, interpretation=practical)
- Y21: p028 ゾル -> p003 ハナ (gen=2, intensity=0.56, interpretation=spiritual)
- Y22: p013 ファラ -> p030 オルン (gen=3, intensity=0.78, interpretation=practical)
- Y22: p032 ゾル -> p028 ゾル (gen=1, intensity=0.49, interpretation=blame)
- Y23: p003 ハナ -> p012 イシュ (gen=3, intensity=0.55, interpretation=spiritual)
- Y23: p004 オルン -> p011 シオン (gen=2, intensity=0.66, interpretation=practical)
- Y23: p021 メイ -> p001 ケイ (gen=2, intensity=0.48, interpretation=practical)
- Y23: p032 ゾル -> p028 ゾル (gen=1, intensity=0.44, interpretation=blame)
- Y24: p028 ゾル -> p003 ハナ (gen=2, intensity=0.47, interpretation=blame)
- Y24: p032 ゾル -> p028 ゾル (gen=1, intensity=0.45, interpretation=blame)
- Y25: p003 ハナ -> p012 イシュ (gen=3, intensity=0.58, interpretation=spiritual)
- Y25: p004 オルン -> p011 シオン (gen=2, intensity=0.57, interpretation=practical)
- Y25: p031 カイ -> p033 ファラ (gen=1, intensity=0.44, interpretation=practical)
- Y26: p004 オルン -> p011 シオン (gen=2, intensity=0.54, interpretation=practical)
- Y26: p030 オルン -> p026 ルト (gen=4, intensity=0.79, interpretation=practical)
- Y27: p032 ゾル -> p028 ゾル (gen=1, intensity=0.40, interpretation=blame)
- Y27: p032 ゾル -> p005 オルン (gen=1, intensity=0.44, interpretation=blame)
- Y28: p019 ハナ -> p004 オルン (gen=1, intensity=0.48, interpretation=blame)
- Y29: p005 オルン -> p011 シオン (gen=2, intensity=0.46, interpretation=blame)
- Y29: p032 ゾル -> p028 ゾル (gen=1, intensity=0.47, interpretation=spiritual)
- Y29: p035 ルト -> p021 メイ (gen=1, intensity=0.37, interpretation=practical)
- Y30: p003 ハナ -> p012 イシュ (gen=3, intensity=0.46, interpretation=spiritual)
- Y30: p003 ハナ -> p017 セナ (gen=3, intensity=0.58, interpretation=spiritual)
- Y32: p035 ルト -> p021 メイ (gen=1, intensity=0.42, interpretation=spiritual)
- Y33: p035 ルト -> p021 メイ (gen=1, intensity=0.40, interpretation=practical)
- Y34: p035 ルト -> p021 メイ (gen=1, intensity=0.38, interpretation=practical)

## Diagram

```mermaid
graph TD
  p001["p001"]
  p002["p002"]
  p011["p011"]
  p019["p019"]
  p021["p021"]
  p024["p024"]
  p027["p027"]
  p031["p031"]
  p032["p032"]
  p034["p034"]
  p035["p035"]
  p002["p002 ノア"] -- "Y14 g1 blame" --> p032["p032 ゾル"]
  p031["p031 カイ"] -- "Y14 g1 practical" --> p033["p033 ファラ"]
  p001["p001 ケイ"] -- "Y16 g1 spiritual" --> p028["p028 ゾル"]
  p002["p002 ノア"] -- "Y16 g1 spiritual" --> p032["p032 ゾル"]
  p021["p021 メイ"] -- "Y17 g1 blame" --> p001["p001 ケイ"]
  p021["p021 メイ"] -- "Y17 g1 blame" --> p023["p023 メイ"]
  p028["p028 ゾル"] -- "Y18 g2 spiritual" --> p003["p003 ハナ"]
  p033["p033 ファラ"] -- "Y18 g2 practical" --> p013["p013 ファラ"]
  p001["p001 ケイ"] -- "Y19 g1 spiritual" --> p028["p028 ゾル"]
  p031["p031 カイ"] -- "Y19 g1 practical" --> p033["p033 ファラ"]
  p035["p035 ルト"] -- "Y19 g1 practical" --> p021["p021 メイ"]
  p001["p001 ケイ"] -- "Y21 g1 practical" --> p028["p028 ゾル"]
  p019["p019 ハナ"] -- "Y21 g1 practical" --> p004["p004 オルン"]
  p019["p019 ハナ"] -- "Y21 g1 practical" --> p000["p000 ゾル"]
  p021["p021 メイ"] -- "Y21 g2 practical" --> p001["p001 ケイ"]
  p028["p028 ゾル"] -- "Y21 g2 spiritual" --> p003["p003 ハナ"]
  p013["p013 ファラ"] -- "Y22 g3 practical" --> p030["p030 オルン"]
  p032["p032 ゾル"] -- "Y22 g1 blame" --> p028["p028 ゾル"]
  p003["p003 ハナ"] -- "Y23 g3 spiritual" --> p012["p012 イシュ"]
  p004["p004 オルン"] -- "Y23 g2 practical" --> p011["p011 シオン"]
  p021["p021 メイ"] -- "Y23 g2 practical" --> p001["p001 ケイ"]
  p032["p032 ゾル"] -- "Y23 g1 blame" --> p028["p028 ゾル"]
  p028["p028 ゾル"] -- "Y24 g2 blame" --> p003["p003 ハナ"]
  p032["p032 ゾル"] -- "Y24 g1 blame" --> p028["p028 ゾル"]
  p003["p003 ハナ"] -- "Y25 g3 spiritual" --> p012["p012 イシュ"]
  p004["p004 オルン"] -- "Y25 g2 practical" --> p011["p011 シオン"]
  p031["p031 カイ"] -- "Y25 g1 practical" --> p033["p033 ファラ"]
  p004["p004 オルン"] -- "Y26 g2 practical" --> p011["p011 シオン"]
  p030["p030 オルン"] -- "Y26 g4 practical" --> p026["p026 ルト"]
  p032["p032 ゾル"] -- "Y27 g1 blame" --> p028["p028 ゾル"]
  p032["p032 ゾル"] -- "Y27 g1 blame" --> p005["p005 オルン"]
  p019["p019 ハナ"] -- "Y28 g1 blame" --> p004["p004 オルン"]
  p005["p005 オルン"] -- "Y29 g2 blame" --> p011["p011 シオン"]
  p032["p032 ゾル"] -- "Y29 g1 spiritual" --> p028["p028 ゾル"]
  p035["p035 ルト"] -- "Y29 g1 practical" --> p021["p021 メイ"]
  p003["p003 ハナ"] -- "Y30 g3 spiritual" --> p012["p012 イシュ"]
  p003["p003 ハナ"] -- "Y30 g3 spiritual" --> p017["p017 セナ"]
  p035["p035 ルト"] -- "Y32 g1 spiritual" --> p021["p021 メイ"]
  p035["p035 ルト"] -- "Y33 g1 practical" --> p021["p021 メイ"]
  p035["p035 ルト"] -- "Y34 g1 practical" --> p021["p021 メイ"]
```

## Reading

This trace follows only the Year 14 `project_failure:store_food` memory. It does not include later store_food failures with different source years.

The important question is whether the Year 14 failure memory remained local or moved through the network. If it moved, the branch is not only a numeric supporter difference; it is also a change in who carried and retold a failure.
