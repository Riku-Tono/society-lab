# society_lab v1.4 all-seed report

Compared v1.3 and v1.4 for seeds 1000-1099 over 80 years.

## Counts

| group | count |
| --- | --- |
| log_changed_absorbed | 12 |
| no_log_change | 49 |
| summary_changed | 39 |

## First Diff Families

| family | count |
| --- | --- |
| none | 49 |
| proposal_choice | 5 |
| support_choice | 46 |

## First Diff Year Distribution

| bucket | count |
| --- | --- |
| Y01-20 | 2 |
| Y21-40 | 10 |
| Y41-60 | 20 |
| Y61-80 | 19 |

## Nudge Count vs Final Diffs

Support/action nudge totals are included in the CSV. Large final differences can occur with modest nudge counts, so total nudge count should not be treated as the sole effect-size measure.

## Population delta Ranking

| seed | delta | action nudges | support nudges | first diff year | family |
| --- | --- | --- | --- | --- | --- |
| 1043 | -14 | 4 | 42 | 40 | support_choice |
| 1024 | 12 | 6 | 55 | 38 | support_choice |
| 1036 | -9 | 3 | 59 | 42 | support_choice |
| 1010 | -8 | 5 | 50 | 23 | proposal_choice |
| 1003 | -7 | 7 | 75 | 14 | support_choice |
| 1056 | 5 | 6 | 72 | 54 | support_choice |
| 1012 | -4 | 94 | 1352 | 24 | support_choice |
| 1018 | 4 | 1 | 25 | 8 | support_choice |
| 1004 | -3 | 6 | 86 | 62 | support_choice |
| 1009 | -3 | 30 | 303 | 50 | support_choice |

## Food delta Ranking

| seed | delta | action nudges | support nudges | first diff year | family |
| --- | --- | --- | --- | --- | --- |
| 1024 | -105.05399999999999 | 6 | 55 | 38 | support_choice |
| 1018 | -95.80599999999998 | 1 | 25 | 8 | support_choice |
| 1043 | 70.82000000000001 | 4 | 42 | 40 | support_choice |
| 1003 | 70.52100000000002 | 7 | 75 | 14 | support_choice |
| 1052 | 48.74899999999997 | 7 | 22 | 27 | support_choice |
| 1006 | -36.539000000000016 | 0 | 37 | 62 | support_choice |
| 1060 | 35.331 | 39 | 554 | 43 | support_choice |
| 1012 | -33.129999999999995 | 94 | 1352 | 24 | support_choice |
| 1036 | 31.973 | 3 | 59 | 42 | support_choice |
| 1074 | 29.459000000000003 | 12 | 66 | 67 | support_choice |

## Project failure delta Ranking

| seed | delta | action nudges | support nudges | first diff year | family |
| --- | --- | --- | --- | --- | --- |
| 1003 | 4 | 7 | 75 | 14 | support_choice |
| 1060 | -4 | 39 | 554 | 43 | support_choice |
| 1087 | -4 | 57 | 699 | 35 | support_choice |
| 1025 | 3 | 11 | 149 | 52 | support_choice |
| 1011 | 2 | 7 | 51 | 55 | support_choice |
| 1014 | 2 | 20 | 213 | 57 | support_choice |
| 1028 | -2 | 9 | 40 | 60 | proposal_choice |
| 1029 | -2 | 8 | 45 | 67 | support_choice |
| 1068 | -2 | 2 | 30 | 39 | support_choice |
| 1077 | -2 | 2 | 19 | 65 | support_choice |

## Memory shared delta Ranking

| seed | delta | action nudges | support nudges | first diff year | family |
| --- | --- | --- | --- | --- | --- |
| 1003 | -53 | 7 | 75 | 14 | support_choice |
| 1043 | -51 | 4 | 42 | 40 | support_choice |
| 1042 | -37 | 7 | 110 | 55 | support_choice |
| 1012 | 35 | 94 | 1352 | 24 | support_choice |
| 1096 | 24 | 3 | 41 | 49 | proposal_choice |
| 1009 | -23 | 30 | 303 | 50 | support_choice |
| 1056 | -23 | 6 | 72 | 54 | support_choice |
| 1087 | 23 | 57 | 699 | 35 | support_choice |
| 1016 | -20 | 5 | 39 | 28 | support_choice |
| 1059 | -20 | 15 | 240 | 54 | support_choice |

## Seed 1003-like Candidates

| seed | score | pop | food | memshare | fail | blame |
| --- | --- | --- | --- | --- | --- | --- |
| 1003 | 5.0 | -7 | 70.52100000000002 | -53 | 4 | 0.021699999999999997 |
| 1043 | 5.0 | -14 | 70.82000000000001 | -51 | 1 | 0.011799999999999991 |
| 1004 | 4.0 | -3 | 4.744 | -13 | -1 | 0.004299999999999998 |
| 1016 | 4.0 | 2 | 12.669000000000011 | -20 | 1 | 0.006699999999999998 |
| 1052 | 4.0 | -2 | 48.74899999999997 | -14 | 0 | 0.016399999999999998 |
| 1059 | 4.0 | 2 | 8.225999999999999 | -20 | 1 | 0.004399999999999987 |
| 1074 | 4.0 | -1 | 29.459000000000003 | -1 | -1 | 0.009300000000000003 |
| 1078 | 4.0 | -2 | 2.5420000000000016 | 4 | 1 | 0.008300000000000016 |
| 1091 | 4.0 | 0 | 7.078000000000003 | -16 | 2 | 0.009999999999999981 |
| 1094 | 4.0 | 3 | 6.5060000000000855 | -2 | 1 | 0.00449999999999999 |
| 1009 | 3.0 | -3 | -0.1599999999999966 | -23 | -1 | 0.005299999999999999 |
| 1011 | 3.0 | -3 | -21.903 | 7 | 2 | 0.009899999999999992 |
| 1014 | 3.0 | 1 | 28.052000000000007 | 11 | 2 | 0.012800000000000006 |
| 1036 | 3.0 | -9 | 31.973 | 1 | 0 | 0.014499999999999999 |
| 1060 | 3.0 | -2 | 35.331 | -12 | -4 | -0.01849999999999999 |

## Population-Increase Candidates

| seed | pop delta | food delta | first diff |
| --- | --- | --- | --- |
| 1024 | 12 | -105.05399999999999 | 38 |
| 1056 | 5 | 0.3470000000000013 | 54 |
| 1018 | 4 | -95.80599999999998 | 8 |
| 1089 | 3 | -5.667000000000002 | 79 |
| 1094 | 3 | 6.5060000000000855 | 53 |
| 1096 | 3 | 22.678999999999995 | 49 |
| 1006 | 2 | -36.539000000000016 | 62 |
| 1016 | 2 | 12.669000000000011 | 28 |
| 1028 | 2 | -0.8410000000000082 | 60 |
| 1059 | 2 | 8.225999999999999 | 54 |

## Absorbed Candidates

| seed | first diff year | family | description |
| --- | --- | --- | --- |
| 1008 | 73 | support_choice | Y73 proposal_supported [p009,p051] アルン supported hold_ritual |
| 1019 | 67 | support_choice | Y67 proposal_supported [p012,p030] カイ supported dig_well |
| 1030 | 52 | support_choice | Y52 proposal_supported [p022,p009] ケイ supported store_food |
| 1061 | 61 | support_choice | Y61 proposal_supported [p001,p039] イシュ supported store_food |
| 1064 | 42 | support_choice | Y42 proposal_supported [p008,p018] ルト supported hold_ritual |
| 1069 | 69 | support_choice | Y69 proposal_supported [p032,p032] ケイ supported store_food |
| 1073 | 25 | support_choice | Y25 proposal_supported [p021,p002] ルト supported store_food |
| 1076 | 62 | support_choice | Y62 proposal_supported [p011,p014] ケイ supported hunt_group |
| 1079 | 37 | support_choice | Y37 proposal_supported [p015,p019] ノア supported store_food |
| 1081 | 56 | support_choice | Y56 proposal_supported [p010,p035] ヴァル supported hold_ritual |
| 1084 | 54 | support_choice | Y54 proposal_supported [p031,p021] ユラ supported dig_well |
| 1099 | 52 | support_choice | Y52 proposal_supported [p042,p043] ダン supported hold_ritual |

## High Nudge But Small Summary Delta

| seed | support nudges | pop delta | food delta | failure delta |
| --- | --- | --- | --- | --- |
| 1012 | 1352 | -4 | -33.129999999999995 | 0 |
| 1087 | 699 | -3 | 1.472999999999999 | -4 |
| 1060 | 554 | -2 | 35.331 | -4 |
| 1009 | 303 | -3 | -0.1599999999999966 | -1 |
| 1059 | 240 | 2 | 8.225999999999999 | 1 |
| 1014 | 213 | 1 | 28.052000000000007 | 2 |
| 1025 | 149 | 0 | 22.778 | 3 |
| 1042 | 110 | 1 | -26.557999999999996 | -1 |
| 1091 | 61 | 0 | 7.078000000000003 | 2 |
| 1004 | 86 | -3 | 4.744 | -1 |

## Notes

- `society_lab_v1_4_all_seed_events.csv` is annual cumulative state, not raw event log.
- `society_lab_v1_4_all_seed_nudge_details.csv` is extra output beyond the requested five files. It records support-score nudges and action-weight nudges from an analysis-only subclass.
- Action nudge old/new choice is blank because the current simulator does not store counterfactual random choices.