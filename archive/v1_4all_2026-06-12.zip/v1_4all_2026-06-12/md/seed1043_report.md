# seed1043 外科的解剖レポート

## 目的

Phase 1で magnitude最大（73.1）だったseed1043について、
seed1003で確立した外科的介入フローを適用し、
分岐の最小原因セットを特定。
「death_clusterが最頻分岐型」という仮説の検証。

## 結果サマリ

| 世界 | 最終人口 | 出生数 | 失敗数 | 共有数 |
|---|---|---|---|---|
| baseline | 19 | 17 | 3 | 324 |
| nudge_off | 33 | 29 | 2 | 375 |
| 介入A (Y40 p015のみナッジOFF) | 33 | 29 | 2 | 375 |

**介入A = nudge_off と完全一致。最小原因セット確定。**

---

## 因果連鎖

```
【初期条件】
p015 初期blame bias=0.143 （初期値で既に最大）

【Y11-Y35 蓄積フェーズ】
Y11: move_camp成功 → blame解釈 → blame=0.158
Y31: store_food失敗 → blame解釈 → blame=0.173
Y35: death記憶 → blame解釈 → blame=0.203

【Y40 発火】
water_shortage発生 → council_phase
p018(ルト)が dig_well を提案
p015(ルト): blame dominant → support nudge +0.03
  support_score: baseline=0.2984 / nudge_off=0.2684
  support_chance: baseline=0.2496 / nudge_off=0.2370 (差0.0126)
  → 乱数が境界を越え、baselineのみ p015 が支持参加

【RNGずれ】
baseline: 支持者12名 → project_failure の記憶生成RNG+1消費
nudge_off: 支持者11名

【Y40 死亡者差（RNGずれの即時発現）】
baseline: p007(オルン) 1名死亡
nudge_off: p005(ティア) + p032(セナ) 2名死亡

→ 死亡記憶の配布先・trust構造・以後のRNG列が全部別軌道へ

【長期増幅】
Y40以降40年間にわたり人口・出生・食糧・死亡パターンが拡大
最終: baseline=19 vs nudge_off=33 (差14人)
```

---

## seed1003 vs seed1043 比較

| 項目 | seed1003 | seed1043 |
|---|---|---|
| 分岐年 | Y14 | Y40 |
| 分岐型 | failure_cluster | death_cluster |
| 分岐人物 | p019 ハナ | p015 ルト |
| 支持者差 | 1人 | 1人 |
| ナッジ値 | +0.03 | +0.03 |
| support_chance差 | ~+0.013 | +0.0126 |
| 即時発現 | 記憶共有経路のずれ | Y40死亡者差 |
| 増幅器 | Y28死亡記憶クラスター | Y40以降の死亡記憶連鎖 |
| 最終差 | 18→25 (+7) | 19→33 (+14) |

### 共通構造

```
blame interpretation bias 蓄積
  ↓ (Y1〜)
council/support phaseでのナッジ (+0.03)
  ↓ (seed1003:Y14 / seed1043:Y40)
1人の支持者の差
  ↓
project_failure時のRNG消費ずれ
  ↓
死亡記憶クラスターが別軌道へ
  ↓
trust/共有/出生の長期差
```

### 相違点

- seed1003は「記憶共有経路 (ハナ→ゾル→Y28 trust key)」を経由して遅延増幅
- seed1043は「RNGずれ→Y40死亡者差」として即時発現し、そのまま40年拡大

---

## Phase 1分類の検証

ChatGPTの仮説「death_clusterが最頻分岐型」について:

**支持されるが、より正確な記述が必要。**

- 分岐型分類は「分岐年周辺でdeathイベントが多い」を検出している
- seed1043では死亡者差がRNGずれの**結果**として現れる
- 直接原因はナッジによる1支持者差、死亡クラスターは増幅器

正確な経路:
```
ナッジ（原因）→ RNG消費ずれ → 死亡者差（Phase1分類が見ているもの）→ 長期差
```

Phase1の「death_cluster 15件」は、
「死亡が原因の15件」ではなく、
「ナッジの効果がRNGずれ経由で死亡者差として表面化した可能性が高い15件」
と読み替えるのが安全。

---

## 最小原因セット

### 必要条件（seed1043）
1. p015の初期blame biasが他より高い（初期値RNG）
2. Y11/Y31/Y35の記憶がblame解釈で蓄積
3. Y40に水不足問題が発生しcouncil_phaseが走る
4. p015がblame dominant でsupport_nudge +0.03を受ける
5. Y40の乱数がちょうど参加境界を超える

### 十分条件
この5条件が揃ったとき、p015がY40のdig_wellに参加し、
40年後の人口差14人が確定する。

---

## 一般化

2つのseedから見えてきた一般パターン:

```
「解釈は歴史を直接変えない」は撤回が必要。

解釈biasは support_chanceを+0.012程度押し上げる。
これは1人の参加/不参加の境界を越えることがある。
その1人の差がRNG消費を1個ずらし、
死亡・記憶・trust・共有の全連鎖が別軌道へ入る。

blame biasが最多の増幅器として機能したのは、
blame interpretation → voice_weightなし提案者への+0.03 → support参加
という経路が、failure・crisis後に自然に発動するから。
```

---

## 注意（解釈の限界）

- RNGずれが「主因」かどうかはさらなる検証が必要
  （RNGずれなしで1支持者差を作れば別経路で同じ差が出るか？）
- 2 seedからの一般化は仮説段階
  Phase2では残りのdeath_cluster型（seed1036, 1096, 1094等）でも確認必要
