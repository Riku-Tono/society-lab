# seed1003 trust key mechanism

## Purpose

This pass asks which Y21-Y28 process changes when `p000.trust` contains a `p019` key.

## Results

| exp | final pop | births | failures | memory shares | first diff | p019 death | p000 got p019 death memory | recipients | p019 key after edge | trust value |
|---|---:|---:|---:|---:|---:|---:|---|---:|---|---:|
| baseline | 18 | 18 | 9 | 323 |  | 28 | True | 4 | True | 0.012 |
| KEY_ONLY | 18 | 18 | 9 | 323 |  | 28 | True | 4 | True | 0.0 |
| NO_KEY | 16 | 16 | 4 | 295 | 240 | 28 | False | 3 | False | None |

## baseline: p019 death grants

- Y28 dead=p019 recipients=4
  - p000 ゾル trust=0.012 memory_intensity=0.3554 interpretation=spiritual
  - p002 ノア trust=0.5608 memory_intensity=0.6024 interpretation=spiritual
  - p026 ルト trust=0.7015 memory_intensity=0.6657 interpretation=blame
  - p031 カイ trust=0.6039 memory_intensity=0.6217 interpretation=blame

## KEY_ONLY: p019 death grants

- Y28 dead=p019 recipients=4
  - p000 ゾル trust=0.0 memory_intensity=0.35 interpretation=spiritual
  - p002 ノア trust=0.5608 memory_intensity=0.6024 interpretation=spiritual
  - p026 ルト trust=0.7015 memory_intensity=0.6657 interpretation=blame
  - p031 カイ trust=0.6039 memory_intensity=0.6217 interpretation=blame

## NO_KEY: p019 death grants

- Y28 dead=p019 recipients=3
  - p002 ノア trust=0.5608 memory_intensity=0.6024 interpretation=spiritual
  - p026 ルト trust=0.7015 memory_intensity=0.6657 interpretation=spiritual
  - p031 カイ trust=0.6039 memory_intensity=0.6217 interpretation=blame

## Cautious Reading

- The key difference appears at p019's death in Year 28.
- Baseline and KEY_ONLY give p000 a death memory from p019 because `p019 in p000.trust` is true.
- NO_KEY does not give p000 that death memory because the key is absent.
- This explains why the trust value magnitude did not matter: even value 0 creates the key and passes the membership test.
- The first visible log difference occurs around Year 28, consistent with this delayed death-memory mechanism.
