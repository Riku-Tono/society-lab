# society_lab v1.4 pathway audit

Pathway classification for seeds 1000-1099. This is a heuristic audit, not a final interpretation.

## Pathway Counts

| pathway | count |
| --- | --- |
| A_failure_memory_shrink | 5 |
| B_memory_composition_shrink | 8 |
| C_collapse_avoidance_or_growth | 14 |
| D_absorbed | 12 |
| E_no_log_change | 49 |
| F_proposal_path_changed | 3 |
| G_project_result_path_changed | 8 |
| H_summary_changed_unclear_path | 1 |

## First Diff Families

| family | count |
| --- | --- |
| none | 49 |
| proposal_choice | 5 |
| support_choice | 46 |

## Pathway Definitions

| pathway | working meaning |
| --- | --- |
| A_failure_memory_shrink | support/proposal difference reaches project/failure and memory network, with shrinkage |
| B_memory_composition_shrink | support difference changes the remembered story mix and ends smaller |
| C_collapse_avoidance_or_growth | v1.4 preserves or grows population relative to v1.3 |
| D_absorbed | event log changes but final summary returns |
| E_no_log_change | nudge never changes event path |
| F_proposal_path_changed | proposal choice changes and final summary changes |
| G_project_result_path_changed | project result mix changes without large memory shift |
| H_summary_changed_unclear_path | summary changes but heuristic path is unclear |

## Representative Seeds

| pathway | sample seeds |
| --- | --- |
| A_failure_memory_shrink | 1003, 1011, 1025, 1043, 1091 |
| B_memory_composition_shrink | 1009, 1012, 1036, 1052, 1060, 1068, 1087, 1095 |
| C_collapse_avoidance_or_growth | 1006, 1014, 1016, 1018, 1024, 1028, 1042, 1056 |
| D_absorbed | 1008, 1019, 1030, 1061, 1064, 1069, 1073, 1076 |
| E_no_log_change | 1000, 1001, 1002, 1005, 1007, 1013, 1015, 1017 |
| F_proposal_path_changed | 1010, 1021, 1082 |
| G_project_result_path_changed | 1004, 1029, 1039, 1065, 1074, 1075, 1078, 1083 |
| H_summary_changed_unclear_path | 1097 |

## Summary-Changed Detail

| seed | pathway | first year | family | action | pop | food | fail | memshare | mem path strength |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1003 | A_failure_memory_shrink | 14 | support_choice | store_food | -7.0 | 70.52100000000002 | 4.0 | -53.0 | 44 |
| 1004 | G_project_result_path_changed | 62 | support_choice | store_food | -3.0 | 4.744 | -1.0 | -13.0 | 9 |
| 1006 | C_collapse_avoidance_or_growth | 62 | support_choice | store_food | 2.0 | -36.539000000000016 | -1.0 | -14.0 | 10 |
| 1009 | B_memory_composition_shrink | 50 | support_choice | hunt_group | -3.0 | -0.1599999999999966 | -1.0 | -23.0 | 50 |
| 1010 | F_proposal_path_changed | 23 | proposal_choice | move_camp | -8.0 | -11.450000000000003 | 0.0 | -16.0 | 50 |
| 1011 | A_failure_memory_shrink | 55 | support_choice | store_food | -3.0 | -21.903 | 2.0 | 7.0 | 13 |
| 1012 | B_memory_composition_shrink | 24 | support_choice | hunt_group | -4.0 | -33.129999999999995 | 0.0 | 35.0 | 384 |
| 1014 | C_collapse_avoidance_or_growth | 57 | support_choice | hunt_group | 1.0 | 28.052000000000007 | 2.0 | 11.0 | 18 |
| 1016 | C_collapse_avoidance_or_growth | 28 | support_choice | hold_ritual | 2.0 | 12.669000000000011 | 1.0 | -20.0 | 45 |
| 1018 | C_collapse_avoidance_or_growth | 8 | support_choice | store_food | 4.0 | -95.80599999999998 | -1.0 | 11.0 | 32 |
| 1021 | F_proposal_path_changed | 70 | proposal_choice | move_camp | 0.0 | -14.694000000000017 | 0.0 | 0.0 | 0 |
| 1024 | C_collapse_avoidance_or_growth | 38 | support_choice | store_food | 12.0 | -105.05399999999999 | 0.0 | -5.0 | 27 |
| 1025 | A_failure_memory_shrink | 52 | support_choice | hold_ritual | 0.0 | 22.778 | 3.0 | 7.0 | 21 |
| 1028 | C_collapse_avoidance_or_growth | 60 | proposal_choice | hold_ritual | 2.0 | -0.8410000000000082 | -2.0 | -4.0 | 10 |
| 1029 | G_project_result_path_changed | 67 | support_choice | hunt_group | -2.0 | -28.436999999999983 | -2.0 | -11.0 | 8 |
| 1036 | B_memory_composition_shrink | 42 | support_choice | hunt_group | -9.0 | 31.973 | 0.0 | 1.0 | 51 |
| 1039 | G_project_result_path_changed | 70 | support_choice | dig_well | 0.0 | 5.138999999999996 | 0.0 | -5.0 | 7 |
| 1042 | C_collapse_avoidance_or_growth | 55 | support_choice | store_food | 1.0 | -26.557999999999996 | -1.0 | -37.0 | 55 |
| 1043 | A_failure_memory_shrink | 40 | support_choice | dig_well | -14.0 | 70.82000000000001 | 1.0 | -51.0 | 39 |
| 1052 | B_memory_composition_shrink | 27 | support_choice | store_food | -2.0 | 48.74899999999997 | 0.0 | -14.0 | 25 |
| 1056 | C_collapse_avoidance_or_growth | 54 | support_choice | move_camp | 5.0 | 0.3470000000000013 | 0.0 | -23.0 | 39 |
| 1059 | C_collapse_avoidance_or_growth | 54 | support_choice | store_food | 2.0 | 8.225999999999999 | 1.0 | -20.0 | 37 |
| 1060 | B_memory_composition_shrink | 43 | support_choice | hold_ritual | -2.0 | 35.331 | -4.0 | -12.0 | 24 |
| 1065 | G_project_result_path_changed | 63 | support_choice | hold_ritual | -1.0 | -17.081000000000003 | 0.0 | -4.0 | 7 |
| 1066 | C_collapse_avoidance_or_growth | 66 | support_choice | hold_ritual | 2.0 | 26.775 | 1.0 | 9.0 | 8 |
| 1068 | B_memory_composition_shrink | 39 | support_choice | move_camp | 0.0 | 28.604999999999997 | -2.0 | -15.0 | 26 |
| 1074 | G_project_result_path_changed | 67 | support_choice | dig_well | -1.0 | 29.459000000000003 | -1.0 | -1.0 | 7 |
| 1075 | G_project_result_path_changed | 80 | support_choice | dig_well | 0.0 | -14.370000000000005 | 0.0 | -2.0 | 2 |
| 1077 | C_collapse_avoidance_or_growth | 65 | support_choice | store_food | 2.0 | -17.717 | -2.0 | 4.0 | 8 |
| 1078 | G_project_result_path_changed | 55 | support_choice | store_food | -2.0 | 2.5420000000000016 | 1.0 | 4.0 | 4 |
| 1082 | F_proposal_path_changed | 68 | proposal_choice | dig_well | 0.0 | 2.7320000000000277 | 0.0 | 0.0 | 0 |
| 1083 | G_project_result_path_changed | 77 | support_choice | store_food | -1.0 | -4.161999999999992 | 0.0 | 0.0 | 2 |
| 1087 | B_memory_composition_shrink | 35 | support_choice | store_food | -3.0 | 1.472999999999999 | -4.0 | 23.0 | 34 |
| 1089 | C_collapse_avoidance_or_growth | 79 | support_choice | store_food | 3.0 | -5.667000000000002 | 0.0 | -2.0 | 2 |
| 1091 | A_failure_memory_shrink | 58 | support_choice | dig_well | 0.0 | 7.078000000000003 | 2.0 | -16.0 | 12 |
| 1094 | C_collapse_avoidance_or_growth | 53 | support_choice | hold_ritual | 3.0 | 6.5060000000000855 | 1.0 | -2.0 | 8 |
| 1095 | B_memory_composition_shrink | 54 | support_choice | hunt_group | -3.0 | -20.65 | -1.0 | -5.0 | 35 |
| 1096 | C_collapse_avoidance_or_growth | 49 | proposal_choice | move_camp | 3.0 | 22.678999999999995 | 0.0 | 24.0 | 37 |
| 1097 | H_summary_changed_unclear_path | 72 | support_choice | hold_ritual | 0.0 | 0.0 | 0.0 | 0.0 | 1 |

## Cautions

- This classification is based on log-derived heuristics. Borderline cases need manual deep reading.
- `memory_connection_strength` is the largest absolute post-first-diff memory-share delta by event name, not proof of causality.
- A seed can be socially interesting even if it lands in `H_summary_changed_unclear_path`.

## Reading

The key split is not result shape alone. The model separates into no path change, absorbed path change, and several amplified path changes. This supports using v1.4 as a pathway audit baseline before adding external shocks.