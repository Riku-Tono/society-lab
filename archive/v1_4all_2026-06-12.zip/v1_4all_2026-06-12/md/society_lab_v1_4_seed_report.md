# society_lab v1.4 seed comparison

Compared versions:

- v1.3: interpretation is observed
- v1.4: interpretation weakly nudges project choice and proposal support

Run length: 80 years

## Summary

In seeds 42, 1000, 1001, and 1002, v1.4 produced no summary-level differences from v1.3.

That means the new bridge from interpretation to behavior is weak enough not to rewrite the society by default.

Seed 1003 is the useful exception. There, the same initial world diverged after interpretation nudges entered proposal choice and support choice.

## Seed 1003 differences

```text
final_population: 25 -> 18
final_food_stock: 156.815 -> 227.336
avg_fear: 0.0 -> 0.026
proposal_count: 26 -> 23
project_failure_count: 5 -> 9
shared_narrative_count: 48 -> 45
network_split_count: 7 -> 4
narrative_divergence_count: 17 -> 16
interpretation_divergence_count: 9 -> 4
avg_bias_spiritual: 0.1077 -> 0.117
avg_bias_practical: 0.1238 -> 0.1206
avg_bias_blame: 0.1116 -> 0.1333
birth_count: 25 -> 18
memory_shared_count: 376 -> 323
```

## Reading

Seed 1003 shows the intended v1.4 effect.

A small interpretation nudge did not create religion, revolution, authority, or ideology as direct variables. Instead, it slightly changed which proposals people made and supported.

Most worlds were unchanged. In one world, that small shift accumulated into more project failures, fewer births, fewer memory-sharing events, and a different pattern of interpretation divergence.

So v1.4 is best read as:

> interpretation does not control society, but it can bend the path of society when a fragile situation gives it leverage.

