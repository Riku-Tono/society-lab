# Actor Trace p030 seed 1003

## Overview

- roles: ['death_memory_holder', 'interpretation_moved_supporter', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer', 'supporter']
- biography events: 53
- memory told count: 3
- top listeners: [('p026', 3)]

## Root Memories

| memory_id | event | year | interpretation | descendant_events | unique_holders | max_depth | last_year | interpretations_seen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00545 | death | 59 | blame | 1 | 1 | 0 | 59 | {'blame': 1} |
| m00502 | death | 54 | practical | 1 | 1 | 0 | 54 | {'practical': 1} |
| m00519 | death | 54 | blame | 1 | 1 | 0 | 54 | {'blame': 1} |
| m00475 | death | 51 | blame | 1 | 1 | 0 | 51 | {'blame': 1} |
| m00452 | project_failure:store_food | 48 | blame | 1 | 1 | 0 | 48 | {'blame': 1} |
| m00430 | project_failure:move_camp | 47 | blame | 1 | 1 | 0 | 47 | {'blame': 1} |
| m00416 | death | 46 | spiritual | 1 | 1 | 0 | 46 | {'spiritual': 1} |
| m00243 | project_success:dig_well | 33 | blame | 1 | 1 | 0 | 33 | {'blame': 1} |
| m00197 | death | 28 | blame | 1 | 1 | 0 | 28 | {'blame': 1} |
| m00093 | project_failure:store_food | 15 | blame | 1 | 1 | 0 | 15 | {'blame': 1} |

## Biography

| year | bio_event | memory_id | event | listener_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 8 | memory_received | m00042 | project_failure:hold_ritual |  |  |  |  |  |
| 11 | proposal_supported |  |  |  | p001 | hold_ritual | storage_damage | 0.0 |
| 13 | memory_received | m00069 | project_failure:hold_ritual |  |  |  |  |  |
| 15 | proposal_made |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_supported |  |  |  | p030 | store_food | storage_damage | 0.0 |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | proposal_received_support |  |  |  |  | store_food | storage_damage |  |
| 15 | project_started |  |  |  | p030 | store_food | storage_damage |  |
| 15 | project_started |  |  |  | p030 | store_food | storage_damage |  |
| 15 | memory_created | m00093 | project_failure:store_food |  |  |  |  |  |
| 15 | project_failure |  |  |  | p030 | store_food | storage_damage |  |
| 15 | project_failure |  |  |  | p030 | store_food | storage_damage |  |
| 16 | memory_received | m00110 | project_failure:hold_ritual |  |  |  |  |  |
| 16 | memory_told | m00110 | project_failure:hold_ritual | p026 |  |  |  |  |
| 18 | memory_told | m00110 | project_failure:hold_ritual | p026 |  |  |  |  |
| 22 | memory_received | m00139 | project_failure:store_food |  |  |  |  |  |
| 26 | memory_told | m00139 | project_failure:store_food | p026 |  |  |  |  |
| 28 | memory_created | m00197 | death |  |  |  |  |  |
| 33 | proposal_supported |  |  |  | p006 | dig_well | water_shortage | 0.03 |
| 33 | project_started |  |  |  | p006 | dig_well | water_shortage |  |
| 33 | memory_created | m00243 | project_success:dig_well |  |  |  |  |  |
| 33 | project_success |  |  |  | p006 | dig_well | water_shortage |  |
| 33 | memory_received | m00250 | death |  |  |  |  |  |
| 34 | memory_received | m00257 | death |  |  |  |  |  |
| 36 | memory_received | m00284 | death |  |  |  |  |  |
| 37 | memory_received | m00290 | death |  |  |  |  |  |
| 42 | memory_received | m00372 | death |  |  |  |  |  |
| 46 | memory_created | m00416 | death |  |  |  |  |  |
| 47 | proposal_supported |  |  |  | p006 | move_camp | water_shortage | 0.03 |
| 47 | project_started |  |  |  | p006 | move_camp | water_shortage |  |
| 47 | memory_created | m00430 | project_failure:move_camp |  |  |  |  |  |
| 47 | project_failure |  |  |  | p006 | move_camp | water_shortage |  |
| 48 | proposal_supported |  |  |  | p029 | store_food | storage_damage | 0.03 |
| 48 | project_started |  |  |  | p029 | store_food | storage_damage |  |
| 48 | memory_created | m00452 | project_failure:store_food |  |  |  |  |  |
| 48 | project_failure |  |  |  | p029 | store_food | storage_damage |  |
| 49 | memory_received | m00464 | death |  |  |  |  |  |
| 51 | memory_created | m00475 | death |  |  |  |  |  |
| 52 | memory_received | m00481 | death |  |  |  |  |  |
| 54 | memory_created | m00502 | death |  |  |  |  |  |
| 54 | memory_created | m00519 | death |  |  |  |  |  |
| 59 | memory_received | m00537 | death |  |  |  |  |  |
| 59 | memory_created | m00545 | death |  |  |  |  |  |
| 61 | death |  |  |  |  |  |  |  |

## Support Events Involving Actor

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance |
| --- | --- | --- | --- | --- | --- | --- |
| 11 | p030 | p001 | hold_ritual | storage_damage | 0.0 | 0.2428 |
| 15 | p008 | p030 | store_food | storage_damage | 0.0 | 0.2614 |
| 15 | p009 | p030 | store_food | storage_damage | 0.0 | 0.3617 |
| 15 | p011 | p030 | store_food | storage_damage | 0.0 | 0.2688 |
| 15 | p016 | p030 | store_food | storage_damage | 0.0 | 0.2685 |
| 15 | p017 | p030 | store_food | storage_damage | 0.0 | 0.2199 |
| 15 | p024 | p030 | store_food | storage_damage | 0.0 | 0.2884 |
| 15 | p030 | p030 | store_food | storage_damage | 0.0 | 0.237 |
| 15 | p032 | p030 | store_food | storage_damage | 0.0 | 0.2777 |
| 15 | p033 | p030 | store_food | storage_damage | 0.03 | 0.2522 |
| 15 | p034 | p030 | store_food | storage_damage | 0.0 | 0.265 |
| 15 | p037 | p030 | store_food | storage_damage | 0.0 | 0.2743 |
| 33 | p030 | p006 | dig_well | water_shortage | 0.03 | 0.2637 |
| 47 | p030 | p006 | move_camp | water_shortage | 0.03 | 0.2376 |
| 48 | p030 | p029 | store_food | storage_damage | 0.03 | 0.2823 |

## Project Rows Where Actor Proposed

| year | event | action | problem | supporters | success_chance | supporter_fear_delta | supporter_trust_to_proposer_delta |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 15 | project_failure | store_food | storage_damage | 11 | 0.5583 | 1.1087 | -0.045 |

## Memory/Support Proximity Within 5 Years

| gap_years | memory_year | memory_id | memory_event | memory_interpretation | support_year | supporter_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p008 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p009 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p011 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p016 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p017 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p024 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p030 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p032 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p034 | p030 | store_food | storage_damage | 0.0 |
| 0 | 15 | m00093 | project_failure:store_food | blame | 15 | p037 | p030 | store_food | storage_damage | 0.0 |
| 0 | 33 | m00243 | project_success:dig_well | blame | 33 | p030 | p006 | dig_well | water_shortage | 0.03 |
| 0 | 33 | m00250 | death | practical | 33 | p030 | p006 | dig_well | water_shortage | 0.03 |
| 0 | 47 | m00430 | project_failure:move_camp | blame | 47 | p030 | p006 | move_camp | water_shortage | 0.03 |
| 0 | 48 | m00452 | project_failure:store_food | blame | 48 | p030 | p029 | store_food | storage_damage | 0.03 |
| 1 | 46 | m00416 | death | spiritual | 47 | p030 | p006 | move_camp | water_shortage | 0.03 |
| 1 | 47 | m00430 | project_failure:move_camp | blame | 48 | p030 | p029 | store_food | storage_damage | 0.03 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p008 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p009 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p011 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p016 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p017 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p024 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p030 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p032 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p034 | p030 | store_food | storage_damage | 0.0 |
| 2 | 13 | m00069 | project_failure:hold_ritual | practical | 15 | p037 | p030 | store_food | storage_damage | 0.0 |
| 2 | 46 | m00416 | death | spiritual | 48 | p030 | p029 | store_food | storage_damage | 0.03 |
| 3 | 8 | m00042 | project_failure:hold_ritual | blame | 11 | p030 | p001 | hold_ritual | storage_damage | 0.0 |
| 5 | 28 | m00197 | death | blame | 33 | p030 | p006 | dig_well | water_shortage | 0.03 |
| 5 | 42 | m00372 | death | blame | 47 | p030 | p006 | move_camp | water_shortage | 0.03 |
