# society_lab seed 1043 deep analysis

Compared v1.3 and v1.4 for seed 1043 over 80 years.

## Summary Delta

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| final_population | 33 | 19 | -14 |
| final_food_stock | 87.223 | 158.043 | 70.82000000000001 |
| project_success_count | 2 | 3 | 1 |
| project_failure_count | 2 | 3 | 1 |
| birth_count | 29 | 17 | -12 |
| death_count | 34 | 36 | 2 |
| memory_shared_count | 375 | 324 | -51 |
| shared_narrative_count | 32 | 48 | 16 |
| narrative_divergence_count | 17 | 17 | 0 |
| network_split_count | 15 | 12 | -3 |
| avg_bias_blame | 0.1221 | 0.1339 | 0.011799999999999991 |

## First Log Difference

First differing log index: 305
First differing year: 40

```text
v1.3: Y40 proposal_supported [p025,p018] サナ supported dig_well
v1.4: Y40 proposal_supported [p015,p018] ルト supported dig_well
```

## Year 40 Support Difference

| proposal | v1.3 supporters | v1.4 supporters | added | removed |
| --- | --- | --- | --- | --- |
| p018:dig_well | 11 | 12 | p015 | - |

## Nearby Events

### v1.3

```text
Y38 memory_shared [p001,p019] オルン told ティア about project_success:hold_ritual intensity=0.68 generation=2
Y38 memory_shared [p003,p023] ミラ told イシュ about project_success:hold_ritual intensity=0.68 generation=1
Y38 memory_shared [p003,p020] ミラ told ティア about project_success:hold_ritual intensity=0.55 generation=1
Y38 memory_shared [p020,p023] ティア told イシュ about project_success:hold_ritual intensity=0.76 generation=2
Y38 memory_shared [p023,p039] イシュ told ゾル about project_success:move_camp intensity=1.00 generation=6
Y38 memory_shared [p023,p011] イシュ told ルト about project_success:move_camp intensity=0.98 generation=6
Y38 memory_shared [p028,p003] シオン told ミラ about death intensity=0.48 generation=1
Y38 memory_shared [p029,p024] タロ told ユラ about project_failure:store_food intensity=0.49 generation=1
Y38 memory_shared [p030,p028] ゾル told シオン about project_success:hold_ritual intensity=1.00 generation=4
Y38 memory_shared [p040,p026] オルン told ギル about project_success:hold_ritual intensity=1.00 generation=5
Y38 birth [p043,p051] カイ had a child: リオ
Y38 shared_narrative [p000,p001,p003,p004,p005,p007,p008,p011,p015,p019,p020,p023,p024,p025,p027,p028,p030,p032,p033,p039,p041,p043,p045] shared_narrative detected: project_success:move_camp, 23 persons, avg_intensity 0.52
Y39 memory_shared [p005,p024] ティア told ユラ about death intensity=0.57 generation=1
Y39 memory_shared [p006,p018] ミラ told ルト about project_success:hold_ritual intensity=0.43 generation=1
Y39 memory_shared [p012,p011] サナ told ルト about project_success:hold_ritual intensity=0.55 generation=1
Y39 memory_shared [p025,p001] サナ told オルン about project_success:hold_ritual intensity=0.54 generation=1
Y39 narrative_divergence [] narrative_divergence: project_success:move_camp, versions 0.36 vs 0.86
Y40 problem_detected [] water_shortage severity=0.78
Y40 council_formed [] council_formed: problems=water_shortage
Y40 proposal_made [p018] ルト proposed dig_well for water_shortage
Y40 proposal_supported [p000,p018] ノア supported dig_well
Y40 proposal_supported [p008,p018] メイ supported dig_well
Y40 proposal_supported [p011,p018] ルト supported dig_well
Y40 proposal_supported [p025,p018] サナ supported dig_well
Y40 proposal_supported [p028,p018] シオン supported dig_well
Y40 proposal_supported [p034,p018] アルン supported dig_well
Y40 proposal_supported [p035,p018] オルン supported dig_well
Y40 proposal_supported [p042,p018] ユラ supported dig_well
Y40 proposal_supported [p044,p018] エリン supported dig_well
Y40 proposal_supported [p045,p018] リオ supported dig_well
Y40 proposal_supported [p047,p018] ノア supported dig_well
Y40 project_started [p018,p000,p008,p011,p025,p028,p034,p035,p042,p044,p045,p047] project_started: dig_well for water_shortage supporters=11
Y40 project_failure [p018,p000,p008,p011,p025,p028,p034,p035,p042,p044,p045,p047] project_failure: dig_well for water_shortage chance=0.41
Y40 memory_shared [p009,p019] オルン told ティア about death intensity=0.52 generation=1
Y40 memory_shared [p025,p001] サナ told オルン about project_failure:dig_well intensity=0.81 generation=1
Y40 memory_shared [p027,p000] ファラ told ノア about project_success:hold_ritual intensity=0.51 generation=1
Y40 memory_shared [p027,p011] ファラ told ルト about project_success:hold_ritual intensity=0.43 generation=1
Y40 memory_shared [p037,p020] ユラ told ティア about death intensity=0.60 generation=1
Y40 memory_shared [p043,p019] カイ told ティア about project_success:hold_ritual intensity=0.60 generation=4
Y40 memory_shared [p043,p051] カイ told リオ about project_success:hold_ritual intensity=0.70 generation=4
Y40 memory_shared [p051,p043] リオ told カイ about project_success:hold_ritual intensity=0.88 generation=5
Y40 death [p005] ティア died age=81 health=1.00
Y40 death [p032] セナ died age=89 health=1.00
Y40 shared_narrative [p000,p001,p003,p004,p006,p007,p008,p010,p011,p012,p015,p016,p018,p019,p020,p023,p025,p026,p027,p028,p030,p033,p035,p040,p041,p043,p044,p046,p051] shared_narrative detected: project_success:hold_ritual, 29 persons, avg_intensity 0.61
Y40 shared_narrative [p000,p003,p004,p007,p008,p009,p010,p015,p016,p019,p020,p023,p024,p025,p027,p028,p029,p030,p033,p035,p036,p037,p040,p041] shared_narrative detected: death, 24 persons, avg_intensity 0.55
Y40 narrative_divergence [] narrative_divergence: project_success:hold_ritual, versions 0.37 vs 0.80
Y41 memory_shared [p000,p007] ノア told オルン about project_failure:dig_well intensity=0.77 generation=1
Y41 memory_shared [p010,p003] セナ told ミラ about death intensity=0.61 generation=2
Y41 memory_shared [p010,p001] セナ told オルン about death intensity=0.55 generation=2
Y41 memory_shared [p016,p000] シオン told ノア about death intensity=0.68 generation=2
Y41 memory_shared [p019,p043] ティア told カイ about project_success:hold_ritual intensity=0.93 generation=5
Y41 memory_shared [p026,p040] ギル told オルン about project_success:hold_ritual intensity=0.95 generation=6
Y41 memory_shared [p047,p020] ノア told ティア about project_failure:dig_well intensity=0.82 generation=1
Y41 memory_shared [p047,p029] ノア told タロ about project_failure:dig_well intensity=0.78 generation=1
Y41 death [p006] ミラ died age=93 health=1.00
Y41 birth [p045,p052] リオ had a child: オルン
Y41 shared_narrative [p000,p002,p003,p007,p012,p015,p016,p018,p019,p024,p026,p028,p029,p033,p035,p037,p039,p041,p043,p046] shared_narrative detected: project_failure:store_food, 20 persons, avg_intensity 0.48
Y41 shared_narrative [p000,p001,p007,p008,p011,p020,p025,p028,p029,p034,p035,p042,p044,p045,p047] shared_narrative detected: project_failure:dig_well, 15 persons, avg_intensity 0.72
Y42 memory_shared [p004,p020] ハナ told ティア about death intensity=0.52 generation=1
Y42 memory_shared [p009,p019] オルン told ティア about death intensity=0.57 generation=1
Y42 memory_shared [p030,p028] ゾル told シオン about project_success:hold_ritual intensity=1.00 generation=4
Y42 memory_shared [p035,p016] オルン told シオン about project_failure:dig_well intensity=0.77 generation=1
Y42 memory_shared [p040,p026] オルン told ギル about project_success:hold_ritual intensity=1.00 generation=7
Y42 memory_shared [p041,p015] ギル told ルト about project_success:hold_ritual intensity=0.63 generation=2
Y42 memory_shared [p045,p019] リオ told ティア about project_failure:dig_well intensity=0.80 generation=1
```

### v1.4

```text
Y38 memory_shared [p001,p019] オルン told ティア about project_success:hold_ritual intensity=0.68 generation=2
Y38 memory_shared [p003,p023] ミラ told イシュ about project_success:hold_ritual intensity=0.68 generation=1
Y38 memory_shared [p003,p020] ミラ told ティア about project_success:hold_ritual intensity=0.55 generation=1
Y38 memory_shared [p020,p023] ティア told イシュ about project_success:hold_ritual intensity=0.76 generation=2
Y38 memory_shared [p023,p039] イシュ told ゾル about project_success:move_camp intensity=1.00 generation=6
Y38 memory_shared [p023,p011] イシュ told ルト about project_success:move_camp intensity=0.98 generation=6
Y38 memory_shared [p028,p003] シオン told ミラ about death intensity=0.48 generation=1
Y38 memory_shared [p029,p024] タロ told ユラ about project_failure:store_food intensity=0.49 generation=1
Y38 memory_shared [p030,p028] ゾル told シオン about project_success:hold_ritual intensity=1.00 generation=4
Y38 memory_shared [p040,p026] オルン told ギル about project_success:hold_ritual intensity=1.00 generation=5
Y38 birth [p043,p051] カイ had a child: リオ
Y38 shared_narrative [p000,p001,p003,p004,p005,p007,p008,p011,p015,p019,p020,p023,p024,p025,p027,p028,p030,p032,p033,p039,p041,p043,p045] shared_narrative detected: project_success:move_camp, 23 persons, avg_intensity 0.52
Y39 memory_shared [p005,p024] ティア told ユラ about death intensity=0.57 generation=1
Y39 memory_shared [p006,p018] ミラ told ルト about project_success:hold_ritual intensity=0.43 generation=1
Y39 memory_shared [p012,p011] サナ told ルト about project_success:hold_ritual intensity=0.55 generation=1
Y39 memory_shared [p025,p001] サナ told オルン about project_success:hold_ritual intensity=0.54 generation=1
Y39 narrative_divergence [] narrative_divergence: project_success:move_camp, versions 0.36 vs 0.86
Y40 problem_detected [] water_shortage severity=0.78
Y40 council_formed [] council_formed: problems=water_shortage
Y40 proposal_made [p018] ルト proposed dig_well for water_shortage
Y40 proposal_supported [p000,p018] ノア supported dig_well
Y40 proposal_supported [p008,p018] メイ supported dig_well
Y40 proposal_supported [p011,p018] ルト supported dig_well
Y40 proposal_supported [p015,p018] ルト supported dig_well
Y40 proposal_supported [p025,p018] サナ supported dig_well
Y40 proposal_supported [p028,p018] シオン supported dig_well
Y40 proposal_supported [p034,p018] アルン supported dig_well
Y40 proposal_supported [p035,p018] オルン supported dig_well
Y40 proposal_supported [p042,p018] ユラ supported dig_well
Y40 proposal_supported [p044,p018] エリン supported dig_well
Y40 proposal_supported [p045,p018] リオ supported dig_well
Y40 proposal_supported [p047,p018] ノア supported dig_well
Y40 project_started [p018,p000,p008,p011,p015,p025,p028,p034,p035,p042,p044,p045,p047] project_started: dig_well for water_shortage supporters=12
Y40 project_failure [p018,p000,p008,p011,p015,p025,p028,p034,p035,p042,p044,p045,p047] project_failure: dig_well for water_shortage chance=0.42
Y40 memory_shared [p008,p032] メイ told セナ about project_failure:dig_well intensity=0.69 generation=1
Y40 memory_shared [p024,p005] ユラ told ティア about death intensity=0.62 generation=2
Y40 memory_shared [p026,p040] ギル told オルン about project_success:hold_ritual intensity=1.00 generation=6
Y40 memory_shared [p026,p042] ギル told ユラ about project_success:hold_ritual intensity=0.78 generation=6
Y40 memory_shared [p036,p010] ユラ told セナ about death intensity=0.60 generation=1
Y40 memory_shared [p042,p026] ユラ told ギル about project_success:hold_ritual intensity=0.55 generation=7
Y40 memory_shared [p042,p048] ユラ told ファラ about project_success:hold_ritual intensity=0.73 generation=7
Y40 memory_shared [p047,p020] ノア told ティア about project_failure:dig_well intensity=0.70 generation=1
Y40 death [p007] オルン died age=88 health=1.00
Y40 shared_narrative [p000,p001,p003,p004,p006,p008,p010,p011,p012,p015,p016,p018,p019,p020,p023,p025,p026,p027,p028,p030,p033,p035,p040,p041,p042,p043,p044,p046,p048] shared_narrative detected: project_success:hold_ritual, 29 persons, avg_intensity 0.62
Y40 shared_narrative [p000,p003,p004,p005,p008,p009,p010,p014,p015,p016,p019,p020,p023,p024,p025,p027,p028,p032,p035,p036,p037,p040,p041] shared_narrative detected: death, 23 persons, avg_intensity 0.56
Y40 narrative_divergence [] narrative_divergence: project_success:hold_ritual, versions 0.36 vs 0.80
Y41 memory_shared [p004,p020] ハナ told ティア about death intensity=0.54 generation=1
Y41 memory_shared [p015,p041] ルト told ギル about project_failure:dig_well intensity=0.65 generation=1
Y41 memory_shared [p020,p023] ティア told イシュ about project_failure:dig_well intensity=0.75 generation=2
Y41 memory_shared [p025,p001] サナ told オルン about project_failure:dig_well intensity=0.76 generation=1
Y41 memory_shared [p025,p010] サナ told セナ about project_failure:dig_well intensity=0.59 generation=1
Y41 memory_shared [p033,p019] ノア told ティア about project_success:hold_ritual intensity=0.52 generation=3
Y41 birth [p043,p052] カイ had a child: ノア
Y41 shared_narrative [p000,p002,p003,p005,p012,p015,p016,p018,p019,p024,p026,p028,p029,p033,p035,p037,p039,p041,p043,p046] shared_narrative detected: project_failure:store_food, 20 persons, avg_intensity 0.48
Y41 shared_narrative [p000,p001,p008,p010,p011,p015,p020,p023,p025,p028,p032,p034,p035,p041,p042,p044,p045,p047] shared_narrative detected: project_failure:dig_well, 18 persons, avg_intensity 0.69
Y42 memory_shared [p002,p003] ノア told ミラ about project_failure:store_food intensity=0.42 generation=1
Y42 memory_shared [p005,p024] ティア told ユラ about death intensity=0.68 generation=1
Y42 memory_shared [p018,p008] ルト told メイ about project_failure:store_food intensity=0.41 generation=1
Y42 memory_shared [p023,p039] イシュ told ゾル about project_success:move_camp intensity=0.92 generation=6
Y42 memory_shared [p030,p028] ゾル told シオン about project_success:hold_ritual intensity=1.00 generation=4
Y42 memory_shared [p036,p010] ユラ told セナ about death intensity=0.55 generation=1
Y42 death [p008] メイ died age=87 health=1.00
```

## Milestone Timeline

| year | pop | food | fail | birth | memshare | narr_div | blame | v1.4 nudges |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 44->44 | 158.575->158.575 | 0->0 | 6->6 | 0->0 | 0->0 | 0.104->0.104 | 0/0 |
| 20 | 48->48 | 142.228->142.228 | 0->0 | 10->10 | 35->35 | 0->0 | 0.103->0.103 | 0/1 |
| 30 | 49->49 | 168.962->168.962 | 0->0 | 11->11 | 95->95 | 1->1 | 0.105->0.105 | 0/1 |
| 39 | 47->47 | 172.128->172.128 | 1->1 | 14->14 | 167->167 | 4->4 | 0.109->0.109 | 0/3 |
| 40 | 45->46 | 171.101->171.101 | 2->2 | 14->14 | 175->175 | 5->5 | 0.112->0.112 | 0/7 |
| 41 | 45->47 | 167.928->163.826 | 2->2 | 15->15 | 183->181 | 5->5 | 0.112->0.112 | 0/7 |
| 42 | 45->46 | 164.892->160.673 | 2->2 | 15->15 | 190->187 | 5->5 | 0.112->0.112 | 0/7 |
| 50 | 44->42 | 90.986->137.920 | 2->2 | 22->17 | 245->245 | 10->10 | 0.121->0.119 | 1/14 |
| 60 | 41->32 | 81.304->75.303 | 2->2 | 24->17 | 303->276 | 13->15 | 0.119->0.133 | 1/27 |
| 70 | 33->24 | 62.819->111.715 | 2->2 | 27->17 | 338->307 | 16->17 | 0.124->0.134 | 3/38 |
| 80 | 33->19 | 87.223->158.043 | 2->3 | 29->17 | 375->324 | 17->17 | 0.122->0.134 | 4/42 |

## First Projects After Divergence

### v1.3

```text
Y40 project_started [p018,p000,p008,p011,p025,p028,p034,p035,p042,p044,p045,p047] project_started: dig_well for water_shortage supporters=11
Y40 project_failure [p018,p000,p008,p011,p025,p028,p034,p035,p042,p044,p045,p047] project_failure: dig_well for water_shortage chance=0.41
```

### v1.4

```text
Y40 project_started [p018,p000,p008,p011,p015,p025,p028,p034,p035,p042,p044,p045,p047] project_started: dig_well for water_shortage supporters=12
Y40 project_failure [p018,p000,p008,p011,p015,p025,p028,p034,p035,p042,p044,p045,p047] project_failure: dig_well for water_shortage chance=0.42
Y57 project_started [p041,p014,p023,p040,p042,p045,p046,p047,p050,p053] project_started: move_camp for storage_damage supporters=9
Y57 project_success [p041,p014,p023,p040,p042,p045,p046,p047,p050,p053] project_success: move_camp for storage_damage chance=0.47
Y76 project_started [p010,p002,p039,p040,p041,p042,p049,p050,p051,p054] project_started: hold_ritual for water_shortage supporters=9
Y76 project_failure [p010,p002,p039,p040,p041,p042,p049,p050,p051,p054] project_failure: hold_ritual for water_shortage chance=0.54
```

## Memory Sharing After First Difference

| memory event | v1.3 shares | v1.4 shares | delta |
| --- | --- | --- | --- |
| project_success:move_camp | 1 | 20 | 19 |
| project_failure:dig_well | 40 | 45 | 5 |
| project_failure:store_food | 1 | 2 | 1 |
| project_failure:hold_ritual | 0 | 1 | 1 |
| project_success:hold_ritual | 57 | 19 | -38 |
| death | 109 | 70 | -39 |

## Reading

Seed 1043 is not a simple copy of seed 1003. It also begins with a support-choice difference, but the first visible difference is late, at Year 40, not early. The final result is similar in shape to 1003: v1.4 ends with fewer people and more food.

The key question is whether the Year 40 support change enters a failure-memory network. The memory-sharing table helps check that: if the changed project memory expands differently after Year 40, then 1043 supports the same `support -> experience -> memory -> history` hypothesis. If not, 1043 is a different delayed demographic path.
