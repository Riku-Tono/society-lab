# society_lab seed 1003 deep reading

Compared versions:

- v1.3: interpretation is observed
- v1.4: interpretation weakly nudges project choice and proposal support

Seed: 1003
Run length: 80 years

## Core Finding

The first visible divergence happens in Year 14.

Both worlds face the same water shortage. Both worlds propose the same two actions:

- move_camp by p008
- store_food by p006

But v1.4 gives store_food one extra supporter.

```text
v1.3: store_food supporters=10
v1.4: store_food supporters=11
```

The project fails in both worlds, but the supporter list is different. That means different people remember the failure, different people share the memory, and the random sequence starts following a different path.

This is the first hinge.

## Early Branch

The important second step comes immediately after that.

In v1.3, Year 15 mostly continues as memory sharing after the failed water response.

In v1.4, Year 15 creates an extra storage_damage problem. A new store_food project forms and fails.

```text
Year 15 v1.4 only:
storage_damage detected
store_food proposed
store_food project started
store_food project failed
```

So the v1.4 divergence is not a direct ideology effect. It is a small support change that changes who participates in failure, then changes the next year's event path.

## Milestone Timeline

```text
year | population | food stock | failures | births | deaths | memory_shared | interpretation_divergence | blame_bias
  10 | 43 -> 43  | 116.7 -> 116.7 | 1 -> 1 | 8 -> 8   | 0 -> 0   | 42 -> 42   | 0 -> 0 | 0.1132 -> 0.1132
  15 | 44 -> 44  | 113.6 -> 112.6 | 2 -> 3 | 9 -> 9   | 0 -> 0   | 66 -> 70   | 0 -> 0 | 0.1154 -> 0.1182
  30 | 42 -> 40  | 136.9 -> 38.6  | 3 -> 3 | 11 -> 11 | 4 -> 6   | 197 -> 158 | 1 -> 0 | 0.1182 -> 0.1183
  40 | 39 -> 35  | 141.5 -> 76.5  | 3 -> 4 | 12 -> 11 | 8 -> 11  | 261 -> 231 | 3 -> 0 | 0.1235 -> 0.1247
  50 | 35 -> 29  | 81.4 -> 76.9   | 3 -> 7 | 18 -> 15 | 18 -> 21 | 303 -> 263 | 5 -> 2 | 0.1237 -> 0.1317
  60 | 24 -> 22  | 94.1 -> 105.8  | 5 -> 7 | 20 -> 15 | 31 -> 28 | 338 -> 297 | 7 -> 4 | 0.1165 -> 0.1442
  70 | 21 -> 17  | 144.4 -> 172.3 | 5 -> 7 | 21 -> 17 | 35 -> 35 | 359 -> 308 | 9 -> 4 | 0.1175 -> 0.1292
  80 | 25 -> 18  | 156.8 -> 227.3 | 5 -> 9 | 25 -> 18 | 35 -> 35 | 376 -> 323 | 9 -> 4 | 0.1116 -> 0.1333
```

## Reading

v1.4 does not create a new ideology system. It creates a tiny behavioral tilt.

In this seed, that tilt first appears as one extra supporter in Year 14. The project still fails, but the social memory of that failure is distributed differently.

After that, v1.4 enters a slightly harsher path:

- one extra failed project by Year 15
- fewer births after the early branch
- more deaths earlier in the middle period
- lower memory sharing after Year 20
- fewer interpretation divergence detections
- higher blame bias by the late period

The final shape is not collapse. It is contraction.

```text
v1.3: larger, louder, more divergent
v1.4: smaller, quieter, more blame-tilted
```

The food result is especially important:

```text
population: 25 -> 18
food_stock: 156.8 -> 227.3
```

The v1.4 village is not starving. It has fewer people and more surplus. The loss is not material scarcity at the end. The loss is social throughput: fewer births, fewer shared memories, fewer divergent interpretations, and fewer living participants.

## Careful Causality

This does not prove that blame caused the contraction.

The safer claim is:

> In seed 1003, a weak interpretation-to-support bridge changed one early support event. That changed participation in failure, memory transmission, and later event timing. The resulting path ended smaller, quieter, and more blame-tilted than v1.3.

That is enough for v1.4.

The model is now showing a civilization-like pattern without directly encoding religion, ideology, revolution, or trust collapse as named state variables.

