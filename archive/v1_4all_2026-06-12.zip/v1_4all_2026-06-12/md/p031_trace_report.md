# Actor Trace p031 seed 1003

## Overview

- roles: ['death_memory_holder', 'memory_carrier', 'memory_holder']
- biography events: 36
- memory told count: 17
- top listeners: [('p033', 14), ('p006', 3)]

## Root Memories

| memory_id | event | year | interpretation | descendant_events | unique_holders | max_depth | last_year | interpretations_seen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | project_failure:hold_ritual | 2 | spiritual | 35 | 15 | 9 | 58 | {'spiritual': 17, 'practical': 15, 'blame': 3} |
| m00230 | death | 31 | blame | 21 | 8 | 9 | 67 | {'blame': 14, 'spiritual': 5, 'practical': 2} |
| m00080 | project_failure:store_food | 14 | practical | 7 | 5 | 4 | 26 | {'practical': 7} |
| m00279 | project_failure:dig_well | 36 | spiritual | 5 | 3 | 1 | 43 | {'spiritual': 5} |
| m00190 | death | 28 | blame | 3 | 3 | 2 | 30 | {'blame': 3} |
| m00503 | death | 54 | blame | 1 | 1 | 0 | 54 | {'blame': 1} |
| m00520 | death | 54 | blame | 1 | 1 | 0 | 54 | {'blame': 1} |
| m00399 | death | 43 | blame | 1 | 1 | 0 | 43 | {'blame': 1} |
| m00348 | death | 40 | practical | 1 | 1 | 0 | 40 | {'practical': 1} |

## Biography

| year | bio_event | memory_id | event | listener_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | proposal_supported |  |  |  | p029 | hold_ritual | water_shortage | 0.0 |
| 2 | project_started |  |  |  | p029 | hold_ritual | water_shortage |  |
| 2 | memory_created | m00011 | project_failure:hold_ritual |  |  |  |  |  |
| 2 | project_failure |  |  |  | p029 | hold_ritual | water_shortage |  |
| 2 | memory_told | m00011 | project_failure:hold_ritual | p033 |  |  |  |  |
| 6 | memory_told | m00011 | project_failure:hold_ritual | p033 |  |  |  |  |
| 6 | memory_told | m00011 | project_failure:hold_ritual | p006 |  |  |  |  |
| 8 | memory_told | m00011 | project_failure:hold_ritual | p033 |  |  |  |  |
| 11 | memory_told | m00011 | project_failure:hold_ritual | p033 |  |  |  |  |
| 13 | memory_told | m00011 | project_failure:hold_ritual | p033 |  |  |  |  |
| 14 | proposal_supported |  |  |  | p006 | store_food | water_shortage | 0.0 |
| 14 | project_started |  |  |  | p006 | store_food | water_shortage |  |
| 14 | memory_created | m00080 | project_failure:store_food |  |  |  |  |  |
| 14 | project_failure |  |  |  | p006 | store_food | water_shortage |  |
| 14 | memory_told | m00080 | project_failure:store_food | p033 |  |  |  |  |
| 19 | memory_told | m00080 | project_failure:store_food | p033 |  |  |  |  |
| 25 | memory_told | m00080 | project_failure:store_food | p033 |  |  |  |  |
| 28 | memory_created | m00190 | death |  |  |  |  |  |
| 29 | memory_told | m00190 | death | p033 |  |  |  |  |
| 31 | memory_created | m00230 | death |  |  |  |  |  |
| 33 | memory_told | m00230 | death | p033 |  |  |  |  |
| 33 | memory_told | m00230 | death | p006 |  |  |  |  |
| 35 | memory_told | m00230 | death | p033 |  |  |  |  |
| 36 | proposal_supported |  |  |  | p034 | dig_well | water_shortage | 0.03 |
| 36 | project_started |  |  |  | p034 | dig_well | water_shortage |  |
| 36 | memory_created | m00279 | project_failure:dig_well |  |  |  |  |  |
| 36 | project_failure |  |  |  | p034 | dig_well | water_shortage |  |
| 40 | memory_told | m00279 | project_failure:dig_well | p033 |  |  |  |  |
| 40 | memory_told | m00279 | project_failure:dig_well | p006 |  |  |  |  |
| 40 | memory_created | m00348 | death |  |  |  |  |  |
| 41 | memory_told | m00279 | project_failure:dig_well | p033 |  |  |  |  |
| 43 | memory_told | m00279 | project_failure:dig_well | p033 |  |  |  |  |
| 43 | memory_created | m00399 | death |  |  |  |  |  |
| 54 | memory_created | m00503 | death |  |  |  |  |  |
| 54 | memory_created | m00520 | death |  |  |  |  |  |
| 65 | death |  |  |  |  |  |  |  |

## Support Events Involving Actor

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance |
| --- | --- | --- | --- | --- | --- | --- |
| 2 | p031 | p029 | hold_ritual | water_shortage | 0.0 | 0.3155 |
| 14 | p031 | p006 | store_food | water_shortage | 0.0 | 0.423 |
| 36 | p031 | p034 | dig_well | water_shortage | 0.03 | 0.2149 |

## Project Rows Where Actor Proposed

_none_

## Memory/Support Proximity Within 5 Years

| gap_years | memory_year | memory_id | memory_event | memory_interpretation | support_year | supporter_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 2 | m00011 | project_failure:hold_ritual | spiritual | 2 | p031 | p029 | hold_ritual | water_shortage | 0.0 |
| 0 | 2 | m00015 | project_failure:hold_ritual | spiritual | 2 | p031 | p029 | hold_ritual | water_shortage | 0.0 |
| 0 | 14 | m00080 | project_failure:store_food | practical | 14 | p031 | p006 | store_food | water_shortage | 0.0 |
| 0 | 14 | m00086 | project_failure:store_food | practical | 14 | p031 | p006 | store_food | water_shortage | 0.0 |
| 0 | 36 | m00279 | project_failure:dig_well | spiritual | 36 | p031 | p034 | dig_well | water_shortage | 0.03 |
| 1 | 13 | m00071 | project_failure:hold_ritual | spiritual | 14 | p031 | p006 | store_food | water_shortage | 0.0 |
| 1 | 35 | m00269 | death | blame | 36 | p031 | p034 | dig_well | water_shortage | 0.03 |
| 3 | 11 | m00059 | project_failure:hold_ritual | spiritual | 14 | p031 | p006 | store_food | water_shortage | 0.0 |
| 3 | 33 | m00252 | death | blame | 36 | p031 | p034 | dig_well | water_shortage | 0.03 |
| 3 | 33 | m00253 | death | blame | 36 | p031 | p034 | dig_well | water_shortage | 0.03 |
| 5 | 31 | m00230 | death | blame | 36 | p031 | p034 | dig_well | water_shortage | 0.03 |
