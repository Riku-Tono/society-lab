# seed1003 butterfly experiments

Seed: 1003
Years: 80
Target: `p019` Hana, `p004` Orun, `p011` Shion, `project_failure:store_food` from Year 14

## Summary table

| exp | intervention | final pop | births | deaths | failures | shared narratives | memory shares | target edges | matches v1.3 summary | first diff |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|
| v1.4 | baseline | 18 | 18 | 35 | 9 | 45 | 323 | 7 | False |  |
| A | remove p019 Hana from Year14 supporters | 23 | 23 | 35 | 5 | 56 | 390 | 0 | False | 108 |
| B | p019 Hana participates but does not remember Year14 failure | 18 | 18 | 35 | 9 | 45 | 323 | 1 | False | 147 |
| C | p019 Hana remembers but does not share Year14 failure | 15 | 15 | 35 | 8 | 52 | 328 | 0 | False | 179 |
| D | block p019 Hana -> p004 Orun only | 18 | 18 | 35 | 9 | 45 | 321 | 2 | False | 179 |
| E | block p004 Orun -> p011 Shion only | 18 | 18 | 35 | 9 | 45 | 320 | 4 | False | 201 |
| F | no_hana_to_p000 | 15 | 15 | 35 | 8 | 52 | 329 | 2 | False | 180 |
| G | only_hana_to_p000 | 18 | 18 | 35 | 9 | 45 | 321 | 2 | False | 179 |
| H | only_hana_to_p004 | 15 | 15 | 35 | 8 | 52 | 329 | 2 | False | 180 |
| I | randomized_hana_listener_same_year | 22 | 22 | 35 | 4 | 37 | 347 | 3 | False | 179 |

## Baseline comparison

v1.3 selected summary:

```json
{
  "final_population": 25,
  "final_food_stock": 156.815,
  "proposal_count": 26,
  "project_success_count": 3,
  "project_failure_count": 5,
  "shared_narrative_count": 48,
  "network_split_count": 7,
  "narrative_divergence_count": 17,
  "interpretation_divergence_count": 9,
  "interpretation_action_nudge_count": null,
  "interpretation_support_nudge_count": null,
  "death_count": 35,
  "birth_count": 25,
  "memory_shared_count": 376
}
```

v1.4 selected summary:

```json
{
  "final_population": 18,
  "final_food_stock": 227.336,
  "proposal_count": 23,
  "project_success_count": 3,
  "project_failure_count": 9,
  "shared_narrative_count": 45,
  "network_split_count": 4,
  "narrative_divergence_count": 16,
  "interpretation_divergence_count": 4,
  "interpretation_action_nudge_count": 7,
  "interpretation_support_nudge_count": 75,
  "death_count": 35,
  "birth_count": 18,
  "memory_shared_count": 323
}
```

## A. remove p019 Hana from Year14 supporters

Changed summary keys vs v1.4:

```json
{
  "final_population": {
    "v14": 18,
    "A": 23
  },
  "final_food_stock": {
    "v14": 227.336,
    "A": 120.967
  },
  "proposal_count": {
    "v14": 23,
    "A": 41
  },
  "project_success_count": {
    "v14": 3,
    "A": 6
  },
  "project_failure_count": {
    "v14": 9,
    "A": 5
  },
  "shared_narrative_count": {
    "v14": 45,
    "A": 56
  },
  "network_split_count": {
    "v14": 4,
    "A": 9
  },
  "narrative_divergence_count": {
    "v14": 16,
    "A": 19
  },
  "interpretation_divergence_count": {
    "v14": 4,
    "A": 10
  },
  "interpretation_action_nudge_count": {
    "v14": 7,
    "A": 13
  },
  "interpretation_support_nudge_count": {
    "v14": 75,
    "A": 100
  },
  "birth_count": {
    "v14": 18,
    "A": 23
  },
  "memory_shared_count": {
    "v14": 323,
    "A": 390
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 108,
  "baseline": "Y14 proposal_supported [p019,p006] ハナ supported store_food",
  "experiment": "Y14 proposal_supported [p021,p006] メイ supported store_food"
}
```

Target-edge events:

- none

## B. p019 Hana participates but does not remember Year14 failure

Changed summary keys vs v1.4:

```json
{
  "interpretation_divergence_count": {
    "v14": 4,
    "B": 6
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 147,
  "baseline": "Y15 shared_narrative [p001,p002,p008,p009,p011,p015,p016,p017,p019,p021,p024,p027,p029,p030,p031,p032,p033,p034,p035,p037] shared_narrative detected: project_failure:store_food, 20 persons, avg_intensity 0.56",
  "experiment": "Y15 shared_narrative [p001,p002,p008,p009,p011,p015,p016,p017,p021,p024,p027,p029,p030,p031,p032,p033,p034,p035,p037] shared_narrative detected: project_failure:store_food, 19 persons, avg_intensity 0.56"
}
```

Target-edge events:

- Y29 memory_shared [p005,p011] オルン told シオン about project_failure:store_food intensity=0.46 generation=2

## C. p019 Hana remembers but does not share Year14 failure

Changed summary keys vs v1.4:

```json
{
  "final_population": {
    "v14": 18,
    "C": 15
  },
  "final_food_stock": {
    "v14": 227.336,
    "C": 263.59
  },
  "proposal_count": {
    "v14": 23,
    "C": 32
  },
  "project_success_count": {
    "v14": 3,
    "C": 2
  },
  "project_failure_count": {
    "v14": 9,
    "C": 8
  },
  "shared_narrative_count": {
    "v14": 45,
    "C": 52
  },
  "network_split_count": {
    "v14": 4,
    "C": 0
  },
  "narrative_divergence_count": {
    "v14": 16,
    "C": 22
  },
  "interpretation_action_nudge_count": {
    "v14": 7,
    "C": 3
  },
  "interpretation_support_nudge_count": {
    "v14": 75,
    "C": 82
  },
  "birth_count": {
    "v14": 18,
    "C": 15
  },
  "memory_shared_count": {
    "v14": 323,
    "C": 328
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 179,
  "baseline": "Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1",
  "experiment": "Y21 memory_shared [p020,p024] アルン told ファラ about project_failure:hold_ritual intensity=0.43 generation=1"
}
```

Target-edge events:

- none

## D. block p019 Hana -> p004 Orun only

Changed summary keys vs v1.4:

```json
{
  "memory_shared_count": {
    "v14": 323,
    "D": 321
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 179,
  "baseline": "Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1",
  "experiment": "Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1"
}
```

Target-edge events:

- Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1
- Y29 memory_shared [p005,p011] オルン told シオン about project_failure:store_food intensity=0.46 generation=2

## E. block p004 Orun -> p011 Shion only

Changed summary keys vs v1.4:

```json
{
  "memory_shared_count": {
    "v14": 323,
    "E": 320
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 201,
  "baseline": "Y23 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.66 generation=2",
  "experiment": "Y23 memory_shared [p007,p037] ファラ told イシュ about project_failure:hold_ritual intensity=0.53 generation=4"
}
```

Target-edge events:

- Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1
- Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1
- Y28 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.48 generation=1
- Y29 memory_shared [p005,p011] オルン told シオン about project_failure:store_food intensity=0.46 generation=2

## F. no_hana_to_p000

Changed summary keys vs v1.4:

```json
{
  "final_population": {
    "v14": 18,
    "F": 15
  },
  "final_food_stock": {
    "v14": 227.336,
    "F": 263.59
  },
  "proposal_count": {
    "v14": 23,
    "F": 32
  },
  "project_success_count": {
    "v14": 3,
    "F": 2
  },
  "project_failure_count": {
    "v14": 9,
    "F": 8
  },
  "shared_narrative_count": {
    "v14": 45,
    "F": 52
  },
  "network_split_count": {
    "v14": 4,
    "F": 0
  },
  "narrative_divergence_count": {
    "v14": 16,
    "F": 22
  },
  "interpretation_action_nudge_count": {
    "v14": 7,
    "F": 3
  },
  "interpretation_support_nudge_count": {
    "v14": 75,
    "F": 82
  },
  "birth_count": {
    "v14": 18,
    "F": 15
  },
  "memory_shared_count": {
    "v14": 323,
    "F": 329
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 180,
  "baseline": "Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1",
  "experiment": "Y21 memory_shared [p020,p024] アルン told ファラ about project_failure:hold_ritual intensity=0.43 generation=1"
}
```

Target-edge events:

- Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1
- Y25 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.67 generation=2

## G. only_hana_to_p000

Changed summary keys vs v1.4:

```json
{
  "memory_shared_count": {
    "v14": 323,
    "G": 321
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 179,
  "baseline": "Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1",
  "experiment": "Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1"
}
```

Target-edge events:

- Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1
- Y29 memory_shared [p005,p011] オルン told シオン about project_failure:store_food intensity=0.46 generation=2

## H. only_hana_to_p004

Changed summary keys vs v1.4:

```json
{
  "final_population": {
    "v14": 18,
    "H": 15
  },
  "final_food_stock": {
    "v14": 227.336,
    "H": 263.59
  },
  "proposal_count": {
    "v14": 23,
    "H": 32
  },
  "project_success_count": {
    "v14": 3,
    "H": 2
  },
  "project_failure_count": {
    "v14": 9,
    "H": 8
  },
  "shared_narrative_count": {
    "v14": 45,
    "H": 52
  },
  "network_split_count": {
    "v14": 4,
    "H": 0
  },
  "narrative_divergence_count": {
    "v14": 16,
    "H": 22
  },
  "interpretation_action_nudge_count": {
    "v14": 7,
    "H": 3
  },
  "interpretation_support_nudge_count": {
    "v14": 75,
    "H": 82
  },
  "birth_count": {
    "v14": 18,
    "H": 15
  },
  "memory_shared_count": {
    "v14": 323,
    "H": 329
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 180,
  "baseline": "Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1",
  "experiment": "Y21 memory_shared [p020,p024] アルン told ファラ about project_failure:hold_ritual intensity=0.43 generation=1"
}
```

Target-edge events:

- Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1
- Y25 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.67 generation=2

## I. randomized_hana_listener_same_year

Changed summary keys vs v1.4:

```json
{
  "final_population": {
    "v14": 18,
    "I": 22
  },
  "final_food_stock": {
    "v14": 227.336,
    "I": 220.437
  },
  "proposal_count": {
    "v14": 23,
    "I": 27
  },
  "project_success_count": {
    "v14": 3,
    "I": 2
  },
  "project_failure_count": {
    "v14": 9,
    "I": 4
  },
  "shared_narrative_count": {
    "v14": 45,
    "I": 37
  },
  "network_split_count": {
    "v14": 4,
    "I": 6
  },
  "narrative_divergence_count": {
    "v14": 16,
    "I": 18
  },
  "interpretation_divergence_count": {
    "v14": 4,
    "I": 7
  },
  "interpretation_action_nudge_count": {
    "v14": 7,
    "I": 8
  },
  "interpretation_support_nudge_count": {
    "v14": 75,
    "I": 48
  },
  "birth_count": {
    "v14": 18,
    "I": 22
  },
  "memory_shared_count": {
    "v14": 323,
    "I": 347
  }
}
```

First log difference vs v1.4:

```json
{
  "index": 179,
  "baseline": "Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1",
  "experiment": "Y21 memory_shared [p019,p008] ハナ told ルト about project_failure:store_food intensity=0.58 generation=1"
}
```

Target-edge events:

- Y21 memory_shared [p019,p008] ハナ told ルト about project_failure:store_food intensity=0.58 generation=1
- Y21 memory_shared [p019,p029] ハナ told メイ about project_failure:store_food intensity=0.45 generation=1
- Y22 memory_shared [p019,p021] ハナ told メイ about project_failure:store_food intensity=0.52 generation=1
