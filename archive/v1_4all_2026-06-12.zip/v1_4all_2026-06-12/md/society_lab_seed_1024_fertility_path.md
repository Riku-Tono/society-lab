# society_lab seed 1024 fertility path

Focus: what changed before the birth gap opened between Year 38 and Year 65.

## Fertility / Parent Generation Timeline

| year | pop | fertile | parent_gen | births | deaths | food | avg_hunger |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 38 | 22->23 | 2->2 | 8->8 | 6->6 | 4->3 | 69.657->69.657 | 0.000->0.000 |
| 39 | 22->22 | 2->2 | 7->7 | 6->6 | 4->4 | 68.850->73.283 | 0.000->0.000 |
| 40 | 21->21 | 2->2 | 6->6 | 6->6 | 5->5 | 65.881->70.297 | 0.000->0.000 |
| 41 | 21->21 | 2->2 | 6->6 | 6->6 | 5->5 | 63.981->74.003 | 0.000->0.000 |
| 42 | 21->22 | 2->2 | 5->5 | 6->7 | 5->5 | 66.473->75.254 | 0.000->0.000 |
| 43 | 21->23 | 2->2 | 6->6 | 6->8 | 5->5 | 56.424->71.093 | 0.000->0.000 |
| 44 | 21->23 | 2->2 | 6->6 | 6->9 | 5->6 | 59.723->67.935 | 0.000->0.000 |
| 45 | 21->22 | 2->2 | 7->7 | 6->9 | 5->7 | 59.990->64.558 | 0.000->0.000 |
| 46 | 20->23 | 2->2 | 7->7 | 6->10 | 6->7 | 60.650->63.662 | 0.000->0.000 |
| 47 | 19->23 | 1->1 | 5->5 | 6->10 | 7->7 | 50.672->60.896 | 0.000->0.000 |
| 48 | 19->22 | 1->1 | 5->5 | 6->10 | 7->8 | 49.714->59.242 | 0.000->0.000 |
| 49 | 19->22 | 1->1 | 5->5 | 6->10 | 7->8 | 53.511->48.658 | 0.000->0.000 |
| 50 | 18->22 | 1->1 | 5->5 | 6->10 | 8->8 | 53.998->46.740 | 0.000->0.000 |
| 51 | 18->22 | 1->1 | 6->6 | 6->10 | 8->8 | 54.698->32.774 | 0.000->0.000 |
| 52 | 17->22 | 1->1 | 6->6 | 6->10 | 9->8 | 58.596->34.123 | 0.000->0.000 |
| 53 | 17->20 | 1->1 | 6->6 | 6->10 | 9->10 | 44.938->32.298 | 0.000->0.000 |
| 54 | 17->20 | 1->1 | 6->6 | 6->10 | 9->10 | 49.279->20.393 | 0.000->0.000 |
| 55 | 17->20 | 1->1 | 6->6 | 6->10 | 9->10 | 52.182->19.893 | 0.000->0.000 |
| 56 | 16->20 | 1->1 | 6->6 | 6->10 | 10->10 | 56.291->24.941 | 0.000->0.000 |
| 57 | 15->20 | 1->1 | 6->6 | 6->10 | 11->10 | 46.350->26.852 | 0.000->0.000 |
| 58 | 15->18 | 1->1 | 5->5 | 6->10 | 11->12 | 50.010->31.877 | 0.000->0.000 |
| 59 | 14->18 | 1->1 | 5->5 | 6->10 | 12->12 | 57.753->34.645 | 0.000->0.000 |
| 60 | 13->18 | 1->2 | 4->5 | 6->10 | 13->12 | 63.615->38.967 | 0.000->0.000 |
| 61 | 12->18 | 1->2 | 4->6 | 6->11 | 14->13 | 58.791->46.422 | 0.000->0.000 |
| 62 | 12->18 | 1->3 | 4->7 | 6->12 | 14->14 | 66.732->52.043 | 0.000->0.000 |
| 63 | 11->18 | 1->3 | 4->7 | 6->12 | 15->14 | 77.327->51.291 | 0.000->0.000 |
| 64 | 11->18 | 1->4 | 4->8 | 6->12 | 15->14 | 81.988->53.150 | 0.000->0.000 |
| 65 | 11->19 | 1->4 | 4->8 | 6->13 | 15->14 | 77.806->58.203 | 0.000->0.000 |

## Fertile People At Key Years

### Year 38

| version | fertile_count | fertile_people |
| --- | --- | --- |
| v1.3 | 2 | p020:オルン:age=36:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=34:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 |
| v1.4 | 2 | p020:オルン:age=36:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=34:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 |

### Year 45

| version | fertile_count | fertile_people |
| --- | --- | --- |
| v1.3 | 2 | p021:タロ:age=41:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p024:ユラ:age=18:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |
| v1.4 | 2 | p021:タロ:age=41:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p024:ユラ:age=18:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |

### Year 50

| version | fertile_count | fertile_people |
| --- | --- | --- |
| v1.3 | 1 | p024:ユラ:age=23:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |
| v1.4 | 1 | p024:ユラ:age=23:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |

### Year 55

| version | fertile_count | fertile_people |
| --- | --- | --- |
| v1.3 | 1 | p024:ユラ:age=28:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |
| v1.4 | 1 | p024:ユラ:age=28:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |

### Year 60

| version | fertile_count | fertile_people |
| --- | --- | --- |
| v1.3 | 1 | p024:ユラ:age=33:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |
| v1.4 | 2 | p024:ユラ:age=33:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p026:ケイ:age=18:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.44 |

### Year 65

| version | fertile_count | fertile_people |
| --- | --- | --- |
| v1.3 | 1 | p024:ユラ:age=38:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 |
| v1.4 | 4 | p024:ユラ:age=38:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p026:ケイ:age=23:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.44 \| p028:ダン:age=21:sex=f:health=1.00:hunger=0.00:charisma=0.16:food=0.24 \| p029:ファラ:age=19:sex=f:health=1.00:hunger=0.00:charisma=0.49:food=0.54 |

## Deaths And Births During Watch Window

### Year 38

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p007:リオ died age=88 health=1.00 |
| v1.4 | - | - |

### Year 39

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | - | p004:サナ died age=82 health=1.00 |

### Year 40

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p011:ルト died age=86 health=1.00 |
| v1.4 | - | p015:エリン died age=85 health=1.00 |

### Year 42

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | p021:p026:タロ had a child: ケイ | - |

### Year 43

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | p020:p027:オルン had a child: ヴァル | - |

### Year 44

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | p020:p028:オルン had a child: ダン | p007:リオ died age=94 health=1.00 |

### Year 45

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | - | p014:レン died age=93 health=1.00 |

### Year 46

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p015:エリン died age=91 health=1.00 |
| v1.4 | p021:p029:タロ had a child: ファラ | - |

### Year 47

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p014:レン died age=95 health=1.00 |
| v1.4 | - | - |

### Year 48

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | - | p011:ルト died age=94 health=1.00 |

### Year 50

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p004:サナ died age=93 health=1.00 |
| v1.4 | - | - |

### Year 52

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p001:ハナ died age=84 health=1.00 |
| v1.4 | - | - |

### Year 53

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | - | p001:ハナ died age=85 health=1.00 \| p005:ミラ died age=80 health=1.00 |

### Year 56

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p009:オルン died age=87 health=1.00 |
| v1.4 | - | - |

### Year 57

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p005:ミラ died age=84 health=1.00 |
| v1.4 | - | - |

### Year 58

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | - | p006:ダン died age=95 health=1.00 \| p009:オルン died age=89 health=1.00 |

### Year 59

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p000:サナ died age=87 health=1.00 |
| v1.4 | - | - |

### Year 60

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p019:タロ died age=101 health=1.00 |
| v1.4 | - | - |

### Year 61

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p016:ハナ died age=81 health=1.00 |
| v1.4 | p026:p030:ケイ had a child: ヴァル | p019:タロ died age=102 health=1.00 |

### Year 62

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | p024:p031:ユラ had a child: ゾル | p000:サナ died age=90 health=1.00 |

### Year 63

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | p006:ダン died age=100 health=1.00 |
| v1.4 | - | - |

### Year 65

| version | births | deaths |
| --- | --- | --- |
| v1.3 | - | - |
| v1.4 | p028:p032:ダン had a child: ヴァル | - |

## Trust And Support

### Year 38

| version | top incoming trust | support targets |
| --- | --- | --- |
| v1.3 | p021:タロ:0.684 \| p025:ゾル:0.620 \| p008:ルト:0.597 \| p002:レン:0.534 \| p024:ユラ:0.518 | move_camp:9 \| store_food:2 |
| v1.4 | p021:タロ:0.681 \| p025:ゾル:0.620 \| p008:ルト:0.597 \| p002:レン:0.534 \| p024:ユラ:0.522 | move_camp:8 \| store_food:3 |

### Year 45

| version | top incoming trust | support targets |
| --- | --- | --- |
| v1.3 | p021:タロ:0.684 \| p025:ゾル:0.620 \| p008:ルト:0.599 \| p024:ユラ:0.522 \| p002:レン:0.454 | - |
| v1.4 | p021:タロ:0.788 \| p020:オルン:0.652 \| p002:レン:0.614 \| p008:ルト:0.589 \| p025:ゾル:0.585 | hunt_group:4 \| store_food:2 |

### Year 50

| version | top incoming trust | support targets |
| --- | --- | --- |
| v1.3 | p021:タロ:0.779 \| p025:ゾル:0.620 \| p024:ユラ:0.538 \| p002:レン:0.502 \| p008:ルト:0.466 | dig_well:4 |
| v1.4 | p021:タロ:0.800 \| p020:オルン:0.652 \| p002:レン:0.621 \| p008:ルト:0.592 \| p029:ファラ:0.552 | - |

### Year 55

| version | top incoming trust | support targets |
| --- | --- | --- |
| v1.3 | p025:ゾル:0.862 \| p021:タロ:0.695 \| p024:ユラ:0.538 \| p008:ルト:0.521 \| p002:レン:0.504 | - |
| v1.4 | p021:タロ:0.773 \| p008:ルト:0.674 \| p027:ヴァル:0.662 \| p029:ファラ:0.648 \| p002:レン:0.621 | - |

### Year 60

| version | top incoming trust | support targets |
| --- | --- | --- |
| v1.3 | p025:ゾル:0.874 \| p021:タロ:0.701 \| p002:レン:0.627 \| p024:ユラ:0.538 \| p003:イシュ:0.464 | - |
| v1.4 | p002:レン:0.896 \| p021:タロ:0.773 \| p027:ヴァル:0.662 \| p029:ファラ:0.648 \| p008:ルト:0.645 | - |

### Year 65

| version | top incoming trust | support targets |
| --- | --- | --- |
| v1.3 | p025:ゾル:0.898 \| p021:タロ:0.701 \| p002:レン:0.605 \| p024:ユラ:0.538 \| p013:シオン:0.495 | dig_well:1 \| hold_ritual:1 |
| v1.4 | p002:レン:0.731 \| p026:ケイ:0.672 \| p028:ダン:0.664 \| p027:ヴァル:0.662 \| p008:ルト:0.657 | - |

## Support Details At Key Years

### Year 38

| version | support details |
| --- | --- |
| v1.3 | ハナ supported move_camp \| サナ supported move_camp \| ミラ supported store_food \| ダン supported move_camp \| リオ supported move_camp \| ルト supported move_camp \| シオン supported move_camp \| レン supported store_food \| エリン supported move_camp \| タロ supported move_camp \| ユラ supported move_camp |
| v1.4 | ハナ supported move_camp \| サナ supported store_food \| ミラ supported store_food \| ダン supported move_camp \| リオ supported move_camp \| ルト supported move_camp \| シオン supported move_camp \| レン supported store_food \| エリン supported move_camp \| タロ supported move_camp \| ユラ supported move_camp |

### Year 45

| version | support details |
| --- | --- |
| v1.3 | - |
| v1.4 | オルン supported store_food \| ルト supported hunt_group \| シオン supported hunt_group \| タロ supported hunt_group \| オルン supported store_food \| タロ supported hunt_group |

### Year 50

| version | support details |
| --- | --- |
| v1.3 | ハナ supported dig_well \| ルト supported dig_well \| シオン supported dig_well \| ハナ supported dig_well |
| v1.4 | - |

### Year 65

| version | support details |
| --- | --- |
| v1.3 | ユラ supported dig_well \| ゾル supported hold_ritual |
| v1.4 | - |

## Alive Roster At Structural Breakpoints

### Year 38

| version | alive roster |
| --- | --- |
| v1.3 | p000:サナ:age=66:sex=m:health=1.00:hunger=0.00:charisma=0.67:food=0.85 \| p001:ハナ:age=70:sex=f:health=1.00:hunger=0.00:charisma=0.11:food=0.69 \| p002:レン:age=52:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=47:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p004:サナ:age=81:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.68 \| p005:ミラ:age=65:sex=f:health=1.00:hunger=0.00:charisma=0.17:food=0.84 \| p006:ダン:age=75:sex=f:health=1.00:hunger=0.00:charisma=0.22:food=0.86 \| p008:ルト:age=47:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p009:オルン:age=69:sex=m:health=1.00:hunger=0.00:charisma=0.31:food=0.37 \| p011:ルト:age=84:sex=m:health=1.00:hunger=0.00:charisma=0.22:food=0.99 \| p013:シオン:age=54:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p014:レン:age=86:sex=m:health=1.00:hunger=0.00:charisma=0.68:food=0.34 \| p015:エリン:age=83:sex=f:health=1.00:hunger=0.00:charisma=0.47:food=0.69 \| p016:ハナ:age=58:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=55:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p019:タロ:age=79:sex=m:health=1.00:hunger=0.00:charisma=0.07:food=0.44 \| p020:オルン:age=36:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=34:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=28:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=13:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=11:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=5:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 |
| v1.4 | p000:サナ:age=66:sex=m:health=1.00:hunger=0.00:charisma=0.67:food=0.85 \| p001:ハナ:age=70:sex=f:health=1.00:hunger=0.00:charisma=0.11:food=0.69 \| p002:レン:age=52:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=47:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p004:サナ:age=81:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.68 \| p005:ミラ:age=65:sex=f:health=1.00:hunger=0.00:charisma=0.17:food=0.84 \| p006:ダン:age=75:sex=f:health=1.00:hunger=0.00:charisma=0.22:food=0.86 \| p007:リオ:age=88:sex=f:health=1.00:hunger=0.00:charisma=0.60:food=0.65 \| p008:ルト:age=47:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p009:オルン:age=69:sex=m:health=1.00:hunger=0.00:charisma=0.31:food=0.37 \| p011:ルト:age=84:sex=m:health=1.00:hunger=0.00:charisma=0.22:food=0.99 \| p013:シオン:age=54:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p014:レン:age=86:sex=m:health=1.00:hunger=0.00:charisma=0.68:food=0.34 \| p015:エリン:age=83:sex=f:health=1.00:hunger=0.00:charisma=0.47:food=0.69 \| p016:ハナ:age=58:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=55:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p019:タロ:age=79:sex=m:health=1.00:hunger=0.00:charisma=0.07:food=0.44 \| p020:オルン:age=36:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=34:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=28:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=13:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=11:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=5:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 |

### Year 46

| version | alive roster |
| --- | --- |
| v1.3 | p000:サナ:age=74:sex=m:health=1.00:hunger=0.00:charisma=0.67:food=0.85 \| p001:ハナ:age=78:sex=f:health=1.00:hunger=0.00:charisma=0.11:food=0.69 \| p002:レン:age=60:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=55:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p004:サナ:age=89:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.68 \| p005:ミラ:age=73:sex=f:health=1.00:hunger=0.00:charisma=0.17:food=0.84 \| p006:ダン:age=83:sex=f:health=1.00:hunger=0.00:charisma=0.22:food=0.86 \| p008:ルト:age=55:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p009:オルン:age=77:sex=m:health=1.00:hunger=0.00:charisma=0.31:food=0.37 \| p013:シオン:age=62:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p014:レン:age=94:sex=m:health=1.00:hunger=0.00:charisma=0.68:food=0.34 \| p016:ハナ:age=66:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=63:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p019:タロ:age=87:sex=m:health=1.00:hunger=0.00:charisma=0.07:food=0.44 \| p020:オルン:age=44:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=42:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=36:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=21:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=19:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=13:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 |
| v1.4 | p000:サナ:age=74:sex=m:health=1.00:hunger=0.00:charisma=0.67:food=0.85 \| p001:ハナ:age=78:sex=f:health=1.00:hunger=0.00:charisma=0.11:food=0.69 \| p002:レン:age=60:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=55:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p005:ミラ:age=73:sex=f:health=1.00:hunger=0.00:charisma=0.17:food=0.84 \| p006:ダン:age=83:sex=f:health=1.00:hunger=0.00:charisma=0.22:food=0.86 \| p008:ルト:age=55:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p009:オルン:age=77:sex=m:health=1.00:hunger=0.00:charisma=0.31:food=0.37 \| p011:ルト:age=92:sex=m:health=1.00:hunger=0.00:charisma=0.22:food=0.99 \| p013:シオン:age=62:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p016:ハナ:age=66:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=63:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p019:タロ:age=87:sex=m:health=1.00:hunger=0.00:charisma=0.07:food=0.44 \| p020:オルン:age=44:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=42:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=36:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=21:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=19:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=13:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 \| p026:ケイ:age=4:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.44 \| p027:ヴァル:age=3:sex=m:health=1.00:hunger=0.00:charisma=0.41:food=0.80 \| p028:ダン:age=2:sex=f:health=1.00:hunger=0.00:charisma=0.16:food=0.24 \| p029:ファラ:age=0:sex=f:health=1.00:hunger=0.00:charisma=0.49:food=0.54 |

### Year 60

| version | alive roster |
| --- | --- |
| v1.3 | p002:レン:age=74:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=69:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p006:ダン:age=97:sex=f:health=1.00:hunger=0.00:charisma=0.22:food=0.86 \| p008:ルト:age=69:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p013:シオン:age=76:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p016:ハナ:age=80:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=77:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p020:オルン:age=58:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=56:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=50:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=35:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=33:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=27:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 |
| v1.4 | p000:サナ:age=88:sex=m:health=1.00:hunger=0.00:charisma=0.67:food=0.85 \| p002:レン:age=74:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=69:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p008:ルト:age=69:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p013:シオン:age=76:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p016:ハナ:age=80:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=77:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p019:タロ:age=101:sex=m:health=1.00:hunger=0.00:charisma=0.07:food=0.44 \| p020:オルン:age=58:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=56:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=50:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=35:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=33:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=27:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 \| p026:ケイ:age=18:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.44 \| p027:ヴァル:age=17:sex=m:health=1.00:hunger=0.00:charisma=0.41:food=0.80 \| p028:ダン:age=16:sex=f:health=1.00:hunger=0.00:charisma=0.16:food=0.24 \| p029:ファラ:age=14:sex=f:health=1.00:hunger=0.00:charisma=0.49:food=0.54 |

### Year 65

| version | alive roster |
| --- | --- |
| v1.3 | p002:レン:age=79:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=74:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p008:ルト:age=74:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p013:シオン:age=81:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p017:セナ:age=82:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p020:オルン:age=63:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=61:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=55:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=40:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=38:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=32:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 |
| v1.4 | p002:レン:age=79:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.43 \| p003:イシュ:age=74:sex=f:health=1.00:hunger=0.00:charisma=0.70:food=0.80 \| p008:ルト:age=74:sex=f:health=1.00:hunger=0.00:charisma=0.32:food=0.79 \| p013:シオン:age=81:sex=m:health=1.00:hunger=0.00:charisma=0.17:food=0.73 \| p016:ハナ:age=85:sex=f:health=1.00:hunger=0.00:charisma=0.06:food=0.78 \| p017:セナ:age=82:sex=m:health=1.00:hunger=0.00:charisma=0.21:food=0.92 \| p020:オルン:age=63:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.48 \| p021:タロ:age=61:sex=f:health=1.00:hunger=0.00:charisma=0.46:food=0.53 \| p022:ヴァル:age=55:sex=m:health=1.00:hunger=0.00:charisma=0.52:food=0.66 \| p023:ノア:age=40:sex=m:health=1.00:hunger=0.00:charisma=0.03:food=0.34 \| p024:ユラ:age=38:sex=f:health=1.00:hunger=0.00:charisma=0.31:food=0.44 \| p025:ゾル:age=32:sex=m:health=1.00:hunger=0.00:charisma=0.29:food=0.47 \| p026:ケイ:age=23:sex=f:health=1.00:hunger=0.00:charisma=0.10:food=0.44 \| p027:ヴァル:age=22:sex=m:health=1.00:hunger=0.00:charisma=0.41:food=0.80 \| p028:ダン:age=21:sex=f:health=1.00:hunger=0.00:charisma=0.16:food=0.24 \| p029:ファラ:age=19:sex=f:health=1.00:hunger=0.00:charisma=0.49:food=0.54 \| p030:ヴァル:age=4:sex=f:health=1.00:hunger=0.00:charisma=0.56:food=0.30 \| p031:ゾル:age=3:sex=f:health=1.00:hunger=0.00:charisma=0.28:food=0.96 \| p032:ヴァル:age=0:sex=f:health=1.00:hunger=0.00:charisma=0.40:food=0.44 |

## Authority Pattern

| version | authority events |
| --- | --- |
| v1.3 | - |
| v1.4 | Y51 authority_pattern: イシュ repeated support/success successes=2 supports=28 |

## Reading

The key check is whether v1.3 loses fertile women or parent-generation population before v1.4 does. If fertile_count diverges before birth_count diverges, the birth gap is structural rather than merely random.