# society_lab v1.4 changed-seed common points

Compared v1.3 and v1.4 over seeds 1000-1099, 80 years each.

## Main Split

| group | count | mean action nudge | mean support nudge | median first diff year |
| --- | --- | --- | --- | --- |
| summary changed | 39 | 10.87 | 125.36 | 55.00 |
| log changed, summary returned | 12 | 4.92 | 41.08 | 55.00 |
| no log change | 49 | 3.84 | 26.53 | - |

## First-Difference Timing

| group | Y01-20 | Y21-40 | Y41-60 | Y61-80 |
| --- | --- | --- | --- | --- |
| summary changed | 2 | 8 | 15 | 14 |
| absorbed | 0 | 2 | 5 | 5 |
| all log changed | 2 | 10 | 20 | 19 |

## First-Difference Event Families

| first diff family | summary changed | absorbed |
| --- | --- | --- |
| proposal_choice | 5 | 0 |
| support_choice | 34 | 12 |

## Pre-Divergence State Averages

For changed/absorbed seeds, this is the v1.4 state at the year before the first log difference. For no-log-change seeds, this is the year-80 state.

| group | pop | food | failures | memory shares | total memories | avg memories/person |
| --- | --- | --- | --- | --- | --- | --- |
| summary changed | 34.54 | 96.71 | 1.74 | 177.79 | 194.77 | 6.06 |
| absorbed | 30.92 | 124.29 | 2.17 | 184.33 | 204.67 | 7.60 |
| no log change | 17.04 | 218.05 | 2.59 | 230.51 | 113.22 | 6.52 |

## Changed Seeds Detail

| seed | first diff | family | nudges | pop | food | fail | birth | memshare | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1003 | 14 | support_choice | 7/75 | -7 | +70.521 | +4 | -7 | -53 | +0.022 |
| 1004 | 62 | support_choice | 6/86 | -3 | +4.744 | -1 | +0 | -13 | +0.004 |
| 1006 | 62 | support_choice | 0/37 | +2 | -36.539 | -1 | +2 | -14 | -0.012 |
| 1009 | 50 | support_choice | 30/303 | -3 | -0.160 | -1 | -1 | -23 | +0.005 |
| 1010 | 23 | proposal_choice | 5/50 | -8 | -11.450 | +0 | -4 | -16 | -0.002 |
| 1011 | 55 | support_choice | 7/51 | -3 | -21.903 | +2 | +1 | +7 | +0.010 |
| 1012 | 24 | support_choice | 94/1352 | -4 | -33.130 | +0 | +2 | +35 | +0.048 |
| 1014 | 57 | support_choice | 20/213 | +1 | +28.052 | +2 | -2 | +11 | +0.013 |
| 1016 | 28 | support_choice | 5/39 | +2 | +12.669 | +1 | +2 | -20 | +0.007 |
| 1018 | 8 | support_choice | 1/25 | +4 | -95.806 | -1 | +4 | +11 | -0.002 |
| 1021 | 70 | proposal_choice | 3/15 | +0 | -14.694 | +0 | +0 | +0 | +0 |
| 1024 | 38 | support_choice | 6/55 | +12 | -105.054 | +0 | +13 | -5 | -0.022 |
| 1025 | 52 | support_choice | 11/149 | +0 | +22.778 | +3 | +0 | +7 | -0.003 |
| 1028 | 60 | proposal_choice | 9/40 | +2 | -0.841 | -2 | +2 | -4 | -0.008 |
| 1029 | 67 | support_choice | 8/45 | -2 | -28.437 | -2 | -2 | -11 | -0.013 |
| 1036 | 42 | support_choice | 3/59 | -9 | +31.973 | +0 | -9 | +1 | +0.014 |
| 1039 | 70 | support_choice | 7/29 | +0 | +5.139 | +0 | +1 | -5 | -0.002 |
| 1042 | 55 | support_choice | 7/110 | +1 | -26.558 | -1 | +4 | -37 | -0.013 |
| 1043 | 40 | support_choice | 4/42 | -14 | +70.820 | +1 | -12 | -51 | +0.012 |
| 1052 | 27 | support_choice | 7/22 | -2 | +48.749 | +0 | -2 | -14 | +0.016 |
| 1056 | 54 | support_choice | 6/72 | +5 | +0.347 | +0 | +1 | -23 | -0.020 |
| 1059 | 54 | support_choice | 15/240 | +2 | +8.226 | +1 | +1 | -20 | +0.004 |
| 1060 | 43 | support_choice | 39/554 | -2 | +35.331 | -4 | +0 | -12 | -0.018 |
| 1065 | 63 | support_choice | 0/19 | -1 | -17.081 | +0 | +2 | -4 | -0.010 |
| 1066 | 66 | support_choice | 6/45 | +2 | +26.775 | +1 | +2 | +9 | +0.004 |
| 1068 | 39 | support_choice | 2/30 | +0 | +28.605 | -2 | -1 | -15 | -0.002 |
| 1074 | 67 | support_choice | 12/66 | -1 | +29.459 | -1 | +0 | -1 | +0.009 |
| 1075 | 80 | support_choice | 0/21 | +0 | -14.370 | +0 | -1 | -2 | +0.002 |
| 1077 | 65 | support_choice | 2/19 | +2 | -17.717 | -2 | +2 | +4 | -0.008 |
| 1078 | 55 | support_choice | 3/35 | -2 | +2.542 | +1 | -2 | +4 | +0.008 |
| 1082 | 68 | proposal_choice | 7/17 | +0 | +2.732 | +0 | +0 | +0 | +0 |
| 1083 | 77 | support_choice | 2/23 | -1 | -4.162 | +0 | -3 | +0 | -0.002 |
| 1087 | 35 | support_choice | 57/699 | -3 | +1.473 | -4 | -1 | +23 | +0.005 |
| 1089 | 79 | support_choice | 4/25 | +3 | -5.667 | +0 | +2 | -2 | -0.005 |
| 1091 | 58 | support_choice | 6/61 | +0 | +7.078 | +2 | -1 | -16 | +0.010 |
| 1094 | 53 | support_choice | 11/45 | +3 | +6.506 | +1 | +3 | -2 | +0.004 |
| 1095 | 54 | support_choice | 7/32 | -3 | -20.650 | -1 | -5 | -5 | +0.014 |
| 1096 | 49 | proposal_choice | 3/41 | +3 | +22.679 | +0 | +5 | +24 | +0.006 |
| 1097 | 72 | support_choice | 2/48 | +0 | +0 | +0 | +0 | +0 | +0 |

## Working Hypotheses

1. The changed seeds are not defined by nudge existence. Every seed in this range has some nudge activity.
2. Changed seeds have higher average support-nudge volume than no-log-change seeds, but high volume alone is not sufficient.
3. First differences are often late. Seed 1003 is unusually readable because it diverges early at Year 14.
4. The first log difference is usually a support choice, with a smaller proposal-choice group. The later consequences still vary, so there is not one universal 1003-style chain.
5. A useful next check is to deep-read one seed from each outcome type: early support change, proposal change, large late population swing, absorbed log change, and no-path-change.

Recommended next sample:

- 1003: early support-choice divergence
- 1012: high nudge volume
- 1043: large population loss with later first divergence
- 1008 or 1019: log changes but final summary returns
- 1002: nudge-only, no path change
