# pathway validation report

Validation of whether v1.4 divergence can be read as a social pathway rather than only random stream drift.

## Headline Counts

| metric | value |
| --- | --- |
| seeds | 100 |
| summary_changed | 39 |
| absorbed | 12 |
| no_log_change | 49 |
| summary_changed with first_diff -> project participant change | 21/39 |
| participant-change seeds with that project memory shared | 16/21 |
| summary_changed seeds with that project memory shared | 24/39 |

## Group Memory Differences After First Diff

| group | count | mean max memory diff | mean project memory diff | mean abs pop diff | mean abs food diff | mean abs birth diff | mean abs memshare diff |
| --- | --- | --- | --- | --- | --- | --- | --- |
| summary_changed | 39 | 30.54 | -3.56 | 2.87 | 23.63 | 2.62 | 12.92 |
| absorbed | 12 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| no_log_change | 49 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

## Correlation: Memory Difference vs Final Difference

| x | y | Pearson r in summary_changed |
| --- | --- | --- |
| project_memory_diff | abs_population_diff | 0.064 |
| project_memory_diff | abs_food_diff | 0.125 |
| project_memory_diff | abs_birth_diff | 0.200 |
| project_memory_diff | abs_memory_shared_diff | -0.166 |
| max_memory_diff_abs_after_first_diff | abs_population_diff | 0.203 |
| max_memory_diff_abs_after_first_diff | abs_food_diff | 0.142 |
| max_memory_diff_abs_after_first_diff | abs_birth_diff | 0.099 |
| max_memory_diff_abs_after_first_diff | abs_memory_shared_diff | 0.447 |

## Repeated Path Patterns

| pattern | count |
| --- | --- |
| none / - / no_project_memory / no_log_change | 49 |
| support_choice / store_food / project_memory / summary | 9 |
| support_choice / store_food / no_project_memory / summary | 5 |
| support_choice / hold_ritual / project_memory / summary | 5 |
| support_choice / hold_ritual / no_project_memory / absorbed | 4 |
| support_choice / hunt_group / project_memory / summary | 4 |
| support_choice / dig_well / project_memory / summary | 4 |
| support_choice / store_food / no_project_memory / absorbed | 3 |
| proposal_choice / move_camp / no_project_memory / summary | 2 |
| support_choice / dig_well / no_project_memory / absorbed | 2 |
| support_choice / hunt_group / no_project_memory / summary | 2 |
| support_choice / store_food / project_memory / absorbed | 2 |
| support_choice / hold_ritual / no_project_memory / summary | 2 |
| proposal_choice / hold_ritual / no_project_memory / summary | 1 |
| support_choice / move_camp / project_memory / summary | 1 |

## No-Log-Change Nudge Check

All no-log-change seeds still have nudge opportunities in v1.4: 49/49. Because first_diff is absent, those nudges did not alter actual logged choices.

## Top Summary-Changed Seeds By Memory Difference

| seed | first year | family | action | participant | project memory | project mem diff | max mem diff | pop | food | birth | memshare |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1012 | 24 | support_choice | hunt_group | True | project_success:hunt_group | -143 | 384 | -4.0 | -33.129999999999995 | 2.0 | 35.0 |
| 1042 | 55 | support_choice | store_food | False | project_success:store_food | 8 | 55 | 1.0 | -26.557999999999996 | 4.0 | -37.0 |
| 1036 | 42 | support_choice | hunt_group | True | project_success:hunt_group | 7 | 51 | -9.0 | 31.973 | -9.0 | 1.0 |
| 1009 | 50 | support_choice | hunt_group | False | project_success:hunt_group | -50 | 50 | -3.0 | -0.1599999999999966 | -1.0 | -23.0 |
| 1010 | 23 | proposal_choice | move_camp | True |  | 0 | 50 | -8.0 | -11.450000000000003 | -4.0 | -16.0 |
| 1016 | 28 | support_choice | hold_ritual | True | project_failure:hold_ritual | -24 | 45 | 2.0 | 12.669000000000011 | 2.0 | -20.0 |
| 1003 | 14 | support_choice | store_food | True | project_failure:store_food | 35 | 44 | -7.0 | 70.52100000000002 | -7.0 | -53.0 |
| 1043 | 40 | support_choice | dig_well | True | project_failure:dig_well | 5 | 39 | -14.0 | 70.82000000000001 | -12.0 | -51.0 |
| 1056 | 54 | support_choice | move_camp | False | project_success:move_camp | 4 | 39 | 5.0 | 0.3470000000000013 | 1.0 | -23.0 |
| 1059 | 54 | support_choice | store_food | True | project_failure:store_food | 0 | 37 | 2.0 | 8.225999999999999 | 1.0 | -20.0 |
| 1096 | 49 | proposal_choice | move_camp | True | project_success:move_camp | 2 | 37 | 3.0 | 22.678999999999995 | 5.0 | 24.0 |
| 1095 | 54 | support_choice | hunt_group | False |  | 0 | 35 | -3.0 | -20.65 | -5.0 | -5.0 |
| 1087 | 35 | support_choice | store_food | False | project_success:store_food | 0 | 34 | -3.0 | 1.472999999999999 | -1.0 | 23.0 |
| 1018 | 8 | support_choice | store_food | False |  | 0 | 32 | 4.0 | -95.80599999999998 | 4.0 | 11.0 |
| 1024 | 38 | support_choice | store_food | False | project_success:store_food | 11 | 27 | 12.0 | -105.05399999999999 | 13.0 | -5.0 |
| 1068 | 39 | support_choice | move_camp | False |  | 0 | 26 | 0.0 | 28.604999999999997 | -1.0 | -15.0 |
| 1052 | 27 | support_choice | store_food | False | project_success:store_food | 19 | 25 | -2.0 | 48.74899999999997 | -2.0 | -14.0 |
| 1060 | 43 | support_choice | hold_ritual | False | project_success:hold_ritual | -11 | 24 | -2.0 | 35.331 | 0.0 | -12.0 |
| 1025 | 52 | support_choice | hold_ritual | True | project_success:hold_ritual | -14 | 21 | 0.0 | 22.778 | 0.0 | 7.0 |
| 1014 | 57 | support_choice | hunt_group | False | project_failure:hunt_group | 1 | 18 | 1.0 | 28.052000000000007 | -2.0 | 11.0 |

## Verdict

The pathway hypothesis is only partially supported: some conditions match, but the distinction from random stream drift remains weak.

Caution: memory events are logged as `project_failure:action` or `project_success:action`; problem type is not preserved in memory names. This report therefore validates action-level memory pathways, not exact action+problem pathways.