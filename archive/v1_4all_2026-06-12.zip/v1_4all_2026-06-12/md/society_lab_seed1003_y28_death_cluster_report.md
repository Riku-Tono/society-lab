# seed1003 Y28 death cluster tests

## Purpose

This batch tests whether the Y28 cluster of deaths changes the v1.4 trajectory through death-memory distribution. Main experiments preserve deaths and block only memory distribution; the shift test is a separate timing intervention.

## Results

| exp | intervention | final pop | births | failures | memory shares | shared narratives | first diff | changed keys | Y28 deaths | Y28 recipients | blocked |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CL_BASE | baseline v1.4 | 18 | 18 | 9 | 323 | 45 |  | 0 | 3 | 17 | 0 |
| CL_NO_P004_DEATH_MEMORY | block p004 death-memory distribution only | 16 | 17 | 4 | 300 | 38 | 241 | 14 | 3 | 11 | 6 |
| CL_NO_P019_DEATH_MEMORY | block p019 death-memory distribution only | 17 | 17 | 5 | 319 | 58 | 241 | 13 | 3 | 13 | 4 |
| CL_NO_P026_DEATH_MEMORY | block p026 death-memory distribution only | 13 | 13 | 7 | 291 | 42 | 241 | 13 | 3 | 10 | 7 |
| CL_NO_Y28_DEATH_MEMORIES | block all Y28 death-memory distribution | 30 | 30 | 5 | 319 | 35 | 241 | 13 | 3 | 0 | 17 |
| CL_SHIFT_Y28_DEATHS_TO_Y29 | shift baseline Y28 deaths to Y29 | 24 | 24 | 5 | 337 | 33 | 238 | 12 | 1 | 2 | 0 |
| CL_P000_NO_DEATHS | block only p000 receiving Y28 death memories | 18 | 18 | 9 | 323 | 45 | 241 | 0 | 3 | 15 | 2 |
| CL_ALL_RECEIVE_Y28_DEATHS | all alive receive each Y28 death memory | 29 | 29 | 3 | 334 | 28 | 239 | 13 | 2 | 83 | 0 |

## Yearly Village State Y27-Y31

### CL_BASE

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 40,
    "avg_fear": 0.0061,
    "avg_hunger": 0.0,
    "death_memory_total": 23,
    "death_strongest_count": 14,
    "death": 3,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  },
  {
    "year": 29,
    "population": 39,
    "avg_fear": 0.0054,
    "avg_hunger": 0.0,
    "death_memory_total": 34,
    "death_strongest_count": 19,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 13,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 40,
    "avg_fear": 0.0045,
    "avg_hunger": 0.0,
    "death_memory_total": 39,
    "death_strongest_count": 20,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 39,
    "avg_fear": 0.004,
    "avg_hunger": 0.0,
    "death_memory_total": 45,
    "death_strongest_count": 20,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 0
  }
]
```

### CL_NO_P004_DEATH_MEMORY

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 40,
    "avg_fear": 0.0061,
    "avg_hunger": 0.0,
    "death_memory_total": 18,
    "death_strongest_count": 12,
    "death": 3,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  },
  {
    "year": 29,
    "population": 39,
    "avg_fear": 0.0054,
    "avg_hunger": 0.0,
    "death_memory_total": 29,
    "death_strongest_count": 18,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 13,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 39,
    "avg_fear": 0.0047,
    "avg_hunger": 0.0,
    "death_memory_total": 34,
    "death_strongest_count": 19,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 40,
    "avg_fear": 0.0039,
    "avg_hunger": 0.0,
    "death_memory_total": 39,
    "death_strongest_count": 20,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 0
  }
]
```

### CL_NO_P019_DEATH_MEMORY

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 40,
    "avg_fear": 0.0061,
    "avg_hunger": 0.0,
    "death_memory_total": 20,
    "death_strongest_count": 12,
    "death": 3,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  },
  {
    "year": 29,
    "population": 39,
    "avg_fear": 0.0054,
    "avg_hunger": 0.0,
    "death_memory_total": 31,
    "death_strongest_count": 17,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 12,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 40,
    "avg_fear": 0.0045,
    "avg_hunger": 0.0,
    "death_memory_total": 36,
    "death_strongest_count": 17,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 41,
    "avg_fear": 0.0038,
    "avg_hunger": 0.0,
    "death_memory_total": 42,
    "death_strongest_count": 18,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 0
  }
]
```

### CL_NO_P026_DEATH_MEMORY

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 40,
    "avg_fear": 0.0061,
    "avg_hunger": 0.0,
    "death_memory_total": 16,
    "death_strongest_count": 9,
    "death": 3,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  },
  {
    "year": 29,
    "population": 38,
    "avg_fear": 0.0056,
    "avg_hunger": 0.0,
    "death_memory_total": 24,
    "death_strongest_count": 10,
    "death": 2,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 11,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 39,
    "avg_fear": 0.0047,
    "avg_hunger": 0.0,
    "death_memory_total": 28,
    "death_strongest_count": 9,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 9,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 40,
    "avg_fear": 0.0039,
    "avg_hunger": 0.0,
    "death_memory_total": 31,
    "death_strongest_count": 10,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 8,
    "shared_narrative": 0
  }
]
```

### CL_NO_Y28_DEATH_MEMORIES

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 40,
    "avg_fear": 0.0061,
    "avg_hunger": 0.0,
    "death_memory_total": 8,
    "death_strongest_count": 5,
    "death": 3,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 0
  },
  {
    "year": 29,
    "population": 39,
    "avg_fear": 0.0054,
    "avg_hunger": 0.0,
    "death_memory_total": 15,
    "death_strongest_count": 9,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 12,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 39,
    "avg_fear": 0.0047,
    "avg_hunger": 0.0,
    "death_memory_total": 17,
    "death_strongest_count": 9,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 37,
    "avg_fear": 0.0042,
    "avg_hunger": 0.0,
    "death_memory_total": 26,
    "death_strongest_count": 13,
    "death": 2,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  }
]
```

### CL_SHIFT_Y28_DEATHS_TO_Y29

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 42,
    "avg_fear": 0.0062,
    "avg_hunger": 0.0,
    "death_memory_total": 10,
    "death_strongest_count": 7,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 0
  },
  {
    "year": 29,
    "population": 41,
    "avg_fear": 0.0054,
    "avg_hunger": 0.0,
    "death_memory_total": 21,
    "death_strongest_count": 11,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 15,
    "shared_narrative": 1
  },
  {
    "year": 30,
    "population": 42,
    "avg_fear": 0.0046,
    "avg_hunger": 0.0,
    "death_memory_total": 21,
    "death_strongest_count": 11,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 42,
    "avg_fear": 0.0039,
    "avg_hunger": 0.0,
    "death_memory_total": 22,
    "death_strongest_count": 11,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 4,
    "shared_narrative": 0
  }
]
```

### CL_P000_NO_DEATHS

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 40,
    "avg_fear": 0.0061,
    "avg_hunger": 0.0,
    "death_memory_total": 21,
    "death_strongest_count": 13,
    "death": 3,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  },
  {
    "year": 29,
    "population": 39,
    "avg_fear": 0.0054,
    "avg_hunger": 0.0,
    "death_memory_total": 31,
    "death_strongest_count": 18,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 13,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 40,
    "avg_fear": 0.0045,
    "avg_hunger": 0.0,
    "death_memory_total": 36,
    "death_strongest_count": 19,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 39,
    "avg_fear": 0.004,
    "avg_hunger": 0.0,
    "death_memory_total": 42,
    "death_strongest_count": 19,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 0
  }
]
```

### CL_ALL_RECEIVE_Y28_DEATHS

```json
[
  {
    "year": 27,
    "population": 43,
    "avg_fear": 0.007,
    "avg_hunger": 0.0,
    "death_memory_total": 6,
    "death_strongest_count": 4,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 1
  },
  {
    "year": 28,
    "population": 41,
    "avg_fear": 0.0063,
    "avg_hunger": 0.0,
    "death_memory_total": 90,
    "death_strongest_count": 19,
    "death": 2,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 6,
    "shared_narrative": 1
  },
  {
    "year": 29,
    "population": 41,
    "avg_fear": 0.0052,
    "avg_hunger": 0.0,
    "death_memory_total": 96,
    "death_strongest_count": 22,
    "death": 1,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 7,
    "shared_narrative": 0
  },
  {
    "year": 30,
    "population": 41,
    "avg_fear": 0.0044,
    "avg_hunger": 0.0,
    "death_memory_total": 106,
    "death_strongest_count": 25,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 12,
    "shared_narrative": 1
  },
  {
    "year": 31,
    "population": 42,
    "avg_fear": 0.0037,
    "avg_hunger": 0.0,
    "death_memory_total": 107,
    "death_strongest_count": 24,
    "death": 0,
    "proposal_made": 0,
    "proposal_supported": 0,
    "project_success": 0,
    "project_failure": 0,
    "memory_shared": 5,
    "shared_narrative": 0
  }
]
```

## Cautious Reading

- The block-distribution experiments isolate death-memory delivery while preserving the deaths themselves and preserving interpretation RNG calls for blocked grants.
- CL_SHIFT_Y28_DEATHS_TO_Y29 is not directly comparable to the distribution-only cuts; it changes survival/timing and should be read as a timing stress test.
- `悲しみ` or `喪中` is a narrative interpretation. The empirical layer is death events, death-memory recipients, strongest_memory counts, and trajectory divergence.
