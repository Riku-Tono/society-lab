# p031 to p033 trace seed 1003

## Overview

- relay roles: ['death_memory_holder', 'interpretation_moved_supporter', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter']
- memories received from source: 14
- relay transmissions to third people: 49
- interpretation changes after relay: 25
- third person counts: [('p008', 9), ('p013', 7), ('p007', 7), ('p030', 6), ('p040', 4), ('p012', 3), ('p026', 3), ('p037', 3), ('p023', 2), ('p029', 2), ('p011', 1), ('p017', 1), ('p016', 1)]

## Memories Received From Source

| year | memory_id | parent_memory_id | event | intensity | generation | interpretation |
| --- | --- | --- | --- | --- | --- | --- |
| 2 | m00015 | m00011 | project_failure:hold_ritual | 0.5894 | 1 | spiritual |
| 6 | m00032 | m00011 | project_failure:hold_ritual | 0.4838 | 1 | spiritual |
| 8 | m00044 | m00011 | project_failure:hold_ritual | 0.605 | 1 | blame |
| 11 | m00059 | m00011 | project_failure:hold_ritual | 0.4637 | 1 | spiritual |
| 13 | m00071 | m00011 | project_failure:hold_ritual | 0.53 | 1 | spiritual |
| 14 | m00086 | m00080 | project_failure:store_food | 0.6606 | 1 | practical |
| 19 | m00126 | m00080 | project_failure:store_food | 0.5377 | 1 | practical |
| 25 | m00166 | m00080 | project_failure:store_food | 0.4352 | 1 | practical |
| 29 | m00208 | m00190 | death | 0.6027 | 1 | blame |
| 33 | m00252 | m00230 | death | 0.7119 | 1 | blame |
| 35 | m00269 | m00230 | death | 0.5399 | 1 | blame |
| 40 | m00327 | m00279 | project_failure:dig_well | 0.5262 | 1 | spiritual |
| 41 | m00353 | m00279 | project_failure:dig_well | 0.4734 | 1 | spiritual |
| 43 | m00384 | m00279 | project_failure:dig_well | 0.5318 | 1 | spiritual |

## Rooted Received Summary

| root_memory_id | root_event | root_year | root_interpretation | received_memory_id | received_year | received_interpretation | branch_events_from_relay | third_person_events | third_person_holders | max_depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00015 | 2 | spiritual | 13 | 12 | ['p007', 'p008', 'p011', 'p012', 'p013', 'p017', 'p023', 'p030'] | 6 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00032 | 6 | spiritual | 1 | 0 | [] | 0 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00044 | 8 | blame | 17 | 16 | ['p007', 'p013', 'p016', 'p026', 'p029', 'p030', 'p037'] | 8 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00059 | 11 | spiritual | 1 | 0 | [] | 0 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00071 | 13 | spiritual | 1 | 0 | [] | 0 |
| m00080 | project_failure:store_food | 14 | practical | m00086 | 14 | practical | 4 | 3 | ['p013', 'p026', 'p030'] | 3 |
| m00080 | project_failure:store_food | 14 | practical | m00126 | 19 | practical | 1 | 0 | [] | 0 |
| m00080 | project_failure:store_food | 14 | practical | m00166 | 25 | practical | 1 | 0 | [] | 0 |
| m00190 | death | 28 | blame | m00208 | 29 | blame | 2 | 1 | ['p013'] | 1 |
| m00230 | death | 31 | blame | m00252 | 33 | blame | 18 | 17 | ['p008', 'p012', 'p013', 'p030', 'p040'] | 8 |
| m00230 | death | 31 | blame | m00269 | 35 | blame | 1 | 0 | [] | 0 |
| m00279 | project_failure:dig_well | 36 | spiritual | m00327 | 40 | spiritual | 1 | 0 | [] | 0 |
| m00279 | project_failure:dig_well | 36 | spiritual | m00353 | 41 | spiritual | 1 | 0 | [] | 0 |
| m00279 | project_failure:dig_well | 36 | spiritual | m00384 | 43 | spiritual | 1 | 0 | [] | 0 |

## Relay Transmissions To Third People

| root_memory_id | received_memory_id | memory_id | year | event | holder_id | source_id | interpretation | depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | m00015 | m00016 | 2 | project_failure:hold_ritual | p013 | p033 | spiritual | 1 |
| m00011 | m00015 | m00017 | 2 | project_failure:hold_ritual | p008 | p033 | spiritual | 1 |
| m00011 | m00015 | m00026 | 4 | project_failure:hold_ritual | p013 | p033 | blame | 1 |
| m00011 | m00015 | m00018 | 3 | project_failure:hold_ritual | p012 | p008 | spiritual | 2 |
| m00011 | m00015 | m00027 | 5 | project_failure:hold_ritual | p012 | p008 | spiritual | 2 |
| m00011 | m00015 | m00042 | 8 | project_failure:hold_ritual | p030 | p013 | blame | 2 |
| m00011 | m00015 | m00036 | 7 | project_failure:hold_ritual | p007 | p012 | spiritual | 3 |
| m00011 | m00015 | m00046 | 9 | project_failure:hold_ritual | p007 | p012 | spiritual | 3 |
| m00011 | m00015 | m00108 | 16 | project_failure:hold_ritual | p011 | p007 | spiritual | 4 |
| m00011 | m00015 | m00109 | 16 | project_failure:hold_ritual | p023 | p011 | spiritual | 5 |
| m00011 | m00015 | m00114 | 17 | project_failure:hold_ritual | p023 | p011 | spiritual | 5 |
| m00011 | m00015 | m00137 | 21 | project_failure:hold_ritual | p017 | p023 | spiritual | 6 |
| m00011 | m00044 | m00066 | 12 | project_failure:hold_ritual | p013 | p033 | practical | 1 |
| m00011 | m00044 | m00069 | 13 | project_failure:hold_ritual | p030 | p013 | practical | 2 |
| m00011 | m00044 | m00110 | 16 | project_failure:hold_ritual | p030 | p013 | practical | 2 |
| m00011 | m00044 | m00112 | 16 | project_failure:hold_ritual | p026 | p030 | practical | 3 |
| m00011 | m00044 | m00119 | 18 | project_failure:hold_ritual | p026 | p030 | practical | 3 |
| m00011 | m00044 | m00125 | 19 | project_failure:hold_ritual | p016 | p026 | practical | 4 |
| m00011 | m00044 | m00234 | 32 | project_failure:hold_ritual | p029 | p016 | practical | 5 |
| m00011 | m00044 | m00308 | 39 | project_failure:hold_ritual | p029 | p016 | practical | 5 |
| m00011 | m00044 | m00251 | 33 | project_failure:hold_ritual | p007 | p029 | practical | 6 |
| m00011 | m00044 | m00457 | 48 | project_failure:hold_ritual | p007 | p029 | practical | 6 |
| m00011 | m00044 | m00283 | 36 | project_failure:hold_ritual | p037 | p007 | practical | 7 |
| m00011 | m00044 | m00468 | 50 | project_failure:hold_ritual | p037 | p007 | spiritual | 7 |
| m00011 | m00044 | m00534 | 58 | project_failure:hold_ritual | p037 | p007 | practical | 7 |
| m00011 | m00044 | m00311 | 39 | project_failure:hold_ritual | p007 | p037 | practical | 8 |
| m00011 | m00044 | m00386 | 43 | project_failure:hold_ritual | p007 | p037 | practical | 8 |
| m00011 | m00044 | m00458 | 48 | project_failure:hold_ritual | p007 | p037 | practical | 8 |
| m00080 | m00086 | m00120 | 18 | project_failure:store_food | p013 | p033 | practical | 1 |
| m00080 | m00086 | m00139 | 22 | project_failure:store_food | p030 | p013 | practical | 2 |
| m00080 | m00086 | m00169 | 26 | project_failure:store_food | p026 | p030 | practical | 3 |
| m00190 | m00208 | m00220 | 30 | death | p013 | p033 | blame | 1 |
| m00230 | m00252 | m00259 | 34 | death | p013 | p033 | practical | 1 |
| m00230 | m00252 | m00260 | 34 | death | p008 | p033 | blame | 1 |
| m00230 | m00252 | m00271 | 35 | death | p013 | p033 | blame | 1 |
| m00230 | m00252 | m00265 | 35 | death | p040 | p008 | blame | 2 |
| m00230 | m00252 | m00284 | 36 | death | p030 | p013 | blame | 2 |
| m00230 | m00252 | m00290 | 37 | death | p030 | p013 | blame | 2 |
| m00230 | m00252 | m00286 | 36 | death | p008 | p040 | spiritual | 3 |
| m00230 | m00252 | m00292 | 37 | death | p008 | p040 | blame | 3 |
| m00230 | m00252 | m00302 | 38 | death | p040 | p008 | blame | 4 |
| m00230 | m00252 | m00304 | 38 | death | p008 | p040 | blame | 5 |
| m00230 | m00252 | m00479 | 52 | death | p040 | p008 | spiritual | 6 |
| m00230 | m00252 | m00480 | 52 | death | p012 | p008 | blame | 6 |
| m00230 | m00252 | m00493 | 54 | death | p008 | p040 | spiritual | 7 |
| m00230 | m00252 | m00536 | 58 | death | p008 | p040 | blame | 7 |
| m00230 | m00252 | m00561 | 64 | death | p008 | p040 | spiritual | 7 |
| m00230 | m00252 | m00562 | 65 | death | p008 | p040 | spiritual | 7 |
| m00230 | m00252 | m00567 | 67 | death | p040 | p008 | practical | 8 |

## Interpretation Changes After Relay

| root_memory_id | from_memory_id | to_memory_id | year | holder_id | from_interpretation | to_interpretation | depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | m00015 | m00026 | 4 | p013 | spiritual | blame | 1 |
| m00011 | m00015 | m00042 | 8 | p030 | spiritual | blame | 2 |
| m00011 | m00044 | m00066 | 12 | p013 | blame | practical | 1 |
| m00011 | m00044 | m00069 | 13 | p030 | blame | practical | 2 |
| m00011 | m00044 | m00110 | 16 | p030 | blame | practical | 2 |
| m00011 | m00044 | m00112 | 16 | p026 | blame | practical | 3 |
| m00011 | m00044 | m00119 | 18 | p026 | blame | practical | 3 |
| m00011 | m00044 | m00125 | 19 | p016 | blame | practical | 4 |
| m00011 | m00044 | m00234 | 32 | p029 | blame | practical | 5 |
| m00011 | m00044 | m00308 | 39 | p029 | blame | practical | 5 |
| m00011 | m00044 | m00251 | 33 | p007 | blame | practical | 6 |
| m00011 | m00044 | m00457 | 48 | p007 | blame | practical | 6 |
| m00011 | m00044 | m00283 | 36 | p037 | blame | practical | 7 |
| m00011 | m00044 | m00468 | 50 | p037 | blame | spiritual | 7 |
| m00011 | m00044 | m00534 | 58 | p037 | blame | practical | 7 |
| m00011 | m00044 | m00311 | 39 | p007 | blame | practical | 8 |
| m00011 | m00044 | m00386 | 43 | p007 | blame | practical | 8 |
| m00011 | m00044 | m00458 | 48 | p007 | blame | practical | 8 |
| m00230 | m00252 | m00259 | 34 | p013 | blame | practical | 1 |
| m00230 | m00252 | m00286 | 36 | p008 | blame | spiritual | 3 |
| m00230 | m00252 | m00479 | 52 | p040 | blame | spiritual | 6 |
| m00230 | m00252 | m00493 | 54 | p008 | blame | spiritual | 7 |
| m00230 | m00252 | m00561 | 64 | p008 | blame | spiritual | 7 |
| m00230 | m00252 | m00562 | 65 | p008 | blame | spiritual | 7 |
| m00230 | m00252 | m00567 | 67 | p040 | blame | practical | 8 |

## Relay Support Near Source Memories Within 5 Years

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance | nearest_memory_gap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | p033 | p029 | hold_ritual | water_shortage | 0.0 | 0.3038 | 0 |
| 14 | p033 | p008 | move_camp | water_shortage | 0.0 | 0.3454 | 0 |
| 15 | p033 | p030 | store_food | storage_damage | 0.03 | 0.2522 | 1 |
| 22 | p033 | p008 | hold_ritual | storage_damage | 0.0 | 0.2982 | 3 |
| 42 | p033 | p008 | hunt_group | storage_damage | 0.03 | 0.3991 | 1 |

## Relay Biography Focus

| year | bio_event | memory_id | parent_memory_id | speaker_id | listener_id | event | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | proposal_supported |  |  |  |  |  | p029 | hold_ritual | water_shortage | 0.0 |
| 2 | project_started |  |  |  |  |  | p029 | hold_ritual | water_shortage |  |
| 2 | project_failure |  |  |  |  |  | p029 | hold_ritual | water_shortage |  |
| 2 | memory_received | m00015 | m00011 | p031 |  | project_failure:hold_ritual |  |  |  |  |
| 2 | memory_told | m00015 |  |  | p013 | project_failure:hold_ritual |  |  |  |  |
| 2 | memory_told | m00015 |  |  | p008 | project_failure:hold_ritual |  |  |  |  |
| 4 | memory_told | m00015 |  |  | p013 | project_failure:hold_ritual |  |  |  |  |
| 6 | memory_received | m00032 | m00011 | p031 |  | project_failure:hold_ritual |  |  |  |  |
| 8 | memory_received | m00044 | m00011 | p031 |  | project_failure:hold_ritual |  |  |  |  |
| 11 | memory_received | m00059 | m00011 | p031 |  | project_failure:hold_ritual |  |  |  |  |
| 12 | memory_told | m00044 |  |  | p013 | project_failure:hold_ritual |  |  |  |  |
| 13 | memory_received | m00071 | m00011 | p031 |  | project_failure:hold_ritual |  |  |  |  |
| 14 | proposal_supported |  |  |  |  |  | p008 | move_camp | water_shortage | 0.0 |
| 14 | memory_received | m00086 | m00080 | p031 |  | project_failure:store_food |  |  |  |  |
| 15 | proposal_supported |  |  |  |  |  | p030 | store_food | storage_damage | 0.03 |
| 15 | project_started |  |  |  |  |  | p030 | store_food | storage_damage |  |
| 15 | project_failure |  |  |  |  |  | p030 | store_food | storage_damage |  |
| 18 | memory_told | m00086 |  |  | p013 | project_failure:store_food |  |  |  |  |
| 19 | memory_received | m00126 | m00080 | p031 |  | project_failure:store_food |  |  |  |  |
| 22 | proposal_supported |  |  |  |  |  | p008 | hold_ritual | storage_damage | 0.0 |
| 25 | memory_received | m00166 | m00080 | p031 |  | project_failure:store_food |  |  |  |  |
| 29 | memory_received | m00208 | m00190 | p031 |  | death |  |  |  |  |
| 30 | memory_told | m00208 |  |  | p013 | death |  |  |  |  |
| 33 | memory_received | m00252 | m00230 | p031 |  | death |  |  |  |  |
| 34 | memory_told | m00252 |  |  | p013 | death |  |  |  |  |
| 34 | memory_told | m00252 |  |  | p008 | death |  |  |  |  |
| 35 | memory_received | m00269 | m00230 | p031 |  | death |  |  |  |  |
| 35 | memory_told | m00252 |  |  | p013 | death |  |  |  |  |
| 40 | memory_received | m00327 | m00279 | p031 |  | project_failure:dig_well |  |  |  |  |
| 41 | memory_received | m00353 | m00279 | p031 |  | project_failure:dig_well |  |  |  |  |
| 42 | proposal_supported |  |  |  |  |  | p008 | hunt_group | storage_damage | 0.03 |
| 42 | project_started |  |  |  |  |  | p008 | hunt_group | storage_damage |  |
| 42 | project_success |  |  |  |  |  | p008 | hunt_group | storage_damage |  |
| 43 | memory_received | m00384 | m00279 | p031 |  | project_failure:dig_well |  |  |  |  |
| 43 | memory_told | m00367 |  |  | p008 | project_success:hunt_group |  |  |  |  |
