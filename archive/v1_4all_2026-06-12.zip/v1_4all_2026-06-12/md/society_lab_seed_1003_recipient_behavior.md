# society_lab seed 1003 recipient behavior trace

Version: v1.4
Seed: 1003
Target memory: `project_failure:store_food` from Year 14

## Reading Guardrails

- This report follows behavior after receiving one specific source memory.
- It does not prove that the memory caused the later behavior.
- People who die early have fewer chances to act; compare counts with survival time.
- A later bias value may reflect pre-existing tendency, received memory, later events, or all three.

## Focus People

## p006 シオン

Basic profile:

- initial age=38, charisma=0.521, food_skill=0.954, incoming_trust=0.779, trust_links=4
- initial bias: spiritual=0.0569, practical=0.1079, blame=0.1411
- final/death: alive=False, death_year=54, age=92, incoming_trust=0.068, trust_links=7, memory_count=12
- final bias: spiritual=0.0569, practical=0.1529, blame=0.1861

First receipt: not observed for the target Year14 memory.

Post-receipt role counts:

- proposal_made: 4
- proposal_supported_as_supporter: 1
- proposal_supported_as_proposer: 37
- project_participation: 5
- project_failure_participation: 4
- project_success_participation: 1
- memory_shared_as_speaker: 6
- memory_shared_as_listener: 5
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 27

Retells of the target Year14 memory:

- none

Selected post-receipt events:

- Y14 proposal_made [p006] シオン proposed store_food for water_shortage
- Y14 proposal_supported [p001,p006] ケイ supported store_food
- Y14 proposal_supported [p002,p006] ノア supported store_food
- Y14 proposal_supported [p011,p006] シオン supported store_food
- Y14 proposal_supported [p019,p006] ハナ supported store_food
- Y14 proposal_supported [p021,p006] メイ supported store_food
- Y14 proposal_supported [p024,p006] ファラ supported store_food
- Y14 proposal_supported [p027,p006] ユラ supported store_food
- Y14 proposal_supported [p031,p006] カイ supported store_food
- Y14 proposal_supported [p032,p006] ゾル supported store_food
- Y14 proposal_supported [p034,p006] イシュ supported store_food
- Y14 proposal_supported [p035,p006] ルト supported store_food
- Y14 project_started [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_started: store_food for water_shortage supporters=11
- Y14 project_failure [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_failure: store_food for water_shortage chance=0.60
- Y15 memory_shared [p006,p014] シオン told セナ about project_failure:hold_ritual intensity=0.43 generation=1
- Y19 memory_shared [p006,p014] シオン told セナ about project_failure:hold_ritual intensity=0.37 generation=1
- Y26 memory_shared [p006,p014] シオン told セナ about project_failure:hold_ritual intensity=0.38 generation=1
- Y29 memory_shared [p006,p014] シオン told セナ about project_failure:hold_ritual intensity=0.28 generation=1
- ... 46 more

## p019 ハナ

Basic profile:

- initial age=58, charisma=0.478, food_skill=0.559, incoming_trust=0.622, trust_links=6
- initial bias: spiritual=0.0539, practical=0.1210, blame=0.1497
- final/death: alive=False, death_year=28, age=86, incoming_trust=0.0, trust_links=8, memory_count=3
- final bias: spiritual=0.0539, practical=0.136, blame=0.1797

First receipt: Y14, mode=experienced_failure, from=p006 シオン, interpretation=practical, intensity=0.58, generation=0

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 1
- proposal_supported_as_proposer: 0
- project_participation: 1
- project_failure_participation: 1
- project_success_participation: 0
- memory_shared_as_speaker: 3
- memory_shared_as_listener: 0
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 12

Retells of the target Year14 memory:

- Y21: p019 ハナ -> p004 オルン (interpretation=practical, gen=1, intensity=0.60)
- Y21: p019 ハナ -> p000 ゾル (interpretation=practical, gen=1, intensity=0.42)
- Y28: p019 ハナ -> p004 オルン (interpretation=blame, gen=1, intensity=0.48)

Selected post-receipt events:

- Y14 proposal_supported [p019,p006] ハナ supported store_food
- Y14 project_started [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_started: store_food for water_shortage supporters=11
- Y14 project_failure [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_failure: store_food for water_shortage chance=0.60
- Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1
- Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1
- Y28 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.48 generation=1
- Y28 death [p019] ハナ died age=86 health=1.00

## p004 オルン

Basic profile:

- initial age=57, charisma=0.194, food_skill=0.767, incoming_trust=0.796, trust_links=3
- initial bias: spiritual=0.1248, practical=0.1390, blame=0.1106
- final/death: alive=False, death_year=28, age=85, incoming_trust=0.0, trust_links=4, memory_count=6
- final bias: spiritual=0.1248, practical=0.139, blame=0.1106

First receipt: Y21, mode=heard_memory, from=p019 ハナ, interpretation=practical, intensity=0.60, generation=1

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 0
- proposal_supported_as_proposer: 0
- project_participation: 0
- project_failure_participation: 0
- project_success_participation: 0
- memory_shared_as_speaker: 3
- memory_shared_as_listener: 2
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 3

Retells of the target Year14 memory:

- Y23: p004 オルン -> p011 シオン (interpretation=practical, gen=2, intensity=0.66)
- Y25: p004 オルン -> p011 シオン (interpretation=practical, gen=2, intensity=0.57)
- Y26: p004 オルン -> p011 シオン (interpretation=practical, gen=2, intensity=0.54)

Selected post-receipt events:

- Y21 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.60 generation=1
- Y23 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.66 generation=2
- Y25 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.57 generation=2
- Y26 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.54 generation=2
- Y28 memory_shared [p019,p004] ハナ told オルン about project_failure:store_food intensity=0.48 generation=1
- Y28 death [p004] オルン died age=85 health=1.00

## p011 シオン

Basic profile:

- initial age=45, charisma=0.331, food_skill=0.858, incoming_trust=0.733, trust_links=6
- initial bias: spiritual=0.0681, practical=0.0629, blame=0.1121
- final/death: alive=False, death_year=43, age=88, incoming_trust=0.193, trust_links=17, memory_count=18
- final bias: spiritual=0.1281, practical=0.0629, blame=0.1871

First receipt: Y14, mode=experienced_failure, from=p006 シオン, interpretation=blame, intensity=0.58, generation=0

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 4
- proposal_supported_as_proposer: 0
- project_participation: 3
- project_failure_participation: 2
- project_success_participation: 1
- memory_shared_as_speaker: 10
- memory_shared_as_listener: 6
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 16

Retells of the target Year14 memory:

- none

Selected post-receipt events:

- Y14 proposal_supported [p011,p006] シオン supported store_food
- Y14 project_started [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_started: store_food for water_shortage supporters=11
- Y14 project_failure [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_failure: store_food for water_shortage chance=0.60
- Y15 proposal_supported [p011,p030] シオン supported store_food
- Y15 project_started [p030,p008,p009,p011,p016,p017,p024,p030,p032,p033,p034,p037] project_started: store_food for storage_damage supporters=11
- Y15 project_failure [p030,p008,p009,p011,p016,p017,p024,p030,p032,p033,p034,p037] project_failure: store_food for storage_damage chance=0.56
- Y16 memory_shared [p007,p011] ファラ told シオン about project_failure:hold_ritual intensity=0.77 generation=5
- Y16 memory_shared [p011,p023] シオン told メイ about project_failure:hold_ritual intensity=0.79 generation=6
- Y17 memory_shared [p011,p023] シオン told メイ about project_failure:hold_ritual intensity=0.81 generation=6
- Y19 memory_shared [p007,p011] ファラ told シオン about project_failure:hold_ritual intensity=0.80 generation=4
- Y21 memory_shared [p011,p023] シオン told メイ about project_failure:hold_ritual intensity=0.70 generation=5
- Y23 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.66 generation=2
- Y25 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.57 generation=2
- Y26 memory_shared [p004,p011] オルン told シオン about project_failure:store_food intensity=0.54 generation=2
- Y29 memory_shared [p005,p011] オルン told シオン about project_failure:store_food intensity=0.46 generation=2
- Y29 memory_shared [p011,p023] シオン told メイ about death intensity=0.69 generation=1
- Y29 memory_shared [p011,p018] シオン told ダン about death intensity=0.66 generation=1
- Y32 memory_shared [p011,p023] シオン told メイ about death intensity=0.68 generation=1
- ... 9 more

## p000 ゾル

Basic profile:

- initial age=39, charisma=0.425, food_skill=0.253, incoming_trust=0.736, trust_links=3
- initial bias: spiritual=0.1003, practical=0.1397, blame=0.1373
- final/death: alive=False, death_year=46, age=85, incoming_trust=0.0, trust_links=7, memory_count=7
- final bias: spiritual=0.1303, practical=0.1847, blame=0.1523

First receipt: Y21, mode=heard_memory, from=p019 ハナ, interpretation=practical, intensity=0.42, generation=1

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 1
- proposal_supported_as_proposer: 0
- project_participation: 1
- project_failure_participation: 0
- project_success_participation: 1
- memory_shared_as_speaker: 2
- memory_shared_as_listener: 1
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 22

Retells of the target Year14 memory:

- none

Selected post-receipt events:

- Y21 memory_shared [p019,p000] ハナ told ゾル about project_failure:store_food intensity=0.42 generation=1
- Y29 memory_shared [p000,p018] ゾル told ダン about death intensity=0.57 generation=1
- Y37 memory_shared [p000,p018] ゾル told ダン about death intensity=0.59 generation=1
- Y42 proposal_supported [p000,p008] ゾル supported hunt_group
- Y42 project_started [p008,p000,p003,p008,p009,p011,p021,p032,p033,p039,p040,p042] project_started: hunt_group for storage_damage supporters=11
- Y42 project_success [p008,p000,p003,p008,p009,p011,p021,p032,p033,p039,p040,p042] project_success: hunt_group for storage_damage chance=0.60
- Y46 death [p000] ゾル died age=85 health=1.00

## p028 ゾル

Basic profile:

- initial age=45, charisma=0.402, food_skill=0.342, incoming_trust=0.815, trust_links=3
- initial bias: spiritual=0.0667, practical=0.1371, blame=0.0535
- final/death: alive=False, death_year=40, age=85, incoming_trust=0.208, trust_links=11, memory_count=20
- final bias: spiritual=0.0817, practical=0.1371, blame=0.0835

First receipt: Y16, mode=heard_memory, from=p001 ケイ, interpretation=spiritual, intensity=0.66, generation=1

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 1
- proposal_supported_as_proposer: 0
- project_participation: 1
- project_failure_participation: 0
- project_success_participation: 1
- memory_shared_as_speaker: 5
- memory_shared_as_listener: 12
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 11

Retells of the target Year14 memory:

- Y18: p028 ゾル -> p003 ハナ (interpretation=spiritual, gen=2, intensity=0.56)
- Y21: p028 ゾル -> p003 ハナ (interpretation=spiritual, gen=2, intensity=0.56)
- Y24: p028 ゾル -> p003 ハナ (interpretation=blame, gen=2, intensity=0.47)

Selected post-receipt events:

- Y16 memory_shared [p001,p028] ケイ told ゾル about project_failure:store_food intensity=0.66 generation=1
- Y18 memory_shared [p028,p003] ゾル told ハナ about project_failure:store_food intensity=0.56 generation=2
- Y19 memory_shared [p001,p028] ケイ told ゾル about project_failure:store_food intensity=0.55 generation=1
- Y21 memory_shared [p001,p028] ケイ told ゾル about project_failure:store_food intensity=0.46 generation=1
- Y21 memory_shared [p028,p003] ゾル told ハナ about project_failure:store_food intensity=0.56 generation=2
- Y22 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.49 generation=1
- Y23 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.44 generation=1
- Y24 memory_shared [p028,p003] ゾル told ハナ about project_failure:store_food intensity=0.47 generation=2
- Y24 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.45 generation=1
- Y27 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.40 generation=1
- Y29 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.47 generation=1
- Y31 memory_shared [p001,p028] ケイ told ゾル about death intensity=0.50 generation=1
- Y31 memory_shared [p032,p028] ゾル told ゾル about death intensity=0.59 generation=2
- Y33 proposal_supported [p028,p006] ゾル supported dig_well
- Y33 project_started [p006,p015,p018,p023,p028,p030,p039,p041,p042] project_started: dig_well for water_shortage supporters=8
- Y33 project_success [p006,p015,p018,p023,p028,p030,p039,p041,p042] project_success: dig_well for water_shortage chance=0.48
- Y35 memory_shared [p032,p028] ゾル told ゾル about death intensity=0.56 generation=1
- Y37 memory_shared [p028,p003] ゾル told ハナ about death intensity=0.59 generation=2
- ... 3 more

## p032 ゾル

Basic profile:

- initial age=43, charisma=0.233, food_skill=0.284, incoming_trust=0.829, trust_links=5
- initial bias: spiritual=0.0681, practical=0.1051, blame=0.1253
- final/death: alive=False, death_year=46, age=89, incoming_trust=0.278, trust_links=14, memory_count=18
- final bias: spiritual=0.1131, practical=0.1801, blame=0.1703

First receipt: Y14, mode=experienced_failure, from=p006 シオン, interpretation=blame, intensity=0.58, generation=0

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 3
- proposal_supported_as_proposer: 0
- project_participation: 3
- project_failure_participation: 2
- project_success_participation: 1
- memory_shared_as_speaker: 9
- memory_shared_as_listener: 7
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 18

Retells of the target Year14 memory:

- Y22: p032 ゾル -> p028 ゾル (interpretation=blame, gen=1, intensity=0.49)
- Y23: p032 ゾル -> p028 ゾル (interpretation=blame, gen=1, intensity=0.44)
- Y24: p032 ゾル -> p028 ゾル (interpretation=blame, gen=1, intensity=0.45)
- Y27: p032 ゾル -> p028 ゾル (interpretation=blame, gen=1, intensity=0.40)
- Y27: p032 ゾル -> p005 オルン (interpretation=blame, gen=1, intensity=0.44)
- Y29: p032 ゾル -> p028 ゾル (interpretation=spiritual, gen=1, intensity=0.47)

Selected post-receipt events:

- Y14 proposal_supported [p032,p006] ゾル supported store_food
- Y14 project_started [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_started: store_food for water_shortage supporters=11
- Y14 project_failure [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_failure: store_food for water_shortage chance=0.60
- Y14 memory_shared [p002,p032] ノア told ゾル about project_failure:store_food intensity=0.54 generation=1
- Y15 proposal_supported [p032,p030] ゾル supported store_food
- Y15 project_started [p030,p008,p009,p011,p016,p017,p024,p030,p032,p033,p034,p037] project_started: store_food for storage_damage supporters=11
- Y15 project_failure [p030,p008,p009,p011,p016,p017,p024,p030,p032,p033,p034,p037] project_failure: store_food for storage_damage chance=0.56
- Y16 memory_shared [p002,p032] ノア told ゾル about project_failure:store_food intensity=0.54 generation=1
- Y22 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.49 generation=1
- Y23 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.44 generation=1
- Y24 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.45 generation=1
- Y27 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.40 generation=1
- Y27 memory_shared [p032,p005] ゾル told オルン about project_failure:store_food intensity=0.44 generation=1
- Y29 memory_shared [p032,p028] ゾル told ゾル about project_failure:store_food intensity=0.47 generation=1
- Y30 memory_shared [p002,p032] ノア told ゾル about death intensity=0.67 generation=1
- Y31 memory_shared [p002,p032] ノア told ゾル about death intensity=0.56 generation=1
- Y31 memory_shared [p032,p028] ゾル told ゾル about death intensity=0.59 generation=2
- Y35 memory_shared [p002,p032] ノア told ゾル about death intensity=0.56 generation=1
- ... 8 more

## p021 メイ

Basic profile:

- initial age=26, charisma=0.051, food_skill=0.866, incoming_trust=0.737, trust_links=3
- initial bias: spiritual=0.1312, practical=0.0878, blame=0.0677
- final/death: alive=False, death_year=65, age=91, incoming_trust=0.591, trust_links=11, memory_count=26
- final bias: spiritual=0.2362, practical=0.0878, blame=0.1577

First receipt: Y14, mode=experienced_failure, from=p006 シオン, interpretation=blame, intensity=0.58, generation=0

Post-receipt role counts:

- proposal_made: 0
- proposal_supported_as_supporter: 5
- proposal_supported_as_proposer: 0
- project_participation: 4
- project_failure_participation: 3
- project_success_participation: 1
- memory_shared_as_speaker: 10
- memory_shared_as_listener: 13
- birth_parent: 0
- death_self: 1
- inactive_years_after_receipt_or_Y14: 29

Retells of the target Year14 memory:

- Y17: p021 メイ -> p001 ケイ (interpretation=blame, gen=1, intensity=0.47)
- Y17: p021 メイ -> p023 メイ (interpretation=blame, gen=1, intensity=0.57)
- Y21: p021 メイ -> p001 ケイ (interpretation=practical, gen=2, intensity=0.58)
- Y23: p021 メイ -> p001 ケイ (interpretation=practical, gen=2, intensity=0.48)

Selected post-receipt events:

- Y14 proposal_supported [p021,p006] メイ supported store_food
- Y14 project_started [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_started: store_food for water_shortage supporters=11
- Y14 project_failure [p006,p001,p002,p011,p019,p021,p024,p027,p031,p032,p034,p035] project_failure: store_food for water_shortage chance=0.60
- Y17 memory_shared [p021,p001] メイ told ケイ about project_failure:store_food intensity=0.47 generation=1
- Y17 memory_shared [p021,p023] メイ told メイ about project_failure:store_food intensity=0.57 generation=1
- Y19 memory_shared [p035,p021] ルト told メイ about project_failure:store_food intensity=0.52 generation=1
- Y21 memory_shared [p021,p001] メイ told ケイ about project_failure:store_food intensity=0.58 generation=2
- Y23 memory_shared [p021,p001] メイ told ケイ about project_failure:store_food intensity=0.48 generation=2
- Y29 memory_shared [p035,p021] ルト told メイ about project_failure:store_food intensity=0.37 generation=1
- Y32 memory_shared [p035,p021] ルト told メイ about project_failure:store_food intensity=0.42 generation=1
- Y33 proposal_supported [p021,p008] メイ supported move_camp
- Y33 memory_shared [p035,p021] ルト told メイ about project_failure:store_food intensity=0.40 generation=1
- Y34 memory_shared [p035,p021] ルト told メイ about project_failure:store_food intensity=0.38 generation=1
- Y35 memory_shared [p021,p035] メイ told ルト about death intensity=0.67 generation=1
- Y35 memory_shared [p021,p001] メイ told ケイ about death intensity=0.56 generation=1
- Y36 proposal_supported [p021,p034] メイ supported dig_well
- Y36 project_started [p034,p002,p003,p010,p015,p018,p021,p031,p034,p042,p043] project_started: dig_well for water_shortage supporters=10
- Y36 project_failure [p034,p002,p003,p010,p015,p018,p021,p031,p034,p042,p043] project_failure: dig_well for water_shortage chance=0.55
- ... 19 more
