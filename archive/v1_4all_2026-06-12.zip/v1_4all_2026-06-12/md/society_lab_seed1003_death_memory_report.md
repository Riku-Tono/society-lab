# seed1003 death memory cut tests

## Purpose

This batch tests whether Y28 p019 Hana death memory entering p000 Zol is necessary or sufficient for the v1.4 trajectory. It keeps factual mechanism separate from narrative interpretation.

## Results

| exp | intervention | final pop | births | failures | memory shares | first diff | changed keys | p000 got Hana death | mode | Y28 strongest | Y29 action |
|---|---|---:|---:|---:|---:|---:|---:|---|---|---|---|
| DTH_BASE | baseline v1.4 | 18 | 18 | 9 | 323 |  | 0 | True | regular | death | reassure |
| DTH_NO_P000_DEATH_MEMORY | block only p000 receiving p019 death memory | 18 | 18 | 9 | 323 | 436 | 0 | False |  | death | reassure |
| DTH_ONLY_P000_DEATH_MEMORY | NO_KEY plus manual p000 p019 death memory | 18 | 18 | 9 | 323 |  | 0 | True | manual | death | reassure |
| DTH_FAKE_DEATH_MEMORY | NO_KEY plus fake death memory for p000 | 18 | 18 | 9 | 323 |  | 0 | True | manual | death | reassure |
| DTH_STRONGEST_FIXED | p000 receives p019 death but strongest_memory ignores death | 18 | 18 | 9 | 323 | 242 | 0 | True | regular | project_failure:store_food | reassure |
| DTH_MEMORY_COUNT_ONLY | NO_KEY plus neutral dummy memory count for p000 | 18 | 18 | 9 | 323 | 436 | 0 | True | manual | death | reassure |

## P000 State Y27-Y30

### DTH_BASE

```json
[
  {
    "year": 27,
    "alive": true,
    "age": 66,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 1,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.365,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.365,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      }
    ]
  },
  {
    "year": 28,
    "alive": true,
    "age": 67,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "share_memory",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6297,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3577,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3554,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6297,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 29,
    "alive": true,
    "age": 68,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "reassure",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6171,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3505,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3483,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6171,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 30,
    "alive": true,
    "age": 69,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6047,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3435,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3413,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6047,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  }
]
```

### DTH_NO_P000_DEATH_MEMORY

```json
[
  {
    "year": 27,
    "alive": true,
    "age": 66,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 1,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.365,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.365,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      }
    ]
  },
  {
    "year": 28,
    "alive": true,
    "age": 67,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "share_memory",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 2,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6297,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3577,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6297,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 29,
    "alive": true,
    "age": 68,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "reassure",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 2,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6171,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3505,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6171,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 30,
    "alive": true,
    "age": 69,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 2,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6047,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3435,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6047,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  }
]
```

### DTH_ONLY_P000_DEATH_MEMORY

```json
[
  {
    "year": 27,
    "alive": true,
    "age": 66,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 1,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.365,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.365,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      }
    ]
  },
  {
    "year": 28,
    "alive": true,
    "age": 67,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "share_memory",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6297,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3577,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3554,
        "generation": 0,
        "source": "manual_p019_death",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6297,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 29,
    "alive": true,
    "age": 68,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "reassure",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6171,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3505,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3483,
        "generation": 0,
        "source": "manual_p019_death",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6171,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 30,
    "alive": true,
    "age": 69,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6047,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3435,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3413,
        "generation": 0,
        "source": "manual_p019_death",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6047,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  }
]
```

### DTH_FAKE_DEATH_MEMORY

```json
[
  {
    "year": 27,
    "alive": true,
    "age": 66,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 1,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.365,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.365,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      }
    ]
  },
  {
    "year": 28,
    "alive": true,
    "age": 67,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "share_memory",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6297,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3577,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3554,
        "generation": 0,
        "source": "manual_fake_death",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6297,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 29,
    "alive": true,
    "age": 68,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "reassure",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6171,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3505,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3483,
        "generation": 0,
        "source": "manual_fake_death",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6171,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 30,
    "alive": true,
    "age": 69,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6047,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3435,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3413,
        "generation": 0,
        "source": "manual_fake_death",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6047,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  }
]
```

### DTH_STRONGEST_FIXED

```json
[
  {
    "year": 27,
    "alive": true,
    "age": 66,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 1,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.365,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.365,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      }
    ]
  },
  {
    "year": 28,
    "alive": true,
    "age": 67,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "share_memory",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.3577,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3577,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3554,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6297,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 29,
    "alive": true,
    "age": 68,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "reassure",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.3505,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3505,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3483,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6171,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 30,
    "alive": true,
    "age": 69,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026",
      "p019"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.3435,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3435,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.3413,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6047,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  }
]
```

### DTH_MEMORY_COUNT_ONLY

```json
[
  {
    "year": 27,
    "alive": true,
    "age": 66,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 1,
    "strongest_memory": {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.365,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.365,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      }
    ]
  },
  {
    "year": 28,
    "alive": true,
    "age": 67,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "share_memory",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6297,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3577,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "neutral_marker",
        "year": 28,
        "intensity": 0.3554,
        "generation": 0,
        "source": "manual_dummy",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6297,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 29,
    "alive": true,
    "age": 68,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "reassure",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6171,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3505,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "neutral_marker",
        "year": 28,
        "intensity": 0.3483,
        "generation": 0,
        "source": "manual_dummy",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6171,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  },
  {
    "year": 30,
    "alive": true,
    "age": 69,
    "health": 1.0,
    "hunger": 0.0,
    "fear": 0.0,
    "action": "withdraw",
    "top_trusted": [
      "p018",
      "p028",
      "p026"
    ],
    "memory_count": 3,
    "strongest_memory": {
      "event": "death",
      "year": 28,
      "intensity": 0.6047,
      "generation": 0,
      "source": "self",
      "interpretation": "spiritual"
    },
    "memories": [
      {
        "event": "project_failure:store_food",
        "year": 14,
        "intensity": 0.3435,
        "generation": 1,
        "source": "p019",
        "interpretation": "practical"
      },
      {
        "event": "neutral_marker",
        "year": 28,
        "intensity": 0.3413,
        "generation": 0,
        "source": "manual_dummy",
        "interpretation": "spiritual"
      },
      {
        "event": "death",
        "year": 28,
        "intensity": 0.6047,
        "generation": 0,
        "source": "self",
        "interpretation": "spiritual"
      }
    ]
  }
]
```

## Cautious Reading

- DTH_NO_P000_DEATH_MEMORY tests necessity: if it diverges, p000's Hana-death memory is needed for the baseline path.
- DTH_ONLY_P000_DEATH_MEMORY tests sufficiency under NO_KEY: if it returns to baseline, the death memory itself is sufficient.
- DTH_FAKE_DEATH_MEMORY tests whether a generic death memory is enough in this code, where event/source are what downstream logic can inspect.
- DTH_STRONGEST_FIXED tests whether p000 speaking from death as strongest_memory is required.
- DTH_MEMORY_COUNT_ONLY tests whether merely adding one memory-like object is enough.

## Narrative Boundary

The factual chain is death memory / strongest_memory / action / trajectory. Any reading about grief, regret, or re-meaning is interpretive and is not directly represented as a model variable.
