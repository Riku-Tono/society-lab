# Actor Trace p033 seed 1003

## Overview

- roles: ['death_memory_holder', 'interpretation_moved_supporter', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter']
- biography events: 46
- memory told count: 10
- top listeners: [('p013', 7), ('p008', 3)]

## Root Memories

| memory_id | event | year | interpretation | descendant_events | unique_holders | max_depth | last_year | interpretations_seen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00367 | project_success:hunt_group | 42 | blame | 2 | 2 | 1 | 43 | {'blame': 2} |
| m00144 | death | 22 | blame | 1 | 1 | 0 | 22 | {'blame': 1} |
| m00095 | project_failure:store_food | 15 | blame | 1 | 1 | 0 | 15 | {'blame': 1} |
| m00013 | project_failure:hold_ritual | 2 | practical | 1 | 1 | 0 | 2 | {'practical': 1} |

## Biography

| year | bio_event | memory_id | event | listener_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | proposal_supported |  |  |  | p029 | hold_ritual | water_shortage | 0.0 |
| 2 | project_started |  |  |  | p029 | hold_ritual | water_shortage |  |
| 2 | memory_created | m00013 | project_failure:hold_ritual |  |  |  |  |  |
| 2 | project_failure |  |  |  | p029 | hold_ritual | water_shortage |  |
| 2 | memory_received | m00015 | project_failure:hold_ritual |  |  |  |  |  |
| 2 | memory_told | m00015 | project_failure:hold_ritual | p013 |  |  |  |  |
| 2 | memory_told | m00015 | project_failure:hold_ritual | p008 |  |  |  |  |
| 4 | memory_told | m00015 | project_failure:hold_ritual | p013 |  |  |  |  |
| 6 | memory_received | m00032 | project_failure:hold_ritual |  |  |  |  |  |
| 8 | memory_received | m00044 | project_failure:hold_ritual |  |  |  |  |  |
| 9 | memory_received | m00047 | project_failure:hold_ritual |  |  |  |  |  |
| 11 | memory_received | m00059 | project_failure:hold_ritual |  |  |  |  |  |
| 12 | memory_told | m00044 | project_failure:hold_ritual | p013 |  |  |  |  |
| 13 | memory_received | m00071 | project_failure:hold_ritual |  |  |  |  |  |
| 14 | proposal_supported |  |  |  | p008 | move_camp | water_shortage | 0.0 |
| 14 | memory_received | m00086 | project_failure:store_food |  |  |  |  |  |
| 15 | proposal_supported |  |  |  | p030 | store_food | storage_damage | 0.03 |
| 15 | project_started |  |  |  | p030 | store_food | storage_damage |  |
| 15 | memory_created | m00095 | project_failure:store_food |  |  |  |  |  |
| 15 | project_failure |  |  |  | p030 | store_food | storage_damage |  |
| 18 | memory_told | m00086 | project_failure:store_food | p013 |  |  |  |  |
| 19 | memory_received | m00126 | project_failure:store_food |  |  |  |  |  |
| 22 | proposal_supported |  |  |  | p008 | hold_ritual | storage_damage | 0.0 |
| 22 | memory_created | m00144 | death |  |  |  |  |  |
| 23 | memory_received | m00148 | project_failure:store_food |  |  |  |  |  |
| 25 | memory_received | m00166 | project_failure:store_food |  |  |  |  |  |
| 27 | memory_received | m00172 | project_failure:store_food |  |  |  |  |  |
| 29 | memory_received | m00208 | death |  |  |  |  |  |
| 30 | memory_told | m00208 | death | p013 |  |  |  |  |
| 33 | memory_received | m00252 | death |  |  |  |  |  |
| 34 | memory_told | m00252 | death | p013 |  |  |  |  |
| 34 | memory_told | m00252 | death | p008 |  |  |  |  |
| 35 | memory_received | m00269 | death |  |  |  |  |  |
| 35 | memory_told | m00252 | death | p013 |  |  |  |  |
| 38 | memory_received | m00303 | project_failure:dig_well |  |  |  |  |  |
| 40 | memory_received | m00327 | project_failure:dig_well |  |  |  |  |  |
| 41 | memory_received | m00351 | project_failure:dig_well |  |  |  |  |  |
| 41 | memory_received | m00353 | project_failure:dig_well |  |  |  |  |  |
| 42 | proposal_supported |  |  |  | p008 | hunt_group | storage_damage | 0.03 |
| 42 | project_started |  |  |  | p008 | hunt_group | storage_damage |  |
| 42 | memory_created | m00367 | project_success:hunt_group |  |  |  |  |  |
| 42 | project_success |  |  |  | p008 | hunt_group | storage_damage |  |
| 42 | memory_received | m00374 | project_failure:dig_well |  |  |  |  |  |
| 43 | memory_received | m00384 | project_failure:dig_well |  |  |  |  |  |
| 43 | memory_told | m00367 | project_success:hunt_group | p008 |  |  |  |  |
| 43 | death |  |  |  |  |  |  |  |

## Support Events Involving Actor

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance |
| --- | --- | --- | --- | --- | --- | --- |
| 2 | p033 | p029 | hold_ritual | water_shortage | 0.0 | 0.3038 |
| 14 | p033 | p008 | move_camp | water_shortage | 0.0 | 0.3454 |
| 15 | p033 | p030 | store_food | storage_damage | 0.03 | 0.2522 |
| 22 | p033 | p008 | hold_ritual | storage_damage | 0.0 | 0.2982 |
| 42 | p033 | p008 | hunt_group | storage_damage | 0.03 | 0.3991 |

## Project Rows Where Actor Proposed

_none_

## Memory/Support Proximity Within 5 Years

| gap_years | memory_year | memory_id | memory_event | memory_interpretation | support_year | supporter_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 2 | m00013 | project_failure:hold_ritual | practical | 2 | p033 | p029 | hold_ritual | water_shortage | 0.0 |
| 0 | 2 | m00015 | project_failure:hold_ritual | spiritual | 2 | p033 | p029 | hold_ritual | water_shortage | 0.0 |
| 0 | 2 | m00016 | project_failure:hold_ritual | spiritual | 2 | p033 | p029 | hold_ritual | water_shortage | 0.0 |
| 0 | 2 | m00017 | project_failure:hold_ritual | spiritual | 2 | p033 | p029 | hold_ritual | water_shortage | 0.0 |
| 0 | 14 | m00086 | project_failure:store_food | practical | 14 | p033 | p008 | move_camp | water_shortage | 0.0 |
| 0 | 15 | m00095 | project_failure:store_food | blame | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 0 | 22 | m00144 | death | blame | 22 | p033 | p008 | hold_ritual | storage_damage | 0.0 |
| 0 | 42 | m00367 | project_success:hunt_group | blame | 42 | p033 | p008 | hunt_group | storage_damage | 0.03 |
| 0 | 42 | m00374 | project_failure:dig_well | spiritual | 42 | p033 | p008 | hunt_group | storage_damage | 0.03 |
| 1 | 13 | m00071 | project_failure:hold_ritual | spiritual | 14 | p033 | p008 | move_camp | water_shortage | 0.0 |
| 1 | 14 | m00086 | project_failure:store_food | practical | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 1 | 41 | m00351 | project_failure:dig_well | spiritual | 42 | p033 | p008 | hunt_group | storage_damage | 0.03 |
| 1 | 41 | m00353 | project_failure:dig_well | spiritual | 42 | p033 | p008 | hunt_group | storage_damage | 0.03 |
| 2 | 12 | m00066 | project_failure:hold_ritual | practical | 14 | p033 | p008 | move_camp | water_shortage | 0.0 |
| 2 | 13 | m00071 | project_failure:hold_ritual | spiritual | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 2 | 40 | m00327 | project_failure:dig_well | spiritual | 42 | p033 | p008 | hunt_group | storage_damage | 0.03 |
| 3 | 11 | m00059 | project_failure:hold_ritual | spiritual | 14 | p033 | p008 | move_camp | water_shortage | 0.0 |
| 3 | 12 | m00066 | project_failure:hold_ritual | practical | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 3 | 19 | m00126 | project_failure:store_food | practical | 22 | p033 | p008 | hold_ritual | storage_damage | 0.0 |
| 4 | 11 | m00059 | project_failure:hold_ritual | spiritual | 15 | p033 | p030 | store_food | storage_damage | 0.03 |
| 4 | 18 | m00120 | project_failure:store_food | practical | 22 | p033 | p008 | hold_ritual | storage_damage | 0.0 |
| 4 | 38 | m00303 | project_failure:dig_well | spiritual | 42 | p033 | p008 | hunt_group | storage_damage | 0.03 |
| 5 | 9 | m00047 | project_failure:hold_ritual | practical | 14 | p033 | p008 | move_camp | water_shortage | 0.0 |
