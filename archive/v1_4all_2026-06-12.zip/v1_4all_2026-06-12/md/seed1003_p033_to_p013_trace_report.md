# p033 to p013 trace seed 1003

## Overview

- relay roles: ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver']
- memories received from source: 7
- relay transmissions to third people: 20
- interpretation changes after relay: 1
- third person counts: [('p030', 6), ('p007', 5), ('p026', 3), ('p037', 3), ('p029', 2), ('p016', 1)]

## Memories Received From Source

| year | memory_id | parent_memory_id | event | intensity | generation | interpretation |
| --- | --- | --- | --- | --- | --- | --- |
| 2 | m00016 | m00015 | project_failure:hold_ritual | 0.5545 | 2 | spiritual |
| 4 | m00026 | m00015 | project_failure:hold_ritual | 0.5493 | 2 | blame |
| 12 | m00066 | m00044 | project_failure:hold_ritual | 0.6614 | 2 | practical |
| 18 | m00120 | m00086 | project_failure:store_food | 0.6257 | 2 | practical |
| 30 | m00220 | m00208 | death | 0.5312 | 2 | blame |
| 34 | m00259 | m00252 | death | 0.7013 | 2 | practical |
| 35 | m00271 | m00252 | death | 0.757 | 2 | blame |

## Rooted Received Summary

| root_memory_id | root_event | root_year | root_interpretation | received_memory_id | received_year | received_interpretation | branch_events_from_relay | third_person_events | third_person_holders | max_depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00016 | 2 | spiritual | 1 | 0 | [] | 0 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00026 | 4 | blame | 2 | 1 | ['p030'] | 1 |
| m00011 | project_failure:hold_ritual | 2 | spiritual | m00066 | 12 | practical | 16 | 15 | ['p007', 'p016', 'p026', 'p029', 'p030', 'p037'] | 7 |
| m00080 | project_failure:store_food | 14 | practical | m00120 | 18 | practical | 3 | 2 | ['p026', 'p030'] | 2 |
| m00190 | death | 28 | blame | m00220 | 30 | blame | 1 | 0 | [] | 0 |
| m00230 | death | 31 | blame | m00259 | 34 | practical | 1 | 0 | [] | 0 |
| m00230 | death | 31 | blame | m00271 | 35 | blame | 3 | 2 | ['p030'] | 1 |

## Relay Transmissions To Third People

| root_memory_id | received_memory_id | memory_id | year | event | holder_id | source_id | interpretation | depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | m00026 | m00042 | 8 | project_failure:hold_ritual | p030 | p013 | blame | 1 |
| m00011 | m00066 | m00069 | 13 | project_failure:hold_ritual | p030 | p013 | practical | 1 |
| m00011 | m00066 | m00110 | 16 | project_failure:hold_ritual | p030 | p013 | practical | 1 |
| m00011 | m00066 | m00112 | 16 | project_failure:hold_ritual | p026 | p030 | practical | 2 |
| m00011 | m00066 | m00119 | 18 | project_failure:hold_ritual | p026 | p030 | practical | 2 |
| m00011 | m00066 | m00125 | 19 | project_failure:hold_ritual | p016 | p026 | practical | 3 |
| m00011 | m00066 | m00234 | 32 | project_failure:hold_ritual | p029 | p016 | practical | 4 |
| m00011 | m00066 | m00308 | 39 | project_failure:hold_ritual | p029 | p016 | practical | 4 |
| m00011 | m00066 | m00251 | 33 | project_failure:hold_ritual | p007 | p029 | practical | 5 |
| m00011 | m00066 | m00457 | 48 | project_failure:hold_ritual | p007 | p029 | practical | 5 |
| m00011 | m00066 | m00283 | 36 | project_failure:hold_ritual | p037 | p007 | practical | 6 |
| m00011 | m00066 | m00468 | 50 | project_failure:hold_ritual | p037 | p007 | spiritual | 6 |
| m00011 | m00066 | m00534 | 58 | project_failure:hold_ritual | p037 | p007 | practical | 6 |
| m00011 | m00066 | m00311 | 39 | project_failure:hold_ritual | p007 | p037 | practical | 7 |
| m00011 | m00066 | m00386 | 43 | project_failure:hold_ritual | p007 | p037 | practical | 7 |
| m00011 | m00066 | m00458 | 48 | project_failure:hold_ritual | p007 | p037 | practical | 7 |
| m00080 | m00120 | m00139 | 22 | project_failure:store_food | p030 | p013 | practical | 1 |
| m00080 | m00120 | m00169 | 26 | project_failure:store_food | p026 | p030 | practical | 2 |
| m00230 | m00271 | m00284 | 36 | death | p030 | p013 | blame | 1 |
| m00230 | m00271 | m00290 | 37 | death | p030 | p013 | blame | 1 |

## Interpretation Changes After Relay

| root_memory_id | from_memory_id | to_memory_id | year | holder_id | from_interpretation | to_interpretation | depth_from_relay |
| --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | m00066 | m00468 | 50 | p037 | practical | spiritual | 6 |

## Relay Support Near Source Memories Within 5 Years

_none_

## Relay Biography Focus

| year | bio_event | memory_id | parent_memory_id | speaker_id | listener_id | event | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | memory_received | m00016 | m00015 | p033 |  | project_failure:hold_ritual |  |  |  |  |
| 4 | memory_received | m00026 | m00015 | p033 |  | project_failure:hold_ritual |  |  |  |  |
| 8 | memory_told | m00026 |  |  | p030 | project_failure:hold_ritual |  |  |  |  |
| 12 | memory_received | m00066 | m00044 | p033 |  | project_failure:hold_ritual |  |  |  |  |
| 13 | memory_told | m00066 |  |  | p030 | project_failure:hold_ritual |  |  |  |  |
| 16 | memory_told | m00066 |  |  | p030 | project_failure:hold_ritual |  |  |  |  |
| 18 | memory_received | m00120 | m00086 | p033 |  | project_failure:store_food |  |  |  |  |
| 22 | memory_told | m00120 |  |  | p030 | project_failure:store_food |  |  |  |  |
| 30 | memory_received | m00220 | m00208 | p033 |  | death |  |  |  |  |
| 33 | memory_told | m00161 |  |  | p030 | death |  |  |  |  |
| 34 | memory_told | m00161 |  |  | p030 | death |  |  |  |  |
| 34 | memory_told | m00161 |  |  | p016 | death |  |  |  |  |
| 34 | memory_received | m00259 | m00252 | p033 |  | death |  |  |  |  |
| 35 | memory_received | m00271 | m00252 | p033 |  | death |  |  |  |  |
| 36 | memory_told | m00271 |  |  | p030 | death |  |  |  |  |
| 37 | memory_told | m00271 |  |  | p030 | death |  |  |  |  |
| 42 | memory_told | m00317 |  |  | p030 | death |  |  |  |  |
| 42 | memory_told | m00317 |  |  | p016 | death |  |  |  |  |
| 48 | proposal_supported |  |  |  |  |  | p029 | store_food | storage_damage | 0.03 |
| 48 | project_started |  |  |  |  |  | p029 | store_food | storage_damage |  |
| 48 | project_failure |  |  |  |  |  | p029 | store_food | storage_damage |  |
| 49 | memory_told | m00379 |  |  | p030 | death |  |  |  |  |
| 52 | memory_told | m00379 |  |  | p030 | death |  |  |  |  |
| 59 | memory_told | m00379 |  |  | p030 | death |  |  |  |  |
