# seed 1024 p004 Sana trace

Focus: p004 Sana from Year 38 to Year 46 after the Year38 support/project participation difference.

## Status At Year 46

| version | status |
| --- | --- |
| v1.3 | p004:サナ:age=89:sex=f:alive=True:health=1.00:hunger=0.00:action=share_memory |
| v1.4 | p004:サナ:age=82:sex=f:alive=False:health=1.00:hunger=0.00:action=ask_help |

## P004-Involved Events And Birth/Death Context

### v1.3

| year | alive_after_year | age_after_year | event | role | persons | detail |
| --- | --- | --- | --- | --- | --- | --- |
| 38 | True | 81 | proposal_supported | participant | p004,p014 | サナ supported move_camp |
| 38 | True | 81 | project_started | participant | p014,p001,p004,p006,p007,p011,p013,p015,p021,p024 | project_started: move_camp for storage_damage supporters=9 |
| 38 | True | 81 | project_failure | participant | p014,p001,p004,p006,p007,p011,p013,p015,p021,p024 | project_failure: move_camp for storage_damage chance=0.74 |
| 38 | True | 81 | death | - | p007 | リオ died age=88 health=1.00 |
| 38 | True | 81 | shared_narrative | participant | p001,p004,p006,p011,p013,p015,p021,p024 | shared_narrative detected: project_failure:move_camp, 8 persons, avg_intensity 0.55 |
| 39 | True | 82 | shared_narrative | participant | p000,p001,p002,p003,p004,p006,p008,p009,p011,p014,p015,p016,p019,p020,p021 | shared_narrative detected: project_success:dig_well, 15 persons, avg_intensity 0.60 |
| 39 | True | 82 | shared_narrative | participant | p001,p002,p003,p004,p005,p008,p009,p014,p015,p017,p019,p020,p021,p022 | shared_narrative detected: project_failure:dig_well, 14 persons, avg_intensity 0.53 |
| 40 | True | 83 | death | - | p011 | ルト died age=86 health=1.00 |
| 41 | True | 84 | memory_shared | speaker | p004,p019 | サナ told タロ about project_failure:dig_well intensity=0.58 generation=3 |
| 41 | True | 84 | memory_shared | speaker | p004,p003 | サナ told イシュ about project_failure:dig_well intensity=0.62 generation=3 |
| 41 | True | 84 | memory_shared | listener | p019,p004 | タロ told サナ about project_failure:dig_well intensity=0.69 generation=4 |
| 42 | True | 85 | shared_narrative | participant | p000,p001,p003,p004,p005,p006,p008,p009,p013,p014,p015,p016,p017,p019,p020,p023 | shared_narrative detected: death, 16 persons, avg_intensity 0.56 |
| 43 | True | 86 | memory_shared | speaker | p004,p019 | サナ told タロ about project_failure:dig_well intensity=0.95 generation=5 |
| 43 | True | 86 | memory_shared | listener | p019,p004 | タロ told サナ about project_success:dig_well intensity=0.81 generation=7 |
| 43 | True | 86 | shared_narrative | participant | p001,p002,p004,p006,p013,p015,p021,p024 | shared_narrative detected: project_failure:move_camp, 8 persons, avg_intensity 0.49 |
| 44 | True | 87 | memory_shared | listener | p019,p004 | タロ told サナ about project_success:dig_well intensity=1.00 generation=7 |
| 44 | True | 87 | shared_narrative | participant | p000,p001,p002,p003,p004,p006,p008,p009,p014,p015,p016,p019,p020,p021 | shared_narrative detected: project_success:dig_well, 14 persons, avg_intensity 0.63 |
| 44 | True | 87 | shared_narrative | participant | p001,p002,p003,p004,p005,p008,p009,p014,p015,p017,p019,p020,p021,p022 | shared_narrative detected: project_failure:dig_well, 14 persons, avg_intensity 0.52 |
| 46 | True | 89 | death | - | p015 | エリン died age=91 health=1.00 |

### v1.4

| year | alive_after_year | age_after_year | event | role | persons | detail |
| --- | --- | --- | --- | --- | --- | --- |
| 38 | True | 81 | proposal_supported | participant | p004,p008 | サナ supported store_food |
| 39 | False | 82 | memory_shared | listener | p019,p004 | タロ told サナ about project_failure:dig_well intensity=0.61 generation=2 |
| 39 | False | 82 | death | participant | p004 | サナ died age=82 health=1.00 |
| 40 | False | 82 | death | - | p015 | エリン died age=85 health=1.00 |
| 42 | False | 82 | birth | - | p021,p026 | タロ had a child: ケイ |
| 43 | False | 82 | birth | - | p020,p027 | オルン had a child: ヴァル |
| 44 | False | 82 | death | - | p007 | リオ died age=94 health=1.00 |
| 44 | False | 82 | birth | - | p020,p028 | オルン had a child: ダン |
| 45 | False | 82 | death | - | p014 | レン died age=93 health=1.00 |
| 46 | False | 82 | birth | - | p021,p029 | タロ had a child: ファラ |

## Direct Check

- v1.3 p004 alive at Year46: True; age=89
- v1.4 p004 alive at Year46: False; age=82
- Birth events where p004 is the parent: []
- Memory shares involving p004: [{'version': 'v1.3', 'year': '41', 'p004_alive_after_year': 'True', 'p004_age_after_year': '84', 'event_type': 'memory_shared', 'role': 'speaker', 'persons': 'p004,p019', 'detail': 'サナ told タロ about project_failure:dig_well intensity=0.58 generation=3'}, {'version': 'v1.3', 'year': '41', 'p004_alive_after_year': 'True', 'p004_age_after_year': '84', 'event_type': 'memory_shared', 'role': 'speaker', 'persons': 'p004,p003', 'detail': 'サナ told イシュ about project_failure:dig_well intensity=0.62 generation=3'}, {'version': 'v1.3', 'year': '41', 'p004_alive_after_year': 'True', 'p004_age_after_year': '84', 'event_type': 'memory_shared', 'role': 'listener', 'persons': 'p019,p004', 'detail': 'タロ told サナ about project_failure:dig_well intensity=0.69 generation=4'}, {'version': 'v1.3', 'year': '43', 'p004_alive_after_year': 'True', 'p004_age_after_year': '86', 'event_type': 'memory_shared', 'role': 'speaker', 'persons': 'p004,p019', 'detail': 'サナ told タロ about project_failure:dig_well intensity=0.95 generation=5'}, {'version': 'v1.3', 'year': '43', 'p004_alive_after_year': 'True', 'p004_age_after_year': '86', 'event_type': 'memory_shared', 'role': 'listener', 'persons': 'p019,p004', 'detail': 'タロ told サナ about project_success:dig_well intensity=0.81 generation=7'}, {'version': 'v1.3', 'year': '44', 'p004_alive_after_year': 'True', 'p004_age_after_year': '87', 'event_type': 'memory_shared', 'role': 'listener', 'persons': 'p019,p004', 'detail': 'タロ told サナ about project_success:dig_well intensity=1.00 generation=7'}, {'version': 'v1.4', 'year': '39', 'p004_alive_after_year': 'False', 'p004_age_after_year': '82', 'event_type': 'memory_shared', 'role': 'listener', 'persons': 'p019,p004', 'detail': 'タロ told サナ about project_failure:dig_well intensity=0.61 generation=2'}]