# Actor Trace p013 seed 1003

## Overview

- roles: ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver']
- biography events: 32
- memory told count: 14
- top listeners: [('p030', 12), ('p016', 2)]

## Root Memories

| memory_id | event | year | interpretation | descendant_events | unique_holders | max_depth | last_year | interpretations_seen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m00379 | death | 42 | blame | 4 | 2 | 1 | 59 | {'blame': 3, 'practical': 1} |
| m00161 | death | 24 | practical | 4 | 3 | 1 | 34 | {'practical': 3, 'blame': 1} |
| m00317 | death | 39 | blame | 3 | 3 | 1 | 42 | {'blame': 3} |
| m00541 | death | 59 | blame | 1 | 1 | 0 | 59 | {'blame': 1} |
| m00515 | death | 54 | blame | 1 | 1 | 0 | 54 | {'blame': 1} |
| m00450 | project_failure:store_food | 48 | practical | 1 | 1 | 0 | 48 | {'practical': 1} |
| m00396 | death | 43 | spiritual | 1 | 1 | 0 | 43 | {'spiritual': 1} |

## Biography

| year | bio_event | memory_id | event | listener_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | memory_received | m00016 | project_failure:hold_ritual |  |  |  |  |  |
| 4 | memory_received | m00026 | project_failure:hold_ritual |  |  |  |  |  |
| 8 | memory_told | m00026 | project_failure:hold_ritual | p030 |  |  |  |  |
| 12 | memory_received | m00066 | project_failure:hold_ritual |  |  |  |  |  |
| 13 | memory_told | m00066 | project_failure:hold_ritual | p030 |  |  |  |  |
| 16 | memory_told | m00066 | project_failure:hold_ritual | p030 |  |  |  |  |
| 18 | memory_received | m00120 | project_failure:store_food |  |  |  |  |  |
| 22 | memory_told | m00120 | project_failure:store_food | p030 |  |  |  |  |
| 24 | memory_created | m00161 | death |  |  |  |  |  |
| 30 | memory_received | m00220 | death |  |  |  |  |  |
| 33 | memory_told | m00161 | death | p030 |  |  |  |  |
| 34 | memory_told | m00161 | death | p030 |  |  |  |  |
| 34 | memory_told | m00161 | death | p016 |  |  |  |  |
| 34 | memory_received | m00259 | death |  |  |  |  |  |
| 35 | memory_received | m00271 | death |  |  |  |  |  |
| 36 | memory_told | m00271 | death | p030 |  |  |  |  |
| 37 | memory_told | m00271 | death | p030 |  |  |  |  |
| 39 | memory_created | m00317 | death |  |  |  |  |  |
| 42 | memory_told | m00317 | death | p030 |  |  |  |  |
| 42 | memory_told | m00317 | death | p016 |  |  |  |  |
| 42 | memory_created | m00379 | death |  |  |  |  |  |
| 43 | memory_created | m00396 | death |  |  |  |  |  |
| 48 | proposal_supported |  |  |  | p029 | store_food | storage_damage | 0.03 |
| 48 | project_started |  |  |  | p029 | store_food | storage_damage |  |
| 48 | memory_created | m00450 | project_failure:store_food |  |  |  |  |  |
| 48 | project_failure |  |  |  | p029 | store_food | storage_damage |  |
| 49 | memory_told | m00379 | death | p030 |  |  |  |  |
| 52 | memory_told | m00379 | death | p030 |  |  |  |  |
| 54 | memory_created | m00515 | death |  |  |  |  |  |
| 59 | memory_told | m00379 | death | p030 |  |  |  |  |
| 59 | memory_created | m00541 | death |  |  |  |  |  |
| 59 | death |  |  |  |  |  |  |  |

## Support Events Involving Actor

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance |
| --- | --- | --- | --- | --- | --- | --- |
| 48 | p013 | p029 | store_food | storage_damage | 0.03 | 0.2819 |

## Project Rows Where Actor Proposed

_none_

## Memory/Support Proximity Within 5 Years

| gap_years | memory_year | memory_id | memory_event | memory_interpretation | support_year | supporter_id | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 48 | m00450 | project_failure:store_food | practical | 48 | p013 | p029 | store_food | storage_damage | 0.03 |
| 5 | 43 | m00396 | death | spiritual | 48 | p013 | p029 | store_food | storage_damage | 0.03 |
