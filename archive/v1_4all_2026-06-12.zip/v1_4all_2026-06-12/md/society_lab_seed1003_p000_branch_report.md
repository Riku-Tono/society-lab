# society_lab seed1003 p000 branch trace

## Provisional Reading

F-I showed that `p019 Hana -> p000 Zol` is closer to a sufficient condition for the v1.4 path than the visible `p004 -> p011` branch. This report avoids saying `Zol caused history`; it separates p000 receipt, p000 re-sharing, p000 behavior effects, network position, and timing.

## p000 Profile

- id/name: `p000` ゾル
- sex: m
- age: initial 39, final 85
- charisma: 0.4249
- food_skill: 0.2528
- death_year: 46
- final health/hunger/fear: 1.0 / 0.0 / 0.0
- final bias: {'spiritual': 0.1303, 'practical': 0.1847, 'blame': 0.1523}
- top_trusted: ['p018', 'p028', 'p026', 'p008', 'p019']

Top incoming trust:

- p019 ハナ: 0.8151
- p016 サナ: 0.7228
- p030 オルン: 0.6709
- p018 ダン: 0.024
- p032 ゾル: 0.012

Top outgoing trust:

- p018 ダン: 0.6716
- p028 ゾル: 0.657
- p026 ルト: 0.6215
- p008 ルト: 0.067
- p019 ハナ: 0.012
- p042 レン: 0.012

## Network Snapshots

### Year 0

- in_degree/out_degree: 3 / 3
- weighted incoming/outgoing: 2.2088 / 1.9501
- closeness approx: 0.3636
- betweenness approx: 0.0189
- component size: 35
- distance to Hana/Orun/Shion: 2 / 3 / 3

### Year 14

- in_degree/out_degree: 3 / 3
- weighted incoming/outgoing: 2.2088 / 1.9501
- closeness approx: 0.3675
- betweenness approx: 0.01
- component size: 44
- distance to Hana/Orun/Shion: 2 / 3 / 3

### Year 21

- in_degree/out_degree: 3 / 4
- weighted incoming/outgoing: 2.2088 / 1.9621
- closeness approx: 0.4019
- betweenness approx: 0.0111
- component size: 44
- distance to Hana/Orun/Shion: 1 / 2 / 3

### Year 28

- in_degree/out_degree: 2 / 2
- weighted incoming/outgoing: 1.3937 / 1.3286
- closeness approx: 0.3451
- betweenness approx: 0.0081
- component size: 40
- distance to Hana/Orun/Shion: None / None / 3

### Year 40

- in_degree/out_degree: 2 / 0
- weighted incoming/outgoing: 1.3937 / 0
- closeness approx: 0.0
- betweenness approx: 0.0
- component size: 35
- distance to Hana/Orun/Shion: None / None / None

## p000 Branch Descendants

- edge_count: 1
- unique_speakers: 1
- unique_listeners: 1
- unique_people_touched: 2
- last_share_year: 21
- max_generation: 1

Baseline p000-branch edges:

- Y21: p019 ハナ -> p000 ゾル (gen=1, intensity=0.4204, interp=practical)

## Intervention Results

| exp | intervention | final pop | births | failures | memory shares | p000-branch edges | touched | last year | first diff |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | baseline v1.4 | 18 | 18 | 9 | 323 | 1 | 2 | 21 |  |
| F | no_hana_to_p000 | 15 | 15 | 8 | 329 | 0 | 0 | None | 180 |
| G | only_hana_to_p000 | 18 | 18 | 9 | 321 | 1 | 2 | 21 | 179 |
| H | only_hana_to_p004 | 15 | 15 | 8 | 329 | 0 | 0 | None | 180 |
| I | randomized_hana_listener_same_year | 22 | 22 | 4 | 347 | 1 | 2 | 21 | 179 |
| J_p004 | other_sender_to_p000: p004 | 18 | 18 | 9 | 323 | 1 | 2 | 21 | 180 |
| J_p005 | other_sender_to_p000: p005 | 16 | 16 | 3 | 327 | 1 | 2 | 21 | 180 |
| J_p020 | other_sender_to_p000: p020 | 26 | 26 | 4 | 344 | 1 | 2 | 21 | 180 |
| K | hana_to_p000_but_no_p000_share | 18 | 18 | 9 | 323 | 1 | 2 | 21 |  |
| L | hana_to_p000_but_no_behavior_effect | 18 | 18 | 9 | 323 | 1 | 2 | 21 |  |
| M | hana_to_network_equivalent_non_p000: p035 | 15 | 15 | 8 | 329 | 1 | 2 | 21 | 179 |
| N_23 | p000_receives_late: Y23 | 16 | 16 | 6 | 322 | 1 | 2 | 23 | 180 |
| N_25 | p000_receives_late: Y25 | 18 | 18 | 4 | 319 | 3 | 3 | 30 | 180 |
| N_28 | p000_receives_late: Y28 | 15 | 15 | 8 | 330 | 1 | 2 | 28 | 180 |

## Main Findings

1. Baseline p000-branch tracing found only one marked edge: `Y21 p019 -> p000`. The marked Year14 memory was not observed as a p000 re-share branch afterward.
2. K is identical to baseline because p000 did not re-share this marked memory in the baseline trace.
3. L is also identical to baseline, so the measured v1.4 path is not explained by p000 later using this memory in proposal/support choice.
4. J is mixed: replacing Hana with `p004 -> p000` preserves the high-level v1.4 summary, but `p005 -> p000` and `p020 -> p000` do not. This weakens a simple `any sender to p000 works` reading.
5. M falls to the non-v1.4 path, so the selected network-near substitute (`p035`) did not replace p000.
6. N shows timing sensitivity: Y23 and Y28 diverge strongly; Y25 preserves final population/births but changes the project path.

The safest current reading is: p000 receipt at the original Y21 position is a strong condition, but not because p000 visibly re-broadcasts the marked memory. The effect is more likely tied to the exact event-order/trust-update/network state around the Y21 receipt than to a long p000 descendant tree.

## Interpretation Guardrails

- If J variants preserve v1.4, p000 receipt matters more than the Hana-p000 pair.
- If K changes history, p000 re-sharing matters more than p000 merely holding the memory.
- If L changes history, p000's support/proposal use of the memory matters.
- If M preserves v1.4, network position may matter more than p000 as a person.
- If N changes with delay, timing is part of the condition.
