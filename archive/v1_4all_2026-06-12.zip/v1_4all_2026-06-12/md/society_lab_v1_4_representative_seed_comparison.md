# society_lab v1.4 representative seed comparison

Representative seeds compared in a shared format. Interpretation is intentionally restrained.

## Cross Comparison

| seed | type | first_diff_year | family | participant_changed | project_result_changed | project_memory | memory_delta | pop_delta | food_delta | birth_delta | memory_shared_delta | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1003 | A_failure_memory_shrink | 14 | support_choice | True | False | project_failure:store_food | 35 | -7.0 | 70.52100000000002 | -7.0 | -53.0 | first difference reaches project memory sharing |
| 1043 | A_failure_memory_shrink | 40 | support_choice | True | False | project_failure:dig_well | 5 | -14.0 | 70.82000000000001 | -12.0 | -51.0 | first difference reaches project memory sharing |
| 1012 | B_memory_composition_shrink | 24 | support_choice | True | False | project_success:hunt_group | -143 | -4.0 | -33.129999999999995 | 2.0 | 35.0 | first difference reaches project memory sharing |
| 1024 | C_collapse_avoidance_or_growth | 38 | support_choice | False | False |  | 0 | 12.0 | -105.05399999999999 | 13.0 | -5.0 | summary changed, but first support difference did not clearly alter project participants |
| 1008 | D_absorbed | 73 | support_choice | False | False |  | 0 | 0.0 | 0.0 | 0.0 | 0.0 | choice changed but absorbed; no durable summary difference |
| 1002 | E_no_log_change |  | none | False | False |  | 0 | 0.0 | 0.0 | 0.0 | 0.0 | nudge present but no logged choice change |

## Seed 1003 (A_failure_memory_shrink)

### First Difference

```text
v1.3: Y14 proposal_supported [p021,p006] メイ supported store_food
v1.4: Y14 proposal_supported [p019,p006] ハナ supported store_food
```

| field | value |
| --- | --- |
| changed person | p019 ハナ |
| changed action/problem | store_food / water_shortage |
| supporters v1.3 -> v1.4 | 10 -> 11 |
| supporter added | p019 |
| supporter removed | - |
| participant_changed | True |
| project_result_changed | False |

### Project Memory

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| shares | 12 | 47 | 35 |
| unique speakers | 4 | 19 | 15 |
| unique listeners | 6 | 20 | 14 |
| people touched | 7 | 27 | 20 |
| last share year | 24 | 77 |  |
| max generation | 2 | 4 |  |

### 10-Year Timeline

| year | pop | food | birth | death | failure | memshare | shared narrative | narr div | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 43->43 | 116.721->116.721 | 8->8 | 0->0 | 1->1 | 42->42 | 2->2 | 0->0 | 0.1132->0.1132 |
| 20 | 44->44 | 113.533->77.356 | 10->9 | 1->0 | 3->3 | 103->95 | 5->6 | 1->2 | 0.1177->0.1182 |
| 30 | 42->40 | 136.883->38.572 | 11->11 | 4->6 | 3->3 | 197->158 | 16->11 | 4->4 | 0.1182->0.1183 |
| 40 | 39->35 | 141.502->76.543 | 12->11 | 8->11 | 3->4 | 261->231 | 27->18 | 8->8 | 0.1235->0.1247 |
| 50 | 35->29 | 81.37->76.891 | 18->15 | 18->21 | 3->7 | 303->263 | 35->28 | 11->12 | 0.1237->0.1317 |
| 60 | 24->22 | 94.092->105.818 | 20->15 | 31->28 | 5->7 | 338->297 | 40->34 | 15->15 | 0.1165->0.1442 |
| 70 | 21->17 | 144.401->172.347 | 21->17 | 35->35 | 5->7 | 359->308 | 44->40 | 17->16 | 0.1175->0.1292 |
| 80 | 25->18 | 156.815->227.336 | 25->18 | 35->35 | 5->9 | 376->323 | 48->45 | 17->16 | 0.1116->0.1333 |

Verdict: first difference reaches project memory sharing

## Seed 1043 (A_failure_memory_shrink)

### First Difference

```text
v1.3: Y40 proposal_supported [p025,p018] サナ supported dig_well
v1.4: Y40 proposal_supported [p015,p018] ルト supported dig_well
```

| field | value |
| --- | --- |
| changed person | p015 ルト |
| changed action/problem | dig_well / water_shortage |
| supporters v1.3 -> v1.4 | 11 -> 12 |
| supporter added | p015 |
| supporter removed | - |
| participant_changed | True |
| project_result_changed | False |

### Project Memory

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| shares | 40 | 45 | 5 |
| unique speakers | 12 | 14 | 2 |
| unique listeners | 12 | 16 | 4 |
| people touched | 16 | 21 | 5 |
| last share year | 65 | 77 |  |
| max generation | 6 | 7 |  |

### 10-Year Timeline

| year | pop | food | birth | death | failure | memshare | shared narrative | narr div | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 44->44 | 158.575->158.575 | 6->6 | 0->0 | 0->0 | 0->0 | 0->0 | 0->0 | 0.1038->0.1038 |
| 20 | 48->48 | 142.228->142.228 | 10->10 | 0->0 | 0->0 | 35->35 | 2->2 | 0->0 | 0.1033->0.1033 |
| 30 | 49->49 | 168.962->168.962 | 11->11 | 0->0 | 0->0 | 95->95 | 6->6 | 1->1 | 0.1048->0.1048 |
| 40 | 45->46 | 171.101->171.101 | 14->14 | 7->6 | 2->2 | 175->175 | 14->14 | 5->5 | 0.1119->0.1117 |
| 50 | 44->42 | 90.986->137.92 | 22->17 | 16->13 | 2->2 | 245->245 | 22->24 | 10->10 | 0.1208->0.1187 |
| 60 | 41->32 | 81.304->75.303 | 24->17 | 21->23 | 2->2 | 303->276 | 27->33 | 13->15 | 0.1187->0.1332 |
| 70 | 33->24 | 62.819->111.715 | 27->17 | 32->31 | 2->2 | 338->307 | 30->41 | 16->17 | 0.1241->0.1338 |
| 80 | 33->19 | 87.223->158.043 | 29->17 | 34->36 | 2->3 | 375->324 | 32->48 | 17->17 | 0.1221->0.1339 |

Verdict: first difference reaches project memory sharing

## Seed 1012 (B_memory_composition_shrink)

### First Difference

```text
v1.3: Y24 proposal_supported [p002,p007] ダン supported hold_ritual
v1.4: Y24 proposal_supported [p000,p014] アルン supported hunt_group
```

| field | value |
| --- | --- |
| changed person | p000 アルン |
| changed action/problem | hunt_group / general_anxiety |
| supporters v1.3 -> v1.4 | 12 -> 13 |
| supporter added | p000 |
| supporter removed | - |
| participant_changed | True |
| project_result_changed | False |

### Project Memory

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| shares | 159 | 16 | -143 |
| unique speakers | 29 | 9 | -20 |
| unique listeners | 29 | 11 | -18 |
| people touched | 36 | 17 | -19 |
| last share year | 69 | 74 |  |
| max generation | 11 | 2 |  |

### 10-Year Timeline

| year | pop | food | birth | death | failure | memshare | shared narrative | narr div | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 44->44 | 86.613->86.613 | 14->14 | 0->0 | 2->2 | 12->12 | 1->1 | 0->0 | 0.1033->0.1033 |
| 20 | 47->47 | 0.0->0.0 | 17->17 | 0->0 | 2->2 | 76->76 | 5->5 | 0->0 | 0.1054->0.1054 |
| 30 | 48->48 | 0.0->0.0 | 18->18 | 0->0 | 5->3 | 224->212 | 15->13 | 2->1 | 0.1356->0.1237 |
| 40 | 48->49 | 0.0->7.934 | 18->19 | 0->0 | 9->4 | 357->323 | 29->21 | 7->4 | 0.1665->0.1436 |
| 50 | 48->48 | 6.477->0.0 | 18->20 | 0->2 | 16->9 | 499->525 | 45->34 | 16->10 | 0.1959->0.1986 |
| 60 | 39->43 | 0.697->10.844 | 18->20 | 9->7 | 23->20 | 595->656 | 64->51 | 27->17 | 0.2478->0.2655 |
| 70 | 28->28 | 7.91->4.381 | 18->20 | 20->22 | 29->26 | 666->705 | 82->71 | 37->24 | 0.3104->0.344 |
| 80 | 23->19 | 54.522->21.392 | 18->20 | 25->31 | 30->30 | 678->713 | 99->91 | 46->29 | 0.3346->0.3823 |

Verdict: first difference reaches project memory sharing

## Seed 1024 (C_collapse_avoidance_or_growth)

### First Difference

```text
v1.3: Y38 proposal_supported [p004,p014] サナ supported move_camp
v1.4: Y38 proposal_supported [p004,p008] サナ supported store_food
```

| field | value |
| --- | --- |
| changed person | p004 サナ |
| changed action/problem | store_food /  |
| supporters v1.3 -> v1.4 | 2 -> 3 |
| supporter added | p004 |
| supporter removed | - |
| participant_changed | False |
| project_result_changed | False |

### Project Memory

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| shares | 0 | 0 | 0 |
| unique speakers | 0 | 0 | 0 |
| unique listeners | 0 | 0 | 0 |
| people touched | 0 | 0 | 0 |
| last share year |  |  |  |
| max generation |  |  |  |

### 10-Year Timeline

| year | pop | food | birth | death | failure | memshare | shared narrative | narr div | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 23->23 | 31.579->31.579 | 3->3 | 0->0 | 0->0 | 3->3 | 0->0 | 0->0 | 0.1105->0.1105 |
| 20 | 23->23 | 38.137->38.137 | 3->3 | 0->0 | 0->0 | 41->41 | 4->4 | 0->0 | 0.1158->0.1158 |
| 30 | 23->23 | 54.691->54.691 | 5->5 | 2->2 | 2->2 | 77->77 | 10->10 | 0->0 | 0.1204->0.1204 |
| 40 | 21->21 | 65.881->70.297 | 6->6 | 5->5 | 3->3 | 118->116 | 19->19 | 3->3 | 0.1223->0.1258 |
| 50 | 18->22 | 53.998->46.74 | 6->10 | 8->8 | 4->3 | 165->149 | 30->28 | 5->6 | 0.1319->0.1216 |
| 60 | 13->18 | 63.615->38.967 | 6->10 | 13->12 | 4->4 | 186->172 | 37->36 | 8->7 | 0.1375->0.1175 |
| 70 | 9->20 | 118.771->66.494 | 6->17 | 17->17 | 4->4 | 198->187 | 42->40 | 9->8 | 0.1362->0.1192 |
| 80 | 7->19 | 191.765->86.711 | 6->19 | 19->20 | 4->4 | 205->200 | 44->43 | 11->8 | 0.1351->0.1131 |

Verdict: summary changed, but first support difference did not clearly alter project participants

## Seed 1008 (D_absorbed)

### First Difference

```text
v1.3: Y73 proposal_supported [p009,p046] アルン supported hunt_group
v1.4: Y73 proposal_supported [p009,p051] アルン supported hold_ritual
```

| field | value |
| --- | --- |
| changed person | p009 アルン |
| changed action/problem | hold_ritual /  |
| supporters v1.3 -> v1.4 | 1 -> 2 |
| supporter added | p009 |
| supporter removed | - |
| participant_changed | False |
| project_result_changed | False |

### Project Memory

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| shares | 0 | 0 | 0 |
| unique speakers | 0 | 0 | 0 |
| unique listeners | 0 | 0 | 0 |
| people touched | 0 | 0 | 0 |
| last share year |  |  |  |
| max generation |  |  |  |

### 10-Year Timeline

| year | pop | food | birth | death | failure | memshare | shared narrative | narr div | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 42->42 | 84.014->84.014 | 6->6 | 0->0 | 0->0 | 0->0 | 0->0 | 0->0 | 0.0995->0.0995 |
| 20 | 46->46 | 89.009->89.009 | 10->10 | 0->0 | 0->0 | 0->0 | 0->0 | 0->0 | 0.0978->0.0978 |
| 30 | 50->50 | 63.349->63.349 | 14->14 | 0->0 | 1->1 | 19->19 | 3->3 | 0->0 | 0.1012->0.1012 |
| 40 | 42->42 | 59.918->59.918 | 15->15 | 9->9 | 1->1 | 98->98 | 9->9 | 1->1 | 0.1039->0.1039 |
| 50 | 44->44 | 57.091->57.091 | 19->19 | 11->11 | 2->2 | 150->150 | 17->17 | 3->3 | 0.1066->0.1066 |
| 60 | 32->32 | 54.97->54.97 | 19->19 | 23->23 | 2->2 | 196->196 | 23->23 | 5->5 | 0.1143->0.1143 |
| 70 | 27->27 | 119.81->119.81 | 19->19 | 28->28 | 2->2 | 241->241 | 28->28 | 6->6 | 0.1154->0.1154 |
| 80 | 30->30 | 116.646->116.646 | 24->24 | 30->30 | 3->3 | 278->278 | 33->33 | 8->8 | 0.1192->0.1192 |

Verdict: choice changed but absorbed; no durable summary difference

## Seed 1002 (E_no_log_change)

### First Difference

```text
v1.3: 
v1.4: 
```

| field | value |
| --- | --- |
| changed person |   |
| changed action/problem |  /  |
| supporters v1.3 -> v1.4 |  ->  |
| supporter added | - |
| supporter removed | - |
| participant_changed | False |
| project_result_changed | False |

### Project Memory

| metric | v1.3 | v1.4 | delta |
| --- | --- | --- | --- |
| shares | 0 | 0 | 0 |
| unique speakers | 0 | 0 | 0 |
| unique listeners | 0 | 0 | 0 |
| people touched | 0 | 0 | 0 |
| last share year |  |  |  |
| max generation |  |  |  |

### 10-Year Timeline

| year | pop | food | birth | death | failure | memshare | shared narrative | narr div | blame |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 40->40 | 172.731->172.731 | 4->4 | 0->0 | 2->2 | 28->28 | 2->2 | 0->0 | 0.1099->0.1099 |
| 20 | 38->38 | 132.659->132.659 | 4->4 | 2->2 | 2->2 | 89->89 | 6->6 | 0->0 | 0.1119->0.1119 |
| 30 | 31->31 | 115.792->115.792 | 4->4 | 9->9 | 2->2 | 139->139 | 10->10 | 3->3 | 0.1115->0.1115 |
| 40 | 26->26 | 147.246->147.246 | 7->7 | 17->17 | 2->2 | 181->181 | 16->16 | 5->5 | 0.115->0.115 |
| 50 | 17->17 | 213.959->213.959 | 10->10 | 29->29 | 4->4 | 213->213 | 23->23 | 7->7 | 0.1278->0.1278 |
| 60 | 11->11 | 325.461->325.461 | 11->11 | 36->36 | 4->4 | 230->230 | 25->25 | 8->8 | 0.1026->0.1026 |
| 70 | 16->16 | 395.832->395.832 | 16->16 | 36->36 | 4->4 | 243->243 | 27->27 | 8->8 | 0.1024->0.1024 |
| 80 | 19->19 | 407.732->407.732 | 19->19 | 36->36 | 5->5 | 260->260 | 30->30 | 8->8 | 0.1068->0.1068 |

Verdict: nudge present but no logged choice change

## Overall Reading

The A/B/C/D/E labels are useful but not final. The representative set shows at least three distinct outcomes: project-memory-linked shrinkage, memory-composition change, and collapse avoidance/growth. The absorbed and no-log-change examples are useful controls.