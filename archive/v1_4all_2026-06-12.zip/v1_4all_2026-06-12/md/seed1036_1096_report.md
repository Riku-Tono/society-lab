# seed1036 / seed1096 解剖レポート

## 目的

seed1043で確立した「ナッジ→1支持者差→RNGずれ→死亡者差」経路が
再現するか、または別経路が存在するかを検証。

---

## 結果テーブル

| 項目 | seed1043 | seed1036 | seed1096 |
|---|---|---|---|
| 分岐年 | Y40 | Y42 | Y49 |
| 分岐経路 | support_nudge | support_nudge | **action_nudge** |
| 起点bias | blame(p015) | practical(p026) | blame(p011)/spiritual(p043) |
| nudge値 | +0.03 | +0.03 | +0.03 |
| support_chance差 | +0.0126 | +0.0126 | (提案内容自体が変わる) |
| 支持者差 | 12→11 (−1人) | 13→12 (−1人) | 8→11 (全員入れ替わり) |
| 介入AでNudge_off一致 | ✓ YES | ✓ YES | ✓ YES |
| 即時発現 | Y40死亡者差 | Y42死亡者差 | Y49プロジェクト差 |
| 最終人口差 | 19→33 (+14) | 25→34 (+9) | **30→27 (−3)** |

---

## seed1036 因果連鎖

```
【蓄積フェーズ】
p026: 初期practical優位
Y22/23: death記憶をpractical解釈 → practical=0.172

【Y42 発火】
storage_damage問題 → council_phase
ティア(p037)がhunt_groupを提案
p026: practical dominant → hunt_group support_nudge +0.03
  support_chance: baseline=0.2622 / nudge_off=0.2496 (差+0.0126)
  ※ seed1043と同じ差

【支持者差 → RNGずれ → 死亡者差】
baseline: 支持者13名 → p026がproject参加
nudge_off: 支持者12名 → p026は参加しない

Y42死亡: baseline=p007(ダン)+p008(サナ)2名 / nudge_off=p008(サナ)1名
Y43以降: 記憶配布先・trust・共有・出生が別軌道へ

最終: baseline=25 / nudge_off=34 (差9人)
```

**外科的介入A** (Y42のp026 practical support nudgeのみOFF):
`pop=34 birth=34 fail=3 shares=232` → nudge_offと完全一致 ✓

---

## seed1096 因果連鎖（新経路）

```
【蓄積フェーズ】
p011: Y36/38の death記憶をblame解釈 → blame=0.173
p043: spiritual優位（蓄積起源は記録なし、ほぼ初期値）

【Y49 発火: action_nudge経路】
water_shortage問題 → council_phase
提案者p011(アルン): blame dominant → move_camp +3%ウェイト
提案者p043(オルン): spiritual dominant → hold_ritual +3%ウェイト

baseline提案内容: dig_well / move_camp / hold_ritual
nudge_off提案内容: dig_well / hold_ritual / store_food

→ 提案の種類自体が変わる
→ 支持者の分布ごと入れ替わる（8人/11人、かつメンバーが全員違う）
→ 実行されるプロジェクトの内容が違う

最終: baseline=30 / nudge_off=27 (差−3人、baseline側が多い)
```

**外科的介入A** (Y49のaction_nudgeのみOFF):
`pop=27 birth=25 fail=2 shares=151` → nudge_offと完全一致 ✓

---

## 2つの経路の比較

### support_nudge型 (seed1043/1036)

```
bias → support_chance +0.012 → 1人の参加差
→ RNG消費ずれ → 死亡者差（誰が死ぬかが変わる）
→ 死亡記憶の配布先・trust・共有が別軌道
```

### action_nudge型 (seed1096)

```
bias → action選択確率微変化（move_campが約+0.6%、hold_ritualが約+0.4%）
→ 提案内容自体が変わる
→ 支持者の分布ごと入れ替わる
→ 実行プロジェクトが違う → 後続の記憶・trust・birth・deathが別軌道
```

**重要な違い:**
- support_nudge型: 「支持するかどうか」という確率的な境界を越える
- action_nudge型: 「何を提案するか」という離散的な選択が変わる
  後者は1人の差ではなく、それに紐づく支持者群ごと入れ替わるため
  より大きな即時変化を起こしうる（ただしseed1096は差−3人で小さめ）

---

## 共通構造（3seed確認済み）

1. **interpretation biasの蓄積** が前提条件
   （初期値・死亡記憶のblame/spiritual解釈・失敗記憶のblame解釈など）
2. **問題発生（council_phase）** のタイミングで発火
3. **ナッジ値 +0.03** が action or support の確率を微変化
4. **乱数が境界を越える** ことで実際に選択が変わる
5. **単一の外科的介入** で nudge_off と完全一致（最小原因セット確定）

---

## ChatGPTへの報告用サマリ

**言えること（3seed確認済み）:**
- SocietyLab v1.4では、約3%の解釈ナッジが境界上の判断を変え、
  その差がRNG消費・死亡・記憶・trust・出生へ伝播して長期軌道を変える
- 経路は少なくとも2種類ある（support_nudge型 / action_nudge型）
- 3seedとも単一の外科的介入で nudge_off と完全一致（再現性あり）
- biasの蓄積は死亡記憶の解釈が主なトリガーになっていることが多い

**まだ言えないこと:**
- 「death_clusterが原因」ではなくナッジが一次原因であることの一般則化
  → Phase 1の37件中、同じ介入で一致するseedが何割かは未確認
- action_nudge型とsupport_nudge型どちらが多数派か
- transient（自己修復型）8件との構造的違い

---

## 注意（解釈の限界）

- seed1096のintervention結果はbaseline<nudge_off（人口が少ない方向）
  「ナッジが常に社会を悪化させる」ではなく方向は不定
- action_nudgeの確率差は+0.4-0.6%と非常に小さく、
  「bias→提案変化」が毎回起きるわけではない（乱数境界依存）
