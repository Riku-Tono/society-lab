# seed1003 amplification point analysis

## Summary

This pass does not conclude that Zol caused the history. It tests whether `Y21 p019 -> p000` looks like a person effect, a state/location effect, or a timing-sensitive amplification point.

## Phase 1: p000 State

### Y20 End
```json
{
  "id": "p000",
  "name": "ゾル",
  "alive": true,
  "age": 59,
  "sex": "m",
  "charisma": 0.4249,
  "food_skill": 0.2528,
  "health": 1.0,
  "hunger": 0.0,
  "fear": 0.0,
  "action": "share_memory",
  "voice_weight": 0.0,
  "interpretation_bias": {
    "spiritual": 0.1003,
    "practical": 0.1397,
    "blame": 0.1373
  },
  "strongest_memory": null,
  "memory_count": 0,
  "recent_memories": [],
  "incoming_trust_count": 3,
  "incoming_trust_sum": 2.2088,
  "incoming_trust_top": [
    {
      "id": "p019",
      "name": "ハナ",
      "trust": 0.8151
    },
    {
      "id": "p016",
      "name": "サナ",
      "trust": 0.7228
    },
    {
      "id": "p030",
      "name": "オルン",
      "trust": 0.6709
    }
  ],
  "outgoing_trust_count": 3,
  "outgoing_trust_sum": 1.9501,
  "outgoing_trust_top": [
    {
      "id": "p018",
      "name": "ダン",
      "trust": 0.6716
    },
    {
      "id": "p028",
      "name": "ゾル",
      "trust": 0.657
    },
    {
      "id": "p026",
      "name": "ルト",
      "trust": 0.6215
    }
  ],
  "top_trusted": [
    "p018",
    "p028",
    "p026"
  ],
  "closeness_approx": 0.3772,
  "betweenness_approx": 0.0089,
  "component_size": 44
}
```

### Y21 Before Hana -> p000
```json
{
  "id": "p000",
  "name": "ゾル",
  "alive": true,
  "age": 59,
  "sex": "m",
  "charisma": 0.4249,
  "food_skill": 0.2528,
  "health": 1.0,
  "hunger": 0.0,
  "fear": 0.0,
  "action": "share_memory",
  "voice_weight": 0.0,
  "interpretation_bias": {
    "spiritual": 0.1003,
    "practical": 0.1397,
    "blame": 0.1373
  },
  "strongest_memory": null,
  "memory_count": 0,
  "recent_memories": [],
  "incoming_trust_count": 3,
  "incoming_trust_sum": 2.2088,
  "incoming_trust_top": [
    {
      "id": "p019",
      "name": "ハナ",
      "trust": 0.8151
    },
    {
      "id": "p016",
      "name": "サナ",
      "trust": 0.7228
    },
    {
      "id": "p030",
      "name": "オルン",
      "trust": 0.6709
    }
  ],
  "outgoing_trust_count": 3,
  "outgoing_trust_sum": 1.9501,
  "outgoing_trust_top": [
    {
      "id": "p018",
      "name": "ダン",
      "trust": 0.6716
    },
    {
      "id": "p028",
      "name": "ゾル",
      "trust": 0.657
    },
    {
      "id": "p026",
      "name": "ルト",
      "trust": 0.6215
    }
  ],
  "top_trusted": [
    "p018",
    "p028",
    "p026"
  ],
  "closeness_approx": 0.3772,
  "betweenness_approx": 0.0089,
  "component_size": 44
}
```

### Y22 End
```json
{
  "id": "p000",
  "name": "ゾル",
  "alive": true,
  "age": 61,
  "sex": "m",
  "charisma": 0.4249,
  "food_skill": 0.2528,
  "health": 1.0,
  "hunger": 0.0,
  "fear": 0.0,
  "action": "reassure",
  "voice_weight": 0.0,
  "interpretation_bias": {
    "spiritual": 0.1003,
    "practical": 0.1397,
    "blame": 0.1373
  },
  "strongest_memory": {
    "event": "project_failure:store_food",
    "year": 14,
    "intensity": 0.4038,
    "generation": 1,
    "source": "p019",
    "interpretation": "practical"
  },
  "memory_count": 1,
  "recent_memories": [
    {
      "event": "project_failure:store_food",
      "year": 14,
      "intensity": 0.4038,
      "generation": 1,
      "source": "p019",
      "interpretation": "practical"
    }
  ],
  "incoming_trust_count": 3,
  "incoming_trust_sum": 2.2088,
  "incoming_trust_top": [
    {
      "id": "p019",
      "name": "ハナ",
      "trust": 0.8151
    },
    {
      "id": "p016",
      "name": "サナ",
      "trust": 0.7228
    },
    {
      "id": "p030",
      "name": "オルン",
      "trust": 0.6709
    }
  ],
  "outgoing_trust_count": 4,
  "outgoing_trust_sum": 1.9621,
  "outgoing_trust_top": [
    {
      "id": "p018",
      "name": "ダン",
      "trust": 0.6716
    },
    {
      "id": "p028",
      "name": "ゾル",
      "trust": 0.657
    },
    {
      "id": "p026",
      "name": "ルト",
      "trust": 0.6215
    },
    {
      "id": "p019",
      "name": "ハナ",
      "trust": 0.012
    }
  ],
  "top_trusted": [
    "p018",
    "p028",
    "p026",
    "p019"
  ],
  "closeness_approx": 0.4,
  "betweenness_approx": 0.0116,
  "component_size": 43
}
```

## Phase 2: Nearest People At Y21

| rank | id | name | distance | age | memory count | incoming | outgoing | closeness | support | speaker | listener |
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | p022 | メイ | 0.5902 | 83 | 0 | 3.288 | 2.151 | 0.384 | 0 | 0 | 0 |
| 2 | p003 | ハナ | 0.6277 | 56 | 2 | 3.347 | 2.128 | 0.395 | 0 | 1 | 2 |
| 3 | p036 | サナ | 0.6548 | 17 | 0 | 1.165 | 1.285 | 0.355 | 0 | 0 | 0 |
| 4 | p005 | オルン | 0.6965 | 80 | 0 | 1.373 | 2.987 | 0.406 | 0 | 0 | 0 |
| 5 | p026 | ルト | 0.7461 | 73 | 2 | 4.685 | 2.137 | 0.364 | 0 | 1 | 2 |

## Phase 3: Counterfactual Replacements

| exp | listener | final pop | births | failures | memory shares | first diff | changed keys |
|---|---|---:|---:|---:|---:|---:|---|
| baseline | baseline | 18 | 18 | 9 | 323 |  |  |
| P1 | hana_to_closest_1: p022 メイ | 24 | 24 | 4 | 329 | 180 | final_population,final_food_stock,birth_count,proposal_count,project_success_count,project_failure_count,shared_narrative_count,memory_shared_count,network_split_count,interpretation_divergence_count,interpretation_action_nudge_count,interpretation_support_nudge_count |
| P2 | hana_to_closest_2: p003 ハナ | 15 | 15 | 8 | 330 | 180 | final_population,final_food_stock,birth_count,proposal_count,project_success_count,project_failure_count,shared_narrative_count,memory_shared_count,network_split_count,narrative_divergence_count,interpretation_divergence_count,interpretation_action_nudge_count,interpretation_support_nudge_count |
| P3 | hana_to_closest_3: p036 サナ | 18 | 18 | 7 | 356 | 180 | final_food_stock,proposal_count,project_failure_count,shared_narrative_count,memory_shared_count,network_split_count,narrative_divergence_count,interpretation_divergence_count,interpretation_action_nudge_count,interpretation_support_nudge_count |
| P4 | hana_to_closest_4: p005 オルン | 17 | 17 | 7 | 326 | 180 | final_population,final_food_stock,birth_count,proposal_count,project_success_count,project_failure_count,shared_narrative_count,memory_shared_count,network_split_count,narrative_divergence_count,interpretation_divergence_count,interpretation_action_nudge_count,interpretation_support_nudge_count |
| P5 | hana_to_closest_5: p026 ルト | 15 | 15 | 8 | 330 | 180 | final_population,final_food_stock,birth_count,proposal_count,project_success_count,project_failure_count,shared_narrative_count,memory_shared_count,network_split_count,narrative_divergence_count,interpretation_action_nudge_count,interpretation_support_nudge_count |

## Phase 4: Amplification Candidate Ranking

| rank | id | name | score | age | memory | incoming | outgoing | close | betw | support | speaker | listener | action |
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 1 | p001 | ケイ | 17.5547 | 47 | 4 | 5.7281 | 5.5825 | 0.4433 | 0.0908 | 1 | 5 | 3 | share_memory |
| 2 | p023 | メイ | 16.6381 | 58 | 5 | 5.1215 | 5.5753 | 0.4778 | 0.0952 | 1 | 3 | 5 | share_memory |
| 3 | p007 | ファラ | 16.582 | 48 | 13 | 5.9425 | 4.838 | 0.4886 | 0.1174 | 1 | 3 | 13 | store_food |
| 4 | p011 | シオン | 14.4364 | 65 | 8 | 4.0852 | 4.6072 | 0.5 | 0.0786 | 3 | 4 | 5 | reassure |
| 5 | p012 | イシュ | 14.3928 | 47 | 3 | 6.1388 | 3.2798 | 0.4433 | 0.1096 | 0 | 3 | 3 | reassure |
| 6 | p021 | メイ | 13.2181 | 46 | 3 | 3.9589 | 4.2481 | 0.3772 | 0.0421 | 2 | 4 | 1 | share_memory |
| 7 | p032 | ゾル | 13.1352 | 63 | 5 | 3.8941 | 4.0572 | 0.4388 | 0.0709 | 3 | 3 | 2 | withdraw |
| 8 | p018 | ダン | 12.789 | 67 | 4 | 5.6844 | 2.2635 | 0.4095 | 0.062 | 0 | 3 | 4 | share_memory |
| 9 | p034 | イシュ | 12.7625 | 61 | 4 | 5.0463 | 3.245 | 0.4257 | 0.0543 | 2 | 1 | 2 | reassure |
| 10 | p008 | ルト | 12.1694 | 47 | 7 | 3.9358 | 2.9962 | 0.4526 | 0.0377 | 1 | 5 | 6 | share_memory |

## Cautious Reading

- p000 is not obviously unique by the nearest-person metric; several people are close in local state.
- However, replacing the listener with the five closest people does not reproduce the baseline v1.4 path.
- This weakens a simple `same state is enough` reading.
- The strongest safe hypothesis is that the Y21 p000 receipt was a timing-sensitive amplification point: a particular person/state/event-order combination, not just Zol as a heroic actor.
- The amplification ranking is a heuristic candidate list for further experiments, not proof of causality.
