# seed1003 Y21 p019->p000 history-lock batch

## Purpose

This batch tests whether the Y21 Hana->Zol edge is sensitive to memory intensity, interpretation, trust update, p000 action state, or timing. It is a micro-intervention screen, not a final causal proof.

## Results

| exp | intervention | final pop | births | failures | memory shares | first diff | changed keys | edge |
|---|---|---:|---:|---:|---:|---:|---:|---|
| baseline | baseline | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 practical |
| INT_025 | hana_to_p000 intensity=0.25 | 18 | 18 | 9 | 323 | 180 | 0 | Y21 0.25 practical |
| INT_042 | hana_to_p000 intensity=baseline 0.4204 | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 practical |
| INT_060 | hana_to_p000 intensity=0.60 | 18 | 18 | 9 | 323 | 180 | 0 | Y21 0.6 practical |
| INT_080 | hana_to_p000 intensity=0.80 | 18 | 18 | 9 | 323 | 180 | 0 | Y21 0.8 practical |
| INTP_practical | interpretation=practical | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 practical |
| INTP_blame | interpretation=blame | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 blame |
| INTP_spiritual | interpretation=spiritual | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 spiritual |
| INTP_none | interpretation=none | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 none |
| TRUST_none | no trust update on hana->p000 | 16 | 16 | 4 | 295 | 240 | 12 | Y21 0.4204 practical |
| ACT_store_food | force p000 action=store_food at receipt | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 practical |
| ACT_reassure | force p000 action=reassure at receipt | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 practical |
| ACT_withdraw | force p000 action=withdraw at receipt | 18 | 18 | 9 | 323 |  | 0 | Y21 0.4204 practical |
| TIME_Y20 | p000 receives at Y20, original Y21 blocked | 24 | 24 | 5 | 346 | 177 | 13 | Y20 0.4204 practical |
| TIME_Y22 | p000 receives at Y22, original Y21 blocked | 16 | 16 | 6 | 322 | 180 | 12 | Y22 0.4204 practical |
| TIME_Y23 | p000 receives at Y23, original Y21 blocked | 16 | 16 | 6 | 322 | 180 | 12 | Y23 0.4204 practical |

## Quick Reading

- Exact summary matches: ['INT_025', 'INT_042', 'INT_060', 'INT_080', 'INTP_practical', 'INTP_blame', 'INTP_spiritual', 'INTP_none', 'ACT_store_food', 'ACT_reassure', 'ACT_withdraw']
- Population/birth matches but path differs: none
- If intensity/interpretation variants stay close, the edge existence and event order matter more than content details.
- If no-trust-update stays close, trust +0.012 is not sufficient as the main explanation.
- If timing variants diverge, the Y21 placement is part of the condition.
