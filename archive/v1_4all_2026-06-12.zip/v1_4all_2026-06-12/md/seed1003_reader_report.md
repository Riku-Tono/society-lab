# society_lab v1.4_1 reader report seed 1003

## Run Summary

- years: 80
- population: 35 -> 18
- memory lineage events: 608
- support chain events: 126
- project aftermath events: 12
- shared narratives: 45
- narrative divergences: 16

## Most Talked Memories

| root_memory_id | event | root_year | root_holder | interpretation | lineage_events | unique_holders | max_depth |
| --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | project_failure:hold_ritual | 2 | p031 | spiritual | 35 | 15 | 9 |
| m00009 | project_failure:hold_ritual | 2 | p028 | blame | 24 | 9 | 5 |
| m00010 | project_failure:hold_ritual | 2 | p029 | practical | 22 | 10 | 8 |
| m00230 | death | 31 | p031 | blame | 21 | 8 | 9 |
| m00005 | project_failure:hold_ritual | 2 | p019 | blame | 15 | 6 | 5 |
| m00246 | project_success:dig_well | 33 | p042 | none | 15 | 4 | 3 |
| m00446 | project_failure:dig_well | 48 | p045 | practical | 13 | 2 | 4 |
| m00192 | death | 28 | p011 | blame | 12 | 6 | 3 |
| m00000 | project_failure:hold_ritual | 2 | p006 | blame | 11 | 3 | 2 |
| m00073 | project_failure:store_food | 14 | p001 | spiritual | 11 | 5 | 3 |

## Longest Lineages

| root_memory_id | event | root_year | root_holder | interpretation | max_depth | lineage_events | unique_holders |
| --- | --- | --- | --- | --- | --- | --- | --- |
| m00011 | project_failure:hold_ritual | 2 | p031 | spiritual | 9 | 35 | 15 |
| m00230 | death | 31 | p031 | blame | 9 | 21 | 8 |
| m00010 | project_failure:hold_ritual | 2 | p029 | practical | 8 | 22 | 10 |
| m00009 | project_failure:hold_ritual | 2 | p028 | blame | 5 | 24 | 9 |
| m00005 | project_failure:hold_ritual | 2 | p019 | blame | 5 | 15 | 6 |
| m00439 | project_failure:dig_well | 48 | p001 | blame | 5 | 8 | 2 |
| m00446 | project_failure:dig_well | 48 | p045 | practical | 4 | 13 | 2 |
| m00080 | project_failure:store_food | 14 | p031 | practical | 4 | 7 | 5 |
| m00246 | project_success:dig_well | 33 | p042 | none | 3 | 15 | 4 |
| m00192 | death | 28 | p011 | blame | 3 | 12 | 6 |

## Nudged Support

- nudged support events: 25
- by action: {'store_food': 10, 'dig_well': 5, 'hunt_group': 5, 'move_camp': 5}
- by problem: {'water_shortage': 13, 'storage_damage': 12}

| year | supporter_id | proposer_id | action | problem | support_nudge | support_chance |
| --- | --- | --- | --- | --- | --- | --- |
| 14 | p019 | p006 | store_food | water_shortage | 0.03 | 0.2743 |
| 15 | p033 | p030 | store_food | storage_damage | 0.03 | 0.2522 |
| 22 | p020 | p022 | store_food | storage_damage | 0.03 | 0.2649 |
| 33 | p030 | p006 | dig_well | water_shortage | 0.03 | 0.2637 |
| 36 | p031 | p034 | dig_well | water_shortage | 0.03 | 0.2149 |
| 36 | p034 | p034 | dig_well | water_shortage | 0.03 | 0.2671 |
| 42 | p000 | p008 | hunt_group | storage_damage | 0.03 | 0.285 |
| 42 | p009 | p008 | hunt_group | storage_damage | 0.03 | 0.3046 |
| 42 | p011 | p008 | hunt_group | storage_damage | 0.03 | 0.2482 |
| 42 | p033 | p008 | hunt_group | storage_damage | 0.03 | 0.3991 |
| 42 | p039 | p008 | hunt_group | storage_damage | 0.03 | 0.2964 |
| 47 | p012 | p006 | move_camp | water_shortage | 0.03 | 0.3051 |
| 47 | p023 | p006 | move_camp | water_shortage | 0.03 | 0.2637 |
| 47 | p030 | p006 | move_camp | water_shortage | 0.03 | 0.2376 |
| 47 | p043 | p006 | move_camp | water_shortage | 0.03 | 0.3064 |
| 48 | p043 | p006 | dig_well | water_shortage | 0.03 | 0.2913 |
| 48 | p006 | p029 | store_food | storage_damage | 0.03 | 0.2337 |
| 48 | p013 | p029 | store_food | storage_damage | 0.03 | 0.2819 |
| 48 | p027 | p029 | store_food | storage_damage | 0.03 | 0.2746 |
| 48 | p030 | p029 | store_food | storage_damage | 0.03 | 0.2823 |

## Project Aftermath

### project_failure

- count: 9
- avg supporters: 9.111
- avg success chance: 0.528
- avg food stock delta: 0.0
- avg food capacity delta: 0.0
- avg supporter fear delta: 1.041
- avg supporter trust to proposer delta: -0.08

### project_success

- count: 3
- avg supporters: 7.667
- avg success chance: 0.563
- avg food stock delta: -8.079
- avg food capacity delta: 0.264
- avg supporter fear delta: -0.09
- avg supporter trust to proposer delta: 0.446

## Role Labels

- role counts: {'memory_carrier': 39, 'memory_holder': 39, 'death_memory_holder': 34, 'memory_receiver': 31, 'supported_proposer': 7, 'supporter': 6, 'interpretation_moved_supporter': 4, 'failed_proposer': 2}

| person_id | roles | role_count | biography_events |
| --- | --- | --- | --- |
| p030 | ['death_memory_holder', 'interpretation_moved_supporter', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer', 'supporter'] | 7 | 53 |
| p006 | ['death_memory_holder', 'failed_proposer', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer'] | 6 | 77 |
| p029 | ['death_memory_holder', 'failed_proposer', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer'] | 6 | 53 |
| p033 | ['death_memory_holder', 'interpretation_moved_supporter', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter'] | 6 | 46 |
| p008 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer'] | 5 | 75 |
| p021 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter'] | 5 | 57 |
| p042 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter'] | 5 | 52 |
| p011 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter'] | 5 | 45 |
| p017 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver', 'supporter'] | 5 | 32 |
| p001 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 55 |
| p007 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 51 |
| p040 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 50 |
| p032 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 43 |
| p035 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 38 |
| p034 | ['memory_carrier', 'memory_holder', 'memory_receiver', 'supported_proposer'] | 4 | 37 |
| p028 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 34 |
| p023 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 34 |
| p027 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 33 |
| p037 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 33 |
| p039 | ['death_memory_holder', 'memory_carrier', 'memory_holder', 'memory_receiver'] | 4 | 33 |

## Death Memory Near Support

- cases within window: 98

| gap_years | memory_year | holder_supporter_id | memory_source_id | memory_interpretation | support_year | proposer_id | action | problem | support_nudge |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 22 | p018 | self | blame | 22 | p022 | store_food | storage_damage | 0.0 |
| 0 | 22 | p020 | self | blame | 22 | p022 | store_food | storage_damage | 0.03 |
| 0 | 22 | p033 | self | blame | 22 | p008 | hold_ritual | storage_damage | 0.0 |
| 0 | 33 | p018 | p011 | blame | 33 | p006 | dig_well | water_shortage | 0.0 |
| 0 | 33 | p023 | p011 | blame | 33 | p006 | dig_well | water_shortage | 0.0 |
| 0 | 33 | p030 | p013 | practical | 33 | p006 | dig_well | water_shortage | 0.03 |
| 0 | 42 | p021 | p035 | spiritual | 42 | p008 | hunt_group | storage_damage | 0.0 |
| 0 | 47 | p017 | p023 | practical | 47 | p006 | move_camp | water_shortage | 0.0 |
| 0 | 48 | p001 | self | spiritual | 48 | p006 | dig_well | water_shortage | 0.0 |
| 0 | 48 | p001 | self | spiritual | 48 | p029 | store_food | storage_damage | 0.0 |
| 0 | 77 | p037 | p044 | spiritual | 77 | p044 | move_camp | water_shortage | 0.0 |
| 1 | 32 | p017 | p023 | blame | 33 | p008 | move_camp | water_shortage | 0.0 |
| 1 | 32 | p023 | p011 | blame | 33 | p006 | dig_well | water_shortage | 0.0 |
| 1 | 32 | p042 | p027 | none | 33 | p006 | dig_well | water_shortage | 0.0 |
| 1 | 41 | p003 | self | spiritual | 42 | p008 | hunt_group | storage_damage | 0.0 |
| 1 | 41 | p011 | self | blame | 42 | p008 | hunt_group | storage_damage | 0.03 |
| 1 | 46 | p012 | self | spiritual | 47 | p006 | move_camp | water_shortage | 0.03 |
| 1 | 46 | p012 | self | blame | 47 | p006 | move_camp | water_shortage | 0.03 |
| 1 | 46 | p017 | p023 | blame | 47 | p006 | move_camp | water_shortage | 0.0 |
| 1 | 46 | p017 | self | spiritual | 47 | p006 | move_camp | water_shortage | 0.0 |
| 1 | 46 | p030 | self | spiritual | 47 | p006 | move_camp | water_shortage | 0.03 |
| 1 | 47 | p007 | p012 | blame | 48 | p029 | store_food | storage_damage | 0.0 |
| 1 | 72 | p040 | p047 | practical | 73 | p049 | move_camp | water_shortage | 0.0 |
| 1 | 72 | p040 | p049 | spiritual | 73 | p049 | move_camp | water_shortage | 0.0 |
| 2 | 31 | p011 | self | spiritual | 33 | p015 | hold_ritual | water_shortage | 0.0 |
| 2 | 31 | p028 | p001 | practical | 33 | p006 | dig_well | water_shortage | 0.0 |
| 2 | 31 | p028 | p032 | spiritual | 33 | p006 | dig_well | water_shortage | 0.0 |
| 2 | 40 | p000 | self | practical | 42 | p008 | hunt_group | storage_damage | 0.03 |
| 2 | 40 | p003 | p028 | blame | 42 | p008 | hunt_group | storage_damage | 0.0 |
| 2 | 40 | p003 | self | blame | 42 | p008 | hunt_group | storage_damage | 0.0 |
