# society_lab v1.4 seed 1000-1099 classification

Compared versions:

- v1.3: interpretation is observed only
- v1.4: interpretation weakly nudges project choice and proposal support

Run length: 80 years
Seed range: 1000-1099

## Headline

Out of 100 seeds, 39 produced summary-level differences between v1.3 and v1.4. 51 seeds changed their event log. 12 seeds changed internally but returned to the same final summary. 49 seeds had interpretation nudges inside v1.4, but those nudges did not change the event path.

So seed 1003 was not unique in the broader range. It was only the one changed seed inside the earlier small check set of 42, 1000, 1001, 1002, and 1003.

## Category Counts

| category | count |
| --- | --- |
| blame_bias_shift | 4 |
| failure_shift | 11 |
| food_shift | 9 |
| log_changed_summary_same | 12 |
| memory_share_shift | 4 |
| minor_summary_shift | 17 |
| narrative_shift | 8 |
| nudge_only_no_path_change | 49 |
| population_shift | 6 |

Category thresholds:

- `population_shift`: final population changed by 5 or more
- `food_shift`: final food stock changed by 30 or more
- `failure_shift`: project failures changed by 2 or more
- `memory_share_shift`: memory shares changed by 30 or more
- `narrative_shift`: narrative divergences changed by 5 or more
- `blame_bias_shift`: average blame bias changed by 0.02 or more

## Largest Outcome Shifts

| seed | pop | food | fail | birth | memshare | first log diff | labels |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1043 | -14 | +70.820 | +1 | -12 | -51 | 40 | population_shift, food_shift, memory_share_shift |
| 1024 | +12 | -105.054 | +0 | +13 | -5 | 38 | population_shift, food_shift, blame_bias_shift |
| 1036 | -9 | +31.973 | +0 | -9 | +1 | 42 | population_shift, food_shift |
| 1010 | -8 | -11.450 | +0 | -4 | -16 | 23 | population_shift |
| 1003 | -7 | +70.521 | +4 | -7 | -53 | 14 | population_shift, food_shift, failure_shift, memory_share_shift, blame_bias_shift |
| 1056 | +5 | +0.347 | +0 | +1 | -23 | 54 | population_shift, blame_bias_shift |
| 1018 | +4 | -95.806 | -1 | +4 | +11 | 8 | food_shift, narrative_shift |
| 1012 | -4 | -33.130 | +0 | +2 | +35 | 24 | food_shift, memory_share_shift, narrative_shift, blame_bias_shift |
| 1096 | +3 | +22.679 | +0 | +5 | +24 | 49 | minor_summary_shift |
| 1011 | -3 | -21.903 | +2 | +1 | +7 | 55 | failure_shift |
| 1095 | -3 | -20.650 | -1 | -5 | -5 | 54 | minor_summary_shift |
| 1094 | +3 | +6.506 | +1 | +3 | -2 | 53 | minor_summary_shift |
| 1089 | +3 | -5.667 | +0 | +2 | -2 | 79 | minor_summary_shift |
| 1004 | -3 | +4.744 | -1 | +0 | -13 | 62 | minor_summary_shift |
| 1087 | -3 | +1.473 | -4 | -1 | +23 | 35 | failure_shift, narrative_shift |

## Seeds Most Similar To 1003

| seed | 1003-like | pop | food | fail | birth | memshare | blame | first log diff |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1003 | 12.0 | -7 | +70.521 | +4 | -7 | -53 | +0.022 | 14 |
| 1043 | 9.48 | -14 | +70.820 | +1 | -12 | -51 | +0.012 | 40 |
| 1052 | 7.52 | -2 | +48.749 | +0 | -2 | -14 | +0.016 | 27 |
| 1091 | 7.03 | +0 | +7.078 | +2 | -1 | -16 | +0.010 | 58 |
| 1036 | 6.87 | -9 | +31.973 | +0 | -9 | +1 | +0.014 | 42 |
| 1078 | 6.84 | -2 | +2.542 | +1 | -2 | +4 | +0.008 | 55 |
| 1095 | 6.23 | -3 | -20.650 | -1 | -5 | -5 | +0.014 | 54 |
| 1014 | 6.17 | +1 | +28.052 | +2 | -2 | +11 | +0.013 | 57 |
| 1009 | 5.99 | -3 | -0.160 | -1 | -1 | -23 | +0.005 | 50 |
| 1016 | 5.79 | +2 | +12.669 | +1 | +2 | -20 | +0.007 | 28 |
| 1059 | 5.73 | +2 | +8.226 | +1 | +1 | -20 | +0.004 | 54 |
| 1004 | 5.72 | -3 | +4.744 | -1 | +0 | -13 | +0.004 | 62 |

## Reading

The broad scan changes the interpretation. The useful question is no longer `why did only seed 1003 change?` It is `why do some nudges change the path while other nudges are absorbed?`

Seed 1003 remains valuable because its first divergence is readable: a Year 14 `store_food` support difference creates a concrete failure-memory chain. But it should now be treated as one representative case, not as the only evidence.

The next best step is to pick two or three representative changed seeds, then compare their first divergence points against seed 1003. That will show whether the same mechanism repeats or whether v1.4 creates several different branching mechanisms.

Recommended representatives:

- seed 1003: readable failure-memory chain
- seed 1012: extreme nudge volume and many project failures
- seed 1024 or 1043: large population swing
- one unchanged-but-nudged seed such as 1002: absorption case

## Changed Seeds

| seed | changed keys | nudges | pop | food | fail | memshare | first log diff |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1003 | 14 | 7/75 | -7 | +70.521 | +4 | -53 | 14 |
| 1004 | 15 | 6/86 | -3 | +4.744 | -1 | -13 | 62 |
| 1006 | 14 | 0/37 | +2 | -36.539 | -1 | -14 | 62 |
| 1009 | 18 | 30/303 | -3 | -0.160 | -1 | -23 | 50 |
| 1010 | 14 | 5/50 | -8 | -11.450 | +0 | -16 | 23 |
| 1011 | 14 | 7/51 | -3 | -21.903 | +2 | +7 | 55 |
| 1012 | 16 | 94/1352 | -4 | -33.130 | +0 | +35 | 24 |
| 1014 | 17 | 20/213 | +1 | +28.052 | +2 | +11 | 57 |
| 1016 | 15 | 5/39 | +2 | +12.669 | +1 | -20 | 28 |
| 1018 | 14 | 1/25 | +4 | -95.806 | -1 | +11 | 8 |
| 1021 | 2 | 3/15 | +0 | -14.694 | +0 | +0 | 70 |
| 1024 | 14 | 6/55 | +12 | -105.054 | +0 | -5 | 38 |
| 1025 | 13 | 11/149 | +0 | +22.778 | +3 | +7 | 52 |
| 1028 | 13 | 9/40 | +2 | -0.841 | -2 | -4 | 60 |
| 1029 | 14 | 8/45 | -2 | -28.437 | -2 | -11 | 67 |
| 1036 | 14 | 3/59 | -9 | +31.973 | +0 | +1 | 42 |
| 1039 | 9 | 7/29 | +0 | +5.139 | +0 | -5 | 70 |
| 1042 | 17 | 7/110 | +1 | -26.558 | -1 | -37 | 55 |
| 1043 | 15 | 4/42 | -14 | +70.820 | +1 | -51 | 40 |
| 1052 | 11 | 7/22 | -2 | +48.749 | +0 | -14 | 27 |
| 1056 | 15 | 6/72 | +5 | +0.347 | +0 | -23 | 54 |
| 1059 | 17 | 15/240 | +2 | +8.226 | +1 | -20 | 54 |
| 1060 | 16 | 39/554 | -2 | +35.331 | -4 | -12 | 43 |
| 1065 | 13 | 0/19 | -1 | -17.081 | +0 | -4 | 63 |
| 1066 | 13 | 6/45 | +2 | +26.775 | +1 | +9 | 66 |
| 1068 | 14 | 2/30 | +0 | +28.605 | -2 | -15 | 39 |
| 1074 | 11 | 12/66 | -1 | +29.459 | -1 | -1 | 67 |
| 1075 | 12 | 0/21 | +0 | -14.370 | +0 | -2 | 80 |
| 1077 | 14 | 2/19 | +2 | -17.717 | -2 | +4 | 65 |
| 1078 | 10 | 3/35 | -2 | +2.542 | +1 | +4 | 55 |
| 1082 | 1 | 7/17 | +0 | +2.732 | +0 | +0 | 68 |
| 1083 | 12 | 2/23 | -1 | -4.162 | +0 | +0 | 77 |
| 1087 | 17 | 57/699 | -3 | +1.473 | -4 | +23 | 35 |
| 1089 | 11 | 4/25 | +3 | -5.667 | +0 | -2 | 79 |
| 1091 | 13 | 6/61 | +0 | +7.078 | +2 | -16 | 58 |
| 1094 | 13 | 11/45 | +3 | +6.506 | +1 | -2 | 53 |
| 1095 | 15 | 7/32 | -3 | -20.650 | -1 | -5 | 54 |
| 1096 | 15 | 3/41 | +3 | +22.679 | +0 | +24 | 49 |
| 1097 | 3 | 2/48 | +0 | +0 | +0 | +0 | 72 |

## Summary-Unchanged Seeds

| seed | v1.4 action/support nudges | first log diff | labels |
| --- | --- | --- | --- |
| 1000 | 0/10 | - | nudge_only_no_path_change |
| 1001 | 0/8 | - | nudge_only_no_path_change |
| 1002 | 6/37 | - | nudge_only_no_path_change |
| 1005 | 3/33 | - | nudge_only_no_path_change |
| 1007 | 5/26 | - | nudge_only_no_path_change |
| 1008 | 0/44 | 73 | log_changed_summary_same |
| 1013 | 2/24 | - | nudge_only_no_path_change |
| 1015 | 0/6 | - | nudge_only_no_path_change |
| 1017 | 5/13 | - | nudge_only_no_path_change |
| 1019 | 9/46 | 67 | log_changed_summary_same |
| 1020 | 3/39 | - | nudge_only_no_path_change |
| 1022 | 6/30 | - | nudge_only_no_path_change |
| 1023 | 4/11 | - | nudge_only_no_path_change |
| 1026 | 0/11 | - | nudge_only_no_path_change |
| 1027 | 0/17 | - | nudge_only_no_path_change |
| 1030 | 9/68 | 52 | log_changed_summary_same |
| 1031 | 8/56 | - | nudge_only_no_path_change |
| 1032 | 3/12 | - | nudge_only_no_path_change |
| 1033 | 1/24 | - | nudge_only_no_path_change |
| 1034 | 4/23 | - | nudge_only_no_path_change |
| 1035 | 1/32 | - | nudge_only_no_path_change |
| 1037 | 5/35 | - | nudge_only_no_path_change |
| 1038 | 0/12 | - | nudge_only_no_path_change |
| 1040 | 2/20 | - | nudge_only_no_path_change |
| 1041 | 2/35 | - | nudge_only_no_path_change |
| 1044 | 1/23 | - | nudge_only_no_path_change |
| 1045 | 4/13 | - | nudge_only_no_path_change |
| 1046 | 1/20 | - | nudge_only_no_path_change |
| 1047 | 2/10 | - | nudge_only_no_path_change |
| 1048 | 4/82 | - | nudge_only_no_path_change |
| 1049 | 2/26 | - | nudge_only_no_path_change |
| 1050 | 15/83 | - | nudge_only_no_path_change |
| 1051 | 4/17 | - | nudge_only_no_path_change |
| 1053 | 4/20 | - | nudge_only_no_path_change |
| 1054 | 2/11 | - | nudge_only_no_path_change |
| 1055 | 2/13 | - | nudge_only_no_path_change |
| 1057 | 9/24 | - | nudge_only_no_path_change |
| 1058 | 7/10 | - | nudge_only_no_path_change |
| 1061 | 1/41 | 61 | log_changed_summary_same |
| 1062 | 0/20 | - | nudge_only_no_path_change |
| 1063 | 3/43 | - | nudge_only_no_path_change |
| 1064 | 9/35 | 42 | log_changed_summary_same |
| 1067 | 3/12 | - | nudge_only_no_path_change |
| 1069 | 8/29 | 69 | log_changed_summary_same |
| 1070 | 2/12 | - | nudge_only_no_path_change |
| 1071 | 5/23 | - | nudge_only_no_path_change |
| 1072 | 2/18 | - | nudge_only_no_path_change |
| 1073 | 4/23 | 25 | log_changed_summary_same |
| 1076 | 3/23 | 62 | log_changed_summary_same |
| 1079 | 6/20 | 37 | log_changed_summary_same |
| 1080 | 3/24 | - | nudge_only_no_path_change |
| 1081 | 4/104 | 56 | log_changed_summary_same |
| 1084 | 0/24 | 54 | log_changed_summary_same |
| 1085 | 6/44 | - | nudge_only_no_path_change |
| 1086 | 15/86 | - | nudge_only_no_path_change |
| 1088 | 10/36 | - | nudge_only_no_path_change |
| 1090 | 3/25 | - | nudge_only_no_path_change |
| 1092 | 6/19 | - | nudge_only_no_path_change |
| 1093 | 5/16 | - | nudge_only_no_path_change |
| 1098 | 8/56 | - | nudge_only_no_path_change |
| 1099 | 6/36 | 52 | log_changed_summary_same |
