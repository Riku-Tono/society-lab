# society_lab v1.4 extra statistics

Seed range: 1000-1099. Compared v1.3 and v1.4 over 80 years.

## Group Means

| group | count | mean action nudges | mean support nudges | median first diff year | mean abs pop delta | mean abs food delta | mean abs failure delta | mean abs memshare delta |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| summary changed | 39 | 10.87 | 125.36 | 55.00 | 2.87 | 23.63 | 1.08 | 12.92 |
| absorbed | 12 | 4.92 | 41.08 | 55.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| no path change | 49 | 3.84 | 26.53 | - | 0.00 | 0.00 | 0.00 | 0.00 |

## Correlations In Summary-Changed Seeds

| x | y | Pearson r |
| --- | --- | --- |
| support_nudges | abs_pop_delta | 0.032 |
| support_nudges | abs_food_delta | -0.013 |
| support_nudges | abs_failure_delta | 0.228 |
| support_nudges | abs_memshare_delta | 0.346 |
| support_nudges | blame_delta | 0.456 |
| action_nudges | abs_pop_delta | 0.019 |
| action_nudges | abs_food_delta | -0.046 |
| action_nudges | abs_failure_delta | 0.259 |
| action_nudges | abs_memshare_delta | 0.319 |
| action_nudges | blame_delta | 0.468 |
| first_diff_year | abs_pop_delta | -0.506 |
| first_diff_year | abs_food_delta | -0.577 |
| first_diff_year | abs_failure_delta | -0.267 |
| first_diff_year | abs_memshare_delta | -0.571 |
| first_diff_year | blame_delta | -0.336 |

## Largest Absolute Deltas

### population

| seed | delta | first diff year | nudges |
| --- | --- | --- | --- |
| 1043 | -14.000 | 40 | 4/42 |
| 1024 | +12.000 | 38 | 6/55 |
| 1036 | -9.000 | 42 | 3/59 |
| 1010 | -8.000 | 23 | 5/50 |
| 1003 | -7.000 | 14 | 7/75 |
| 1056 | +5.000 | 54 | 6/72 |
| 1012 | -4.000 | 24 | 94/1352 |
| 1018 | +4.000 | 8 | 1/25 |
| 1004 | -3.000 | 62 | 6/86 |
| 1009 | -3.000 | 50 | 30/303 |

### food

| seed | delta | first diff year | nudges |
| --- | --- | --- | --- |
| 1024 | -105.054 | 38 | 6/55 |
| 1018 | -95.806 | 8 | 1/25 |
| 1043 | +70.820 | 40 | 4/42 |
| 1003 | +70.521 | 14 | 7/75 |
| 1052 | +48.749 | 27 | 7/22 |
| 1006 | -36.539 | 62 | 0/37 |
| 1060 | +35.331 | 43 | 39/554 |
| 1012 | -33.130 | 24 | 94/1352 |
| 1036 | +31.973 | 42 | 3/59 |
| 1074 | +29.459 | 67 | 12/66 |

### failures

| seed | delta | first diff year | nudges |
| --- | --- | --- | --- |
| 1003 | +4.000 | 14 | 7/75 |
| 1060 | -4.000 | 43 | 39/554 |
| 1087 | -4.000 | 35 | 57/699 |
| 1025 | +3.000 | 52 | 11/149 |
| 1011 | +2.000 | 55 | 7/51 |
| 1014 | +2.000 | 57 | 20/213 |
| 1028 | -2.000 | 60 | 9/40 |
| 1029 | -2.000 | 67 | 8/45 |
| 1068 | -2.000 | 39 | 2/30 |
| 1077 | -2.000 | 65 | 2/19 |

### memory sharing

| seed | delta | first diff year | nudges |
| --- | --- | --- | --- |
| 1003 | -53.000 | 14 | 7/75 |
| 1043 | -51.000 | 40 | 4/42 |
| 1042 | -37.000 | 55 | 7/110 |
| 1012 | +35.000 | 24 | 94/1352 |
| 1096 | +24.000 | 49 | 3/41 |
| 1009 | -23.000 | 50 | 30/303 |
| 1056 | -23.000 | 54 | 6/72 |
| 1087 | +23.000 | 35 | 57/699 |
| 1016 | -20.000 | 28 | 5/39 |
| 1059 | -20.000 | 54 | 15/240 |

## Reading

Support-nudge volume is associated with whether a path can change, but it is a weak predictor of the size of the final change. Large effects can come from modest nudge counts, as in 1003 and 1043.

The most useful next statistic is not only total nudge count. It is the first nudge that changes a support/proposal choice, plus whether that changed choice enters a project failure or memory-sharing chain.
