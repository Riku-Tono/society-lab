# seed1003 trust decomposition

## Purpose

This batch decomposes the Y21 p019->p000 trust update into amount, key creation, top_trusted effects, and a lightweight RNG-count audit.

## Results

| exp | intervention | final pop | births | failures | memory shares | first diff | changed keys | trust before | trust after | top after |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| baseline | baseline | 18 | 18 | 9 | 323 |  | 0 | None | 0.012 | p018 p028 p026 p019 |
| TRUST_000 | trust delta 0.000 | 18 | 18 | 9 | 323 |  | 0 | None | 0.0 | p018 p028 p026 p019 |
| TRUST_001 | trust delta 0.001 | 18 | 18 | 9 | 323 |  | 0 | None | 0.001 | p018 p028 p026 p019 |
| TRUST_006 | trust delta 0.006 | 18 | 18 | 9 | 323 |  | 0 | None | 0.006 | p018 p028 p026 p019 |
| TRUST_012 | trust delta 0.012 | 18 | 18 | 9 | 323 |  | 0 | None | 0.012 | p018 p028 p026 p019 |
| TRUST_020 | trust delta 0.020 | 18 | 18 | 9 | 323 |  | 0 | None | 0.02 | p018 p028 p026 p019 |
| KEY_ONLY | add p019 key with value 0 | 18 | 18 | 9 | 323 |  | 0 | None | 0.0 | p018 p028 p026 p019 |
| NO_KEY | memory enters but no p019 trust key | 16 | 16 | 4 | 295 | 240 | 12 | None | None |  |
| TOP_FIXED_PRE | after Y21, p000 top_trusted fixed to pre-edge list | 18 | 18 | 9 | 323 |  | 0 | None | 0.012 | p018 p028 p026 p019 |
| TOP_FORCE_HANA | after Y21, force p019 into p000 top_trusted | 20 | 20 | 5 | 296 | 242 | 13 | None | 0.012 | p018 p028 p026 p019 |

## Quick Reading

- Exact summary matches: ['TRUST_000', 'TRUST_001', 'TRUST_006', 'TRUST_012', 'TRUST_020', 'KEY_ONLY', 'TOP_FIXED_PRE']
- TRUST_000, TRUST_001, TRUST_006, TRUST_012, TRUST_020 all match the baseline summary. The amount of the trust value is not the observed lever in this range.
- KEY_ONLY also matches the baseline, while NO_KEY diverges. The important difference is the existence of the `p019` trust key on p000, not the +0.012 magnitude.
- TOP_FIXED_PRE also matches baseline, so the effect is not explained by p019 becoming an active top_trusted listener target in the usual top-N list.
- TOP_FORCE_HANA is a stronger artificial intervention and diverges; forcing Hana into p000's top choices is not equivalent to the baseline key creation.
- RNG counts are included only as a coarse audit; equal counts do not prove equal random values or path identity.
