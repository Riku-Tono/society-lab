from __future__ import annotations

import importlib.util
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(__file__).with_name("society_lab_v1_4.py")

SEED = 1003
YEARS = 80
MILESTONE_YEARS = {1, 10, 20, 30, 40, 50, 60, 70, 80}


@dataclass
class YearSnapshot:
    year: int
    population: int
    food_stock: float
    avg_fear: float
    avg_hunger: float
    proposal_count: int
    project_success_count: int
    project_failure_count: int
    shared_narrative_count: int
    network_split_count: int
    interpretation_divergence_count: int
    avg_bias_spiritual: float
    avg_bias_practical: float
    avg_bias_blame: float
    memory_shared_count: int
    birth_count: int
    death_count: int
    interpretation_action_nudge_count: int | str
    interpretation_support_nudge_count: int | str


def load_module(label: str, path: Path) -> ModuleType:
    module_name = label.replace(".", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def snapshot(sim: object) -> YearSnapshot:
    summary = sim.summary()
    return YearSnapshot(
        year=summary["years"],
        population=summary["final_population"],
        food_stock=summary["final_food_stock"],
        avg_fear=summary["avg_fear"],
        avg_hunger=summary["avg_hunger"],
        proposal_count=summary["proposal_count"],
        project_success_count=summary["project_success_count"],
        project_failure_count=summary["project_failure_count"],
        shared_narrative_count=summary["shared_narrative_count"],
        network_split_count=summary["network_split_count"],
        interpretation_divergence_count=summary["interpretation_divergence_count"],
        avg_bias_spiritual=summary["avg_bias_spiritual"],
        avg_bias_practical=summary["avg_bias_practical"],
        avg_bias_blame=summary["avg_bias_blame"],
        memory_shared_count=summary["memory_shared_count"],
        birth_count=summary["birth_count"],
        death_count=summary["death_count"],
        interpretation_action_nudge_count=summary.get("interpretation_action_nudge_count", "-"),
        interpretation_support_nudge_count=summary.get("interpretation_support_nudge_count", "-"),
    )


def run_yearly(module: ModuleType) -> tuple[object, list[YearSnapshot]]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    snapshots = []
    for _ in range(YEARS):
        if sim.population == 0:
            break
        sim.step()
        snapshots.append(snapshot(sim))
    return sim, snapshots


def compact_event(entry: object) -> str:
    persons = ",".join(entry.persons)
    return f"Y{entry.year:02d} {entry.event_type} [{persons}] {entry.detail}"


def first_log_difference(before: object, after: object) -> tuple[int, str, str] | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        left = compact_event(before_entries[index])
        right = compact_event(after_entries[index])
        if left != right:
            return index, left, right
    if len(before_entries) != len(after_entries):
        left = "<no event>" if len(before_entries) <= limit else compact_event(before_entries[limit])
        right = "<no event>" if len(after_entries) <= limit else compact_event(after_entries[limit])
        return limit, left, right
    return None


def changed_years(
    before: list[YearSnapshot],
    after: list[YearSnapshot],
) -> list[tuple[YearSnapshot, YearSnapshot]]:
    rows = []
    for left, right in zip(before, after):
        important_changed = (
            left.population != right.population
            or left.proposal_count != right.proposal_count
            or left.project_failure_count != right.project_failure_count
            or left.network_split_count != right.network_split_count
            or left.interpretation_divergence_count != right.interpretation_divergence_count
            or left.birth_count != right.birth_count
            or left.death_count != right.death_count
        )
        if left.year in MILESTONE_YEARS or important_changed:
            rows.append((left, right))
    return rows


def print_timeline(rows: list[tuple[YearSnapshot, YearSnapshot]]) -> None:
    header = (
        "year | pop | food | failures | births | deaths | mem_shared | "
        "net_split | interp_div | blame_bias | v1.4 nudges"
    )
    print(header)
    print("-" * len(header))
    for left, right in rows:
        nudge_text = (
            f"{right.interpretation_action_nudge_count}/"
            f"{right.interpretation_support_nudge_count}"
        )
        print(
            f"{left.year:>4} | "
            f"{left.population}->{right.population} | "
            f"{left.food_stock:.1f}->{right.food_stock:.1f} | "
            f"{left.project_failure_count}->{right.project_failure_count} | "
            f"{left.birth_count}->{right.birth_count} | "
            f"{left.death_count}->{right.death_count} | "
            f"{left.memory_shared_count}->{right.memory_shared_count} | "
            f"{left.network_split_count}->{right.network_split_count} | "
            f"{left.interpretation_divergence_count}->{right.interpretation_divergence_count} | "
            f"{left.avg_bias_blame:.4f}->{right.avg_bias_blame:.4f} | "
            f"{nudge_text}"
        )


def print_nearby_events(sim: object, year: int, title: str) -> None:
    print(title)
    for entry in sim.log.entries:
        if year - 1 <= entry.year <= year + 1:
            print(f"  {compact_event(entry)}")


def main() -> None:
    before_module = load_module("society_lab_v1_3", V13_PATH)
    after_module = load_module("society_lab_v1_4", V14_PATH)
    before_sim, before_years = run_yearly(before_module)
    after_sim, after_years = run_yearly(after_module)

    print(f"society_lab deep comparison, seed {SEED}, {YEARS} years")
    print()

    diff = first_log_difference(before_sim, after_sim)
    if diff is None:
        print("First log difference: none")
    else:
        index, left, right = diff
        print(f"First log difference: event index {index}")
        print(f"  v1.3: {left}")
        print(f"  v1.4: {right}")
        print()
        first_year = after_sim.log.entries[index].year
        print_nearby_events(before_sim, first_year, "v1.3 nearby events")
        print()
        print_nearby_events(after_sim, first_year, "v1.4 nearby events")
        print()

    print_timeline(changed_years(before_years, after_years))
    print()
    print("Final summaries")
    print(f"  v1.3: {before_sim.summary()}")
    print(f"  v1.4: {after_sim.summary()}")


if __name__ == "__main__":
    main()
