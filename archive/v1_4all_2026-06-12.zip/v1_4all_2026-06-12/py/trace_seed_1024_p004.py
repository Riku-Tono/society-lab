from __future__ import annotations

import csv
import importlib.util
import sys
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
REPORT_PATH = OUT_DIR / "society_lab_seed_1024_p004_sana_trace.md"
CSV_PATH = OUT_DIR / "society_lab_seed_1024_p004_sana_trace.csv"

SEED = 1024
TARGET = "p004"
START_YEAR = 38
END_YEAR = 46


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def person(sim: object, person_id: str) -> object:
    return next(p for p in sim.people if p.id == person_id)


def person_status(sim: object, person_id: str) -> str:
    p = person(sim, person_id)
    return (
        f"{p.id}:{p.name}:age={p.age}:sex={p.sex}:"
        f"alive={p.alive}:health={p.health:.2f}:hunger={p.hunger:.2f}:"
        f"action={p.action}"
    )


def relevant_events(sim: object, year: int) -> list[object]:
    rows = []
    for entry in sim.log.entries:
        if entry.year != year:
            continue
        if TARGET in entry.persons:
            rows.append(entry)
        elif entry.event_type in {"birth", "death"}:
            rows.append(entry)
    return rows


def trace(module: ModuleType, version: str) -> tuple[object, list[dict[str, str]]]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    rows: list[dict[str, str]] = []
    for _ in range(END_YEAR):
        if sim.population == 0:
            break
        sim.step()
        if START_YEAR <= sim.year <= END_YEAR:
            p = person(sim, TARGET)
            for entry in relevant_events(sim, sim.year):
                role = "-"
                if entry.event_type == "memory_shared" and len(entry.persons) >= 2:
                    if entry.persons[0] == TARGET:
                        role = "speaker"
                    elif entry.persons[1] == TARGET:
                        role = "listener"
                elif TARGET in entry.persons:
                    role = "participant"
                rows.append(
                    {
                        "version": version,
                        "year": str(entry.year),
                        "p004_alive_after_year": str(p.alive),
                        "p004_age_after_year": str(p.age),
                        "event_type": entry.event_type,
                        "role": role,
                        "persons": ",".join(entry.persons),
                        "detail": entry.detail,
                    }
                )
    return sim, rows


def md_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    def cell(value: object) -> str:
        return str(value).replace("|", "\\|")

    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(cell(item) for item in row) + " |")
    return lines


def write_csv(rows: list[dict[str, str]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def build_report() -> str:
    v13 = load_module("society_lab_v1_3_seed1024_p004", V13_PATH)
    v14 = load_module("society_lab_v1_4_seed1024_p004", V14_PATH)
    sim13, rows13 = trace(v13, "v1.3")
    sim14, rows14 = trace(v14, "v1.4")
    rows = rows13 + rows14
    write_csv(rows)

    p13 = person(sim13, TARGET)
    p14 = person(sim14, TARGET)
    lines: list[str] = []
    lines.append("# seed 1024 p004 Sana trace")
    lines.append("")
    lines.append("Focus: p004 Sana from Year 38 to Year 46 after the Year38 support/project participation difference.")
    lines.append("")
    lines.append("## Status At Year 46")
    lines.append("")
    lines.extend(
        md_table(
            ["version", "status"],
            [
                ["v1.3", person_status(sim13, TARGET)],
                ["v1.4", person_status(sim14, TARGET)],
            ],
        )
    )
    lines.append("")
    lines.append("## P004-Involved Events And Birth/Death Context")
    lines.append("")
    for version, version_rows in (("v1.3", rows13), ("v1.4", rows14)):
        lines.append(f"### {version}")
        lines.append("")
        lines.extend(
            md_table(
                ["year", "alive_after_year", "age_after_year", "event", "role", "persons", "detail"],
                [
                    [
                        row["year"],
                        row["p004_alive_after_year"],
                        row["p004_age_after_year"],
                        row["event_type"],
                        row["role"],
                        row["persons"],
                        row["detail"],
                    ]
                    for row in version_rows
                ],
            )
        )
        lines.append("")
    lines.append("## Direct Check")
    lines.append("")
    lines.append(f"- v1.3 p004 alive at Year46: {p13.alive}; age={p13.age}")
    lines.append(f"- v1.4 p004 alive at Year46: {p14.alive}; age={p14.age}")
    lines.append(
        "- Birth events where p004 is the parent: "
        + str([row for row in rows if row["event_type"] == "birth" and row["persons"].split(",")[0] == TARGET])
    )
    lines.append(
        "- Memory shares involving p004: "
        + str([row for row in rows if row["event_type"] == "memory_shared" and TARGET in row["persons"].split(",")])
    )
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(build_report(), encoding="utf-8")
    print(REPORT_PATH)
    print(CSV_PATH)


if __name__ == "__main__":
    main()
