from __future__ import annotations

import importlib.util
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V14_PATH = Path(__file__).with_name("society_lab_v1_4.py")
REPORT_PATH = Path(__file__).with_name("society_lab_seed_1003_recipient_behavior.md")

SEED = 1003
YEARS = 80
TARGET_EVENT = "project_failure:store_food"
TARGET_MEMORY_YEAR = 14
FOCUS_IDS = ("p006", "p019", "p004", "p011", "p000", "p028", "p032", "p035", "p021")


@dataclass
class MemoryReceipt:
    year: int
    receiver_id: str
    receiver_name: str
    source_id: str
    source_name: str
    interpretation: str
    intensity: float
    generation: int
    mode: str


@dataclass
class PersonInitial:
    person_id: str
    name: str
    age: int
    charisma: float
    food_skill: float
    incoming_trust: float
    trust_links: int
    spiritual: float
    practical: float
    blame: float


def load_module(label: str, path: Path) -> ModuleType:
    module_name = label.replace(".", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def build_instrumented_lab(module: ModuleType) -> type:
    class InstrumentedSocietyLab(module.SocietyLab):
        def __init__(self, *args: object, **kwargs: object) -> None:
            super().__init__(*args, **kwargs)
            self.initial_profiles = {
                person.id: PersonInitial(
                    person_id=person.id,
                    name=person.name,
                    age=person.age,
                    charisma=person.charisma,
                    food_skill=person.food_skill,
                    incoming_trust=self._incoming_trust(person.id),
                    trust_links=len(person.trust),
                    spiritual=person.interpretation_bias.get("spiritual", 0.0),
                    practical=person.interpretation_bias.get("practical", 0.0),
                    blame=person.interpretation_bias.get("blame", 0.0),
                )
                for person in self.people
            }
            self.memory_receipts: list[MemoryReceipt] = []

        def _apply_project_failure(self, problem: object, proposal: object, proposer: object, supporters: list[object]) -> None:
            for supporter in supporters:
                self._adjust_trust(supporter, proposer.id, -0.045)
                supporter.fear = self._clamp(supporter.fear + 0.08 + problem.severity * 0.08)
                memory = self._make_memory(
                    supporter,
                    event=f"project_failure:{proposal.action}",
                    intensity=0.45 + problem.severity * 0.35,
                )
                supporter.remember(memory)
                if (
                    self.year == TARGET_MEMORY_YEAR
                    and memory.event == TARGET_EVENT
                ):
                    self.memory_receipts.append(
                        MemoryReceipt(
                            year=self.year,
                            receiver_id=supporter.id,
                            receiver_name=supporter.name,
                            source_id=proposer.id,
                            source_name=proposer.name,
                            interpretation=memory.interpretation,
                            intensity=memory.intensity,
                            generation=memory.generation,
                            mode="experienced_failure",
                        )
                    )

        def _dialogue_phase(self) -> None:
            for speaker in self.alive_people:
                memory = speaker.strongest_memory()
                if memory is None:
                    continue
                share_probability = (
                    0.05
                    + memory.intensity * 0.18
                    + speaker.fear * 0.15
                    + (0.12 if speaker.action == "share_memory" else 0.0)
                )
                if memory.generation >= 4:
                    share_probability *= 0.55
                if self.rng.random() > min(0.55, share_probability):
                    continue
                listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
                listeners = [
                    self._person(person_id)
                    for person_id in speaker.top_trusted(listener_count)
                    if self._person(person_id).alive
                ]
                for listener in listeners:
                    distorted = self._distort_memory(memory, speaker, listener)
                    if (
                        memory.event == TARGET_EVENT
                        and memory.year == TARGET_MEMORY_YEAR
                    ):
                        self.memory_receipts.append(
                            MemoryReceipt(
                                year=self.year,
                                receiver_id=listener.id,
                                receiver_name=listener.name,
                                source_id=speaker.id,
                                source_name=speaker.name,
                                interpretation=distorted.interpretation,
                                intensity=distorted.intensity,
                                generation=distorted.generation,
                                mode="heard_memory",
                            )
                        )
                    listener.remember(distorted)
                    self.log.record(
                        self.year,
                        "memory_shared",
                        [speaker.id, listener.id],
                        (
                            f"{speaker.name} told {listener.name} about "
                            f"{distorted.event} intensity={distorted.intensity:.2f} "
                            f"generation={distorted.generation}"
                        ),
                    )
                    self._adjust_trust(listener, speaker.id, 0.012)

    return InstrumentedSocietyLab


def death_year(sim: object, person_id: str) -> int | None:
    for entry in sim.log.entries:
        if entry.event_type == "death" and entry.persons and entry.persons[0] == person_id:
            return entry.year
    return None


def first_receipt(receipts: list[MemoryReceipt], person_id: str) -> MemoryReceipt | None:
    person_receipts = [receipt for receipt in receipts if receipt.receiver_id == person_id]
    if not person_receipts:
        return None
    return min(person_receipts, key=lambda receipt: receipt.year)


def compact_event(entry: object) -> str:
    persons = ",".join(entry.persons)
    return f"Y{entry.year:02d} {entry.event_type} [{persons}] {entry.detail}"


def events_after(sim: object, person_id: str, start_year: int) -> list[object]:
    relevant_types = {
        "proposal_made",
        "proposal_supported",
        "project_started",
        "project_success",
        "project_failure",
        "memory_shared",
        "birth",
        "death",
    }
    return [
        entry for entry in sim.log.entries
        if entry.year >= start_year
        and entry.event_type in relevant_types
        and person_id in entry.persons
    ]


def year_has_social_action(entry: object, person_id: str) -> bool:
    if person_id not in entry.persons:
        return False
    return entry.event_type in {
        "proposal_made",
        "proposal_supported",
        "project_started",
        "project_success",
        "project_failure",
        "memory_shared",
    }


def inactive_year_count(sim: object, person_id: str, start_year: int, end_year: int) -> int:
    inactive = 0
    for year in range(start_year, end_year + 1):
        involved = any(
            entry.year == year and year_has_social_action(entry, person_id)
            for entry in sim.log.entries
        )
        if not involved:
            inactive += 1
    return inactive


def count_roles(entries: list[object], person_id: str) -> dict[str, int]:
    counts = {
        "proposal_made": 0,
        "proposal_supported_as_supporter": 0,
        "proposal_supported_as_proposer": 0,
        "project_participation": 0,
        "project_failure_participation": 0,
        "project_success_participation": 0,
        "memory_shared_as_speaker": 0,
        "memory_shared_as_listener": 0,
        "birth_parent": 0,
        "death_self": 0,
    }
    for entry in entries:
        if entry.event_type == "proposal_made":
            counts["proposal_made"] += 1
        elif entry.event_type == "proposal_supported":
            if entry.persons[0] == person_id:
                counts["proposal_supported_as_supporter"] += 1
            if len(entry.persons) > 1 and entry.persons[1] == person_id:
                counts["proposal_supported_as_proposer"] += 1
        elif entry.event_type == "project_started":
            counts["project_participation"] += 1
        elif entry.event_type == "project_failure":
            counts["project_failure_participation"] += 1
        elif entry.event_type == "project_success":
            counts["project_success_participation"] += 1
        elif entry.event_type == "memory_shared":
            if entry.persons[0] == person_id:
                counts["memory_shared_as_speaker"] += 1
            if len(entry.persons) > 1 and entry.persons[1] == person_id:
                counts["memory_shared_as_listener"] += 1
        elif entry.event_type == "birth" and entry.persons[0] == person_id:
            counts["birth_parent"] += 1
        elif entry.event_type == "death" and entry.persons[0] == person_id:
            counts["death_self"] += 1
    return counts


def final_profile(sim: object, person_id: str) -> dict[str, object]:
    person = sim._person(person_id)
    return {
        "alive": person.alive,
        "age": person.age,
        "incoming_trust": round(sim._incoming_trust(person_id), 3),
        "trust_links": len(person.trust),
        "memory_count": len(person.memories),
        "spiritual": round(person.interpretation_bias.get("spiritual", 0.0), 4),
        "practical": round(person.interpretation_bias.get("practical", 0.0), 4),
        "blame": round(person.interpretation_bias.get("blame", 0.0), 4),
    }


def write_person_section(lines: list[str], sim: object, person_id: str) -> None:
    initial = sim.initial_profiles.get(person_id)
    if initial is None:
        return
    final = final_profile(sim, person_id)
    receipt = first_receipt(sim.memory_receipts, person_id)
    died = death_year(sim, person_id)
    start_year = receipt.year if receipt else TARGET_MEMORY_YEAR
    end_year = died if died is not None else YEARS
    entries = events_after(sim, person_id, start_year)
    counts = count_roles(entries, person_id)
    inactive = inactive_year_count(sim, person_id, start_year, end_year)
    retells = [
        receipt for receipt in sim.memory_receipts
        if receipt.source_id == person_id and receipt.mode == "heard_memory"
    ]

    lines.append(f"## {person_id} {initial.name}")
    lines.append("")
    lines.append("Basic profile:")
    lines.append("")
    lines.append(
        f"- initial age={initial.age}, charisma={initial.charisma:.3f}, "
        f"food_skill={initial.food_skill:.3f}, incoming_trust={initial.incoming_trust:.3f}, "
        f"trust_links={initial.trust_links}"
    )
    lines.append(
        f"- initial bias: spiritual={initial.spiritual:.4f}, "
        f"practical={initial.practical:.4f}, blame={initial.blame:.4f}"
    )
    lines.append(
        f"- final/death: alive={final['alive']}, death_year={died}, "
        f"age={final['age']}, incoming_trust={final['incoming_trust']}, "
        f"trust_links={final['trust_links']}, memory_count={final['memory_count']}"
    )
    lines.append(
        f"- final bias: spiritual={final['spiritual']}, "
        f"practical={final['practical']}, blame={final['blame']}"
    )
    lines.append("")
    if receipt is None:
        lines.append("First receipt: not observed for the target Year14 memory.")
    else:
        lines.append(
            "First receipt: "
            f"Y{receipt.year}, mode={receipt.mode}, from={receipt.source_id} {receipt.source_name}, "
            f"interpretation={receipt.interpretation}, intensity={receipt.intensity:.2f}, "
            f"generation={receipt.generation}"
        )
    lines.append("")
    lines.append("Post-receipt role counts:")
    lines.append("")
    for key, value in counts.items():
        lines.append(f"- {key}: {value}")
    lines.append(f"- inactive_years_after_receipt_or_Y14: {inactive}")
    lines.append("")
    lines.append("Retells of the target Year14 memory:")
    lines.append("")
    if retells:
        for item in retells:
            lines.append(
                f"- Y{item.year}: {person_id} {initial.name} -> "
                f"{item.receiver_id} {item.receiver_name} "
                f"(interpretation={item.interpretation}, gen={item.generation}, intensity={item.intensity:.2f})"
            )
    else:
        lines.append("- none")
    lines.append("")
    lines.append("Selected post-receipt events:")
    lines.append("")
    selected = entries[:18]
    if selected:
        for entry in selected:
            lines.append(f"- {compact_event(entry)}")
        if len(entries) > len(selected):
            lines.append(f"- ... {len(entries) - len(selected)} more")
    else:
        lines.append("- none")
    lines.append("")


def write_report(sim: object) -> None:
    lines: list[str] = []
    lines.append("# society_lab seed 1003 recipient behavior trace")
    lines.append("")
    lines.append("Version: v1.4")
    lines.append(f"Seed: {SEED}")
    lines.append(f"Target memory: `{TARGET_EVENT}` from Year {TARGET_MEMORY_YEAR}")
    lines.append("")
    lines.append("## Reading Guardrails")
    lines.append("")
    lines.append("- This report follows behavior after receiving one specific source memory.")
    lines.append("- It does not prove that the memory caused the later behavior.")
    lines.append("- People who die early have fewer chances to act; compare counts with survival time.")
    lines.append("- A later bias value may reflect pre-existing tendency, received memory, later events, or all three.")
    lines.append("")
    lines.append("## Focus People")
    lines.append("")
    for person_id in FOCUS_IDS:
        write_person_section(lines, sim, person_id)
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    module = load_module("society_lab_v1_4", V14_PATH)
    lab_class = build_instrumented_lab(module)
    sim = lab_class(seed=SEED, verbose=False)
    sim.run(years=YEARS)
    write_report(sim)
    print(f"Wrote {REPORT_PATH}")
    print(f"receipts recorded: {len(sim.memory_receipts)}")


if __name__ == "__main__":
    main()
