from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
HANA = "p019"
P000 = "p000"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14
BASELINE_EDGE_INTENSITY = 0.4204
BASELINE_EDGE_INTERPRETATION = "practical"


def load_module(label: str, path: Path):
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_history_lock", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    intensity: float | None = None
    interpretation: str | None = None
    no_trust_update: bool = False
    force_action: str | None = None
    timing_year: int | None = None


EXPERIMENTS = [
    Experiment("baseline", "baseline"),
    Experiment("INT_025", "hana_to_p000 intensity=0.25", intensity=0.25),
    Experiment("INT_042", "hana_to_p000 intensity=baseline 0.4204", intensity=BASELINE_EDGE_INTENSITY),
    Experiment("INT_060", "hana_to_p000 intensity=0.60", intensity=0.60),
    Experiment("INT_080", "hana_to_p000 intensity=0.80", intensity=0.80),
    Experiment("INTP_practical", "interpretation=practical", interpretation="practical"),
    Experiment("INTP_blame", "interpretation=blame", interpretation="blame"),
    Experiment("INTP_spiritual", "interpretation=spiritual", interpretation="spiritual"),
    Experiment("INTP_none", "interpretation=none", interpretation="none"),
    Experiment("TRUST_none", "no trust update on hana->p000", no_trust_update=True),
    Experiment("ACT_store_food", "force p000 action=store_food at receipt", force_action="store_food"),
    Experiment("ACT_reassure", "force p000 action=reassure at receipt", force_action="reassure"),
    Experiment("ACT_withdraw", "force p000 action=withdraw at receipt", force_action="withdraw"),
    Experiment("TIME_Y20", "p000 receives at Y20, original Y21 blocked", timing_year=20),
    Experiment("TIME_Y22", "p000 receives at Y22, original Y21 blocked", timing_year=22),
    Experiment("TIME_Y23", "p000 receives at Y23, original Y21 blocked", timing_year=23),
]


def is_target_memory(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    limit = min(len(left.log.entries), len(right.log.entries))
    for index in range(limit):
        baseline = compact_event(left.log.entries[index])
        experiment = compact_event(right.log.entries[index])
        if baseline != experiment:
            return {"index": index, "baseline": baseline, "experiment": experiment}
    if len(left.log.entries) != len(right.log.entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left.log.entries) <= limit else compact_event(left.log.entries[limit]),
            "experiment": "<none>" if len(right.log.entries) <= limit else compact_event(right.log.entries[limit]),
        }
    return None


def synthetic_memory(exp: Experiment):
    return v14.Memory(
        event=TARGET_EVENT,
        year=TARGET_YEAR,
        intensity=exp.intensity if exp.intensity is not None else BASELINE_EDGE_INTENSITY,
        decay_rate=0.02,
        source=HANA,
        generation=1,
        interpretation=exp.interpretation or BASELINE_EDGE_INTERPRETATION,
    )


def apply_edge_modifiers(memory: object, exp: Experiment) -> None:
    if exp.intensity is not None:
        memory.intensity = exp.intensity
    if exp.interpretation is not None:
        memory.interpretation = exp.interpretation


class HistoryLockLab(v14.SocietyLab):
    def __init__(self, *args, exp: Experiment, **kwargs):
        super().__init__(*args, **kwargs)
        self.exp = exp
        self.edge_record: dict[str, Any] | None = None
        self.original_edge_blocked = False
        self.synthetic_injected = False

    def step(self) -> None:
        super().step()
        if self.exp.timing_year is not None and self.year == self.exp.timing_year:
            self._inject_timed_memory()

    def _inject_timed_memory(self) -> None:
        if self.synthetic_injected:
            return
        p000 = self._person(P000)
        hana = self._person(HANA)
        if not p000.alive:
            return
        memory = synthetic_memory(self.exp)
        p000.remember(memory)
        self.synthetic_injected = True
        self.edge_record = {
            "year": self.year,
            "speaker": HANA,
            "listener": P000,
            "mode": "timed_injection",
            "intensity": round(memory.intensity, 4),
            "interpretation": memory.interpretation,
            "p000_action_before": p000.action,
        }
        self.log.record(
            self.year,
            "memory_shared",
            [hana.id, p000.id],
            (
                f"{hana.name} told {p000.name} about {memory.event} "
                f"intensity={memory.intensity:.2f} generation={memory.generation}"
            ),
        )
        self._adjust_trust(p000, hana.id, 0.012)

    def _dialogue_phase(self) -> None:
        for speaker in self.alive_people:
            memory = speaker.strongest_memory()
            if memory is None:
                continue
            share_probability = (
                0.05
                + memory.intensity * 0.18
                + speaker.fear * 0.15
                + (0.12 if speaker.action == "share_memory" else 0.0)
            )
            if memory.generation >= 4:
                share_probability *= 0.55
            if self.rng.random() > min(0.55, share_probability):
                continue
            listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
            listeners = [
                self._person(person_id)
                for person_id in speaker.top_trusted(listener_count)
                if self._person(person_id).alive
            ]
            for listener in listeners:
                target_edge = (
                    self.year == 21
                    and speaker.id == HANA
                    and listener.id == P000
                    and is_target_memory(memory)
                )
                if target_edge and self.exp.timing_year is not None:
                    distorted = self._distort_memory(memory, speaker, listener)
                    self.original_edge_blocked = True
                    continue

                if target_edge and self.exp.force_action is not None:
                    listener.action = self.exp.force_action

                distorted = self._distort_memory(memory, speaker, listener)
                if target_edge:
                    apply_edge_modifiers(distorted, self.exp)
                    self.edge_record = {
                        "year": self.year,
                        "speaker": speaker.id,
                        "listener": listener.id,
                        "mode": "modified_original_edge",
                        "intensity": round(distorted.intensity, 4),
                        "interpretation": distorted.interpretation,
                        "p000_action_before": listener.action,
                        "trust_update": not self.exp.no_trust_update,
                    }
                listener.remember(distorted)
                self.log.record(
                    self.year,
                    "memory_shared",
                    [speaker.id, listener.id],
                    (
                        f"{speaker.name} told {listener.name} about "
                        f"{distorted.event} intensity={distorted.intensity:.2f} "
                        f"generation={distorted.generation}"
                    ),
                )
                if not (target_edge and self.exp.no_trust_update):
                    self._adjust_trust(listener, speaker.id, 0.012)


def run(exp: Experiment) -> HistoryLockLab:
    sim = HistoryLockLab(seed=SEED, verbose=False, exp=exp)
    sim.run(YEARS)
    return sim


baseline = run(EXPERIMENTS[0])
baseline_summary = selected_summary(baseline)
rows = []
details = {
    "seed": SEED,
    "years": YEARS,
    "hypothesis": "Y21 p019->p000 history-lock micro-interventions",
    "baseline_summary": baseline_summary,
    "experiments": {},
}

for exp in EXPERIMENTS:
    sim = baseline if exp.code == "baseline" else run(exp)
    summary = selected_summary(sim)
    first_diff = None if exp.code == "baseline" else first_log_difference(baseline, sim)
    changed_keys = [
        key for key, value in summary.items()
        if baseline_summary.get(key) != value
    ]
    row = {
        "experiment": exp.code,
        "label": exp.label,
        **summary,
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "changed_key_count": len(changed_keys),
        "changed_keys": ",".join(changed_keys),
        "edge_year": "" if sim.edge_record is None else sim.edge_record["year"],
        "edge_intensity": "" if sim.edge_record is None else sim.edge_record["intensity"],
        "edge_interpretation": "" if sim.edge_record is None else sim.edge_record["interpretation"],
    }
    rows.append(row)
    details["experiments"][exp.code] = {
        "label": exp.label,
        "summary": summary,
        "changed_keys_vs_baseline": changed_keys,
        "first_diff_vs_baseline": first_diff,
        "edge_record": sim.edge_record,
        "original_edge_blocked": sim.original_edge_blocked,
    }

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_path = OUT_DIR / "society_lab_seed1003_history_lock_batch.py"
report_path = OUT_DIR / "society_lab_seed1003_history_lock_batch_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_history_lock_batch_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_history_lock_batch_details.json"

script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

report = [
    "# seed1003 Y21 p019->p000 history-lock batch",
    "",
    "## Purpose",
    "",
    "This batch tests whether the Y21 Hana->Zol edge is sensitive to memory intensity, interpretation, trust update, p000 action state, or timing. It is a micro-intervention screen, not a final causal proof.",
    "",
    "## Results",
    "",
    "| exp | intervention | final pop | births | failures | memory shares | first diff | changed keys | edge |",
    "|---|---|---:|---:|---:|---:|---:|---:|---|",
]
for row in rows:
    edge = f"Y{row['edge_year']} {row['edge_intensity']} {row['edge_interpretation']}" if row["edge_year"] != "" else "-"
    report.append(
        f"| {row['experiment']} | {row['label']} | {row['final_population']} | "
        f"{row['birth_count']} | {row['project_failure_count']} | {row['memory_shared_count']} | "
        f"{row['first_diff_index']} | {row['changed_key_count']} | {edge} |"
    )

stable = [
    row["experiment"] for row in rows
    if row["experiment"] != "baseline" and row["changed_key_count"] == 0
]
near = [
    row["experiment"] for row in rows
    if row["experiment"] != "baseline"
    and row["final_population"] == baseline_summary["final_population"]
    and row["birth_count"] == baseline_summary["birth_count"]
    and row["changed_key_count"] > 0
]
report.extend(
    [
        "",
        "## Quick Reading",
        "",
        f"- Exact summary matches: {stable if stable else 'none'}",
        f"- Population/birth matches but path differs: {near if near else 'none'}",
        "- If intensity/interpretation variants stay close, the edge existence and event order matter more than content details.",
        "- If no-trust-update stays close, trust +0.012 is not sufficient as the main explanation.",
        "- If timing variants diverge, the Y21 placement is part of the condition.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
