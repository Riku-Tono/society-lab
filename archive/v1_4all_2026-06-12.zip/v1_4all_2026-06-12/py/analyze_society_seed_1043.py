from __future__ import annotations

import importlib.util
import re
import statistics
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
REPORT_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs\society_lab_seed_1043_deep_analysis.md"
)

SEED = 1043
YEARS = 80
MILESTONES = {10, 20, 30, 40, 50, 60, 70, 80}


@dataclass(frozen=True)
class Snapshot:
    year: int
    population: int
    food: float
    failures: int
    successes: int
    births: int
    deaths: int
    memory_shared: int
    shared_narrative: int
    narrative_divergence: int
    network_split: int
    avg_blame: float
    action_nudges: int | str
    support_nudges: int | str


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def compact_event(entry: object) -> str:
    persons = ",".join(entry.persons)
    return f"Y{entry.year:02d} {entry.event_type} [{persons}] {entry.detail}"


def first_log_difference(before: object, after: object) -> tuple[int, object, object] | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return index, before_entries[index], after_entries[index]
    if len(before_entries) != len(after_entries):
        left = None if len(before_entries) <= limit else before_entries[limit]
        right = None if len(after_entries) <= limit else after_entries[limit]
        return limit, left, right
    return None


def snapshot(sim: object) -> Snapshot:
    summary = sim.summary()
    return Snapshot(
        year=int(summary["years"]),
        population=int(summary["final_population"]),
        food=float(summary["final_food_stock"]),
        failures=int(summary["project_failure_count"]),
        successes=int(summary["project_success_count"]),
        births=int(summary["birth_count"]),
        deaths=int(summary["death_count"]),
        memory_shared=int(summary["memory_shared_count"]),
        shared_narrative=int(summary["shared_narrative_count"]),
        narrative_divergence=int(summary["narrative_divergence_count"]),
        network_split=int(summary["network_split_count"]),
        avg_blame=float(summary["avg_bias_blame"]),
        action_nudges=summary.get("interpretation_action_nudge_count", "-"),
        support_nudges=summary.get("interpretation_support_nudge_count", "-"),
    )


def run_yearly(module: ModuleType) -> tuple[object, list[Snapshot]]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    snaps: list[Snapshot] = []
    for _ in range(YEARS):
        if sim.population == 0:
            break
        sim.step()
        if sim.year in MILESTONES or sim.year in {39, 40, 41, 42}:
            snaps.append(snapshot(sim))
    return sim, snaps


def md_table(headers: list[str], rows: list[list[object]]) -> list[str]:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def fmt(value: float) -> str:
    return f"{value:.3f}"


def event_neighborhood(sim: object, year: int, radius: int = 2) -> list[str]:
    lines = []
    for entry in sim.log.entries:
        if year - radius <= entry.year <= year + radius:
            lines.append(compact_event(entry))
    return lines


def project_event_key(detail: str) -> str | None:
    match = re.search(r"(project_(?:failure|success)):\s+(\w+)\s+for\s+(\w+)", detail)
    if not match:
        return None
    return f"{match.group(1)}:{match.group(2)}:{match.group(3)}"


def memory_event_name(detail: str) -> str | None:
    match = re.search(r"about\s+(project_(?:failure|success):\w+|food_shortage|death)", detail)
    if not match:
        return None
    return match.group(1)


def memory_shares_by_event(sim: object, start_year: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if entry.year < start_year or entry.event_type != "memory_shared":
            continue
        name = memory_event_name(entry.detail)
        if name:
            counts[name] += 1
    return counts


def first_projects_after(sim: object, start_year: int, limit: int = 8) -> list[str]:
    rows = []
    for entry in sim.log.entries:
        if entry.year >= start_year and entry.event_type in {"project_started", "project_success", "project_failure"}:
            rows.append(compact_event(entry))
            if len(rows) >= limit:
                break
    return rows


def support_set_at_year(sim: object, year: int) -> dict[str, list[str]]:
    proposals: dict[str, list[str]] = defaultdict(list)
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type != "proposal_supported":
            continue
        if len(entry.persons) < 2:
            continue
        supporter, proposer = entry.persons[0], entry.persons[1]
        action_match = re.search(r"supported\s+(\w+)", entry.detail)
        action = action_match.group(1) if action_match else "unknown"
        proposals[f"{proposer}:{action}"].append(supporter)
    return dict(proposals)


def changed_supports(before: object, after: object, year: int) -> list[list[object]]:
    left = support_set_at_year(before, year)
    right = support_set_at_year(after, year)
    rows = []
    for key in sorted(set(left) | set(right)):
        left_set = set(left.get(key, []))
        right_set = set(right.get(key, []))
        if left_set == right_set:
            continue
        rows.append(
            [
                key,
                len(left_set),
                len(right_set),
                ", ".join(sorted(right_set - left_set)) or "-",
                ", ".join(sorted(left_set - right_set)) or "-",
            ]
        )
    return rows


def build_report() -> str:
    v13 = load_module("society_lab_v1_3_seed1043", V13_PATH)
    v14 = load_module("society_lab_v1_4_seed1043", V14_PATH)
    before_sim, before_snaps = run_yearly(v13)
    after_sim, after_snaps = run_yearly(v14)
    first = first_log_difference(before_sim, after_sim)
    if first is None:
        raise RuntimeError("No log difference found for seed 1043")
    first_index, first_before, first_after = first
    first_year = int(first_after.year if first_after is not None else first_before.year)

    before_summary = before_sim.summary()
    after_summary = after_sim.summary()

    lines: list[str] = []
    lines.append("# society_lab seed 1043 deep analysis")
    lines.append("")
    lines.append("Compared v1.3 and v1.4 for seed 1043 over 80 years.")
    lines.append("")
    lines.append("## Summary Delta")
    lines.append("")
    summary_rows = []
    for key in (
        "final_population",
        "final_food_stock",
        "project_success_count",
        "project_failure_count",
        "birth_count",
        "death_count",
        "memory_shared_count",
        "shared_narrative_count",
        "narrative_divergence_count",
        "network_split_count",
        "avg_bias_blame",
    ):
        left = before_summary[key]
        right = after_summary[key]
        delta = right - left if isinstance(left, (int, float)) and isinstance(right, (int, float)) else "-"
        summary_rows.append([key, left, right, delta])
    lines.extend(md_table(["metric", "v1.3", "v1.4", "delta"], summary_rows))
    lines.append("")
    lines.append("## First Log Difference")
    lines.append("")
    lines.append(f"First differing log index: {first_index}")
    lines.append(f"First differing year: {first_year}")
    lines.append("")
    lines.append("```text")
    lines.append(f"v1.3: {compact_event(first_before) if first_before else '<end>'}")
    lines.append(f"v1.4: {compact_event(first_after) if first_after else '<end>'}")
    lines.append("```")
    lines.append("")
    lines.append("## Year 40 Support Difference")
    lines.append("")
    support_rows = changed_supports(before_sim, after_sim, first_year)
    if support_rows:
        lines.extend(md_table(["proposal", "v1.3 supporters", "v1.4 supporters", "added", "removed"], support_rows))
    else:
        lines.append("No support-set difference detected at the first-difference year.")
    lines.append("")
    lines.append("## Nearby Events")
    lines.append("")
    lines.append("### v1.3")
    lines.append("")
    lines.append("```text")
    lines.extend(event_neighborhood(before_sim, first_year))
    lines.append("```")
    lines.append("")
    lines.append("### v1.4")
    lines.append("")
    lines.append("```text")
    lines.extend(event_neighborhood(after_sim, first_year))
    lines.append("```")
    lines.append("")
    lines.append("## Milestone Timeline")
    lines.append("")
    snap_by_year_before = {snap.year: snap for snap in before_snaps}
    snap_by_year_after = {snap.year: snap for snap in after_snaps}
    rows = []
    for year in sorted(set(snap_by_year_before) | set(snap_by_year_after)):
        left = snap_by_year_before[year]
        right = snap_by_year_after[year]
        rows.append(
            [
                year,
                f"{left.population}->{right.population}",
                f"{fmt(left.food)}->{fmt(right.food)}",
                f"{left.failures}->{right.failures}",
                f"{left.births}->{right.births}",
                f"{left.memory_shared}->{right.memory_shared}",
                f"{left.narrative_divergence}->{right.narrative_divergence}",
                f"{left.avg_blame:.3f}->{right.avg_blame:.3f}",
                f"{right.action_nudges}/{right.support_nudges}",
            ]
        )
    lines.extend(
        md_table(
            ["year", "pop", "food", "fail", "birth", "memshare", "narr_div", "blame", "v1.4 nudges"],
            rows,
        )
    )
    lines.append("")
    lines.append("## First Projects After Divergence")
    lines.append("")
    lines.append("### v1.3")
    lines.append("")
    lines.append("```text")
    lines.extend(first_projects_after(before_sim, first_year))
    lines.append("```")
    lines.append("")
    lines.append("### v1.4")
    lines.append("")
    lines.append("```text")
    lines.extend(first_projects_after(after_sim, first_year))
    lines.append("```")
    lines.append("")
    lines.append("## Memory Sharing After First Difference")
    lines.append("")
    before_mem = memory_shares_by_event(before_sim, first_year)
    after_mem = memory_shares_by_event(after_sim, first_year)
    rows = []
    for name in sorted(set(before_mem) | set(after_mem), key=lambda key: (after_mem[key] - before_mem[key], key), reverse=True)[:15]:
        rows.append([name, before_mem[name], after_mem[name], after_mem[name] - before_mem[name]])
    lines.extend(md_table(["memory event", "v1.3 shares", "v1.4 shares", "delta"], rows))
    lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "Seed 1043 is not a simple copy of seed 1003. It also begins with a support-choice difference, "
        "but the first visible difference is late, at Year 40, not early. The final result is similar in shape "
        "to 1003: v1.4 ends with fewer people and more food."
    )
    lines.append("")
    lines.append(
        "The key question is whether the Year 40 support change enters a failure-memory network. "
        "The memory-sharing table helps check that: if the changed project memory expands differently after "
        "Year 40, then 1043 supports the same `support -> experience -> memory -> history` hypothesis. "
        "If not, 1043 is a different delayed demographic path."
    )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    REPORT_PATH.write_text(build_report(), encoding="utf-8")
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
