from __future__ import annotations

import csv
import importlib.util
import math
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
CSV_PATH = OUT_DIR / "pathway_validation_stats.csv"
REPORT_PATH = OUT_DIR / "pathway_validation_report.md"

SEEDS = range(1000, 1100)
YEARS = 80

SUMMARY_KEYS = (
    "final_population",
    "final_food_stock",
    "birth_count",
    "death_count",
    "proposal_count",
    "project_failure_count",
    "memory_shared_count",
    "shared_narrative_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
    "avg_bias_spiritual",
    "avg_bias_practical",
    "avg_bias_blame",
)


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def run_sim(module: ModuleType, seed: int) -> object:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim


def compact_event(entry: object | None) -> str:
    if entry is None:
        return "<end>"
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def first_log_diff(before: object, after: object) -> tuple[int, object | None, object | None] | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return index, before_entries[index], after_entries[index]
    if len(before_entries) != len(after_entries):
        left = None if len(before_entries) <= limit else before_entries[limit]
        right = None if len(after_entries) <= limit else after_entries[limit]
        return limit, left, right
    return None


def first_family(entry: object | None) -> str:
    if entry is None:
        return "none"
    if entry.event_type == "proposal_supported":
        return "support_choice"
    if entry.event_type == "proposal_made":
        return "proposal_choice"
    if entry.event_type == "memory_shared":
        return "memory"
    return "event"


def action_from_detail(detail: str, verb: str) -> str:
    match = re.search(rf"{verb}\s+(\w+)", detail)
    return match.group(1) if match else ""


def problem_from_detail(detail: str) -> str:
    match = re.search(r"for\s+(\w+)", detail)
    return match.group(1) if match else ""


def project_started_entries(sim: object, year: int) -> list[object]:
    return [
        entry
        for entry in sim.log.entries
        if entry.year == year and entry.event_type == "project_started"
    ]


def project_result_entries(sim: object, start_year: int) -> list[object]:
    return [
        entry
        for entry in sim.log.entries
        if entry.year >= start_year and entry.event_type in {"project_success", "project_failure"}
    ]


def project_key_from_project_detail(detail: str) -> tuple[str, str]:
    match = re.search(r"project_(?:started|success|failure):\s+(\w+)\s+for\s+(\w+)", detail)
    if not match:
        return "", ""
    return match.group(1), match.group(2)


def support_sets_at_year(sim: object, year: int) -> dict[str, set[str]]:
    supports: dict[str, set[str]] = defaultdict(set)
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type != "proposal_supported" or len(entry.persons) < 2:
            continue
        supporter, proposer = entry.persons[:2]
        action = action_from_detail(entry.detail, "supported")
        supports[f"{proposer}:{action}"].add(supporter)
    return dict(supports)


def summary_changed(before: object, after: object) -> bool:
    left = before.summary()
    right = after.summary()
    return any(left[key] != right[key] for key in SUMMARY_KEYS)


def delta(before: object, after: object, key: str) -> float:
    left = before.summary()[key]
    right = after.summary()[key]
    return float(right) - float(left)


def memory_event_counts(sim: object, start_year: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if entry.year < start_year or entry.event_type != "memory_shared":
            continue
        match = re.search(r"about\s+([^\s]+)\s+intensity=", entry.detail)
        if match:
            counts[match.group(1)] += 1
    return counts


def detect_first_diff_project(before: object, after: object, diff: tuple[int, object | None, object | None] | None) -> dict[str, Any]:
    if diff is None:
        return {
            "first_diff_year": "",
            "first_diff_family": "none",
            "first_diff_v13": "",
            "first_diff_v14": "",
            "participant_change": False,
            "changed_action": "",
            "changed_problem": "",
            "project_event": "",
            "project_memory_event": "",
            "supporters_v13": "",
            "supporters_v14": "",
            "supporter_added": "",
            "supporter_removed": "",
        }

    _, left, right = diff
    entry = right or left
    year = int(entry.year)
    family = first_family(entry)
    action = ""
    problem = ""
    project_event = ""
    project_memory_event = ""
    participant_change = False
    supporters_v13: int | str = ""
    supporters_v14: int | str = ""
    added = ""
    removed = ""

    if family == "support_choice" and right is not None and len(right.persons) >= 2:
        supporter, proposer = right.persons[:2]
        action = action_from_detail(right.detail, "supported")
        support_key = f"{proposer}:{action}"
        before_set = support_sets_at_year(before, year).get(support_key, set())
        after_set = support_sets_at_year(after, year).get(support_key, set())
        supporters_v13 = len(before_set)
        supporters_v14 = len(after_set)
        added = ",".join(sorted(after_set - before_set))
        removed = ",".join(sorted(before_set - after_set))

        for project in project_started_entries(after, year):
            p_action, p_problem = project_key_from_project_detail(project.detail)
            if p_action == action and support_key.split(":", 1)[0] in project.persons[:1]:
                problem = p_problem
                participant_change = set(project.persons[1:]) != {
                    p
                    for p in next(
                        (
                            before_project.persons[1:]
                            for before_project in project_started_entries(before, year)
                            if project_key_from_project_detail(before_project.detail) == (p_action, p_problem)
                        ),
                        [],
                    )
                }
                break
        if not problem:
            for project in project_started_entries(after, year):
                p_action, p_problem = project_key_from_project_detail(project.detail)
                if p_action == action:
                    problem = p_problem
                    participant_change = True
                    break

    elif family == "proposal_choice" and right is not None:
        action = action_from_detail(right.detail, "proposed")
        problem = problem_from_detail(right.detail)
        participant_change = bool(action)

    if action:
        for result in project_result_entries(after, year):
            p_action, p_problem = project_key_from_project_detail(result.detail)
            if p_action == action and (not problem or p_problem == problem):
                project_event = result.event_type
                project_memory_event = f"{result.event_type}:{p_action}"
                break

    return {
        "first_diff_year": year,
        "first_diff_family": family,
        "first_diff_v13": compact_event(left),
        "first_diff_v14": compact_event(right),
        "participant_change": participant_change,
        "changed_action": action,
        "changed_problem": problem,
        "project_event": project_event,
        "project_memory_event": project_memory_event,
        "supporters_v13": supporters_v13,
        "supporters_v14": supporters_v14,
        "supporter_added": added,
        "supporter_removed": removed,
    }


def analyze_seed(seed: int, v13: ModuleType, v14: ModuleType) -> dict[str, Any]:
    before = run_sim(v13, seed)
    after = run_sim(v14, seed)
    diff = first_log_diff(before, after)
    project = detect_first_diff_project(before, after, diff)
    changed = summary_changed(before, after)
    if changed:
        group = "summary_changed"
    elif diff is not None:
        group = "absorbed"
    else:
        group = "no_log_change"

    start_year = int(project["first_diff_year"]) if project["first_diff_year"] != "" else YEARS + 1
    before_mem = memory_event_counts(before, start_year)
    after_mem = memory_event_counts(after, start_year)
    project_memory_event = project["project_memory_event"]
    project_memory_shared_v13 = before_mem.get(project_memory_event, 0)
    project_memory_shared_v14 = after_mem.get(project_memory_event, 0)
    project_memory_diff = project_memory_shared_v14 - project_memory_shared_v13

    all_memory_diffs = {
        name: after_mem[name] - before_mem[name]
        for name in set(before_mem) | set(after_mem)
        if after_mem[name] - before_mem[name] != 0
    }
    max_memory_diff_abs = max((abs(value) for value in all_memory_diffs.values()), default=0)
    top_memory_diffs = "; ".join(
        f"{name}:{value:+d}"
        for name, value in sorted(all_memory_diffs.items(), key=lambda item: abs(item[1]), reverse=True)[:6]
    )

    summary = after.summary()
    return {
        "seed": seed,
        "group": group,
        **project,
        "action_nudge_count": summary.get("interpretation_action_nudge_count", 0),
        "support_nudge_count": summary.get("interpretation_support_nudge_count", 0),
        "project_memory_shared_v13": project_memory_shared_v13,
        "project_memory_shared_v14": project_memory_shared_v14,
        "project_memory_diff": project_memory_diff,
        "has_project_memory_share": project_memory_shared_v13 > 0 or project_memory_shared_v14 > 0,
        "max_memory_diff_abs_after_first_diff": max_memory_diff_abs,
        "top_memory_diffs_after_first_diff": top_memory_diffs,
        "diff_population": delta(before, after, "final_population"),
        "diff_food": delta(before, after, "final_food_stock"),
        "diff_birth": delta(before, after, "birth_count"),
        "diff_death": delta(before, after, "death_count"),
        "diff_memory_shared": delta(before, after, "memory_shared_count"),
        "diff_project_failure": delta(before, after, "project_failure_count"),
        "abs_population_diff": abs(delta(before, after, "final_population")),
        "abs_food_diff": abs(delta(before, after, "final_food_stock")),
        "abs_birth_diff": abs(delta(before, after, "birth_count")),
        "abs_memory_shared_diff": abs(delta(before, after, "memory_shared_count")),
    }


def corr(rows: list[dict[str, Any]], x_key: str, y_key: str) -> str:
    xs = [float(row[x_key]) for row in rows]
    ys = [float(row[y_key]) for row in rows]
    if len(xs) < 2:
        return "-"
    mean_x = statistics.mean(xs)
    mean_y = statistics.mean(ys)
    num = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    den_x = math.sqrt(sum((x - mean_x) ** 2 for x in xs))
    den_y = math.sqrt(sum((y - mean_y) ** 2 for y in ys))
    if den_x == 0 or den_y == 0:
        return "-"
    return f"{num / (den_x * den_y):.3f}"


def mean(rows: list[dict[str, Any]], key: str) -> str:
    if not rows:
        return "-"
    return f"{statistics.mean(float(row[key]) for row in rows):.2f}"


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def write_csv(rows: list[dict[str, Any]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def build_report(rows: list[dict[str, Any]]) -> str:
    summary_changed = [row for row in rows if row["group"] == "summary_changed"]
    absorbed = [row for row in rows if row["group"] == "absorbed"]
    no_log = [row for row in rows if row["group"] == "no_log_change"]
    participant_changed = [row for row in summary_changed if row["participant_change"]]
    participant_all = [row for row in rows if row["participant_change"]]
    participant_with_project_memory = [row for row in participant_all if row["has_project_memory_share"]]
    summary_with_project_memory = [row for row in summary_changed if row["has_project_memory_share"]]

    lines: list[str] = []
    lines.append("# pathway validation report")
    lines.append("")
    lines.append("Validation of whether v1.4 divergence can be read as a social pathway rather than only random stream drift.")
    lines.append("")
    lines.append("## Headline Counts")
    lines.append("")
    lines.extend(
        md_table(
            ["metric", "value"],
            [
                ["seeds", len(rows)],
                ["summary_changed", len(summary_changed)],
                ["absorbed", len(absorbed)],
                ["no_log_change", len(no_log)],
                [
                    "summary_changed with first_diff -> project participant change",
                    f"{len(participant_changed)}/{len(summary_changed)}",
                ],
                [
                    "participant-change seeds with that project memory shared",
                    f"{len(participant_with_project_memory)}/{len(participant_all)}",
                ],
                [
                    "summary_changed seeds with that project memory shared",
                    f"{len(summary_with_project_memory)}/{len(summary_changed)}",
                ],
            ],
        )
    )
    lines.append("")
    lines.append("## Group Memory Differences After First Diff")
    lines.append("")
    lines.extend(
        md_table(
            [
                "group",
                "count",
                "mean max memory diff",
                "mean project memory diff",
                "mean abs pop diff",
                "mean abs food diff",
                "mean abs birth diff",
                "mean abs memshare diff",
            ],
            [
                [
                    "summary_changed",
                    len(summary_changed),
                    mean(summary_changed, "max_memory_diff_abs_after_first_diff"),
                    mean(summary_changed, "project_memory_diff"),
                    mean(summary_changed, "abs_population_diff"),
                    mean(summary_changed, "abs_food_diff"),
                    mean(summary_changed, "abs_birth_diff"),
                    mean(summary_changed, "abs_memory_shared_diff"),
                ],
                [
                    "absorbed",
                    len(absorbed),
                    mean(absorbed, "max_memory_diff_abs_after_first_diff"),
                    mean(absorbed, "project_memory_diff"),
                    mean(absorbed, "abs_population_diff"),
                    mean(absorbed, "abs_food_diff"),
                    mean(absorbed, "abs_birth_diff"),
                    mean(absorbed, "abs_memory_shared_diff"),
                ],
                [
                    "no_log_change",
                    len(no_log),
                    mean(no_log, "max_memory_diff_abs_after_first_diff"),
                    mean(no_log, "project_memory_diff"),
                    mean(no_log, "abs_population_diff"),
                    mean(no_log, "abs_food_diff"),
                    mean(no_log, "abs_birth_diff"),
                    mean(no_log, "abs_memory_shared_diff"),
                ],
            ],
        )
    )
    lines.append("")
    lines.append("## Correlation: Memory Difference vs Final Difference")
    lines.append("")
    corr_rows = []
    for x_key in ("project_memory_diff", "max_memory_diff_abs_after_first_diff"):
        for y_key in ("abs_population_diff", "abs_food_diff", "abs_birth_diff", "abs_memory_shared_diff"):
            corr_rows.append([x_key, y_key, corr(summary_changed, x_key, y_key)])
    lines.extend(md_table(["x", "y", "Pearson r in summary_changed"], corr_rows))
    lines.append("")
    lines.append("## Repeated Path Patterns")
    lines.append("")
    pattern_counts = Counter(
        (
            row["first_diff_family"],
            row["changed_action"] or "-",
            "project_memory" if row["has_project_memory_share"] else "no_project_memory",
            "summary" if row["group"] == "summary_changed" else row["group"],
        )
        for row in rows
    )
    lines.extend(
        md_table(
            ["pattern", "count"],
            [
                [" / ".join(pattern), count]
                for pattern, count in pattern_counts.most_common(15)
            ],
        )
    )
    lines.append("")
    lines.append("## No-Log-Change Nudge Check")
    lines.append("")
    nudge_no_log = [row for row in no_log if int(row["action_nudge_count"]) > 0 or int(row["support_nudge_count"]) > 0]
    lines.append(
        f"All no-log-change seeds still have nudge opportunities in v1.4: {len(nudge_no_log)}/{len(no_log)}. "
        "Because first_diff is absent, those nudges did not alter actual logged choices."
    )
    lines.append("")
    lines.append("## Top Summary-Changed Seeds By Memory Difference")
    lines.append("")
    top_rows = sorted(summary_changed, key=lambda row: row["max_memory_diff_abs_after_first_diff"], reverse=True)[:20]
    lines.extend(
        md_table(
            [
                "seed",
                "first year",
                "family",
                "action",
                "participant",
                "project memory",
                "project mem diff",
                "max mem diff",
                "pop",
                "food",
                "birth",
                "memshare",
            ],
            [
                [
                    row["seed"],
                    row["first_diff_year"],
                    row["first_diff_family"],
                    row["changed_action"],
                    row["participant_change"],
                    row["project_memory_event"],
                    row["project_memory_diff"],
                    row["max_memory_diff_abs_after_first_diff"],
                    row["diff_population"],
                    row["diff_food"],
                    row["diff_birth"],
                    row["diff_memory_shared"],
                ]
                for row in top_rows
            ],
        )
    )
    lines.append("")
    lines.append("## Verdict")
    lines.append("")
    if len(participant_changed) >= len(summary_changed) * 0.75 and float(mean(absorbed, "max_memory_diff_abs_after_first_diff")) < float(mean(summary_changed, "max_memory_diff_abs_after_first_diff")):
        lines.append(
            "The pathway hypothesis is supported: most summary-changing seeds begin with a participant-changing choice, "
            "and absorbed seeds show much smaller post-diff memory differences."
        )
    else:
        lines.append(
            "The pathway hypothesis is only partially supported: some conditions match, but the distinction from random stream drift remains weak."
        )
    lines.append("")
    lines.append("Caution: memory events are logged as `project_failure:action` or `project_success:action`; problem type is not preserved in memory names. This report therefore validates action-level memory pathways, not exact action+problem pathways.")
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    v13 = load_module("society_lab_v1_3_validation", V13_PATH)
    v14 = load_module("society_lab_v1_4_validation", V14_PATH)
    rows = [analyze_seed(seed, v13, v14) for seed in SEEDS]
    write_csv(rows)
    REPORT_PATH.write_text(build_report(rows), encoding="utf-8")
    print(CSV_PATH)
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
