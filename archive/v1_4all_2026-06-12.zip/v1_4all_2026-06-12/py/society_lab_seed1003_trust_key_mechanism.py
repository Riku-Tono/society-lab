from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
HANA = "p019"
P000 = "p000"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14


def load_module(label: str, path: Path):
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_trust_key_mechanism", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    trust_mode: str


EXPERIMENTS = [
    Experiment("baseline", "baseline p019 key value 0.012", "baseline"),
    Experiment("KEY_ONLY", "p019 key value 0.0", "key_only"),
    Experiment("NO_KEY", "no p019 key on p000", "no_key"),
]


def is_target_memory(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    limit = min(len(left.log.entries), len(right.log.entries))
    for index in range(limit):
        baseline = compact_event(left.log.entries[index])
        experiment = compact_event(right.log.entries[index])
        if baseline != experiment:
            return {"index": index, "baseline": baseline, "experiment": experiment}
    if len(left.log.entries) != len(right.log.entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left.log.entries) <= limit else compact_event(left.log.entries[limit]),
            "experiment": "<none>" if len(right.log.entries) <= limit else compact_event(right.log.entries[limit]),
        }
    return None


def memory_summary(memory: object) -> dict[str, Any]:
    return {
        "event": memory.event,
        "year": memory.year,
        "intensity": round(memory.intensity, 4),
        "generation": memory.generation,
        "source": memory.source,
        "interpretation": memory.interpretation,
    }


class TrustKeyMechanismLab(v14.SocietyLab):
    def __init__(self, *args, exp: Experiment, **kwargs):
        super().__init__(*args, **kwargs)
        self.exp = exp
        self.edge_audit: dict[str, Any] | None = None
        self.death_memory_grants: list[dict[str, Any]] = []
        self.p000_years: list[dict[str, Any]] = []
        self.key_checks: list[dict[str, Any]] = []

    def step(self) -> None:
        super().step()
        if 20 <= self.year <= 30:
            self._capture_p000_year()

    def _capture_p000_year(self) -> None:
        p = self._person(P000)
        strongest = p.strongest_memory()
        self.p000_years.append(
            {
                "year": self.year,
                "alive": p.alive,
                "age": p.age,
                "action": p.action,
                "trust_has_p019": HANA in p.trust,
                "trust_p019": p.trust.get(HANA),
                "memory_count": len(p.memories),
                "strongest_memory": None if strongest is None else memory_summary(strongest),
                "memories": [memory_summary(memory) for memory in p.memories],
            }
        )

    def _adjust_trust(self, person, other_id: str, delta: float) -> None:
        if (
            self.year == 21
            and person.id == P000
            and other_id == HANA
            and self.edge_audit is not None
            and self.edge_audit.get("awaiting_trust_adjust")
        ):
            self.edge_audit["trust_before_has_key"] = HANA in person.trust
            self.edge_audit["trust_before_value"] = person.trust.get(HANA)
            if self.exp.trust_mode == "no_key":
                self.edge_audit["trust_action"] = "no_key"
            elif self.exp.trust_mode == "key_only":
                person.trust[HANA] = 0.0
                self.edge_audit["trust_action"] = "key_only_zero"
            else:
                person.trust[HANA] = self._clamp(person.trust.get(HANA, 0.0) + 0.012)
                self.edge_audit["trust_action"] = "baseline_delta"
            self.edge_audit["trust_after_has_key"] = HANA in person.trust
            self.edge_audit["trust_after_value"] = person.trust.get(HANA)
            self.edge_audit["awaiting_trust_adjust"] = False
            return
        super()._adjust_trust(person, other_id, delta)

    def _dialogue_phase(self) -> None:
        for speaker in self.alive_people:
            memory = speaker.strongest_memory()
            if memory is None:
                continue
            share_probability = (
                0.05
                + memory.intensity * 0.18
                + speaker.fear * 0.15
                + (0.12 if speaker.action == "share_memory" else 0.0)
            )
            if memory.generation >= 4:
                share_probability *= 0.55
            if self.rng.random() > min(0.55, share_probability):
                continue
            listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
            listeners = [
                self._person(person_id)
                for person_id in speaker.top_trusted(listener_count)
                if self._person(person_id).alive
            ]
            for listener in listeners:
                target_edge = (
                    self.year == 21
                    and speaker.id == HANA
                    and listener.id == P000
                    and is_target_memory(memory)
                )
                if target_edge:
                    self.edge_audit = {
                        "year": self.year,
                        "speaker": speaker.id,
                        "listener": listener.id,
                        "awaiting_trust_adjust": True,
                    }
                distorted = self._distort_memory(memory, speaker, listener)
                listener.remember(distorted)
                self.log.record(
                    self.year,
                    "memory_shared",
                    [speaker.id, listener.id],
                    (
                        f"{speaker.name} told {listener.name} about "
                        f"{distorted.event} intensity={distorted.intensity:.2f} "
                        f"generation={distorted.generation}"
                    ),
                )
                self._adjust_trust(listener, speaker.id, 0.012)

    def _update_phase(self) -> None:
        for person in self.alive_people:
            person.age += 1
            person.voice_weight = self._clamp(person.voice_weight * 0.97)
            person.fear = self._clamp(person.fear * 0.86)
            if person.hunger > 0.75:
                person.health = self._clamp(person.health - 0.045 * person.hunger)
            else:
                person.health = self._clamp(person.health + 0.02)
            person.hunger = self._clamp(person.hunger * 0.92)

            for memory in person.memories:
                memory.decay()
            person.memories = [
                memory for memory in person.memories
                if memory.intensity >= 0.05
            ]

            age_risk = max(0.0, (person.age - 76) / 95.0)
            health_risk = max(0.0, 0.25 - person.health) * 0.22
            if self.rng.random() < age_risk + health_risk:
                person.alive = False
                self.log.record(
                    self.year,
                    "death",
                    [person.id],
                    f"{person.name} died age={person.age} health={person.health:.2f}",
                )
                recipients = []
                for other in self.alive_people:
                    has_key = person.id in other.trust
                    if 20 <= self.year <= 30 and (person.id == HANA or other.id == P000):
                        self.key_checks.append(
                            {
                                "year": self.year,
                                "dead_person": person.id,
                                "other": other.id,
                                "has_key": has_key,
                                "trust": other.trust.get(person.id),
                            }
                        )
                    if has_key:
                        memory = self._make_memory(
                            other,
                            event="death",
                            intensity=0.35 + other.trust[person.id] * 0.45,
                        )
                        other.remember(memory)
                        recipients.append(
                            {
                                "id": other.id,
                                "name": other.name,
                                "trust": round(other.trust[person.id], 4),
                                "memory": memory_summary(memory),
                            }
                        )
                if 20 <= self.year <= 30:
                    self.death_memory_grants.append(
                        {
                            "year": self.year,
                            "dead_person": person.id,
                            "dead_name": person.name,
                            "recipients": recipients,
                        }
                    )


def run(exp: Experiment) -> TrustKeyMechanismLab:
    sim = TrustKeyMechanismLab(seed=SEED, verbose=False, exp=exp)
    sim.run(YEARS)
    return sim


baseline = run(EXPERIMENTS[0])
baseline_summary = selected_summary(baseline)
rows = []
details = {
    "seed": SEED,
    "years": YEARS,
    "baseline_summary": baseline_summary,
    "experiments": {},
}

for exp in EXPERIMENTS:
    sim = baseline if exp.code == "baseline" else run(exp)
    summary = selected_summary(sim)
    first_diff = None if exp.code == "baseline" else first_log_difference(baseline, sim)
    p019_death_grants = [
        grant for grant in sim.death_memory_grants
        if grant["dead_person"] == HANA
    ]
    p000_received_p019_death = any(
        recipient["id"] == P000
        for grant in p019_death_grants
        for recipient in grant["recipients"]
    )
    row = {
        "experiment": exp.code,
        "label": exp.label,
        **summary,
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "p019_death_year": "" if not p019_death_grants else p019_death_grants[0]["year"],
        "p000_received_p019_death": p000_received_p019_death,
        "p019_death_recipient_count": 0 if not p019_death_grants else len(p019_death_grants[0]["recipients"]),
        "p000_p019_trust_after_edge": None if sim.edge_audit is None else sim.edge_audit.get("trust_after_value"),
        "p000_has_p019_key_after_edge": None if sim.edge_audit is None else sim.edge_audit.get("trust_after_has_key"),
    }
    rows.append(row)
    details["experiments"][exp.code] = {
        "label": exp.label,
        "summary": summary,
        "first_diff_vs_baseline": first_diff,
        "edge_audit": sim.edge_audit,
        "p000_years": sim.p000_years,
        "death_memory_grants_Y20_Y30": sim.death_memory_grants,
        "key_checks_Y20_Y30": sim.key_checks,
        "p019_death_grants": p019_death_grants,
    }

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_path = OUT_DIR / "society_lab_seed1003_trust_key_mechanism.py"
report_path = OUT_DIR / "society_lab_seed1003_trust_key_mechanism_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_trust_key_mechanism_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_trust_key_mechanism_details.json"

script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

report = [
    "# seed1003 trust key mechanism",
    "",
    "## Purpose",
    "",
    "This pass asks which Y21-Y28 process changes when `p000.trust` contains a `p019` key.",
    "",
    "## Results",
    "",
    "| exp | final pop | births | failures | memory shares | first diff | p019 death | p000 got p019 death memory | recipients | p019 key after edge | trust value |",
    "|---|---:|---:|---:|---:|---:|---:|---|---:|---|---:|",
]
for row in rows:
    report.append(
        f"| {row['experiment']} | {row['final_population']} | {row['birth_count']} | "
        f"{row['project_failure_count']} | {row['memory_shared_count']} | {row['first_diff_index']} | "
        f"{row['p019_death_year']} | {row['p000_received_p019_death']} | "
        f"{row['p019_death_recipient_count']} | {row['p000_has_p019_key_after_edge']} | "
        f"{row['p000_p019_trust_after_edge']} |"
    )

for code in ["baseline", "KEY_ONLY", "NO_KEY"]:
    exp = details["experiments"][code]
    report.extend(["", f"## {code}: p019 death grants", ""])
    grants = exp["p019_death_grants"]
    if not grants:
        report.append("- p019 death not recorded in Y20-Y30 window")
        continue
    for grant in grants:
        report.append(f"- Y{grant['year']} dead={grant['dead_person']} recipients={len(grant['recipients'])}")
        for recipient in grant["recipients"]:
            report.append(
                f"  - {recipient['id']} {recipient['name']} trust={recipient['trust']} "
                f"memory_intensity={recipient['memory']['intensity']} "
                f"interpretation={recipient['memory']['interpretation']}"
            )

report.extend(
    [
        "",
        "## Cautious Reading",
        "",
        "- The key difference appears at p019's death in Year 28.",
        "- Baseline and KEY_ONLY give p000 a death memory from p019 because `p019 in p000.trust` is true.",
        "- NO_KEY does not give p000 that death memory because the key is absent.",
        "- This explains why the trust value magnitude did not matter: even value 0 creates the key and passes the membership test.",
        "- The first visible log difference occurs around Year 28, consistent with this delayed death-memory mechanism.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
