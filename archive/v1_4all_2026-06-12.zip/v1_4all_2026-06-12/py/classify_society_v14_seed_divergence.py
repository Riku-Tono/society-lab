from __future__ import annotations

import importlib.util
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
REPORT_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs\society_lab_v1_4_seed_1000_1099_classification.md"
)

YEARS = 80
SEEDS = range(1000, 1100)

SUMMARY_KEYS = (
    "final_population",
    "final_food_stock",
    "avg_fear",
    "avg_hunger",
    "proposal_count",
    "project_success_count",
    "project_failure_count",
    "shared_narrative_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
    "avg_bias_spiritual",
    "avg_bias_practical",
    "avg_bias_blame",
    "death_count",
    "birth_count",
    "memory_shared_count",
    "behavior_copied_count",
)


@dataclass(frozen=True)
class SeedResult:
    seed: int
    v13: dict[str, object]
    v14: dict[str, object]
    changed_keys: tuple[str, ...]
    action_nudges: int
    support_nudges: int
    first_log_diff_year: int | None

    @property
    def summary_changed(self) -> bool:
        return bool(self.changed_keys)

    @property
    def log_changed(self) -> bool:
        return self.first_log_diff_year is not None

    def delta(self, key: str) -> float:
        left = self.v13.get(key, 0)
        right = self.v14.get(key, 0)
        if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
            return 0.0
        return float(right) - float(left)


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def run_sim(module: ModuleType, seed: int) -> object:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim


def compact_event(entry: object) -> str:
    persons = ",".join(entry.persons)
    return f"Y{entry.year:02d} {entry.event_type} [{persons}] {entry.detail}"


def first_log_diff_year(before: object, after: object) -> int | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return int(after_entries[index].year)
    if len(before_entries) != len(after_entries):
        if len(before_entries) > limit:
            return int(before_entries[limit].year)
        return int(after_entries[limit].year)
    return None


def collect_results() -> list[SeedResult]:
    v13 = load_module("society_lab_v1_3_classification", V13_PATH)
    v14 = load_module("society_lab_v1_4_classification", V14_PATH)

    results: list[SeedResult] = []
    for seed in SEEDS:
        before_sim = run_sim(v13, seed)
        after_sim = run_sim(v14, seed)
        before = before_sim.summary()
        after = after_sim.summary()
        changed_keys = tuple(
            key
            for key in SUMMARY_KEYS
            if key in before and key in after and before[key] != after[key]
        )
        results.append(
            SeedResult(
                seed=seed,
                v13=before,
                v14=after,
                changed_keys=changed_keys,
                action_nudges=int(after.get("interpretation_action_nudge_count", 0)),
                support_nudges=int(after.get("interpretation_support_nudge_count", 0)),
                first_log_diff_year=first_log_diff_year(before_sim, after_sim),
            )
        )
    return results


def category_labels(result: SeedResult) -> list[str]:
    labels: list[str] = []

    if abs(result.delta("final_population")) >= 5:
        labels.append("population_shift")
    if abs(result.delta("final_food_stock")) >= 30:
        labels.append("food_shift")
    if abs(result.delta("project_failure_count")) >= 2:
        labels.append("failure_shift")
    if abs(result.delta("memory_shared_count")) >= 30:
        labels.append("memory_share_shift")
    if abs(result.delta("narrative_divergence_count")) >= 5:
        labels.append("narrative_shift")
    if abs(result.delta("avg_bias_blame")) >= 0.02:
        labels.append("blame_bias_shift")

    if result.summary_changed and not labels:
        labels.append("minor_summary_shift")
    if not result.summary_changed and result.log_changed:
        labels.append("log_changed_summary_same")
    if not result.summary_changed and not result.log_changed:
        labels.append("nudge_only_no_path_change")

    return labels


def seed1003_like_score(result: SeedResult, reference: SeedResult) -> float:
    keys = (
        "final_population",
        "final_food_stock",
        "project_failure_count",
        "birth_count",
        "memory_shared_count",
        "avg_bias_blame",
    )
    score = 0.0
    for key in keys:
        ref_delta = reference.delta(key)
        cur_delta = result.delta(key)
        if ref_delta == 0:
            continue
        same_direction = (ref_delta > 0 and cur_delta > 0) or (ref_delta < 0 and cur_delta < 0)
        if same_direction:
            score += 1.0
        scale = max(abs(ref_delta), 1.0)
        score += max(0.0, 1.0 - abs(cur_delta - ref_delta) / scale)
    return round(score, 2)


def md_table(headers: list[str], rows: list[list[object]]) -> list[str]:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def fmt_delta(value: float) -> str:
    if math.isclose(value, round(value)):
        return f"{int(value):+d}"
    return f"{value:+.3f}"


def build_report(results: list[SeedResult]) -> str:
    changed = [result for result in results if result.summary_changed]
    summary_unchanged = [result for result in results if not result.summary_changed]
    log_changed = [result for result in results if result.log_changed]
    log_changed_summary_same = [
        result for result in results if result.log_changed and not result.summary_changed
    ]
    no_path_change = [
        result for result in results if not result.log_changed and not result.summary_changed
    ]
    reference = next(result for result in results if result.seed == 1003)

    category_counts: dict[str, int] = {}
    for result in results:
        for label in category_labels(result):
            category_counts[label] = category_counts.get(label, 0) + 1

    changed_ranked = sorted(
        changed,
        key=lambda result: (
            abs(result.delta("final_population")),
            abs(result.delta("final_food_stock")),
            abs(result.delta("project_failure_count")),
        ),
        reverse=True,
    )
    like_ranked = sorted(
        changed,
        key=lambda result: seed1003_like_score(result, reference),
        reverse=True,
    )

    lines: list[str] = []
    lines.append("# society_lab v1.4 seed 1000-1099 classification")
    lines.append("")
    lines.append("Compared versions:")
    lines.append("")
    lines.append("- v1.3: interpretation is observed only")
    lines.append("- v1.4: interpretation weakly nudges project choice and proposal support")
    lines.append("")
    lines.append(f"Run length: {YEARS} years")
    lines.append(f"Seed range: {min(SEEDS)}-{max(SEEDS)}")
    lines.append("")
    lines.append("## Headline")
    lines.append("")
    lines.append(
        f"Out of {len(results)} seeds, {len(changed)} produced summary-level differences "
        f"between v1.3 and v1.4. {len(log_changed)} seeds changed their event log. "
        f"{len(log_changed_summary_same)} seeds changed internally but returned to the same "
        f"final summary. {len(no_path_change)} seeds had interpretation nudges inside v1.4, "
        "but those nudges did not change the event path."
    )
    lines.append("")
    lines.append(
        "So seed 1003 was not unique in the broader range. It was only the one changed seed "
        "inside the earlier small check set of 42, 1000, 1001, 1002, and 1003."
    )
    lines.append("")
    lines.append("## Category Counts")
    lines.append("")
    category_rows = [
        [label, category_counts[label]]
        for label in sorted(category_counts)
    ]
    lines.extend(md_table(["category", "count"], category_rows))
    lines.append("")
    lines.append("Category thresholds:")
    lines.append("")
    lines.append("- `population_shift`: final population changed by 5 or more")
    lines.append("- `food_shift`: final food stock changed by 30 or more")
    lines.append("- `failure_shift`: project failures changed by 2 or more")
    lines.append("- `memory_share_shift`: memory shares changed by 30 or more")
    lines.append("- `narrative_shift`: narrative divergences changed by 5 or more")
    lines.append("- `blame_bias_shift`: average blame bias changed by 0.02 or more")
    lines.append("")
    lines.append("## Largest Outcome Shifts")
    lines.append("")
    rows = []
    for result in changed_ranked[:15]:
        rows.append(
            [
                result.seed,
                fmt_delta(result.delta("final_population")),
                fmt_delta(result.delta("final_food_stock")),
                fmt_delta(result.delta("project_failure_count")),
                fmt_delta(result.delta("birth_count")),
                fmt_delta(result.delta("memory_shared_count")),
                result.first_log_diff_year or "-",
                ", ".join(category_labels(result)),
            ]
        )
    lines.extend(
        md_table(
            ["seed", "pop", "food", "fail", "birth", "memshare", "first log diff", "labels"],
            rows,
        )
    )
    lines.append("")
    lines.append("## Seeds Most Similar To 1003")
    lines.append("")
    rows = []
    for result in like_ranked[:12]:
        rows.append(
            [
                result.seed,
                seed1003_like_score(result, reference),
                fmt_delta(result.delta("final_population")),
                fmt_delta(result.delta("final_food_stock")),
                fmt_delta(result.delta("project_failure_count")),
                fmt_delta(result.delta("birth_count")),
                fmt_delta(result.delta("memory_shared_count")),
                fmt_delta(result.delta("avg_bias_blame")),
                result.first_log_diff_year or "-",
            ]
        )
    lines.extend(
        md_table(
            ["seed", "1003-like", "pop", "food", "fail", "birth", "memshare", "blame", "first log diff"],
            rows,
        )
    )
    lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "The broad scan changes the interpretation. The useful question is no longer "
        "`why did only seed 1003 change?` It is `why do some nudges change the path while "
        "other nudges are absorbed?`"
    )
    lines.append("")
    lines.append(
        "Seed 1003 remains valuable because its first divergence is readable: a Year 14 "
        "`store_food` support difference creates a concrete failure-memory chain. But it "
        "should now be treated as one representative case, not as the only evidence."
    )
    lines.append("")
    lines.append(
        "The next best step is to pick two or three representative changed seeds, then compare "
        "their first divergence points against seed 1003. That will show whether the same "
        "mechanism repeats or whether v1.4 creates several different branching mechanisms."
    )
    lines.append("")
    lines.append("Recommended representatives:")
    lines.append("")
    lines.append("- seed 1003: readable failure-memory chain")
    lines.append("- seed 1012: extreme nudge volume and many project failures")
    lines.append("- seed 1024 or 1043: large population swing")
    lines.append("- one unchanged-but-nudged seed such as 1002: absorption case")
    lines.append("")
    lines.append("## Changed Seeds")
    lines.append("")
    rows = []
    for result in changed:
        rows.append(
            [
                result.seed,
                len(result.changed_keys),
                f"{result.action_nudges}/{result.support_nudges}",
                fmt_delta(result.delta("final_population")),
                fmt_delta(result.delta("final_food_stock")),
                fmt_delta(result.delta("project_failure_count")),
                fmt_delta(result.delta("memory_shared_count")),
                result.first_log_diff_year or "-",
            ]
        )
    lines.extend(
        md_table(
            ["seed", "changed keys", "nudges", "pop", "food", "fail", "memshare", "first log diff"],
            rows,
        )
    )
    lines.append("")
    lines.append("## Summary-Unchanged Seeds")
    lines.append("")
    rows = [
        [
            result.seed,
            f"{result.action_nudges}/{result.support_nudges}",
            result.first_log_diff_year or "-",
            ", ".join(category_labels(result)),
        ]
        for result in summary_unchanged
    ]
    lines.extend(md_table(["seed", "v1.4 action/support nudges", "first log diff", "labels"], rows))
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    results = collect_results()
    report = build_report(results)
    REPORT_PATH.write_text(report, encoding="utf-8")
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
