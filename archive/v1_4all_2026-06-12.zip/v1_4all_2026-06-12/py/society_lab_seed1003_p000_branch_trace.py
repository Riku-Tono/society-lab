from __future__ import annotations

import csv
import importlib.util
import json
import math
import sys
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from types import ModuleType
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
PREV_JSON = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs\seed1003_butterfly_experiments.json"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
P000 = "p000"
HANA = "p019"
ORUN = "p004"
SHION = "p011"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14
TRACE_YEARS = {14, 21, 28, 40}


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_p000_trace", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    mode: str = "baseline"
    sender: str | None = None
    equivalent_listener: str | None = None
    late_year: int | None = None


EXPERIMENTS = [
    Experiment("baseline", "baseline v1.4"),
    Experiment("F", "no_hana_to_p000", mode="block_hana_to_p000"),
    Experiment("G", "only_hana_to_p000", mode="only_hana_to_p000"),
    Experiment("H", "only_hana_to_p004", mode="only_hana_to_p004"),
    Experiment("I", "randomized_hana_listener_same_year", mode="randomize_hana_listener"),
    Experiment("J_p004", "other_sender_to_p000: p004", mode="other_sender_to_p000", sender="p004"),
    Experiment("J_p005", "other_sender_to_p000: p005", mode="other_sender_to_p000", sender="p005"),
    Experiment("J_p020", "other_sender_to_p000: p020", mode="other_sender_to_p000", sender="p020"),
    Experiment("K", "hana_to_p000_but_no_p000_share", mode="p000_no_target_share"),
    Experiment("L", "hana_to_p000_but_no_behavior_effect", mode="p000_no_behavior_effect"),
    # M is filled after network-equivalent selection.
    Experiment("N_23", "p000_receives_late: Y23", mode="p000_receives_late", late_year=23),
    Experiment("N_25", "p000_receives_late: Y25", mode="p000_receives_late", late_year=25),
    Experiment("N_28", "p000_receives_late: Y28", mode="p000_receives_late", late_year=28),
]


def is_target(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    left_entries = left.log.entries
    right_entries = right.log.entries
    limit = min(len(left_entries), len(right_entries))
    for index in range(limit):
        ltext = compact_event(left_entries[index])
        rtext = compact_event(right_entries[index])
        if ltext != rtext:
            return {"index": index, "baseline": ltext, "experiment": rtext}
    if len(left_entries) != len(right_entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left_entries) <= limit else compact_event(left_entries[limit]),
            "experiment": "<none>" if len(right_entries) <= limit else compact_event(right_entries[limit]),
        }
    return None


def clone_memory(memory: object, source: str, generation: int | None = None):
    cloned = v14.Memory(
        event=memory.event,
        year=memory.year,
        intensity=memory.intensity,
        decay_rate=memory.decay_rate,
        source=source,
        generation=memory.generation if generation is None else generation,
        interpretation=memory.interpretation,
    )
    for attr in ("branch_id", "branch_parent", "branch_root"):
        if hasattr(memory, attr):
            setattr(cloned, attr, getattr(memory, attr))
    return cloned


def annotate_memory(memory: object, branch_id: str, parent: str | None, root: str = "p000") -> object:
    setattr(memory, "branch_id", branch_id)
    setattr(memory, "branch_parent", parent)
    setattr(memory, "branch_root", root)
    return memory


def make_lab_class(exp: Experiment):
    class P000TraceLab(v14.SocietyLab):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.branch_edges: list[dict[str, Any]] = []
            self.blocked_original_p000_memory = None
            self.pending_late_p000_memory = None
            self.p000_received_target = False
            self.network_snapshots: dict[int, dict[str, Any]] = {}
            self.person_years: list[dict[str, Any]] = []
            self._branch_counter = 0

        def step(self) -> None:
            super().step()
            self._capture_person_year()
            if self.year in TRACE_YEARS:
                self.network_snapshots[self.year] = network_metrics(self, P000)
            if exp.mode == "p000_receives_late" and self.year == exp.late_year:
                self._inject_late_p000_memory()

        def _capture_person_year(self) -> None:
            person = self._person(P000)
            if not person.alive:
                alive = False
            else:
                alive = True
            self.person_years.append(
                {
                    "year": self.year,
                    "alive": alive,
                    "age": person.age,
                    "health": round(person.health, 4),
                    "hunger": round(person.hunger, 4),
                    "fear": round(person.fear, 4),
                    "action": person.action,
                    "voice_weight": round(person.voice_weight, 4),
                    "bias_spiritual": round(person.interpretation_bias.get("spiritual", 0.0), 4),
                    "bias_practical": round(person.interpretation_bias.get("practical", 0.0), 4),
                    "bias_blame": round(person.interpretation_bias.get("blame", 0.0), 4),
                    "memory_count": len(person.memories),
                }
            )

        def _support_proposals(self, problem, proposals):
            if not proposals:
                return
            for person in self.alive_people:
                if person.age < 10:
                    continue
                scored = []
                for proposal in proposals:
                    proposer = self._person(proposal.proposer_id)
                    trust = person.trust.get(proposer.id, 0.15)
                    score = (
                        trust * 0.43
                        + proposer.charisma * 0.24
                        + proposer.voice_weight * 0.08
                        + self._project_relevance(problem, proposal, proposer) * 0.20
                        + person.fear * 0.10
                        + self.rng.uniform(-0.08, 0.08)
                    )
                    if exp.mode == "p000_no_behavior_effect" and person.id == P000:
                        support_nudge = self._interpretation_support_nudge_ignore_target(
                            person, problem, proposal, proposer
                        )
                    else:
                        support_nudge = self._interpretation_support_nudge(
                            person, problem, proposal, proposer
                        )
                    score += support_nudge
                    scored.append((score, proposal, support_nudge))
                score, proposal, support_nudge = max(scored, key=lambda item: item[0])
                if support_nudge != 0.0:
                    self.interpretation_support_nudge_count += 1
                support_chance = self._clamp(0.12 + score * 0.42 + person.fear * 0.15)
                if self.rng.random() > support_chance:
                    continue
                proposal.support_ids.append(person.id)
                self.proposal_support_by_person[proposal.proposer_id] = (
                    self.proposal_support_by_person.get(proposal.proposer_id, 0) + 1
                )
                self.log.record(
                    self.year,
                    "proposal_supported",
                    [person.id, proposal.proposer_id],
                    f"{person.name} supported {proposal.action}",
                )

        def _interpretation_support_nudge_ignore_target(self, person, problem, proposal, proposer):
            original = person.memories
            person.memories = [
                memory for memory in original
                if not (is_target(memory) and getattr(memory, "branch_root", None) == P000)
            ]
            try:
                return self._interpretation_support_nudge(person, problem, proposal, proposer)
            finally:
                person.memories = original

        def _choose_project_action(self, problem, proposer, used_actions):
            if exp.mode == "p000_no_behavior_effect" and proposer.id == P000:
                original = proposer.memories
                proposer.memories = [
                    memory for memory in original
                    if not (is_target(memory) and getattr(memory, "branch_root", None) == P000)
                ]
                try:
                    return super()._choose_project_action(problem, proposer, used_actions)
                finally:
                    proposer.memories = original
            return super()._choose_project_action(problem, proposer, used_actions)

        def _dialogue_phase(self):
            for speaker in self.alive_people:
                memory = speaker.strongest_memory()
                if memory is None:
                    continue
                share_probability = (
                    0.05
                    + memory.intensity * 0.18
                    + speaker.fear * 0.15
                    + (0.12 if speaker.action == "share_memory" else 0.0)
                )
                if memory.generation >= 4:
                    share_probability *= 0.55
                if self.rng.random() > min(0.55, share_probability):
                    continue
                listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
                listeners = [
                    self._person(person_id)
                    for person_id in speaker.top_trusted(listener_count)
                    if self._person(person_id).alive
                ]
                for listener in listeners:
                    blocked = False
                    original_listener = listener
                    if is_target(memory):
                        if (
                            exp.mode == "network_equivalent_non_p000"
                            and speaker.id == HANA
                            and listener.id == P000
                            and exp.equivalent_listener is not None
                        ):
                            listener = self._person(exp.equivalent_listener)
                        if exp.mode == "randomize_hana_listener" and speaker.id == HANA:
                            candidates = [
                                person for person in self.alive_people
                                if person.id != speaker.id
                            ]
                            if candidates:
                                listener = self.rng.choice(candidates)
                        elif exp.mode == "only_hana_to_p000" and speaker.id == HANA and listener.id != P000:
                            blocked = True
                        elif exp.mode == "only_hana_to_p004" and speaker.id == HANA and listener.id != ORUN:
                            blocked = True
                        elif (
                            exp.mode == "network_equivalent_non_p000"
                            and speaker.id == HANA
                            and listener.id != exp.equivalent_listener
                        ):
                            blocked = True
                        elif exp.mode in {"block_hana_to_p000", "other_sender_to_p000", "p000_receives_late"} and speaker.id == HANA and listener.id == P000:
                            blocked = True

                    if (
                        exp.mode == "p000_no_target_share"
                        and speaker.id == P000
                        and is_target(memory)
                        and getattr(memory, "branch_root", None) == P000
                    ):
                        blocked = True

                    distorted = self._distort_memory(memory, speaker, listener)
                    if is_target(memory) and speaker.id == HANA and original_listener.id == P000:
                        self.blocked_original_p000_memory = clone_memory(distorted, source=HANA)
                        self.pending_late_p000_memory = clone_memory(distorted, source=HANA)
                        if exp.mode == "other_sender_to_p000":
                            self._inject_other_sender_to_p000(distorted)
                        elif exp.mode not in {"block_hana_to_p000", "p000_receives_late"}:
                            annotate_memory(distorted, self._next_branch_id(), None)

                    if blocked:
                        continue
                    listener.remember(distorted)
                    self._record_branch_if_needed(distorted, speaker, listener)
                    self.log.record(
                        self.year,
                        "memory_shared",
                        [speaker.id, listener.id],
                        (
                            f"{speaker.name} told {listener.name} about "
                            f"{distorted.event} intensity={distorted.intensity:.2f} "
                            f"generation={distorted.generation}"
                        ),
                    )
                    self._adjust_trust(listener, speaker.id, 0.012)

        def _next_branch_id(self) -> str:
            self._branch_counter += 1
            return f"b{self._branch_counter:03d}"

        def _record_branch_if_needed(self, memory, speaker, listener) -> None:
            if not (is_target(memory) and getattr(memory, "branch_root", None) == P000):
                return
            if listener.id == P000:
                self.p000_received_target = True
            parent = getattr(memory, "branch_parent", None)
            self.branch_edges.append(
                {
                    "year": self.year,
                    "speaker": speaker.id,
                    "speaker_name": speaker.name,
                    "listener": listener.id,
                    "listener_name": listener.name,
                    "generation": memory.generation,
                    "intensity": round(memory.intensity, 4),
                    "interpretation": memory.interpretation,
                    "source": memory.source,
                    "branch_id": getattr(memory, "branch_id", None),
                    "parent": parent,
                }
            )

        def _inject_other_sender_to_p000(self, blocked_memory) -> None:
            if self.p000_received_target:
                return
            sender_id = exp.sender or ORUN
            sender = self._person(sender_id)
            listener = self._person(P000)
            injected = clone_memory(blocked_memory, source=sender_id)
            annotate_memory(injected, self._next_branch_id(), None)
            listener.remember(injected)
            self.p000_received_target = True
            self._record_branch_if_needed(injected, sender, listener)
            self.log.record(
                self.year,
                "memory_shared",
                [sender.id, listener.id],
                (
                    f"{sender.name} told {listener.name} about "
                    f"{injected.event} intensity={injected.intensity:.2f} "
                    f"generation={injected.generation}"
                ),
            )
            self._adjust_trust(listener, sender.id, 0.012)

        def _inject_late_p000_memory(self) -> None:
            if self.p000_received_target:
                return
            base = self.pending_late_p000_memory or self.blocked_original_p000_memory
            if base is None:
                return
            sender = self._person(HANA)
            listener = self._person(P000)
            if not listener.alive:
                return
            injected = clone_memory(base, source=HANA)
            annotate_memory(injected, self._next_branch_id(), None)
            listener.remember(injected)
            self.p000_received_target = True
            self._record_branch_if_needed(injected, sender, listener)
            self.log.record(
                self.year,
                "memory_shared",
                [sender.id, listener.id],
                (
                    f"{sender.name} told {listener.name} about "
                    f"{injected.event} intensity={injected.intensity:.2f} "
                    f"generation={injected.generation}"
                ),
            )
            self._adjust_trust(listener, sender.id, 0.012)

        def _distort_memory(self, memory, speaker, listener):
            distorted = super()._distort_memory(memory, speaker, listener)
            if is_target(memory) and getattr(memory, "branch_root", None) == P000:
                annotate_memory(
                    distorted,
                    self._next_branch_id(),
                    getattr(memory, "branch_id", None),
                )
            return distorted

    return P000TraceLab


def run(exp: Experiment) -> object:
    lab_cls = make_lab_class(exp)
    sim = lab_cls(seed=SEED, verbose=False)
    sim.network_snapshots[0] = network_metrics(sim, P000)
    sim.run(YEARS)
    return sim


def person_label(sim: object, person_id: str) -> str:
    try:
        p = sim._person(person_id)
        return f"{person_id} {p.name}"
    except Exception:
        return person_id


def trust_graph(sim: object, alive_only: bool = True) -> tuple[list[str], dict[str, list[tuple[str, float]]]]:
    people = sim.alive_people if alive_only else sim.people
    ids = {p.id for p in people}
    graph: dict[str, list[tuple[str, float]]] = {p.id: [] for p in people}
    for person in people:
        for target_id, weight in person.trust.items():
            if target_id in ids and weight > 0:
                graph[person.id].append((target_id, weight))
    return sorted(ids), graph


def shortest_distances(ids: list[str], graph: dict[str, list[tuple[str, float]]], source: str) -> dict[str, int]:
    distances = {source: 0}
    queue: deque[str] = deque([source])
    while queue:
        current = queue.popleft()
        for nxt, _ in graph.get(current, []):
            if nxt not in distances:
                distances[nxt] = distances[current] + 1
                queue.append(nxt)
    return distances


def approximate_betweenness(ids: list[str], graph: dict[str, list[tuple[str, float]]], target: str) -> float:
    count = 0
    through = 0
    sample = ids[:]
    for i, src in enumerate(sample):
        if src == target:
            continue
        prev: dict[str, str | None] = {src: None}
        queue: deque[str] = deque([src])
        while queue:
            current = queue.popleft()
            for nxt, _ in graph.get(current, []):
                if nxt not in prev:
                    prev[nxt] = current
                    queue.append(nxt)
        for dst in sample[i + 1:]:
            if dst in {src, target} or dst not in prev:
                continue
            count += 1
            cur = dst
            path = []
            while cur is not None:
                path.append(cur)
                cur = prev[cur]
            if target in path[1:-1]:
                through += 1
    return 0.0 if count == 0 else through / count


def component_size(ids: list[str], graph: dict[str, list[tuple[str, float]]], source: str) -> int:
    undirected: dict[str, set[str]] = {pid: set() for pid in ids}
    for src, targets in graph.items():
        for dst, _ in targets:
            undirected[src].add(dst)
            undirected[dst].add(src)
    seen = {source}
    queue: deque[str] = deque([source])
    while queue:
        current = queue.popleft()
        for nxt in undirected[current]:
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return len(seen)


def network_metrics(sim: object, target: str) -> dict[str, Any]:
    ids, graph = trust_graph(sim, alive_only=True)
    person = sim._person(target)
    incoming = [
        (p.id, p.trust[target])
        for p in sim.alive_people
        if target in p.trust and p.id != target
    ]
    outgoing = [(pid, weight) for pid, weight in person.trust.items() if pid in set(ids)]
    distances = shortest_distances(ids, graph, target) if target in ids else {}
    reachable = [dist for pid, dist in distances.items() if pid != target]
    closeness = 0.0 if not reachable else len(reachable) / sum(reachable)
    return {
        "alive": person.alive,
        "population": sim.population,
        "in_degree": len(incoming),
        "out_degree": len(outgoing),
        "weighted_incoming_trust": round(sum(w for _, w in incoming), 4),
        "weighted_outgoing_trust": round(sum(w for _, w in outgoing), 4),
        "top_incoming": [
            {"id": pid, "weight": round(weight, 4)}
            for pid, weight in sorted(incoming, key=lambda item: item[1], reverse=True)[:8]
        ],
        "top_outgoing": [
            {"id": pid, "weight": round(weight, 4)}
            for pid, weight in sorted(outgoing, key=lambda item: item[1], reverse=True)[:8]
        ],
        "top_trusted": person.top_trusted(5),
        "closeness_approx": round(closeness, 4),
        "betweenness_approx": round(approximate_betweenness(ids, graph, target), 4) if target in ids else 0.0,
        "component_size": component_size(ids, graph, target) if target in ids else 0,
        "distance_to_hana": distances.get(HANA),
        "distance_to_orun": distances.get(ORUN),
        "distance_to_shion": distances.get(SHION),
    }


def choose_network_equivalent(baseline: object) -> str:
    metrics = {
        pid: network_metrics_for_candidate(baseline, pid)
        for pid in [p.id for p in baseline.alive_people if p.id not in {P000, HANA, ORUN}]
    }
    p000_m = network_metrics_for_candidate(baseline, P000)
    def distance(item: tuple[str, dict[str, float]]) -> float:
        _, m = item
        return math.sqrt(
            (m["in"] - p000_m["in"]) ** 2
            + (m["out"] - p000_m["out"]) ** 2
            + (m["win"] - p000_m["win"]) ** 2
            + (m["wout"] - p000_m["wout"]) ** 2
            + (m["close"] - p000_m["close"]) ** 2
        )
    return sorted(metrics.items(), key=distance)[0][0]


def network_metrics_for_candidate(sim: object, target: str) -> dict[str, float]:
    ids, graph = trust_graph(sim, alive_only=True)
    person = sim._person(target)
    incoming = [
        p.trust[target]
        for p in sim.alive_people
        if target in p.trust and p.id != target
    ]
    outgoing = [w for pid, w in person.trust.items() if pid in set(ids)]
    distances = shortest_distances(ids, graph, target) if target in ids else {}
    reachable = [dist for pid, dist in distances.items() if pid != target]
    closeness = 0.0 if not reachable else len(reachable) / sum(reachable)
    return {
        "in": float(len(incoming)),
        "out": float(len(outgoing)),
        "win": sum(incoming),
        "wout": sum(outgoing),
        "close": closeness,
    }


def p000_profile(sim: object) -> dict[str, Any]:
    p = sim._person(P000)
    incoming = [
        {"id": other.id, "name": other.name, "trust": round(other.trust[P000], 4)}
        for other in sim.people
        if P000 in other.trust and other.id != P000
    ]
    outgoing = [
        {"id": pid, "name": sim._person(pid).name, "trust": round(weight, 4)}
        for pid, weight in p.trust.items()
    ]
    death_year = None
    for entry in sim.log.entries:
        if entry.event_type == "death" and entry.persons == [P000]:
            death_year = entry.year
            break
    return {
        "id": p.id,
        "name": p.name,
        "initial_age": 39,
        "final_age": p.age,
        "sex": p.sex,
        "charisma": round(p.charisma, 4),
        "food_skill": round(p.food_skill, 4),
        "alive": p.alive,
        "death_year": death_year,
        "final_health": round(p.health, 4),
        "final_hunger": round(p.hunger, 4),
        "final_fear": round(p.fear, 4),
        "final_bias": {k: round(v, 4) for k, v in p.interpretation_bias.items()},
        "incoming_trust_top": sorted(incoming, key=lambda item: item["trust"], reverse=True)[:10],
        "outgoing_trust_top": sorted(outgoing, key=lambda item: item["trust"], reverse=True)[:10],
        "top_trusted": p.top_trusted(5),
    }


def p000_event_history(sim: object) -> list[dict[str, Any]]:
    rows = []
    for entry in sim.log.entries:
        include = False
        role = []
        if P000 in entry.persons:
            include = True
            if entry.event_type == "proposal_made":
                role.append("proposal_made")
            if entry.event_type == "proposal_supported":
                if entry.persons[0] == P000:
                    role.append("supporter")
                if len(entry.persons) > 1 and entry.persons[1] == P000:
                    role.append("supported_proposer")
            if entry.event_type in {"project_started", "project_success", "project_failure"}:
                role.append("project_participant")
            if entry.event_type == "memory_shared":
                role.append("speaker" if entry.persons[0] == P000 else "listener")
            if entry.event_type == "shared_narrative":
                role.append("shared_narrative_member")
        if include:
            rows.append(
                {
                    "year": entry.year,
                    "event_type": entry.event_type,
                    "role": ",".join(role),
                    "persons": entry.persons,
                    "detail": entry.detail,
                }
            )
    return rows


def after_receipt_changes(sim: object) -> dict[str, Any]:
    receipt_year = None
    for edge in sim.branch_edges:
        if edge["listener"] == P000:
            receipt_year = edge["year"]
            break
    def next_event(predicate):
        if receipt_year is None:
            return None
        for entry in sim.log.entries:
            if entry.year >= receipt_year and predicate(entry):
                return compact_event(entry)
        return None
    person_years = sim.person_years
    before = next((row for row in person_years if row["year"] == (receipt_year - 1)), None) if receipt_year else None
    after = next((row for row in person_years if row["year"] == receipt_year), None) if receipt_year else None
    return {
        "receipt_year": receipt_year,
        "next_proposal_support": next_event(lambda e: e.event_type == "proposal_supported" and e.persons and e.persons[0] == P000),
        "next_proposal_made": next_event(lambda e: e.event_type == "proposal_made" and e.persons == [P000]),
        "next_memory_shared_as_speaker": next_event(lambda e: e.event_type == "memory_shared" and e.persons and e.persons[0] == P000),
        "next_project_participation": next_event(lambda e: e.event_type in {"project_started", "project_success", "project_failure"} and P000 in e.persons),
        "state_before_receipt_year_end": before,
        "state_after_receipt_year_end": after,
    }


def branch_stats(sim: object) -> dict[str, Any]:
    edges = sim.branch_edges
    speakers = {edge["speaker"] for edge in edges}
    listeners = {edge["listener"] for edge in edges}
    people = speakers | listeners
    return {
        "edge_count": len(edges),
        "unique_speakers": len(speakers),
        "unique_listeners": len(listeners),
        "unique_people_touched": len(people),
        "last_share_year": max((edge["year"] for edge in edges), default=None),
        "max_generation": max((edge["generation"] for edge in edges), default=None),
        "edges": edges,
    }


baseline = run(Experiment("baseline", "baseline v1.4"))
equivalent = choose_network_equivalent(baseline)
experiments = EXPERIMENTS[:10] + [
    Experiment("M", f"hana_to_network_equivalent_non_p000: {equivalent}", mode="network_equivalent_non_p000", equivalent_listener=equivalent)
] + EXPERIMENTS[10:]


baseline = run(Experiment("baseline", "baseline v1.4"))
baseline_summary = selected_summary(baseline)

results: dict[str, Any] = {}
rows: list[dict[str, Any]] = []
for exp in experiments:
    sim = baseline if exp.code == "baseline" else run(exp)
    summary = selected_summary(sim)
    stats = branch_stats(sim)
    first_diff = None if exp.code == "baseline" else first_log_difference(baseline, sim)
    row = {
        "experiment": exp.code,
        "label": exp.label,
        **summary,
        "target_memory_edges": stats["edge_count"],
        "unique_people_touched": stats["unique_people_touched"],
        "last_share_year": stats["last_share_year"],
        "max_generation": stats["max_generation"],
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "summary_diff_keys_vs_baseline": ",".join(
            key for key, value in summary.items() if baseline_summary.get(key) != value
        ),
    }
    rows.append(row)
    results[exp.code] = {
        "label": exp.label,
        "summary": summary,
        "first_diff_vs_baseline": first_diff,
        "branch_stats": stats,
        "p000_after_receipt": after_receipt_changes(sim),
    }

details = {
    "seed": SEED,
    "years": YEARS,
    "target": {
        "p000": P000,
        "hana": HANA,
        "memory": TARGET_EVENT,
        "memory_year": TARGET_YEAR,
        "network_equivalent_for_M": equivalent,
    },
    "p000_profile": p000_profile(baseline),
    "p000_network_snapshots": baseline.network_snapshots,
    "p000_yearly_state": baseline.person_years,
    "p000_event_history": p000_event_history(baseline),
    "baseline_branch": branch_stats(baseline),
    "experiments": results,
}

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_copy = OUT_DIR / "society_lab_seed1003_p000_branch_trace.py"
report_path = OUT_DIR / "society_lab_seed1003_p000_branch_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_p000_branch_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_p000_branch_details.json"
svg_path = OUT_DIR / "society_lab_seed1003_p000_branch_tree.svg"

script_copy.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")


def md_table(rows: list[dict[str, Any]]) -> list[str]:
    lines = [
        "| exp | intervention | final pop | births | failures | memory shares | p000-branch edges | touched | last year | first diff |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['experiment']} | {row['label']} | {row['final_population']} | "
            f"{row['birth_count']} | {row['project_failure_count']} | {row['memory_shared_count']} | "
            f"{row['target_memory_edges']} | {row['unique_people_touched']} | {row['last_share_year']} | "
            f"{row['first_diff_index']} |"
        )
    return lines


profile = details["p000_profile"]
report = [
    "# society_lab seed1003 p000 branch trace",
    "",
    "## Provisional Reading",
    "",
    "F-I showed that `p019 Hana -> p000 Zol` is closer to a sufficient condition for the v1.4 path than the visible `p004 -> p011` branch. This report avoids saying `Zol caused history`; it separates p000 receipt, p000 re-sharing, p000 behavior effects, network position, and timing.",
    "",
    "## p000 Profile",
    "",
    f"- id/name: `{profile['id']}` {profile['name']}",
    f"- sex: {profile['sex']}",
    f"- age: initial {profile['initial_age']}, final {profile['final_age']}",
    f"- charisma: {profile['charisma']}",
    f"- food_skill: {profile['food_skill']}",
    f"- death_year: {profile['death_year']}",
    f"- final health/hunger/fear: {profile['final_health']} / {profile['final_hunger']} / {profile['final_fear']}",
    f"- final bias: {profile['final_bias']}",
    f"- top_trusted: {profile['top_trusted']}",
    "",
    "Top incoming trust:",
    "",
]
report.extend(
    f"- {item['id']} {item['name']}: {item['trust']}"
    for item in profile["incoming_trust_top"][:6]
)
report.extend(["", "Top outgoing trust:", ""])
report.extend(
    f"- {item['id']} {item['name']}: {item['trust']}"
    for item in profile["outgoing_trust_top"][:6]
)
report.extend(["", "## Network Snapshots", ""])
for year, snap in sorted(details["p000_network_snapshots"].items(), key=lambda item: int(item[0])):
    report.extend(
        [
            f"### Year {year}",
            "",
            f"- in_degree/out_degree: {snap['in_degree']} / {snap['out_degree']}",
            f"- weighted incoming/outgoing: {snap['weighted_incoming_trust']} / {snap['weighted_outgoing_trust']}",
            f"- closeness approx: {snap['closeness_approx']}",
            f"- betweenness approx: {snap['betweenness_approx']}",
            f"- component size: {snap['component_size']}",
            f"- distance to Hana/Orun/Shion: {snap['distance_to_hana']} / {snap['distance_to_orun']} / {snap['distance_to_shion']}",
            "",
        ]
    )

report.extend(["## p000 Branch Descendants", ""])
base_stats = details["baseline_branch"]
report.extend(
    [
        f"- edge_count: {base_stats['edge_count']}",
        f"- unique_speakers: {base_stats['unique_speakers']}",
        f"- unique_listeners: {base_stats['unique_listeners']}",
        f"- unique_people_touched: {base_stats['unique_people_touched']}",
        f"- last_share_year: {base_stats['last_share_year']}",
        f"- max_generation: {base_stats['max_generation']}",
        "",
        "Baseline p000-branch edges:",
        "",
    ]
)
for edge in base_stats["edges"]:
    report.append(
        f"- Y{edge['year']}: {edge['speaker']} {edge['speaker_name']} -> "
        f"{edge['listener']} {edge['listener_name']} "
        f"(gen={edge['generation']}, intensity={edge['intensity']}, interp={edge['interpretation']})"
    )

report.extend(["", "## Intervention Results", ""])
report.extend(md_table(rows))
report.extend(
    [
        "",
        "## Main Findings",
        "",
        "1. Baseline p000-branch tracing found only one marked edge: `Y21 p019 -> p000`. The marked Year14 memory was not observed as a p000 re-share branch afterward.",
        "2. K is identical to baseline because p000 did not re-share this marked memory in the baseline trace.",
        "3. L is also identical to baseline, so the measured v1.4 path is not explained by p000 later using this memory in proposal/support choice.",
        "4. J is mixed: replacing Hana with `p004 -> p000` preserves the high-level v1.4 summary, but `p005 -> p000` and `p020 -> p000` do not. This weakens a simple `any sender to p000 works` reading.",
        "5. M falls to the non-v1.4 path, so the selected network-near substitute (`p035`) did not replace p000.",
        "6. N shows timing sensitivity: Y23 and Y28 diverge strongly; Y25 preserves final population/births but changes the project path.",
        "",
        "The safest current reading is: p000 receipt at the original Y21 position is a strong condition, but not because p000 visibly re-broadcasts the marked memory. The effect is more likely tied to the exact event-order/trust-update/network state around the Y21 receipt than to a long p000 descendant tree.",
        "",
        "## Interpretation Guardrails",
        "",
        "- If J variants preserve v1.4, p000 receipt matters more than the Hana-p000 pair.",
        "- If K changes history, p000 re-sharing matters more than p000 merely holding the memory.",
        "- If L changes history, p000's support/proposal use of the memory matters.",
        "- If M preserves v1.4, network position may matter more than p000 as a person.",
        "- If N changes with delay, timing is part of the condition.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")


svg_edges = base_stats["edges"][:12]
nodes = []
for edge in svg_edges:
    for key in ("speaker", "listener"):
        if edge[key] not in nodes:
            nodes.append(edge[key])
positions = {pid: (80 + (i % 4) * 200, 90 + (i // 4) * 130) for i, pid in enumerate(nodes)}
svg = [
    '<svg width="100%" viewBox="0 0 900 520" xmlns="http://www.w3.org/2000/svg" role="img">',
    "<title>seed1003 p000 branch tree</title>",
    '<rect width="900" height="520" fill="#fbfaf7"/>',
    '<defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M2 1 L8 5 L2 9" fill="none" stroke="#4b5563" stroke-width="1.8"/></marker></defs>',
    '<style>text{font-family:"Yu Gothic","Meiryo",sans-serif;fill:#222}.node{fill:#fffdf8;stroke:#a88f63;stroke-width:1.4}.edge{stroke:#4b5563;stroke-width:1.8;fill:none;marker-end:url(#arrow)}.small{font-size:12px;fill:#555}.title{font-size:22px;font-weight:700}</style>',
    '<text x="450" y="38" text-anchor="middle" class="title">p000 branch: Year14 store_food failure memory</text>',
]
for edge in svg_edges:
    x1, y1 = positions[edge["speaker"]]
    x2, y2 = positions[edge["listener"]]
    svg.append(f'<path d="M{x1+65} {y1+25} C{x1+110} {y1+25} {x2-45} {y2+25} {x2} {y2+25}" class="edge"/>')
    svg.append(f'<text x="{(x1+x2)/2+30:.0f}" y="{(y1+y2)/2+12:.0f}" class="small">Y{edge["year"]} g{edge["generation"]}</text>')
for pid, (x, y) in positions.items():
    label = person_label(baseline, pid)
    fill = "#eaf7ef" if pid == P000 else "#fffdf8"
    svg.append(f'<rect x="{x}" y="{y}" width="130" height="50" rx="10" class="node" fill="{fill}"/>')
    svg.append(f'<text x="{x+65}" y="{y+30}" text-anchor="middle" font-size="14">{label}</text>')
svg.append("</svg>")
svg_path.write_text("\n".join(svg), encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_copy)
print(svg_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
