from __future__ import annotations

import importlib.util
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V14_PATH = Path(__file__).with_name("society_lab_v1_4.py")
REPORT_PATH = Path(__file__).with_name("society_lab_seed_1003_memory_propagation.md")

SEED = 1003
YEARS = 80
TARGET_EVENT = "project_failure:store_food"
TARGET_MEMORY_YEAR = 14


@dataclass
class PropagationEdge:
    year: int
    speaker_id: str
    speaker_name: str
    listener_id: str
    listener_name: str
    intensity: float
    generation: int
    interpretation: str


def load_module(label: str, path: Path) -> ModuleType:
    module_name = label.replace(".", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def node_label(person: object) -> str:
    return f"{person.id} {person.name}"


def mermaid_id(person_id: str) -> str:
    return person_id.replace("-", "_")


def build_instrumented_lab(module: ModuleType) -> type:
    class InstrumentedSocietyLab(module.SocietyLab):
        def __init__(self, *args: object, **kwargs: object) -> None:
            super().__init__(*args, **kwargs)
            self.propagation_edges: list[PropagationEdge] = []

        def _dialogue_phase(self) -> None:
            for speaker in self.alive_people:
                memory = speaker.strongest_memory()
                if memory is None:
                    continue
                share_probability = (
                    0.05
                    + memory.intensity * 0.18
                    + speaker.fear * 0.15
                    + (0.12 if speaker.action == "share_memory" else 0.0)
                )
                if memory.generation >= 4:
                    share_probability *= 0.55
                if self.rng.random() > min(0.55, share_probability):
                    continue
                listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
                listeners = [
                    self._person(person_id)
                    for person_id in speaker.top_trusted(listener_count)
                    if self._person(person_id).alive
                ]
                for listener in listeners:
                    distorted = self._distort_memory(memory, speaker, listener)
                    if (
                        memory.event == TARGET_EVENT
                        and memory.year == TARGET_MEMORY_YEAR
                    ):
                        self.propagation_edges.append(
                            PropagationEdge(
                                year=self.year,
                                speaker_id=speaker.id,
                                speaker_name=speaker.name,
                                listener_id=listener.id,
                                listener_name=listener.name,
                                intensity=distorted.intensity,
                                generation=distorted.generation,
                                interpretation=distorted.interpretation,
                            )
                        )
                    listener.remember(distorted)
                    self.log.record(
                        self.year,
                        "memory_shared",
                        [speaker.id, listener.id],
                        (
                            f"{speaker.name} told {listener.name} about "
                            f"{distorted.event} intensity={distorted.intensity:.2f} "
                            f"generation={distorted.generation}"
                        ),
                    )
                    self._adjust_trust(listener, speaker.id, 0.012)

    return InstrumentedSocietyLab


def target_failure_participants(sim: object) -> list[str]:
    for entry in sim.log.entries:
        if (
            entry.year == TARGET_MEMORY_YEAR
            and entry.event_type == "project_failure"
            and TARGET_EVENT.split(":", 1)[1] in entry.detail
        ):
            return entry.persons
    return []


def person_snapshot(sim: object, person_id: str) -> dict[str, object]:
    person = sim._person(person_id)
    return {
        "id": person.id,
        "name": person.name,
        "alive": person.alive,
        "age": person.age,
        "charisma": round(person.charisma, 3),
        "food_skill": round(person.food_skill, 3),
        "incoming_trust": round(sim._incoming_trust(person_id), 3),
        "trust_links": len(person.trust),
        "memory_count": len(person.memories),
        "bias_blame": round(person.interpretation_bias.get("blame", 0.0), 4),
    }


def summarize_edges(edges: list[PropagationEdge]) -> dict[str, object]:
    speakers = {edge.speaker_id for edge in edges}
    listeners = {edge.listener_id for edge in edges}
    people = speakers | listeners
    by_year: dict[int, int] = {}
    speaker_counts: Counter[str] = Counter()
    listener_counts: Counter[str] = Counter()
    for edge in edges:
        by_year[edge.year] = by_year.get(edge.year, 0) + 1
        speaker_counts[f"{edge.speaker_id} {edge.speaker_name}"] += 1
        listener_counts[f"{edge.listener_id} {edge.listener_name}"] += 1
    return {
        "edge_count": len(edges),
        "speaker_count": len(speakers),
        "listener_count": len(listeners),
        "person_count": len(people),
        "first_share_year": min((edge.year for edge in edges), default=None),
        "last_share_year": max((edge.year for edge in edges), default=None),
        "by_year": by_year,
        "top_speakers": speaker_counts.most_common(6),
        "top_listeners": listener_counts.most_common(6),
    }


def format_edge(edge: PropagationEdge) -> str:
    return (
        f"Y{edge.year}: {edge.speaker_id} {edge.speaker_name} -> "
        f"{edge.listener_id} {edge.listener_name} "
        f"(gen={edge.generation}, intensity={edge.intensity:.2f}, "
        f"interpretation={edge.interpretation})"
    )


def mermaid_graph(edges: list[PropagationEdge], initial_holders: list[str]) -> str:
    lines = ["```mermaid", "graph TD"]
    for person_id in initial_holders:
        lines.append(f'  {mermaid_id(person_id)}["{person_id}"]')
    for edge in edges:
        label = f"Y{edge.year} g{edge.generation} {edge.interpretation}"
        lines.append(
            f'  {mermaid_id(edge.speaker_id)}["{edge.speaker_id} {edge.speaker_name}"] '
            f'-- "{label}" --> '
            f'{mermaid_id(edge.listener_id)}["{edge.listener_id} {edge.listener_name}"]'
        )
    lines.append("```")
    return "\n".join(lines)


def write_report(sim: object) -> None:
    participants = target_failure_participants(sim)
    proposer = participants[0] if participants else "-"
    initial_holders = participants[1:] if participants else []
    edges = sim.propagation_edges
    summary = summarize_edges(edges)

    lines: list[str] = []
    lines.append("# society_lab seed 1003 memory propagation")
    lines.append("")
    lines.append(f"Version: v1.4")
    lines.append(f"Seed: {SEED}")
    lines.append(f"Target memory: `{TARGET_EVENT}` from Year {TARGET_MEMORY_YEAR}")
    lines.append("")
    lines.append("## Source Event")
    lines.append("")
    lines.append(f"Proposer: `{proposer}`")
    lines.append("")
    lines.append("Initial memory holders:")
    lines.append("")
    for person_id in initial_holders:
        snap = person_snapshot(sim, person_id)
        lines.append(
            f"- `{person_id}` {snap['name']} "
            f"(charisma={snap['charisma']}, incoming_trust={snap['incoming_trust']}, "
            f"blame_bias={snap['bias_blame']})"
        )
    lines.append("")
    lines.append("## Propagation Summary")
    lines.append("")
    lines.append(f"- Transmission edges: {summary['edge_count']}")
    lines.append(f"- Unique speakers: {summary['speaker_count']}")
    lines.append(f"- Unique listeners: {summary['listener_count']}")
    lines.append(f"- Unique people touched by propagation: {summary['person_count']}")
    lines.append(f"- First share year: {summary['first_share_year']}")
    lines.append(f"- Last share year: {summary['last_share_year']}")
    lines.append("")
    lines.append("Transmission count by year:")
    lines.append("")
    for year, count in sorted(summary["by_year"].items()):
        lines.append(f"- Year {year}: {count}")
    lines.append("")
    lines.append("Top speakers:")
    lines.append("")
    for label, count in summary["top_speakers"]:
        lines.append(f"- {label}: {count}")
    lines.append("")
    lines.append("Top listeners:")
    lines.append("")
    for label, count in summary["top_listeners"]:
        lines.append(f"- {label}: {count}")
    lines.append("")
    lines.append("## Hana Branch")
    lines.append("")
    hana_edges = [
        edge for edge in edges
        if edge.speaker_id == "p019" or edge.listener_id in {"p004", "p000"}
    ]
    for edge in hana_edges:
        lines.append(f"- {format_edge(edge)}")
    lines.append("")
    lines.append(
        "`p019` does not dominate the whole graph, but her branch is not isolated. "
        "She sends the Year 14 failure memory to `p004` and `p000` in Year 21, "
        "then sends it to `p004` again in Year 28. After receiving it, `p004` "
        "retells the same source memory to `p011` in Years 23, 25, and 26."
    )
    lines.append("")
    lines.append("## Propagation Edges")
    lines.append("")
    if edges:
        for edge in edges:
            lines.append(f"- {format_edge(edge)}")
    else:
        lines.append("No propagation edges were recorded.")
    lines.append("")
    lines.append("## Diagram")
    lines.append("")
    lines.append(mermaid_graph(edges, initial_holders))
    lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "This trace follows only the Year 14 `project_failure:store_food` memory. "
        "It does not include later store_food failures with different source years."
    )
    lines.append("")
    lines.append(
        "The important question is whether the Year 14 failure memory remained local "
        "or moved through the network. If it moved, the branch is not only a numeric "
        "supporter difference; it is also a change in who carried and retold a failure."
    )
    lines.append("")
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    module = load_module("society_lab_v1_4", V14_PATH)
    lab_class = build_instrumented_lab(module)
    sim = lab_class(seed=SEED, verbose=False)
    sim.run(years=YEARS)
    write_report(sim)
    print(f"Wrote {REPORT_PATH}")
    print(summarize_edges(sim.propagation_edges))


if __name__ == "__main__":
    main()
