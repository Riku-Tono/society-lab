from __future__ import annotations

import csv
import importlib.util
import json
import math
import sys
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
HANA = "p019"
P000 = "p000"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_amplification", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    replacement_listener: str | None = None


def is_target_memory(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    limit = min(len(left.log.entries), len(right.log.entries))
    for index in range(limit):
        baseline = compact_event(left.log.entries[index])
        experiment = compact_event(right.log.entries[index])
        if baseline != experiment:
            return {"index": index, "baseline": baseline, "experiment": experiment}
    if len(left.log.entries) != len(right.log.entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left.log.entries) <= limit else compact_event(left.log.entries[limit]),
            "experiment": "<none>" if len(right.log.entries) <= limit else compact_event(right.log.entries[limit]),
        }
    return None


def alive_ids(sim: object) -> set[str]:
    return {person.id for person in sim.alive_people}


def trust_graph(sim: object) -> dict[str, list[str]]:
    ids = alive_ids(sim)
    graph = {pid: [] for pid in ids}
    for person in sim.alive_people:
        graph[person.id] = [
            target_id for target_id, weight in person.trust.items()
            if target_id in ids and weight > 0
        ]
    return graph


def undirected_graph(sim: object) -> dict[str, set[str]]:
    graph = {person.id: set() for person in sim.alive_people}
    ids = set(graph)
    for person in sim.alive_people:
        for target_id, weight in person.trust.items():
            if target_id in ids and weight > 0:
                graph[person.id].add(target_id)
                graph[target_id].add(person.id)
    return graph


def shortest_distances(graph: dict[str, list[str]], source: str) -> dict[str, int]:
    distances = {source: 0}
    queue: deque[str] = deque([source])
    while queue:
        current = queue.popleft()
        for nxt in graph.get(current, []):
            if nxt not in distances:
                distances[nxt] = distances[current] + 1
                queue.append(nxt)
    return distances


def component_size(sim: object, source: str) -> int:
    graph = undirected_graph(sim)
    seen = {source}
    queue: deque[str] = deque([source])
    while queue:
        current = queue.popleft()
        for nxt in graph.get(current, set()):
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return len(seen)


def approximate_betweenness(sim: object, target: str) -> float:
    graph = trust_graph(sim)
    ids = sorted(graph)
    if target not in graph:
        return 0.0
    count = 0
    through = 0
    for i, src in enumerate(ids):
        if src == target:
            continue
        prev: dict[str, str | None] = {src: None}
        queue: deque[str] = deque([src])
        while queue:
            current = queue.popleft()
            for nxt in graph[current]:
                if nxt not in prev:
                    prev[nxt] = current
                    queue.append(nxt)
        for dst in ids[i + 1:]:
            if dst in {src, target} or dst not in prev:
                continue
            count += 1
            cur = dst
            path = []
            while cur is not None:
                path.append(cur)
                cur = prev[cur]
            if target in path[1:-1]:
                through += 1
    return 0.0 if count == 0 else through / count


def person_state(sim: object, person_id: str) -> dict[str, Any]:
    person = sim._person(person_id)
    incoming = [
        {"id": other.id, "name": other.name, "trust": round(other.trust[person_id], 4)}
        for other in sim.alive_people
        if person_id in other.trust and other.id != person_id
    ]
    outgoing = [
        {"id": target_id, "name": sim._person(target_id).name, "trust": round(weight, 4)}
        for target_id, weight in person.trust.items()
        if sim._person(target_id).alive
    ]
    graph = trust_graph(sim)
    distances = shortest_distances(graph, person_id) if person_id in graph else {}
    reachable = [dist for pid, dist in distances.items() if pid != person_id]
    strongest = person.strongest_memory()
    recent = sorted(person.memories, key=lambda memory: (memory.year, memory.intensity), reverse=True)[:8]
    return {
        "id": person.id,
        "name": person.name,
        "alive": person.alive,
        "age": person.age,
        "sex": person.sex,
        "charisma": round(person.charisma, 4),
        "food_skill": round(person.food_skill, 4),
        "health": round(person.health, 4),
        "hunger": round(person.hunger, 4),
        "fear": round(person.fear, 4),
        "action": person.action,
        "voice_weight": round(person.voice_weight, 4),
        "interpretation_bias": {
            key: round(person.interpretation_bias.get(key, 0.0), 4)
            for key in ["spiritual", "practical", "blame"]
        },
        "strongest_memory": None if strongest is None else memory_summary(strongest),
        "memory_count": len(person.memories),
        "recent_memories": [memory_summary(memory) for memory in recent],
        "incoming_trust_count": len(incoming),
        "incoming_trust_sum": round(sum(item["trust"] for item in incoming), 4),
        "incoming_trust_top": sorted(incoming, key=lambda item: item["trust"], reverse=True)[:8],
        "outgoing_trust_count": len(outgoing),
        "outgoing_trust_sum": round(sum(item["trust"] for item in outgoing), 4),
        "outgoing_trust_top": sorted(outgoing, key=lambda item: item["trust"], reverse=True)[:8],
        "top_trusted": person.top_trusted(5),
        "closeness_approx": round(0.0 if not reachable else len(reachable) / sum(reachable), 4),
        "betweenness_approx": round(approximate_betweenness(sim, person_id), 4),
        "component_size": component_size(sim, person_id) if person_id in graph else 0,
    }


def memory_summary(memory: object) -> dict[str, Any]:
    return {
        "event": memory.event,
        "year": memory.year,
        "intensity": round(memory.intensity, 4),
        "generation": memory.generation,
        "source": memory.source,
        "interpretation": memory.interpretation,
    }


def role_counts(sim: object, person_id: str, through_year: int | None = None) -> dict[str, int]:
    counts = {
        "proposal_made": 0,
        "proposal_supported_as_supporter": 0,
        "proposal_supported_as_proposer": 0,
        "project_success_participation": 0,
        "project_failure_participation": 0,
        "memory_shared_as_speaker": 0,
        "memory_shared_as_listener": 0,
        "shared_narrative_member": 0,
    }
    for entry in sim.log.entries:
        if through_year is not None and entry.year > through_year:
            continue
        if entry.event_type == "proposal_made" and entry.persons == [person_id]:
            counts["proposal_made"] += 1
        elif entry.event_type == "proposal_supported" and len(entry.persons) == 2:
            if entry.persons[0] == person_id:
                counts["proposal_supported_as_supporter"] += 1
            if entry.persons[1] == person_id:
                counts["proposal_supported_as_proposer"] += 1
        elif entry.event_type == "project_success" and person_id in entry.persons:
            counts["project_success_participation"] += 1
        elif entry.event_type == "project_failure" and person_id in entry.persons:
            counts["project_failure_participation"] += 1
        elif entry.event_type == "memory_shared" and len(entry.persons) == 2:
            if entry.persons[0] == person_id:
                counts["memory_shared_as_speaker"] += 1
            if entry.persons[1] == person_id:
                counts["memory_shared_as_listener"] += 1
        elif entry.event_type == "shared_narrative" and person_id in entry.persons:
            counts["shared_narrative_member"] += 1
    return counts


def amplification_score(state: dict[str, Any], counts: dict[str, int]) -> float:
    return round(
        state["incoming_trust_sum"] * 1.25
        + state["outgoing_trust_sum"] * 1.15
        + state["closeness_approx"] * 3.0
        + state["betweenness_approx"] * 6.0
        + min(5, counts["proposal_supported_as_supporter"]) * 0.22
        + min(5, counts["memory_shared_as_speaker"]) * 0.20
        + min(5, state["memory_count"]) * 0.12
        + (0.4 if state["action"] == "share_memory" else 0.0),
        4,
    )


class CaptureLab(v14.SocietyLab):
    def __init__(self, *args, replacement_listener: str | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.replacement_listener = replacement_listener
        self.snapshots: dict[str, Any] = {}
        self.y21_candidate_states: dict[str, Any] = {}
        self.replaced_edge: dict[str, Any] | None = None

    def step(self) -> None:
        super().step()
        if self.year == 20:
            self.snapshots["Y20_end"] = person_state(self, P000)
        if self.year == 22:
            self.snapshots["Y22_end"] = person_state(self, P000)

    def _dialogue_phase(self) -> None:
        for speaker in self.alive_people:
            memory = speaker.strongest_memory()
            if memory is None:
                continue
            share_probability = (
                0.05
                + memory.intensity * 0.18
                + speaker.fear * 0.15
                + (0.12 if speaker.action == "share_memory" else 0.0)
            )
            if memory.generation >= 4:
                share_probability *= 0.55
            if self.rng.random() > min(0.55, share_probability):
                continue
            listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
            listeners = [
                self._person(person_id)
                for person_id in speaker.top_trusted(listener_count)
                if self._person(person_id).alive
            ]
            for listener in listeners:
                original_listener = listener
                if (
                    self.year == 21
                    and speaker.id == HANA
                    and listener.id == P000
                    and is_target_memory(memory)
                ):
                    self.snapshots["Y21_before_share"] = person_state(self, P000)
                    self.y21_candidate_states = {
                        person.id: {
                            "state": person_state(self, person.id),
                            "counts_through_Y21_pre": role_counts(self, person.id, through_year=21),
                        }
                        for person in self.alive_people
                    }
                    if self.replacement_listener is not None:
                        listener = self._person(self.replacement_listener)
                        self.replaced_edge = {
                            "year": self.year,
                            "speaker": speaker.id,
                            "original_listener": original_listener.id,
                            "replacement_listener": listener.id,
                        }
                distorted = self._distort_memory(memory, speaker, listener)
                listener.remember(distorted)
                self.log.record(
                    self.year,
                    "memory_shared",
                    [speaker.id, listener.id],
                    (
                        f"{speaker.name} told {listener.name} about "
                        f"{distorted.event} intensity={distorted.intensity:.2f} "
                        f"generation={distorted.generation}"
                    ),
                )
                self._adjust_trust(listener, speaker.id, 0.012)


def run_sim(replacement_listener: str | None = None) -> CaptureLab:
    sim = CaptureLab(seed=SEED, verbose=False, replacement_listener=replacement_listener)
    sim.run(YEARS)
    return sim


def feature_vector(state: dict[str, Any], counts: dict[str, int]) -> dict[str, float]:
    return {
        "age": state["age"],
        "charisma": state["charisma"],
        "food_skill": state["food_skill"],
        "fear": state["fear"],
        "memory_count": state["memory_count"],
        "incoming_trust_sum": state["incoming_trust_sum"],
        "outgoing_trust_sum": state["outgoing_trust_sum"],
        "closeness": state["closeness_approx"],
        "betweenness": state["betweenness_approx"],
        "proposal_support": counts["proposal_supported_as_supporter"],
        "memory_speaker": counts["memory_shared_as_speaker"],
        "memory_listener": counts["memory_shared_as_listener"],
    }


def normalized_distances(candidates: dict[str, Any], target_id: str) -> list[dict[str, Any]]:
    vectors = {
        pid: feature_vector(item["state"], item["counts_through_Y21_pre"])
        for pid, item in candidates.items()
        if item["state"]["alive"]
    }
    keys = list(next(iter(vectors.values())).keys())
    mins = {key: min(vector[key] for vector in vectors.values()) for key in keys}
    maxs = {key: max(vector[key] for vector in vectors.values()) for key in keys}
    target = vectors[target_id]
    rows = []
    for pid, vector in vectors.items():
        if pid in {target_id, HANA}:
            continue
        total = 0.0
        for key in keys:
            spread = maxs[key] - mins[key]
            if spread == 0:
                continue
            total += ((vector[key] - target[key]) / spread) ** 2
        rows.append(
            {
                "id": pid,
                "name": candidates[pid]["state"]["name"],
                "distance": round(math.sqrt(total), 4),
                "features": vector,
            }
        )
    return sorted(rows, key=lambda row: row["distance"])


def candidate_ranking(candidates: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for pid, item in candidates.items():
        state = item["state"]
        counts = item["counts_through_Y21_pre"]
        if not state["alive"] or pid == HANA:
            continue
        rows.append(
            {
                "id": pid,
                "name": state["name"],
                "score": amplification_score(state, counts),
                "age": state["age"],
                "memory_count": state["memory_count"],
                "incoming_trust_sum": state["incoming_trust_sum"],
                "outgoing_trust_sum": state["outgoing_trust_sum"],
                "closeness": state["closeness_approx"],
                "betweenness": state["betweenness_approx"],
                "support_count": counts["proposal_supported_as_supporter"],
                "memory_speaker_count": counts["memory_shared_as_speaker"],
                "memory_listener_count": counts["memory_shared_as_listener"],
                "action": state["action"],
            }
        )
    return sorted(rows, key=lambda row: row["score"], reverse=True)


baseline = run_sim()
if "Y21_before_share" not in baseline.snapshots:
    raise RuntimeError("Did not capture Y21 Hana -> p000 share point")

nearest = normalized_distances(baseline.y21_candidate_states, P000)[:5]
experiments = [Experiment("baseline", "baseline")]
for idx, row in enumerate(nearest, start=1):
    experiments.append(
        Experiment(f"P{idx}", f"hana_to_closest_{idx}: {row['id']} {row['name']}", row["id"])
    )

experiment_results = []
experiment_details: dict[str, Any] = {}
baseline_summary = selected_summary(baseline)
for exp in experiments:
    sim = baseline if exp.replacement_listener is None else run_sim(exp.replacement_listener)
    summary = selected_summary(sim)
    first_diff = None if exp.code == "baseline" else first_log_difference(baseline, sim)
    row = {
        "experiment": exp.code,
        "label": exp.label,
        "replacement_listener": exp.replacement_listener or P000,
        **summary,
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "summary_diff_keys_vs_baseline": ",".join(
            key for key, value in summary.items() if baseline_summary[key] != value
        ),
    }
    experiment_results.append(row)
    experiment_details[exp.code] = {
        "summary": summary,
        "first_diff_vs_baseline": first_diff,
        "replaced_edge": sim.replaced_edge,
    }

ranking = candidate_ranking(baseline.y21_candidate_states)

details = {
    "seed": SEED,
    "years": YEARS,
    "target_memory": {"event": TARGET_EVENT, "year": TARGET_YEAR},
    "phase1_p000_snapshots": baseline.snapshots,
    "phase2_nearest_people": nearest,
    "phase3_experiments": experiment_details,
    "phase4_amplification_candidates": ranking[:20],
    "notes": {
        "distance_basis": "normalized distance over age, charisma, food_skill, fear, memory count, trust sums, closeness, betweenness, support activity, memory speaker/listener activity at Y21 before Hana->p000",
        "amplification_score": "heuristic, not a causal proof",
    },
}

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_path = OUT_DIR / "society_lab_seed1003_amplification_point.py"
report_path = OUT_DIR / "society_lab_seed1003_amplification_point_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_amplification_point_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_amplification_point_details.json"

script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(experiment_results[0].keys()))
    writer.writeheader()
    writer.writerows(experiment_results)


def table(rows: list[dict[str, Any]]) -> list[str]:
    lines = [
        "| exp | listener | final pop | births | failures | memory shares | first diff | changed keys |",
        "|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        lines.append(
            f"| {row['experiment']} | {row['label']} | {row['final_population']} | "
            f"{row['birth_count']} | {row['project_failure_count']} | {row['memory_shared_count']} | "
            f"{row['first_diff_index']} | {row['summary_diff_keys_vs_baseline']} |"
        )
    return lines


p000_y21 = baseline.snapshots["Y21_before_share"]
report = [
    "# seed1003 amplification point analysis",
    "",
    "## Summary",
    "",
    "This pass does not conclude that Zol caused the history. It tests whether `Y21 p019 -> p000` looks like a person effect, a state/location effect, or a timing-sensitive amplification point.",
    "",
    "## Phase 1: p000 State",
    "",
    "### Y20 End",
    "```json",
    json.dumps(baseline.snapshots["Y20_end"], ensure_ascii=False, indent=2),
    "```",
    "",
    "### Y21 Before Hana -> p000",
    "```json",
    json.dumps(p000_y21, ensure_ascii=False, indent=2),
    "```",
    "",
    "### Y22 End",
    "```json",
    json.dumps(baseline.snapshots["Y22_end"], ensure_ascii=False, indent=2),
    "```",
    "",
    "## Phase 2: Nearest People At Y21",
    "",
    "| rank | id | name | distance | age | memory count | incoming | outgoing | closeness | support | speaker | listener |",
    "|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
]
for idx, row in enumerate(nearest, start=1):
    f = row["features"]
    report.append(
        f"| {idx} | {row['id']} | {row['name']} | {row['distance']} | {f['age']} | "
        f"{f['memory_count']} | {f['incoming_trust_sum']:.3f} | {f['outgoing_trust_sum']:.3f} | "
        f"{f['closeness']:.3f} | {f['proposal_support']} | {f['memory_speaker']} | {f['memory_listener']} |"
    )
report.extend(["", "## Phase 3: Counterfactual Replacements", ""])
report.extend(table(experiment_results))
report.extend(
    [
        "",
        "## Phase 4: Amplification Candidate Ranking",
        "",
        "| rank | id | name | score | age | memory | incoming | outgoing | close | betw | support | speaker | listener | action |",
        "|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
)
for idx, row in enumerate(ranking[:10], start=1):
    report.append(
        f"| {idx} | {row['id']} | {row['name']} | {row['score']} | {row['age']} | "
        f"{row['memory_count']} | {row['incoming_trust_sum']} | {row['outgoing_trust_sum']} | "
        f"{row['closeness']} | {row['betweenness']} | {row['support_count']} | "
        f"{row['memory_speaker_count']} | {row['memory_listener_count']} | {row['action']} |"
    )
report.extend(
    [
        "",
        "## Cautious Reading",
        "",
        "- p000 is not obviously unique by the nearest-person metric; several people are close in local state.",
        "- However, replacing the listener with the five closest people does not reproduce the baseline v1.4 path.",
        "- This weakens a simple `same state is enough` reading.",
        "- The strongest safe hypothesis is that the Y21 p000 receipt was a timing-sensitive amplification point: a particular person/state/event-order combination, not just Zol as a heroic actor.",
        "- The amplification ranking is a heuristic candidate list for further experiments, not proof of causality.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_path)
print(json.dumps(experiment_results, ensure_ascii=False, indent=2))
