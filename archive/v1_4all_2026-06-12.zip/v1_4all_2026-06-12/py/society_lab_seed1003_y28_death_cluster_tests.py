from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
P000 = "p000"
Y28_DEATHS = {"p004", "p019", "p026"}


def load_module(label: str, path: Path):
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_y28_cluster", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    mode: str
    target_dead: str | None = None


EXPERIMENTS = [
    Experiment("CL_BASE", "baseline v1.4", "baseline"),
    Experiment("CL_NO_P004_DEATH_MEMORY", "block p004 death-memory distribution only", "block_dead_distribution", "p004"),
    Experiment("CL_NO_P019_DEATH_MEMORY", "block p019 death-memory distribution only", "block_dead_distribution", "p019"),
    Experiment("CL_NO_P026_DEATH_MEMORY", "block p026 death-memory distribution only", "block_dead_distribution", "p026"),
    Experiment("CL_NO_Y28_DEATH_MEMORIES", "block all Y28 death-memory distribution", "block_all_y28_distribution"),
    Experiment("CL_SHIFT_Y28_DEATHS_TO_Y29", "shift baseline Y28 deaths to Y29", "shift_y28_deaths_to_y29"),
    Experiment("CL_P000_NO_DEATHS", "block only p000 receiving Y28 death memories", "block_p000_y28_receipts"),
    Experiment("CL_ALL_RECEIVE_Y28_DEATHS", "all alive receive each Y28 death memory", "all_receive_y28"),
]


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    limit = min(len(left.log.entries), len(right.log.entries))
    for index in range(limit):
        baseline = compact_event(left.log.entries[index])
        experiment = compact_event(right.log.entries[index])
        if baseline != experiment:
            return {"index": index, "baseline": baseline, "experiment": experiment}
    if len(left.log.entries) != len(right.log.entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left.log.entries) <= limit else compact_event(left.log.entries[limit]),
            "experiment": "<none>" if len(right.log.entries) <= limit else compact_event(right.log.entries[limit]),
        }
    return None


def memory_summary(memory: object) -> dict[str, Any]:
    return {
        "event": memory.event,
        "year": memory.year,
        "intensity": round(memory.intensity, 4),
        "generation": memory.generation,
        "source": memory.source,
        "interpretation": memory.interpretation,
    }


class DeathClusterLab(v14.SocietyLab):
    def __init__(self, *args, exp: Experiment, **kwargs):
        super().__init__(*args, **kwargs)
        self.exp = exp
        self.death_grants: list[dict[str, Any]] = []
        self.yearly: list[dict[str, Any]] = []
        self.p000_years: list[dict[str, Any]] = []
        self.p000_events_y28_y38: list[str] = []
        self.postponed_deaths: list[str] = []

    def step(self) -> None:
        super().step()
        if 27 <= self.year <= 31:
            self._capture_year_state()

    def _capture_year_state(self) -> None:
        people = self.alive_people
        death_memory_total = sum(
            1 for person in people for memory in person.memories
            if memory.event == "death"
        )
        death_strongest_count = sum(
            1 for person in people
            if person.strongest_memory() is not None
            and person.strongest_memory().event == "death"
        )
        event_counts = {
            kind: sum(1 for entry in self.log.entries if entry.year == self.year and entry.event_type == kind)
            for kind in [
                "death",
                "proposal_made",
                "proposal_supported",
                "project_success",
                "project_failure",
                "memory_shared",
                "shared_narrative",
            ]
        }
        self.yearly.append(
            {
                "year": self.year,
                "population": self.population,
                "avg_fear": round(self._avg("fear"), 4),
                "avg_hunger": round(self._avg("hunger"), 4),
                "death_memory_total": death_memory_total,
                "death_strongest_count": death_strongest_count,
                **event_counts,
            }
        )
        p = self._person(P000)
        strongest = p.strongest_memory()
        self.p000_years.append(
            {
                "year": self.year,
                "alive": p.alive,
                "age": p.age,
                "health": round(p.health, 4),
                "hunger": round(p.hunger, 4),
                "fear": round(p.fear, 4),
                "action": p.action,
                "top_trusted": p.top_trusted(5),
                "memory_count": len(p.memories),
                "strongest_memory": None if strongest is None else memory_summary(strongest),
                "next_memory_shared": self._next_p000_event_after(self.year, "memory_shared"),
                "next_proposal_support": self._next_p000_support_after(self.year),
            }
        )

    def _next_p000_event_after(self, year: int, event_type: str) -> str | None:
        for entry in self.log.entries:
            if entry.year >= year and entry.event_type == event_type and P000 in entry.persons:
                return compact_event(entry)
        return None

    def _next_p000_support_after(self, year: int) -> str | None:
        for entry in self.log.entries:
            if (
                entry.year >= year
                and entry.event_type == "proposal_supported"
                and entry.persons
                and entry.persons[0] == P000
            ):
                return compact_event(entry)
        return None

    def _should_block_death_memory(self, dead_id: str, recipient_id: str) -> bool:
        if self.year != 28:
            return False
        if self.exp.mode == "block_dead_distribution" and dead_id == self.exp.target_dead:
            return True
        if self.exp.mode == "block_all_y28_distribution":
            return True
        if self.exp.mode == "block_p000_y28_receipts" and recipient_id == P000:
            return True
        return False

    def _should_shift_death(self, person_id: str) -> bool:
        return (
            self.exp.mode == "shift_y28_deaths_to_y29"
            and self.year == 28
            and person_id in Y28_DEATHS
        )

    def _force_postponed_deaths(self) -> None:
        if self.exp.mode != "shift_y28_deaths_to_y29" or self.year != 29:
            return
        for person_id in list(self.postponed_deaths):
            person = self._person(person_id)
            if not person.alive:
                continue
            person.alive = False
            self.log.record(
                self.year,
                "death",
                [person.id],
                f"{person.name} died age={person.age} health={person.health:.2f} shifted_from_Y28",
            )
            self._distribute_death_memories(person)
        self.postponed_deaths.clear()

    def _distribute_death_memories(self, dead_person) -> list[dict[str, Any]]:
        recipients = []
        for other in self.alive_people:
            if dead_person.id not in other.trust:
                continue
            intensity = 0.35 + other.trust[dead_person.id] * 0.45
            memory = self._make_memory(other, event="death", intensity=intensity)
            if self._should_block_death_memory(dead_person.id, other.id):
                recipients.append(
                    {
                        "id": other.id,
                        "name": other.name,
                        "mode": "blocked_preserved_rng",
                        "trust": round(other.trust[dead_person.id], 4),
                        "memory": memory_summary(memory),
                    }
                )
                continue
            other.remember(memory)
            recipients.append(
                {
                    "id": other.id,
                    "name": other.name,
                    "mode": "regular",
                    "trust": round(other.trust[dead_person.id], 4),
                    "memory": memory_summary(memory),
                }
            )

        if self.year == 28 and self.exp.mode == "all_receive_y28":
            existing = {recipient["id"] for recipient in recipients if recipient["mode"] == "regular"}
            for other in self.alive_people:
                if other.id in existing:
                    continue
                intensity = 0.35
                memory = self._make_memory(other, event="death", intensity=intensity)
                memory.source = "manual_cluster_broadcast"
                other.remember(memory)
                recipients.append(
                    {
                        "id": other.id,
                        "name": other.name,
                        "mode": "broadcast",
                        "trust": other.trust.get(dead_person.id),
                        "memory": memory_summary(memory),
                    }
                )
        return recipients

    def _update_phase(self) -> None:
        self._force_postponed_deaths()
        for person in self.alive_people:
            person.age += 1
            person.voice_weight = self._clamp(person.voice_weight * 0.97)
            person.fear = self._clamp(person.fear * 0.86)
            if person.hunger > 0.75:
                person.health = self._clamp(person.health - 0.045 * person.hunger)
            else:
                person.health = self._clamp(person.health + 0.02)
            person.hunger = self._clamp(person.hunger * 0.92)

            for memory in person.memories:
                memory.decay()
            person.memories = [
                memory for memory in person.memories
                if memory.intensity >= 0.05
            ]

            age_risk = max(0.0, (person.age - 76) / 95.0)
            health_risk = max(0.0, 0.25 - person.health) * 0.22
            died = self.rng.random() < age_risk + health_risk
            if not died:
                continue
            if self._should_shift_death(person.id):
                self.postponed_deaths.append(person.id)
                continue
            person.alive = False
            self.log.record(
                self.year,
                "death",
                [person.id],
                f"{person.name} died age={person.age} health={person.health:.2f}",
            )
            recipients = self._distribute_death_memories(person)
            if 27 <= self.year <= 31:
                self.death_grants.append(
                    {
                        "year": self.year,
                        "dead_person": person.id,
                        "dead_name": person.name,
                        "recipients": recipients,
                    }
                )


def run(exp: Experiment) -> DeathClusterLab:
    sim = DeathClusterLab(seed=SEED, verbose=False, exp=exp)
    sim.run(YEARS)
    sim.p000_events_y28_y38 = [
        compact_event(entry)
        for entry in sim.log.entries
        if 28 <= entry.year <= 38 and P000 in entry.persons
    ]
    return sim


baseline = run(EXPERIMENTS[0])
baseline_summary = selected_summary(baseline)
rows = []
details = {
    "seed": SEED,
    "years": YEARS,
    "baseline_summary": baseline_summary,
    "experiments": {},
}

for exp in EXPERIMENTS:
    sim = baseline if exp.code == "CL_BASE" else run(exp)
    summary = selected_summary(sim)
    first_diff = None if exp.code == "CL_BASE" else first_log_difference(baseline, sim)
    changed = [key for key, value in summary.items() if baseline_summary[key] != value]
    y28_deaths = [grant for grant in sim.death_grants if grant["year"] == 28]
    y28_regular_recipients = sum(
        1 for grant in y28_deaths for recipient in grant["recipients"]
        if recipient["mode"] in {"regular", "broadcast"}
    )
    y28_blocked_recipients = sum(
        1 for grant in y28_deaths for recipient in grant["recipients"]
        if recipient["mode"] == "blocked_preserved_rng"
    )
    row = {
        "experiment": exp.code,
        "label": exp.label,
        **summary,
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "changed_key_count": len(changed),
        "changed_keys": ",".join(changed),
        "y28_death_count": len(y28_deaths),
        "y28_regular_or_broadcast_recipients": y28_regular_recipients,
        "y28_blocked_recipients": y28_blocked_recipients,
    }
    rows.append(row)
    details["experiments"][exp.code] = {
        "label": exp.label,
        "summary": summary,
        "changed_keys_vs_baseline": changed,
        "first_diff_vs_baseline": first_diff,
        "death_grants_Y27_Y31": sim.death_grants,
        "yearly_Y27_Y31": sim.yearly,
        "p000_years_Y27_Y31": sim.p000_years,
        "p000_events_Y28_Y38": sim.p000_events_y28_y38,
    }

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_path = OUT_DIR / "society_lab_seed1003_y28_death_cluster_tests.py"
report_path = OUT_DIR / "society_lab_seed1003_y28_death_cluster_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_y28_death_cluster_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_y28_death_cluster_details.json"

script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

report = [
    "# seed1003 Y28 death cluster tests",
    "",
    "## Purpose",
    "",
    "This batch tests whether the Y28 cluster of deaths changes the v1.4 trajectory through death-memory distribution. Main experiments preserve deaths and block only memory distribution; the shift test is a separate timing intervention.",
    "",
    "## Results",
    "",
    "| exp | intervention | final pop | births | failures | memory shares | shared narratives | first diff | changed keys | Y28 deaths | Y28 recipients | blocked |",
    "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
]
for row in rows:
    report.append(
        f"| {row['experiment']} | {row['label']} | {row['final_population']} | "
        f"{row['birth_count']} | {row['project_failure_count']} | {row['memory_shared_count']} | "
        f"{row['shared_narrative_count']} | {row['first_diff_index']} | {row['changed_key_count']} | "
        f"{row['y28_death_count']} | {row['y28_regular_or_broadcast_recipients']} | {row['y28_blocked_recipients']} |"
    )

report.extend(["", "## Yearly Village State Y27-Y31", ""])
for code in [exp.code for exp in EXPERIMENTS]:
    report.extend([f"### {code}", "", "```json"])
    report.append(json.dumps(details["experiments"][code]["yearly_Y27_Y31"], ensure_ascii=False, indent=2))
    report.extend(["```", ""])

report.extend(
    [
        "## Cautious Reading",
        "",
        "- The block-distribution experiments isolate death-memory delivery while preserving the deaths themselves and preserving interpretation RNG calls for blocked grants.",
        "- CL_SHIFT_Y28_DEATHS_TO_Y29 is not directly comparable to the distribution-only cuts; it changes survival/timing and should be read as a timing stress test.",
        "- `悲しみ` or `喪中` is a narrative interpretation. The empirical layer is death events, death-memory recipients, strongest_memory counts, and trajectory divergence.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
