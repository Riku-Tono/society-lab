from __future__ import annotations

import csv
import importlib.util
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
CSV_PATH = OUT_DIR / "society_lab_v1_4_pathway_classification.csv"
REPORT_PATH = OUT_DIR / "society_lab_v1_4_pathway_audit.md"

SEEDS = range(1000, 1100)
YEARS = 80

SUMMARY_KEYS = (
    "final_population",
    "final_food_stock",
    "birth_count",
    "death_count",
    "proposal_count",
    "project_failure_count",
    "memory_shared_count",
    "shared_narrative_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
    "avg_bias_spiritual",
    "avg_bias_practical",
    "avg_bias_blame",
)


@dataclass(frozen=True)
class FirstDiff:
    index: int
    year: int
    family: str
    v13: str
    v14: str
    changed_person_id: str
    changed_person_name: str
    changed_action: str
    changed_project_key: str
    supporters_v13: int | None
    supporters_v14: int | None
    added_supporters: tuple[str, ...]
    removed_supporters: tuple[str, ...]


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def run_sim(module: ModuleType, seed: int) -> object:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim


def compact_event(entry: object | None) -> str:
    if entry is None:
        return "<end>"
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def event_family(entry: object | None) -> str:
    if entry is None:
        return "none"
    if entry.event_type == "proposal_supported":
        return "support_choice"
    if entry.event_type == "proposal_made":
        return "proposal_choice"
    if entry.event_type == "memory_shared":
        return "memory"
    return "event"


def action_from_supported(detail: str) -> str:
    match = re.search(r"supported\s+(\w+)", detail)
    return match.group(1) if match else ""


def action_from_proposed(detail: str) -> str:
    match = re.search(r"proposed\s+(\w+)", detail)
    return match.group(1) if match else ""


def problem_from_project(detail: str) -> str:
    match = re.search(r"for\s+(\w+)", detail)
    return match.group(1) if match else ""


def project_key(action: str, problem: str) -> str:
    return f"{action}:{problem}" if action and problem else ""


def person_name(sim: object, person_id: str) -> str:
    if not person_id:
        return ""
    try:
        return sim._person(person_id).name
    except Exception:
        return ""


def support_sets_at_year(sim: object, year: int) -> dict[str, set[str]]:
    proposals: dict[str, set[str]] = defaultdict(set)
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type != "proposal_supported" or len(entry.persons) < 2:
            continue
        supporter, proposer = entry.persons[0], entry.persons[1]
        action = action_from_supported(entry.detail)
        proposals[f"{proposer}:{action}"].add(supporter)
    return dict(proposals)


def first_log_diff(before: object, after: object) -> tuple[int, object | None, object | None] | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return index, before_entries[index], after_entries[index]
    if len(before_entries) != len(after_entries):
        left = None if len(before_entries) <= limit else before_entries[limit]
        right = None if len(after_entries) <= limit else after_entries[limit]
        return limit, left, right
    return None


def first_diff_details(seed: int, before: object, after: object) -> FirstDiff | None:
    diff = first_log_diff(before, after)
    if diff is None:
        return None
    index, left, right = diff
    entry = right or left
    year = int(entry.year)
    family = event_family(entry)
    changed_person_id = ""
    changed_action = ""
    changed_key = ""
    supporters_v13 = None
    supporters_v14 = None
    added: tuple[str, ...] = ()
    removed: tuple[str, ...] = ()

    if family == "support_choice" and right is not None and len(right.persons) >= 2:
        changed_person_id = right.persons[0]
        proposer = right.persons[1]
        changed_action = action_from_supported(right.detail)
        support_key = f"{proposer}:{changed_action}"
        before_supports = support_sets_at_year(before, year).get(support_key, set())
        after_supports = support_sets_at_year(after, year).get(support_key, set())
        supporters_v13 = len(before_supports)
        supporters_v14 = len(after_supports)
        added = tuple(sorted(after_supports - before_supports))
        removed = tuple(sorted(before_supports - after_supports))
        # Infer the target problem from project_started at the same year and action.
        for project_entry in after.log.entries:
            if project_entry.year == year and project_entry.event_type == "project_started":
                if f"project_started: {changed_action} for " in project_entry.detail:
                    changed_key = project_key(changed_action, problem_from_project(project_entry.detail))
                    break
    elif family == "proposal_choice" and right is not None and right.persons:
        changed_person_id = right.persons[0]
        changed_action = action_from_proposed(right.detail)
        changed_key = project_key(changed_action, problem_from_project(right.detail))
    elif entry is not None and entry.persons:
        changed_person_id = entry.persons[0]

    return FirstDiff(
        index=index,
        year=year,
        family=family,
        v13=compact_event(left),
        v14=compact_event(right),
        changed_person_id=changed_person_id,
        changed_person_name=person_name(after, changed_person_id),
        changed_action=changed_action,
        changed_project_key=changed_key,
        supporters_v13=supporters_v13,
        supporters_v14=supporters_v14,
        added_supporters=added,
        removed_supporters=removed,
    )


def summary_changed(before: object, after: object) -> bool:
    left = before.summary()
    right = after.summary()
    return any(left[key] != right[key] for key in SUMMARY_KEYS)


def delta(before: object, after: object, key: str) -> float:
    left = before.summary()[key]
    right = after.summary()[key]
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return float(right) - float(left)
    return 0.0


def project_events_by_key(sim: object, start_year: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if entry.year < start_year or entry.event_type not in {"project_success", "project_failure"}:
            continue
        action_match = re.search(r"project_(?:success|failure):\s+(\w+)\s+for\s+(\w+)", entry.detail)
        if not action_match:
            continue
        counts[f"{entry.event_type}:{action_match.group(1)}:{action_match.group(2)}"] += 1
    return counts


def memory_events_by_name(sim: object, start_year: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if entry.year < start_year or entry.event_type != "memory_shared":
            continue
        match = re.search(r"about\s+([^\s]+)\s+intensity=", entry.detail)
        if match:
            counts[match.group(1)] += 1
    return counts


def changed_project_result(first: FirstDiff | None, before: object, after: object) -> bool:
    if first is None:
        return False
    before_counts = project_events_by_key(before, first.year)
    after_counts = project_events_by_key(after, first.year)
    return before_counts != after_counts


def memory_connection_strength(first: FirstDiff | None, before: object, after: object) -> tuple[int, str]:
    if first is None:
        return 0, ""
    before_mem = memory_events_by_name(before, first.year)
    after_mem = memory_events_by_name(after, first.year)
    diffs: list[tuple[int, str]] = []
    for name in set(before_mem) | set(after_mem):
        diff = after_mem[name] - before_mem[name]
        if diff:
            diffs.append((abs(diff), f"{name}:{diff:+d}"))
    if not diffs:
        return 0, ""
    diffs.sort(reverse=True)
    return diffs[0][0], "; ".join(text for _, text in diffs[:5])


def pathway_type(first: FirstDiff | None, before: object, after: object) -> tuple[str, str]:
    if first is None:
        return "E_no_log_change", "nudge did not change event path"

    changed = summary_changed(before, after)
    mem_strength, mem_note = memory_connection_strength(first, before, after)
    project_result_changed = changed_project_result(first, before, after)
    pop_delta = delta(before, after, "final_population")
    food_delta = delta(before, after, "final_food_stock")
    fail_delta = delta(before, after, "project_failure_count")
    mem_delta = delta(before, after, "memory_shared_count")

    if not changed:
        return "D_absorbed", "log changed, but final summary returned"

    if first.family == "proposal_choice":
        if pop_delta > 0:
            return "C_collapse_avoidance_or_growth", "proposal change with population gain"
        return "F_proposal_path_changed", "proposal choice changed and summary changed"

    if pop_delta > 0:
        return "C_collapse_avoidance_or_growth", "population increased relative to v1.3"

    if project_result_changed and fail_delta > 0 and mem_strength >= 10:
        return "A_failure_memory_shrink", "project/failure mix and memory network changed"

    if mem_strength >= 20:
        return "B_memory_composition_shrink", "large memory composition shift after support change"

    if project_result_changed:
        return "G_project_result_path_changed", "project result mix changed without large memory shift"

    if mem_delta <= -20 and pop_delta < 0:
        return "B_memory_composition_shrink", "memory sharing fell with population loss"

    return "H_summary_changed_unclear_path", "summary changed, but path needs manual reading"


def analyze_seed(seed: int, v13: ModuleType, v14: ModuleType) -> dict[str, Any]:
    before = run_sim(v13, seed)
    after = run_sim(v14, seed)
    first = first_diff_details(seed, before, after)
    ptype, reason = pathway_type(first, before, after)
    mem_strength, mem_note = memory_connection_strength(first, before, after)
    result_changed = changed_project_result(first, before, after)
    before_summary = before.summary()
    after_summary = after.summary()

    return {
        "seed": seed,
        "pathway_type": ptype,
        "reason": reason,
        "summary_changed": summary_changed(before, after),
        "first_diff_year": first.year if first else "",
        "first_diff_family": first.family if first else "none",
        "first_diff_v13": first.v13 if first else "",
        "first_diff_v14": first.v14 if first else "",
        "changed_person_id": first.changed_person_id if first else "",
        "changed_person_name": first.changed_person_name if first else "",
        "changed_action": first.changed_action if first else "",
        "changed_project_key": first.changed_project_key if first else "",
        "supporters_v13": first.supporters_v13 if first and first.supporters_v13 is not None else "",
        "supporters_v14": first.supporters_v14 if first and first.supporters_v14 is not None else "",
        "added_supporters": ",".join(first.added_supporters) if first else "",
        "removed_supporters": ",".join(first.removed_supporters) if first else "",
        "project_result_changed_after_first_diff": result_changed,
        "memory_connection_strength": mem_strength,
        "top_memory_diffs_after_first_diff": mem_note,
        "diff_population": delta(before, after, "final_population"),
        "diff_food": delta(before, after, "final_food_stock"),
        "diff_birth": delta(before, after, "birth_count"),
        "diff_death": delta(before, after, "death_count"),
        "diff_project_failure": delta(before, after, "project_failure_count"),
        "diff_memory_shared": delta(before, after, "memory_shared_count"),
        "diff_shared_narrative": delta(before, after, "shared_narrative_count"),
        "diff_network_split": delta(before, after, "network_split_count"),
        "diff_narrative_divergence": delta(before, after, "narrative_divergence_count"),
        "diff_interpretation_divergence": delta(before, after, "interpretation_divergence_count"),
        "diff_bias_blame": delta(before, after, "avg_bias_blame"),
        "action_nudges": after_summary.get("interpretation_action_nudge_count", 0),
        "support_nudges": after_summary.get("interpretation_support_nudge_count", 0),
        "v13_population": before_summary["final_population"],
        "v14_population": after_summary["final_population"],
        "v13_food": before_summary["final_food_stock"],
        "v14_food": after_summary["final_food_stock"],
    }


def write_csv(rows: list[dict[str, Any]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def build_report(rows: list[dict[str, Any]]) -> str:
    type_counts = Counter(row["pathway_type"] for row in rows)
    family_counts = Counter(row["first_diff_family"] for row in rows)
    changed = [row for row in rows if row["summary_changed"]]
    lines: list[str] = []
    lines.append("# society_lab v1.4 pathway audit")
    lines.append("")
    lines.append("Pathway classification for seeds 1000-1099. This is a heuristic audit, not a final interpretation.")
    lines.append("")
    lines.append("## Pathway Counts")
    lines.append("")
    lines.extend(md_table(["pathway", "count"], [[key, type_counts[key]] for key in sorted(type_counts)]))
    lines.append("")
    lines.append("## First Diff Families")
    lines.append("")
    lines.extend(md_table(["family", "count"], [[key, family_counts[key]] for key in sorted(family_counts)]))
    lines.append("")
    lines.append("## Pathway Definitions")
    lines.append("")
    lines.extend(
        md_table(
            ["pathway", "working meaning"],
            [
                ["A_failure_memory_shrink", "support/proposal difference reaches project/failure and memory network, with shrinkage"],
                ["B_memory_composition_shrink", "support difference changes the remembered story mix and ends smaller"],
                ["C_collapse_avoidance_or_growth", "v1.4 preserves or grows population relative to v1.3"],
                ["D_absorbed", "event log changes but final summary returns"],
                ["E_no_log_change", "nudge never changes event path"],
                ["F_proposal_path_changed", "proposal choice changes and final summary changes"],
                ["G_project_result_path_changed", "project result mix changes without large memory shift"],
                ["H_summary_changed_unclear_path", "summary changes but heuristic path is unclear"],
            ],
        )
    )
    lines.append("")
    lines.append("## Representative Seeds")
    lines.append("")
    reps = []
    for ptype in sorted(type_counts):
        sample = [row for row in rows if row["pathway_type"] == ptype][:8]
        reps.append([ptype, ", ".join(str(row["seed"]) for row in sample)])
    lines.extend(md_table(["pathway", "sample seeds"], reps))
    lines.append("")
    lines.append("## Summary-Changed Detail")
    lines.append("")
    detail_rows = []
    for row in changed:
        detail_rows.append(
            [
                row["seed"],
                row["pathway_type"],
                row["first_diff_year"],
                row["first_diff_family"],
                row["changed_action"],
                row["diff_population"],
                row["diff_food"],
                row["diff_project_failure"],
                row["diff_memory_shared"],
                row["memory_connection_strength"],
            ]
        )
    lines.extend(
        md_table(
            [
                "seed",
                "pathway",
                "first year",
                "family",
                "action",
                "pop",
                "food",
                "fail",
                "memshare",
                "mem path strength",
            ],
            detail_rows,
        )
    )
    lines.append("")
    lines.append("## Cautions")
    lines.append("")
    lines.append("- This classification is based on log-derived heuristics. Borderline cases need manual deep reading.")
    lines.append("- `memory_connection_strength` is the largest absolute post-first-diff memory-share delta by event name, not proof of causality.")
    lines.append("- A seed can be socially interesting even if it lands in `H_summary_changed_unclear_path`.")
    lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "The key split is not result shape alone. The model separates into no path change, absorbed path change, "
        "and several amplified path changes. This supports using v1.4 as a pathway audit baseline before adding external shocks."
    )
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    v13 = load_module("society_lab_v1_3_pathway", V13_PATH)
    v14 = load_module("society_lab_v1_4_pathway", V14_PATH)
    rows = [analyze_seed(seed, v13, v14) for seed in SEEDS]
    write_csv(rows)
    REPORT_PATH.write_text(build_report(rows), encoding="utf-8")
    print(CSV_PATH)
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
