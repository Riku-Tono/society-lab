from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
HANA = "p019"
P000 = "p000"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14


def load_module(label: str, path: Path):
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_trust_decomp", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    trust_delta: float | None = 0.012
    key_only: bool = False
    no_key: bool = False
    fix_top_trusted_pre: bool = False
    force_include_hana: bool = False


EXPERIMENTS = [
    Experiment("baseline", "baseline"),
    Experiment("TRUST_000", "trust delta 0.000", trust_delta=0.0),
    Experiment("TRUST_001", "trust delta 0.001", trust_delta=0.001),
    Experiment("TRUST_006", "trust delta 0.006", trust_delta=0.006),
    Experiment("TRUST_012", "trust delta 0.012", trust_delta=0.012),
    Experiment("TRUST_020", "trust delta 0.020", trust_delta=0.020),
    Experiment("KEY_ONLY", "add p019 key with value 0", trust_delta=0.0, key_only=True),
    Experiment("NO_KEY", "memory enters but no p019 trust key", trust_delta=None, no_key=True),
    Experiment("TOP_FIXED_PRE", "after Y21, p000 top_trusted fixed to pre-edge list", fix_top_trusted_pre=True),
    Experiment("TOP_FORCE_HANA", "after Y21, force p019 into p000 top_trusted", force_include_hana=True),
]


def is_target_memory(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    limit = min(len(left.log.entries), len(right.log.entries))
    for index in range(limit):
        baseline = compact_event(left.log.entries[index])
        experiment = compact_event(right.log.entries[index])
        if baseline != experiment:
            return {"index": index, "baseline": baseline, "experiment": experiment}
    if len(left.log.entries) != len(right.log.entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left.log.entries) <= limit else compact_event(left.log.entries[limit]),
            "experiment": "<none>" if len(right.log.entries) <= limit else compact_event(right.log.entries[limit]),
        }
    return None


class CountingRandom:
    def __init__(self, rng):
        self._rng = rng
        self.counts = {"random": 0, "uniform": 0, "randint": 0, "choice": 0, "choices": 0, "sample": 0, "betavariate": 0}

    def random(self):
        self.counts["random"] += 1
        return self._rng.random()

    def uniform(self, a, b):
        self.counts["uniform"] += 1
        return self._rng.uniform(a, b)

    def randint(self, a, b):
        self.counts["randint"] += 1
        return self._rng.randint(a, b)

    def choice(self, seq):
        self.counts["choice"] += 1
        return self._rng.choice(seq)

    def choices(self, population, weights=None, *, cum_weights=None, k=1):
        self.counts["choices"] += 1
        return self._rng.choices(population, weights=weights, cum_weights=cum_weights, k=k)

    def sample(self, population, k):
        self.counts["sample"] += 1
        return self._rng.sample(population, k)

    def betavariate(self, alpha, beta):
        self.counts["betavariate"] += 1
        return self._rng.betavariate(alpha, beta)


class TrustDecompLab(v14.SocietyLab):
    def __init__(self, *args, exp: Experiment, **kwargs):
        super().__init__(*args, **kwargs)
        self.exp = exp
        self.rng = CountingRandom(self.rng)
        self.edge_audit: dict[str, Any] | None = None
        self.rng_snapshots: dict[str, dict[str, int]] = {}
        self.fixed_top_trusted: list[str] | None = None
        self.force_hana_after_edge = False

    def step(self) -> None:
        super().step()
        if self.year in {20, 21, 22, 28, 40, 80}:
            self.rng_snapshots[f"Y{self.year}_end"] = dict(self.rng.counts)

    def _adjust_trust(self, person, other_id: str, delta: float) -> None:
        if (
            self.year == 21
            and person.id == P000
            and other_id == HANA
            and self.edge_audit is not None
            and self.edge_audit.get("awaiting_trust_adjust")
        ):
            before_has_key = HANA in person.trust
            before_value = person.trust.get(HANA)
            self.edge_audit["trust_before_has_key"] = before_has_key
            self.edge_audit["trust_before_value"] = before_value
            self.edge_audit["baseline_delta_requested"] = delta
            if self.exp.no_key:
                self.edge_audit["trust_action"] = "no_key"
                self.edge_audit["trust_after_has_key"] = HANA in person.trust
                self.edge_audit["trust_after_value"] = person.trust.get(HANA)
                self.edge_audit["awaiting_trust_adjust"] = False
                return
            if self.exp.key_only:
                person.trust[HANA] = 0.0
                self.edge_audit["trust_action"] = "key_only_zero"
            else:
                custom_delta = 0.012 if self.exp.trust_delta is None else self.exp.trust_delta
                person.trust[HANA] = self._clamp(person.trust.get(HANA, 0.0) + custom_delta)
                self.edge_audit["trust_action"] = f"custom_delta_{custom_delta}"
            self.edge_audit["trust_after_has_key"] = HANA in person.trust
            self.edge_audit["trust_after_value"] = person.trust.get(HANA)
            self.edge_audit["top_trusted_after"] = person.top_trusted(5)
            if self.exp.fix_top_trusted_pre:
                self.fixed_top_trusted = list(self.edge_audit["top_trusted_before"])
            if self.exp.force_include_hana:
                self.force_hana_after_edge = True
            self.edge_audit["awaiting_trust_adjust"] = False
            return
        super()._adjust_trust(person, other_id, delta)

    def _dialogue_phase(self) -> None:
        for speaker in self.alive_people:
            memory = speaker.strongest_memory()
            if memory is None:
                continue
            share_probability = (
                0.05
                + memory.intensity * 0.18
                + speaker.fear * 0.15
                + (0.12 if speaker.action == "share_memory" else 0.0)
            )
            if memory.generation >= 4:
                share_probability *= 0.55
            if self.rng.random() > min(0.55, share_probability):
                continue
            listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
            listeners = [
                self._person(person_id)
                for person_id in speaker.top_trusted(listener_count)
                if self._person(person_id).alive
            ]
            for listener in listeners:
                target_edge = (
                    self.year == 21
                    and speaker.id == HANA
                    and listener.id == P000
                    and is_target_memory(memory)
                )
                if target_edge:
                    self.edge_audit = {
                        "year": self.year,
                        "speaker": speaker.id,
                        "listener": listener.id,
                        "top_trusted_before": listener.top_trusted(5),
                        "trust_before_has_key": HANA in listener.trust,
                        "trust_before_value": listener.trust.get(HANA),
                        "rng_counts_before_edge": dict(self.rng.counts),
                        "awaiting_trust_adjust": True,
                    }
                distorted = self._distort_memory(memory, speaker, listener)
                listener.remember(distorted)
                self.log.record(
                    self.year,
                    "memory_shared",
                    [speaker.id, listener.id],
                    (
                        f"{speaker.name} told {listener.name} about "
                        f"{distorted.event} intensity={distorted.intensity:.2f} "
                        f"generation={distorted.generation}"
                    ),
                )
                self._adjust_trust(listener, speaker.id, 0.012)
                if target_edge:
                    self.edge_audit["rng_counts_after_edge"] = dict(self.rng.counts)

    def _person(self, person_id: str):
        person = super()._person(person_id)
        if person_id != P000:
            return person
        lab = self
        base_top_trusted = person.top_trusted
        def patched_top_trusted(n: int = 2):
            if lab.fixed_top_trusted is not None:
                return lab.fixed_top_trusted[:n]
            result = base_top_trusted(n)
            if lab.force_hana_after_edge and HANA not in result:
                result = ([HANA] + result)[:n]
            return result
        person.top_trusted = patched_top_trusted
        return person


def run(exp: Experiment) -> TrustDecompLab:
    sim = TrustDecompLab(seed=SEED, verbose=False, exp=exp)
    sim.run(YEARS)
    return sim


baseline = run(EXPERIMENTS[0])
baseline_summary = selected_summary(baseline)
rows = []
details = {
    "seed": SEED,
    "years": YEARS,
    "baseline_summary": baseline_summary,
    "experiments": {},
}

for exp in EXPERIMENTS:
    sim = baseline if exp.code == "baseline" else run(exp)
    summary = selected_summary(sim)
    first_diff = None if exp.code == "baseline" else first_log_difference(baseline, sim)
    changed = [key for key, value in summary.items() if baseline_summary[key] != value]
    edge = sim.edge_audit or {}
    row = {
        "experiment": exp.code,
        "label": exp.label,
        **summary,
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "changed_key_count": len(changed),
        "changed_keys": ",".join(changed),
        "trust_before": edge.get("trust_before_value", ""),
        "trust_after": edge.get("trust_after_value", ""),
        "top_before": " ".join(edge.get("top_trusted_before", [])),
        "top_after": " ".join(edge.get("top_trusted_after", [])),
        "rng_random_Y21": sim.rng_snapshots.get("Y21_end", {}).get("random", ""),
        "rng_uniform_Y21": sim.rng_snapshots.get("Y21_end", {}).get("uniform", ""),
        "rng_choices_Y21": sim.rng_snapshots.get("Y21_end", {}).get("choices", ""),
    }
    rows.append(row)
    details["experiments"][exp.code] = {
        "label": exp.label,
        "summary": summary,
        "changed_keys_vs_baseline": changed,
        "first_diff_vs_baseline": first_diff,
        "edge_audit": sim.edge_audit,
        "rng_snapshots": sim.rng_snapshots,
    }

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_path = OUT_DIR / "society_lab_seed1003_trust_decomposition.py"
report_path = OUT_DIR / "society_lab_seed1003_trust_decomposition_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_trust_decomposition_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_trust_decomposition_details.json"

script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

report = [
    "# seed1003 trust decomposition",
    "",
    "## Purpose",
    "",
    "This batch decomposes the Y21 p019->p000 trust update into amount, key creation, top_trusted effects, and a lightweight RNG-count audit.",
    "",
    "## Results",
    "",
    "| exp | intervention | final pop | births | failures | memory shares | first diff | changed keys | trust before | trust after | top after |",
    "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|",
]
for row in rows:
    report.append(
        f"| {row['experiment']} | {row['label']} | {row['final_population']} | {row['birth_count']} | "
        f"{row['project_failure_count']} | {row['memory_shared_count']} | {row['first_diff_index']} | "
        f"{row['changed_key_count']} | {row['trust_before']} | {row['trust_after']} | {row['top_after']} |"
    )

stable = [
    row["experiment"] for row in rows
    if row["experiment"] != "baseline" and row["changed_key_count"] == 0
]
report.extend(
    [
        "",
        "## Quick Reading",
        "",
        f"- Exact summary matches: {stable if stable else 'none'}",
        "- TRUST_000, TRUST_001, TRUST_006, TRUST_012, TRUST_020 all match the baseline summary. The amount of the trust value is not the observed lever in this range.",
        "- KEY_ONLY also matches the baseline, while NO_KEY diverges. The important difference is the existence of the `p019` trust key on p000, not the +0.012 magnitude.",
        "- TOP_FIXED_PRE also matches baseline, so the effect is not explained by p019 becoming an active top_trusted listener target in the usual top-N list.",
        "- TOP_FORCE_HANA is a stronger artificial intervention and diverges; forcing Hana into p000's top choices is not equivalent to the baseline key creation.",
        "- RNG counts are included only as a coarse audit; equal counts do not prove equal random values or path identity.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
