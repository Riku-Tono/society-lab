from __future__ import annotations

import csv
import importlib.util
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
REPORT_PATH = OUT_DIR / "society_lab_seed_1024_fertility_path.md"
CSV_PATH = OUT_DIR / "society_lab_seed_1024_fertility_path.csv"

SEED = 1024
YEARS = 65
WATCH_YEARS = set(range(38, 66))


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def alive_people(sim: object) -> list[object]:
    return list(sim.alive_people)


def fertile_people(sim: object) -> list[object]:
    return [person for person in alive_people(sim) if person.can_give_birth()]


def parent_generation_people(sim: object) -> list[object]:
    return [person for person in alive_people(sim) if 18 <= person.age <= 55]


def incoming_trust(sim: object, person_id: str) -> float:
    values = [
        person.trust[person_id]
        for person in alive_people(sim)
        if person_id in person.trust and person.alive
    ]
    return sum(values) / len(values) if values else 0.0


def top_incoming_trust(sim: object, n: int = 5) -> list[str]:
    rows = []
    for person in alive_people(sim):
        rows.append((incoming_trust(sim, person.id), person.id, person.name))
    rows.sort(reverse=True)
    return [f"{pid}:{name}:{value:.3f}" for value, pid, name in rows[:n]]


def support_targets(sim: object, year: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if entry.year == year and entry.event_type == "proposal_supported" and len(entry.persons) >= 2:
            action = re.search(r"supported\s+(\w+)", entry.detail)
            action_name = action.group(1) if action else "unknown"
            counts[action_name] += 1
    return counts


def authority_patterns(sim: object, start: int, end: int) -> list[str]:
    return [
        f"Y{entry.year:02d} {entry.detail}"
        for entry in sim.log.entries
        if start <= entry.year <= end and entry.event_type == "authority_pattern"
    ]


def deaths_by_year(sim: object, year: int) -> list[str]:
    rows = []
    for entry in sim.log.entries:
        if entry.year == year and entry.event_type == "death" and entry.persons:
            pid = entry.persons[0]
            rows.append(f"{pid}:{entry.detail}")
    return rows


def births_by_year(sim: object, year: int) -> list[str]:
    rows = []
    for entry in sim.log.entries:
        if entry.year == year and entry.event_type == "birth":
            rows.append(":".join(entry.persons) + ":" + entry.detail)
    return rows


def alive_roster(sim: object) -> list[str]:
    return [person_brief(person) for person in alive_people(sim)]


def support_details(sim: object, year: int) -> list[str]:
    rows = []
    for entry in sim.log.entries:
        if entry.year == year and entry.event_type == "proposal_supported":
            rows.append(entry.detail)
    return rows


def person_brief(person: object) -> str:
    return (
        f"{person.id}:{person.name}:age={person.age}:sex={person.sex}:"
        f"health={person.health:.2f}:hunger={person.hunger:.2f}:"
        f"charisma={person.charisma:.2f}:food={person.food_skill:.2f}"
    )


def snapshot(sim: object, version: str, year: int) -> dict[str, Any]:
    summary = sim.summary()
    fertile = fertile_people(sim)
    parents = parent_generation_people(sim)
    fertile_ids = [person_brief(person) for person in fertile]
    parent_ids = [person_brief(person) for person in parents]
    supports = support_targets(sim, year)
    return {
        "version": version,
        "year": year,
        "population": summary["final_population"],
        "food": summary["final_food_stock"],
        "birth_count": summary["birth_count"],
        "death_count": summary["death_count"],
        "fertile_count": len(fertile),
        "fertile_people": " | ".join(fertile_ids),
        "parent_generation_count": len(parents),
        "parent_generation_people": " | ".join(parent_ids),
        "avg_fear": summary["avg_fear"],
        "avg_hunger": summary["avg_hunger"],
        "avg_bias_blame": summary["avg_bias_blame"],
        "top_incoming_trust": " | ".join(top_incoming_trust(sim)),
        "support_targets": " | ".join(f"{key}:{value}" for key, value in supports.most_common()),
        "support_details": " | ".join(support_details(sim, year)),
        "deaths_this_year": " | ".join(deaths_by_year(sim, year)),
        "births_this_year": " | ".join(births_by_year(sim, year)),
        "alive_roster": " | ".join(alive_roster(sim)),
    }


def run_watch(module: ModuleType, version: str) -> tuple[object, list[dict[str, Any]]]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    rows = []
    for _ in range(YEARS):
        if sim.population == 0:
            break
        sim.step()
        if sim.year in WATCH_YEARS:
            rows.append(snapshot(sim, version, sim.year))
    return sim, rows


def write_csv(rows: list[dict[str, Any]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    def cell(value: Any) -> str:
        return str(value).replace("|", "\\|")

    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(cell(item) for item in row) + " |")
    return lines


def compare_years(v13_rows: list[dict[str, Any]], v14_rows: list[dict[str, Any]]) -> list[list[Any]]:
    by13 = {row["year"]: row for row in v13_rows}
    by14 = {row["year"]: row for row in v14_rows}
    rows = []
    for year in sorted(set(by13) | set(by14)):
        left = by13[year]
        right = by14[year]
        rows.append(
            [
                year,
                f"{left['population']}->{right['population']}",
                f"{left['fertile_count']}->{right['fertile_count']}",
                f"{left['parent_generation_count']}->{right['parent_generation_count']}",
                f"{left['birth_count']}->{right['birth_count']}",
                f"{left['death_count']}->{right['death_count']}",
                f"{left['food']:.3f}->{right['food']:.3f}",
                f"{left['avg_hunger']:.3f}->{right['avg_hunger']:.3f}",
            ]
        )
    return rows


def build_report() -> str:
    v13 = load_module("society_lab_v1_3_seed1024_fertility", V13_PATH)
    v14 = load_module("society_lab_v1_4_seed1024_fertility", V14_PATH)
    sim13, rows13 = run_watch(v13, "v1.3")
    sim14, rows14 = run_watch(v14, "v1.4")
    all_rows = rows13 + rows14
    write_csv(all_rows)

    lines: list[str] = []
    lines.append("# society_lab seed 1024 fertility path")
    lines.append("")
    lines.append("Focus: what changed before the birth gap opened between Year 38 and Year 65.")
    lines.append("")
    lines.append("## Fertility / Parent Generation Timeline")
    lines.append("")
    lines.extend(
        md_table(
            ["year", "pop", "fertile", "parent_gen", "births", "deaths", "food", "avg_hunger"],
            compare_years(rows13, rows14),
        )
    )
    lines.append("")
    lines.append("## Fertile People At Key Years")
    lines.append("")
    for year in (38, 45, 50, 55, 60, 65):
        left = next(row for row in rows13 if row["year"] == year)
        right = next(row for row in rows14 if row["year"] == year)
        lines.append(f"### Year {year}")
        lines.append("")
        lines.extend(
            md_table(
                ["version", "fertile_count", "fertile_people"],
                [
                    ["v1.3", left["fertile_count"], left["fertile_people"] or "-"],
                    ["v1.4", right["fertile_count"], right["fertile_people"] or "-"],
                ],
            )
        )
        lines.append("")
    lines.append("## Deaths And Births During Watch Window")
    lines.append("")
    for year in range(38, 66):
        left = next(row for row in rows13 if row["year"] == year)
        right = next(row for row in rows14 if row["year"] == year)
        if left["deaths_this_year"] or right["deaths_this_year"] or left["births_this_year"] or right["births_this_year"]:
            lines.append(f"### Year {year}")
            lines.append("")
            lines.extend(
                md_table(
                    ["version", "births", "deaths"],
                    [
                        ["v1.3", left["births_this_year"] or "-", left["deaths_this_year"] or "-"],
                        ["v1.4", right["births_this_year"] or "-", right["deaths_this_year"] or "-"],
                    ],
                )
            )
            lines.append("")
    lines.append("## Trust And Support")
    lines.append("")
    for year in (38, 45, 50, 55, 60, 65):
        left = next(row for row in rows13 if row["year"] == year)
        right = next(row for row in rows14 if row["year"] == year)
        lines.append(f"### Year {year}")
        lines.append("")
        lines.extend(
            md_table(
                ["version", "top incoming trust", "support targets"],
                [
                    ["v1.3", left["top_incoming_trust"], left["support_targets"] or "-"],
                    ["v1.4", right["top_incoming_trust"], right["support_targets"] or "-"],
                ],
            )
        )
        lines.append("")
    lines.append("## Support Details At Key Years")
    lines.append("")
    for year in (38, 45, 50, 65):
        left = next(row for row in rows13 if row["year"] == year)
        right = next(row for row in rows14 if row["year"] == year)
        lines.append(f"### Year {year}")
        lines.append("")
        lines.extend(
            md_table(
                ["version", "support details"],
                [
                    ["v1.3", left["support_details"] or "-"],
                    ["v1.4", right["support_details"] or "-"],
                ],
            )
        )
        lines.append("")
    lines.append("## Alive Roster At Structural Breakpoints")
    lines.append("")
    for year in (38, 46, 60, 65):
        left = next(row for row in rows13 if row["year"] == year)
        right = next(row for row in rows14 if row["year"] == year)
        lines.append(f"### Year {year}")
        lines.append("")
        lines.extend(
            md_table(
                ["version", "alive roster"],
                [
                    ["v1.3", left["alive_roster"] or "-"],
                    ["v1.4", right["alive_roster"] or "-"],
                ],
            )
        )
        lines.append("")
    lines.append("## Authority Pattern")
    lines.append("")
    auth13 = authority_patterns(sim13, 38, 65)
    auth14 = authority_patterns(sim14, 38, 65)
    lines.extend(
        md_table(
            ["version", "authority events"],
            [
                ["v1.3", " | ".join(auth13) or "-"],
                ["v1.4", " | ".join(auth14) or "-"],
            ],
        )
    )
    lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "The key check is whether v1.3 loses fertile women or parent-generation population before v1.4 does. "
        "If fertile_count diverges before birth_count diverges, the birth gap is structural rather than merely random."
    )
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(build_report(), encoding="utf-8")
    print(REPORT_PATH)
    print(CSV_PATH)


if __name__ == "__main__":
    main()
