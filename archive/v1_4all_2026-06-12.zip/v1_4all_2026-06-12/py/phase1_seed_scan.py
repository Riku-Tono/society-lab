"""
Phase 1: seed1000-1099 divergence scan
=======================================

目的:
seed1003で見つかった「微小イベント→後続クラスター→軌道分岐」構造が
他seedにも存在するかを調べる第一段階。

方法:
各seedについて2つの世界を並走させる。

  baseline  : society_lab v1.4 そのまま
  nudge_off : 解釈ナッジ(action/support)だけを外科的に0化
              (乱数消費順は変えない。v1.3相当の「解釈→行動ブリッジなし」世界)

毎年stepごとに状態指紋を比較し、最初に分岐した年 (first_diff_year) を記録。
80年後の最終サマリ差も記録。

分類:
  no_divergence  : 80年間一度も分岐しない (ナッジが発火しなかった/効かなかった)
  transient      : 途中で分岐するが最終サマリはほぼ一致 (自己修復型)
  diverged       : 最終サマリが変わる (歴史が変わった)

さらにdivergedについて、分岐年の周辺イベントを分類:
  death_cluster / failure_cluster / crisis / council_path / share_path / other

元の society_lab_v1_4.py は一切変更しない。
"""

from __future__ import annotations

import csv
import json
import sys
from collections import Counter

from society_lab_v1_4 import SocietyLab


# ----------------------------------------------------------------------
# 外科的介入: ナッジ無効化サブクラス (乱数消費は不変)
# ----------------------------------------------------------------------
class SocietyLabNudgeOff(SocietyLab):
    """v1.4の解釈→行動ブリッジ(約3%ナッジ)だけを切る。

    _interpretation_action_nudge / _interpretation_support_nudge は
    乱数を消費しないため、0を返してもRNG列はbaselineと同期したまま。
    分岐が起きるとすれば「ナッジが実際に選択を変えた瞬間」以降のみ。
    """

    def _interpretation_action_nudge(self, interpretation: str, action: str) -> float:
        return 0.0

    def _interpretation_support_nudge(self, person, problem, proposal, proposer) -> float:
        return 0.0


# ----------------------------------------------------------------------
# 状態指紋: 年ごとの比較キー
# ----------------------------------------------------------------------
def fingerprint(sim: SocietyLab) -> tuple:
    people = sim.alive_people
    return (
        sim.population,
        round(sim.food.stock, 6),
        len(sim.log.entries),
        sum(len(p.memories) for p in people),
        round(sum(p.fear for p in people), 6),
        round(sum(p.hunger for p in people), 6),
    )


def year_events(sim: SocietyLab, year: int) -> Counter:
    return Counter(e.event_type for e in sim.log.entries if e.year == year)


def classify_divergence_year(base: SocietyLab, alt: SocietyLab, year: int) -> str:
    """分岐年とその前後1年のイベント構成から分岐型をラフ分類。"""
    window = Counter()
    for y in (year - 1, year, year + 1):
        window += year_events(base, y)
        window += year_events(alt, y)

    deaths = window.get("death", 0)
    failures = window.get("project_failure", 0)
    crises = window.get("crisis", 0)
    councils = window.get("council_formed", 0)
    shares = window.get("memory_shared", 0)
    births = window.get("birth", 0)

    if deaths >= 4:
        return "death_cluster"
    if crises >= 2:
        return "crisis"
    if failures >= 2:
        return "failure_cluster"
    if births >= 4:
        return "birth_cluster"
    if councils >= 2:
        return "council_path"
    if shares >= 8:
        return "share_path"
    return "other"


# ----------------------------------------------------------------------
# 1seed分のスキャン
# ----------------------------------------------------------------------
KEY_METRICS = (
    "final_population",
    "birth_count",
    "death_count",
    "project_success_count",
    "project_failure_count",
    "memory_shared_count",
    "shared_narrative_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
)


def scan_seed(seed: int, years: int = 80) -> dict:
    base = SocietyLab(seed=seed)
    alt = SocietyLabNudgeOff(seed=seed)

    first_diff_year = None
    for _ in range(years):
        if base.population == 0 and alt.population == 0:
            break
        if base.population > 0:
            base.step()
        if alt.population > 0:
            alt.step()
        if first_diff_year is None and fingerprint(base) != fingerprint(alt):
            first_diff_year = base.year

    bs, as_ = base.summary(), alt.summary()
    diffs = {k: as_[k] - bs[k] for k in KEY_METRICS}
    n_final_diffs = sum(1 for v in diffs.values() if v != 0)

    if first_diff_year is None:
        category = "no_divergence"
        div_type = "-"
    elif n_final_diffs == 0:
        category = "transient"
        div_type = classify_divergence_year(base, alt, first_diff_year)
    else:
        category = "diverged"
        div_type = classify_divergence_year(base, alt, first_diff_year)

    # 分岐の大きさスコア (人口差を重く)
    magnitude = (
        abs(diffs["final_population"]) * 3
        + abs(diffs["birth_count"]) * 2
        + abs(diffs["project_failure_count"]) * 2
        + abs(diffs["memory_shared_count"]) * 0.1
    )

    row = {
        "seed": seed,
        "category": category,
        "first_diff_year": first_diff_year if first_diff_year is not None else -1,
        "divergence_type": div_type,
        "magnitude": round(magnitude, 2),
        "base_action_nudges": bs["interpretation_action_nudge_count"],
        "base_support_nudges": bs["interpretation_support_nudge_count"],
        "base_final_population": bs["final_population"],
        "alt_final_population": as_["final_population"],
    }
    for k in KEY_METRICS:
        row[f"diff_{k}"] = diffs[k]
    return row


def main() -> None:
    start, end = 1000, 1100
    if len(sys.argv) >= 3:
        start, end = int(sys.argv[1]), int(sys.argv[2])

    rows = []
    for seed in range(start, end):
        rows.append(scan_seed(seed))
        r = rows[-1]
        print(
            f"seed{seed}: {r['category']:<13} first_diff={r['first_diff_year']:>3} "
            f"type={r['divergence_type']:<15} mag={r['magnitude']:>6} "
            f"pop {r['base_final_population']}->{r['alt_final_population']}"
        )

    with open("phase1_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    cats = Counter(r["category"] for r in rows)
    types = Counter(r["divergence_type"] for r in rows if r["category"] == "diverged")
    top = sorted(
        (r for r in rows if r["category"] == "diverged"),
        key=lambda r: r["magnitude"],
        reverse=True,
    )[:20]

    summary = {
        "seed_range": [start, end - 1],
        "category_counts": dict(cats),
        "diverged_type_counts": dict(types),
        "top20_by_magnitude": [
            {k: r[k] for k in (
                "seed", "first_diff_year", "divergence_type", "magnitude",
                "base_final_population", "alt_final_population",
                "diff_final_population", "diff_birth_count",
                "diff_project_failure_count", "diff_memory_shared_count",
            )}
            for r in top
        ],
    }
    with open("phase1_summary.json", "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print("\n=== Phase 1 summary ===")
    print("categories:", dict(cats))
    print("diverged types:", dict(types))
    print("\nTop 20 by magnitude:")
    for r in top:
        print(
            f"  seed{r['seed']}: mag={r['magnitude']:>6} first_diff=Y{r['first_diff_year']} "
            f"type={r['divergence_type']} pop {r['base_final_population']}->{r['alt_final_population']} "
            f"dpop={r['diff_final_population']:+d} dbirth={r['diff_birth_count']:+d} "
            f"dfail={r['diff_project_failure_count']:+d}"
        )


if __name__ == "__main__":
    main()
