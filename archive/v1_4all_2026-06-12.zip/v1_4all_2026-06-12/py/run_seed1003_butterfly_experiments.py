from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
TARGET_HANA = "p019"
TARGET_ZOL = "p000"
TARGET_ORUN = "p004"
TARGET_SHION = "p011"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v13 = load_module("society_lab_v1_3_for_butterfly", V13_PATH)
v14 = load_module("society_lab_v1_4_for_butterfly", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    remove_hana_year14_support: bool = False
    hana_no_target_memory: bool = False
    block_hana_target_sharing: bool = False
    blocked_edges: tuple[tuple[str, str], ...] = ()
    only_hana_target_listeners: tuple[str, ...] | None = None
    randomize_hana_target_listener_same_year: bool = False


EXPERIMENTS = [
    Experiment("v1.4", "baseline"),
    Experiment("A", "remove p019 Hana from Year14 supporters", remove_hana_year14_support=True),
    Experiment("B", "p019 Hana participates but does not remember Year14 failure", hana_no_target_memory=True),
    Experiment("C", "p019 Hana remembers but does not share Year14 failure", block_hana_target_sharing=True),
    Experiment("D", "block p019 Hana -> p004 Orun only", blocked_edges=((TARGET_HANA, TARGET_ORUN),)),
    Experiment("E", "block p004 Orun -> p011 Shion only", blocked_edges=((TARGET_ORUN, TARGET_SHION),)),
    Experiment("F", "no_hana_to_p000", blocked_edges=((TARGET_HANA, TARGET_ZOL),)),
    Experiment(
        "G",
        "only_hana_to_p000",
        only_hana_target_listeners=(TARGET_ZOL,),
    ),
    Experiment(
        "H",
        "only_hana_to_p004",
        only_hana_target_listeners=(TARGET_ORUN,),
    ),
    Experiment(
        "I",
        "randomized_hana_listener_same_year",
        randomize_hana_target_listener_same_year=True,
    ),
]


def is_target_memory(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def is_year14_target_proposal(sim: object, problem: object, proposal: object) -> bool:
    return (
        sim.year == TARGET_YEAR
        and problem.type == "water_shortage"
        and proposal.proposer_id == "p006"
        and proposal.action == "store_food"
    )


def make_lab_class(exp: Experiment):
    class ButterflyLab(v14.SocietyLab):
        def _support_proposals(self, problem, proposals):
            if not proposals:
                return
            for person in self.alive_people:
                if person.age < 10:
                    continue
                scored = []
                for proposal in proposals:
                    proposer = self._person(proposal.proposer_id)
                    trust = person.trust.get(proposer.id, 0.15)
                    score = (
                        trust * 0.43
                        + proposer.charisma * 0.24
                        + proposer.voice_weight * 0.08
                        + self._project_relevance(problem, proposal, proposer) * 0.20
                        + person.fear * 0.10
                        + self.rng.uniform(-0.08, 0.08)
                    )
                    support_nudge = self._interpretation_support_nudge(
                        person, problem, proposal, proposer
                    )
                    score += support_nudge
                    scored.append((score, proposal, support_nudge))
                score, proposal, support_nudge = max(scored, key=lambda item: item[0])
                if support_nudge != 0.0:
                    self.interpretation_support_nudge_count += 1
                support_chance = self._clamp(0.12 + score * 0.42 + person.fear * 0.15)
                if self.rng.random() > support_chance:
                    continue
                if (
                    exp.remove_hana_year14_support
                    and person.id == TARGET_HANA
                    and is_year14_target_proposal(self, problem, proposal)
                ):
                    continue
                proposal.support_ids.append(person.id)
                self.proposal_support_by_person[proposal.proposer_id] = (
                    self.proposal_support_by_person.get(proposal.proposer_id, 0) + 1
                )
                self.log.record(
                    self.year,
                    "proposal_supported",
                    [person.id, proposal.proposer_id],
                    f"{person.name} supported {proposal.action}",
                )

        def _apply_project_failure(self, problem, proposal, proposer, supporters):
            for supporter in supporters:
                self._adjust_trust(supporter, proposer.id, -0.045)
                supporter.fear = self._clamp(
                    supporter.fear + 0.08 + problem.severity * 0.08
                )
                if (
                    exp.hana_no_target_memory
                    and supporter.id == TARGET_HANA
                    and self.year == TARGET_YEAR
                    and proposal.action == "store_food"
                ):
                    self._assign_interpretation(supporter, TARGET_EVENT)
                    continue
                supporter.remember(
                    self._make_memory(
                        supporter,
                        event=f"project_failure:{proposal.action}",
                        intensity=0.45 + problem.severity * 0.35,
                    )
                )

        def _dialogue_phase(self):
            for speaker in self.alive_people:
                memory = speaker.strongest_memory()
                if memory is None:
                    continue
                share_probability = (
                    0.05
                    + memory.intensity * 0.18
                    + speaker.fear * 0.15
                    + (0.12 if speaker.action == "share_memory" else 0.0)
                )
                if memory.generation >= 4:
                    share_probability *= 0.55
                if self.rng.random() > min(0.55, share_probability):
                    continue
                listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
                listeners = [
                    self._person(person_id)
                    for person_id in speaker.top_trusted(listener_count)
                    if self._person(person_id).alive
                ]
                for listener in listeners:
                    blocked = False
                    if is_target_memory(memory):
                        if (
                            exp.randomize_hana_target_listener_same_year
                            and speaker.id == TARGET_HANA
                        ):
                            candidates = [
                                person for person in self.alive_people
                                if person.id != speaker.id
                            ]
                            if candidates:
                                listener = self.rng.choice(candidates)
                        if exp.block_hana_target_sharing and speaker.id == TARGET_HANA:
                            blocked = True
                        if (
                            exp.only_hana_target_listeners is not None
                            and speaker.id == TARGET_HANA
                            and listener.id not in exp.only_hana_target_listeners
                        ):
                            blocked = True
                        if (speaker.id, listener.id) in exp.blocked_edges:
                            blocked = True
                    distorted = self._distort_memory(memory, speaker, listener)
                    if blocked:
                        continue
                    listener.remember(distorted)
                    self.log.record(
                        self.year,
                        "memory_shared",
                        [speaker.id, listener.id],
                        (
                            f"{speaker.name} told {listener.name} about "
                            f"{distorted.event} intensity={distorted.intensity:.2f} "
                            f"generation={distorted.generation}"
                        ),
                    )
                    self._adjust_trust(listener, speaker.id, 0.012)

    return ButterflyLab


def compact_event(entry: object) -> str:
    return (
        f"Y{entry.year:02d} {entry.event_type} "
        f"[{','.join(entry.persons)}] {entry.detail}"
    )


def first_log_difference(left: object, right: object) -> dict[str, object] | None:
    left_entries = left.log.entries
    right_entries = right.log.entries
    limit = min(len(left_entries), len(right_entries))
    for index in range(limit):
        left_text = compact_event(left_entries[index])
        right_text = compact_event(right_entries[index])
        if left_text != right_text:
            return {"index": index, "baseline": left_text, "experiment": right_text}
    if len(left_entries) != len(right_entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left_entries) <= limit else compact_event(left_entries[limit]),
            "experiment": "<none>" if len(right_entries) <= limit else compact_event(right_entries[limit]),
        }
    return None


def target_edges(sim: object) -> list[str]:
    edges = []
    for entry in sim.log.entries:
        if entry.event_type != "memory_shared":
            continue
        if len(entry.persons) != 2:
            continue
        if TARGET_EVENT not in entry.detail:
            continue
        speaker, listener = entry.persons
        if speaker in {TARGET_HANA, TARGET_ORUN} or listener in {TARGET_ORUN, TARGET_SHION}:
            edges.append(compact_event(entry))
    return edges


def year14_supporters(sim: object) -> list[str]:
    supporters = []
    for entry in sim.log.entries:
        if entry.year != TARGET_YEAR or entry.event_type != "proposal_supported":
            continue
        if len(entry.persons) == 2 and entry.persons[1] == "p006" and "store_food" in entry.detail:
            supporters.append(entry.persons[0])
    return supporters


def run_experiment(exp: Experiment) -> object:
    cls = v14.SocietyLab if exp.code == "v1.4" else make_lab_class(exp)
    sim = cls(seed=SEED, verbose=False)
    sim.run(YEARS)
    return sim


def event_signature(sim: object) -> tuple[tuple[int, str, str], ...]:
    return tuple((entry.year, entry.event_type, entry.detail) for entry in sim.log.entries)


def selected_summary(summary: dict[str, object]) -> dict[str, object]:
    keys = [
        "final_population",
        "final_food_stock",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
        "death_count",
        "birth_count",
        "memory_shared_count",
    ]
    return {key: summary.get(key) for key in keys}


def changed_summary_keys(left: dict[str, object], right: dict[str, object]) -> list[str]:
    return [key for key in left if left.get(key) != right.get(key)]


baseline_v13 = v13.SocietyLab(seed=SEED, verbose=False)
baseline_v13.run(YEARS)
baseline_v14 = run_experiment(EXPERIMENTS[0])
baseline_v14_summary = selected_summary(baseline_v14.summary())
baseline_v13_summary = selected_summary(baseline_v13.summary())

rows = []
details = {}
for exp in EXPERIMENTS:
    sim = baseline_v14 if exp.code == "v1.4" else run_experiment(exp)
    summary = selected_summary(sim.summary())
    first_diff = None if exp.code == "v1.4" else first_log_difference(baseline_v14, sim)
    rows.append(
        {
            "experiment": exp.code,
            "label": exp.label,
            **summary,
            "summary_diff_keys_vs_v14": ",".join(changed_summary_keys(baseline_v14_summary, summary)),
            "summary_matches_v13": summary == baseline_v13_summary,
            "event_log_matches_v14": event_signature(sim) == event_signature(baseline_v14),
            "year14_supporters": " ".join(year14_supporters(sim)),
            "target_edge_count": len(target_edges(sim)),
            "first_diff_index": "" if first_diff is None else first_diff["index"],
        }
    )
    details[exp.code] = {
        "label": exp.label,
        "summary": summary,
        "summary_diff_vs_v14": {
            key: {"v14": baseline_v14_summary.get(key), exp.code: summary.get(key)}
            for key in changed_summary_keys(baseline_v14_summary, summary)
        },
        "summary_matches_v13": summary == baseline_v13_summary,
        "first_log_difference_vs_v14": first_diff,
        "year14_supporters": year14_supporters(sim),
        "target_edges": target_edges(sim),
        "key_events_after_year14": [
            compact_event(entry)
            for entry in sim.log.entries
            if 14 <= entry.year <= 30
            and entry.event_type in {
                "proposal_supported",
                "project_started",
                "project_success",
                "project_failure",
                "memory_shared",
                "shared_narrative",
                "death",
                "birth",
            }
            and (
                TARGET_EVENT in entry.detail
                or any(pid in entry.persons for pid in [TARGET_HANA, TARGET_ORUN, TARGET_SHION])
            )
        ],
    }

OUT_DIR.mkdir(parents=True, exist_ok=True)
csv_path = OUT_DIR / "seed1003_butterfly_experiments.csv"
json_path = OUT_DIR / "seed1003_butterfly_experiments.json"
md_path = OUT_DIR / "seed1003_butterfly_experiments.md"

with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

json_path.write_text(
    json.dumps(
        {
            "seed": SEED,
            "years": YEARS,
            "target": {
                "hana": TARGET_HANA,
                "orun": TARGET_ORUN,
                "shion": TARGET_SHION,
                "memory": TARGET_EVENT,
                "memory_year": TARGET_YEAR,
            },
            "v13_summary": baseline_v13_summary,
            "v14_summary": baseline_v14_summary,
            "experiments": details,
        },
        ensure_ascii=False,
        indent=2,
    ),
    encoding="utf-8",
)

lines = [
    "# seed1003 butterfly experiments",
    "",
    f"Seed: {SEED}",
    f"Years: {YEARS}",
    f"Target: `{TARGET_HANA}` Hana, `{TARGET_ORUN}` Orun, `{TARGET_SHION}` Shion, `{TARGET_EVENT}` from Year {TARGET_YEAR}",
    "",
    "## Summary table",
    "",
    "| exp | intervention | final pop | births | deaths | failures | shared narratives | memory shares | target edges | matches v1.3 summary | first diff |",
    "|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|",
]
for row in rows:
    lines.append(
        "| {experiment} | {label} | {final_population} | {birth_count} | {death_count} | "
        "{project_failure_count} | {shared_narrative_count} | {memory_shared_count} | "
        "{target_edge_count} | {summary_matches_v13} | {first_diff_index} |".format(**row)
    )

lines.extend(
    [
        "",
        "## Baseline comparison",
        "",
        "v1.3 selected summary:",
        "",
        "```json",
        json.dumps(baseline_v13_summary, ensure_ascii=False, indent=2),
        "```",
        "",
        "v1.4 selected summary:",
        "",
        "```json",
        json.dumps(baseline_v14_summary, ensure_ascii=False, indent=2),
        "```",
    ]
)

for code, detail in details.items():
    if code == "v1.4":
        continue
    lines.extend(
        [
            "",
            f"## {code}. {detail['label']}",
            "",
            "Changed summary keys vs v1.4:",
            "",
            "```json",
            json.dumps(detail["summary_diff_vs_v14"], ensure_ascii=False, indent=2),
            "```",
            "",
            "First log difference vs v1.4:",
            "",
            "```json",
            json.dumps(detail["first_log_difference_vs_v14"], ensure_ascii=False, indent=2),
            "```",
            "",
            "Target-edge events:",
            "",
        ]
    )
    if detail["target_edges"]:
        lines.extend(f"- {edge}" for edge in detail["target_edges"])
    else:
        lines.append("- none")

md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

print(csv_path)
print(json_path)
print(md_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
