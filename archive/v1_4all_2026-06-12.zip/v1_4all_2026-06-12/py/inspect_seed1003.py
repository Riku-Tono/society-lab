from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


SOURCE = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日\文明シミュレーション\py\v1.3-1.4\society_lab_v1_4.py"
)


def load_module():
    spec = importlib.util.spec_from_file_location("society_lab_v1_4", SOURCE)
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load society_lab_v1_4.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


mod = load_module()
sim = mod.SocietyLab(seed=1003, verbose=False)
print("initial")
for person in sim.people:
    print(
        f"{person.id} {person.name} age={person.age} sex={person.sex} "
        f"charisma={person.charisma:.3f} food={person.food_skill:.3f}"
    )

sim.run(80)
print("\nsummary")
for key, value in sim.summary().items():
    print(f"{key}: {value}")

print("\nYear 1-20 key events")
for entry in sim.log.entries:
    if 1 <= entry.year <= 20 and entry.event_type in {
        "proposal_made",
        "proposal_supported",
        "project_started",
        "project_success",
        "project_failure",
        "memory_shared",
        "shared_narrative",
        "authority_pattern",
        "faction_pattern",
        "problem_detected",
        "crisis",
    }:
        print(
            f"Y{entry.year:02d} {entry.event_type:22s} "
            f"{','.join(entry.persons) or '-':18s} {entry.detail}"
        )

print("\nHana/Orun/Shion traces")
interesting = {"ハナ", "オルン", "シオン"}
interesting_ids = {p.id for p in sim.people if p.name in interesting}
for entry in sim.log.entries:
    if any(pid in interesting_ids for pid in entry.persons):
        print(
            f"Y{entry.year:02d} {entry.event_type:22s} "
            f"{','.join(entry.persons) or '-':18s} {entry.detail}"
        )
