from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any


def load_payload(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def build_lineage_maps(memories: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], dict[str, list[str]]]:
    by_id = {entry["memory_id"]: entry for entry in memories}
    children: dict[str, list[str]] = defaultdict(list)
    for entry in memories:
        parent = entry.get("parent_memory_id", "")
        if parent:
            children[parent].append(entry["memory_id"])
    return by_id, children


def collect_descendants(root_id: str, by_id: dict[str, dict[str, Any]], children: dict[str, list[str]]) -> list[dict[str, Any]]:
    descendants: list[dict[str, Any]] = []
    queue: deque[tuple[str, int]] = deque([(root_id, 0)])
    while queue:
        memory_id, depth = queue.popleft()
        entry = dict(by_id[memory_id])
        entry["depth_from_root"] = depth
        descendants.append(entry)
        for child_id in children.get(memory_id, []):
            queue.append((child_id, depth + 1))
    return descendants


def summarize_root(root: dict[str, Any], descendants: list[dict[str, Any]]) -> dict[str, Any]:
    holders = {entry["holder_id"] for entry in descendants}
    interpretations = Counter(entry["interpretation"] for entry in descendants)
    years = [entry["year"] for entry in descendants]
    return {
        "memory_id": root["memory_id"],
        "event": root["event"],
        "year": root["year"],
        "interpretation": root["interpretation"],
        "intensity": root["intensity"],
        "descendant_events": len(descendants),
        "unique_holders": len(holders),
        "max_depth": max(entry["depth_from_root"] for entry in descendants),
        "first_year": min(years),
        "last_year": max(years),
        "interpretations_seen": dict(interpretations.most_common()),
    }


def nearby_support_for_actor(
    actor_id: str,
    memories: list[dict[str, Any]],
    supports: list[dict[str, Any]],
    window: int,
) -> list[dict[str, Any]]:
    actor_memories = [
        memory
        for memory in memories
        if memory["holder_id"] == actor_id or memory["source_id"] == actor_id
    ]
    actor_supports = [
        support
        for support in supports
        if support["supporter_id"] == actor_id or support["proposer_id"] == actor_id
    ]
    cases = []
    for memory in actor_memories:
        for support in actor_supports:
            gap = support["year"] - memory["year"]
            if 0 <= gap <= window:
                cases.append(
                    {
                        "gap_years": gap,
                        "memory_id": memory["memory_id"],
                        "memory_year": memory["year"],
                        "memory_event": memory["event"],
                        "memory_holder": memory["holder_id"],
                        "memory_source": memory["source_id"],
                        "memory_interpretation": memory["interpretation"],
                        "support_year": support["year"],
                        "supporter_id": support["supporter_id"],
                        "proposer_id": support["proposer_id"],
                        "action": support["action"],
                        "problem": support["problem"],
                        "support_nudge": support["support_nudge"],
                        "support_chance": support["support_chance"],
                    }
                )
    cases.sort(key=lambda item: (item["gap_years"], item["memory_year"], item["support_year"]))
    return cases


def actor_project_rows(actor_id: str, projects: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for project in projects:
        if project["proposer_id"] == actor_id:
            rows.append({**project, "actor_relation": "proposer"})
    return rows


def table(rows: list[dict[str, Any]], columns: list[str], limit: int = 20) -> str:
    if not rows:
        return "_none_\n"
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    for row in rows[:limit]:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    return "\n".join(lines) + "\n"


def build_actor_trace(payload: dict[str, Any], actor_id: str, window: int) -> dict[str, Any]:
    memories = payload["memory_lineage_trace"]
    supports = payload["support_chain_trace"]
    projects = payload["project_aftermath_trace"]
    actor_bio = payload["actor_biography"].get(actor_id, [])
    role_labels = payload["observation_summary"]["role_labels"].get(actor_id, [])

    by_id, children = build_lineage_maps(memories)
    root_memories = [
        entry
        for entry in memories
        if entry["holder_id"] == actor_id
        and entry.get("parent_memory_id", "") == ""
    ]
    lineage_summaries = []
    lineage_details = {}
    for root in root_memories:
        descendants = collect_descendants(root["memory_id"], by_id, children)
        lineage_summaries.append(summarize_root(root, descendants))
        lineage_details[root["memory_id"]] = descendants
    lineage_summaries.sort(
        key=lambda item: (item["descendant_events"], item["max_depth"], item["last_year"]),
        reverse=True,
    )

    told_events = [
        entry for entry in actor_bio if entry.get("bio_event") == "memory_told"
    ]
    told_targets = Counter(entry["listener_id"] for entry in told_events)
    support_rows = [
        entry
        for entry in supports
        if entry["supporter_id"] == actor_id or entry["proposer_id"] == actor_id
    ]

    return {
        "actor_id": actor_id,
        "roles": role_labels,
        "biography_event_count": len(actor_bio),
        "biography": actor_bio,
        "root_memory_summaries": lineage_summaries,
        "lineage_details": lineage_details,
        "memory_told_count": len(told_events),
        "top_listeners": told_targets.most_common(10),
        "support_events": support_rows,
        "project_rows": actor_project_rows(actor_id, projects),
        "nearby_memory_support": nearby_support_for_actor(actor_id, memories, supports, window),
    }


def build_report(trace: dict[str, Any], seed: int, window: int) -> str:
    actor_id = trace["actor_id"]
    lines = [
        f"# Actor Trace {actor_id} seed {seed}",
        "",
        "## Overview",
        "",
        f"- roles: {trace['roles']}",
        f"- biography events: {trace['biography_event_count']}",
        f"- memory told count: {trace['memory_told_count']}",
        f"- top listeners: {trace['top_listeners']}",
        "",
        "## Root Memories",
        "",
        table(
            trace["root_memory_summaries"],
            [
                "memory_id",
                "event",
                "year",
                "interpretation",
                "descendant_events",
                "unique_holders",
                "max_depth",
                "last_year",
                "interpretations_seen",
            ],
            limit=30,
        ),
        "## Biography",
        "",
        table(
            trace["biography"],
            ["year", "bio_event", "memory_id", "event", "listener_id", "proposer_id", "action", "problem", "support_nudge"],
            limit=80,
        ),
        "## Support Events Involving Actor",
        "",
        table(
            trace["support_events"],
            ["year", "supporter_id", "proposer_id", "action", "problem", "support_nudge", "support_chance"],
            limit=50,
        ),
        "## Project Rows Where Actor Proposed",
        "",
        table(
            trace["project_rows"],
            [
                "year",
                "event",
                "action",
                "problem",
                "supporters",
                "success_chance",
                "supporter_fear_delta",
                "supporter_trust_to_proposer_delta",
            ],
            limit=30,
        ),
        f"## Memory/Support Proximity Within {window} Years",
        "",
        table(
            trace["nearby_memory_support"],
            [
                "gap_years",
                "memory_year",
                "memory_id",
                "memory_event",
                "memory_interpretation",
                "support_year",
                "supporter_id",
                "proposer_id",
                "action",
                "problem",
                "support_nudge",
            ],
            limit=80,
        ),
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Trace one actor in a society_lab v1.4_1 observation JSON.")
    parser.add_argument(
        "input",
        type=Path,
        nargs="?",
        default=Path("society_lab_v1_4_1_observation_seed1003.json"),
    )
    parser.add_argument("--actor", default="p031")
    parser.add_argument("--window", type=int, default=5)
    parser.add_argument("--json-out", type=Path, default=Path("p031_trace_summary.json"))
    parser.add_argument("--md-out", type=Path, default=Path("p031_trace_report.md"))
    args = parser.parse_args()

    payload = load_payload(args.input)
    trace = build_actor_trace(payload, args.actor, args.window)
    seed = payload["summary"]["seed"]

    args.json_out.write_text(
        json.dumps(trace, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    args.md_out.write_text(build_report(trace, seed, args.window), encoding="utf-8")
    print(args.md_out)
    print(args.json_out)


if __name__ == "__main__":
    main()
