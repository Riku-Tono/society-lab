from __future__ import annotations

import csv
import importlib.util
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)

SUMMARY_CSV = OUT_DIR / "society_lab_v1_4_all_seed_comparison.csv"
EVENTS_CSV = OUT_DIR / "society_lab_v1_4_all_seed_events.csv"
MEMORY_CSV = OUT_DIR / "society_lab_v1_4_all_seed_memory_stats.csv"
FIRST_DIFF_CSV = OUT_DIR / "society_lab_v1_4_all_seed_first_diffs.csv"
NUDGE_CSV = OUT_DIR / "society_lab_v1_4_all_seed_nudge_details.csv"
REPORT_MD = OUT_DIR / "society_lab_v1_4_all_seed_report.md"

SEEDS = range(1000, 1100)
YEARS = 80

SUMMARY_KEYS = (
    "final_population",
    "final_food_stock",
    "birth_count",
    "death_count",
    "proposal_count",
    "project_failure_count",
    "memory_shared_count",
    "shared_narrative_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
    "avg_bias_spiritual",
    "avg_bias_practical",
    "avg_bias_blame",
)


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def first_log_difference(before: object, after: object) -> tuple[int, object | None, object | None] | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return index, before_entries[index], after_entries[index]
    if len(before_entries) != len(after_entries):
        left = None if len(before_entries) <= limit else before_entries[limit]
        right = None if len(after_entries) <= limit else after_entries[limit]
        return limit, left, right
    return None


def first_diff_family(entry: object | None) -> str:
    if entry is None:
        return "none"
    if entry.event_type == "proposal_supported":
        return "support_choice"
    if entry.event_type == "proposal_made":
        return "proposal_choice"
    if entry.event_type == "memory_shared":
        return "memory"
    return "event"


def person_name(sim: object, person_id: str) -> str:
    try:
        return sim._person(person_id).name
    except Exception:
        return ""


def supported_action(detail: str) -> str:
    match = re.search(r"supported\s+(\w+)", detail)
    return match.group(1) if match else ""


def proposal_action(detail: str) -> str:
    match = re.search(r"proposed\s+(\w+)", detail)
    return match.group(1) if match else ""


def project_key_from_detail(detail: str) -> str:
    match = re.search(r"project_(?:started|success|failure):\s+(\w+)\s+for\s+(\w+)", detail)
    if match:
        return f"{match.group(1)}:{match.group(2)}"
    return ""


def support_sets_at_year(sim: object, year: int) -> dict[str, set[str]]:
    supports: dict[str, set[str]] = defaultdict(set)
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type != "proposal_supported" or len(entry.persons) < 2:
            continue
        supporter, proposer = entry.persons[:2]
        action = supported_action(entry.detail)
        supports[f"{proposer}:{action}"].add(supporter)
    return supports


def project_results_at_year(sim: object, year: int) -> dict[str, str]:
    results = {}
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type not in {"project_success", "project_failure"}:
            continue
        key = project_key_from_detail(entry.detail)
        if key:
            results[key] = entry.event_type
    return results


def first_diff_detail(seed: int, before: object, after: object) -> dict[str, Any]:
    diff = first_log_difference(before, after)
    if diff is None:
        return {
            "seed": seed,
            "first_diff_year": "",
            "first_diff_family": "none",
            "first_diff_v13": "",
            "first_diff_v14": "",
            "changed_person_id": "",
            "changed_person_name": "",
            "changed_action_or_project": "",
            "supporters_v13": "",
            "supporters_v14": "",
            "supporter_added": "",
            "supporter_removed": "",
            "project_result_v13": "",
            "project_result_v14": "",
            "immediate_next_year_diff": "",
            "notes": "",
        }
    _, left, right = diff
    entry = right or left
    year = int(entry.year)
    family = first_diff_family(entry)
    changed_person_id = ""
    changed_person = ""
    action = ""
    supporters_v13 = ""
    supporters_v14 = ""
    added = ""
    removed = ""
    project_result_v13 = ""
    project_result_v14 = ""
    notes = ""

    if family == "support_choice" and right is not None and len(right.persons) >= 2:
        changed_person_id = right.persons[0]
        changed_person = person_name(after, changed_person_id)
        proposer = right.persons[1]
        action = supported_action(right.detail)
        key = f"{proposer}:{action}"
        before_supports = support_sets_at_year(before, year)
        after_supports = support_sets_at_year(after, year)
        left_set = before_supports.get(key, set())
        right_set = after_supports.get(key, set())
        supporters_v13 = len(left_set)
        supporters_v14 = len(right_set)
        added = ",".join(sorted(right_set - left_set))
        removed = ",".join(sorted(left_set - right_set))
        before_results = project_results_at_year(before, year)
        after_results = project_results_at_year(after, year)
        project_key = f"{action}:"
        project_result_v13 = ";".join(
            f"{key}:{value}" for key, value in before_results.items() if key.startswith(project_key)
        )
        project_result_v14 = ";".join(
            f"{key}:{value}" for key, value in after_results.items() if key.startswith(project_key)
        )
    elif family == "proposal_choice" and right is not None and right.persons:
        changed_person_id = right.persons[0]
        changed_person = person_name(after, changed_person_id)
        action = proposal_action(right.detail)
    elif entry is not None and entry.persons:
        changed_person_id = entry.persons[0]
        changed_person = person_name(after, changed_person_id)
        action = project_key_from_detail(entry.detail) or supported_action(entry.detail) or proposal_action(entry.detail)

    left_next = next(
        (compact_event(e) for e in before.log.entries if e.year == year + 1),
        "",
    )
    right_next = next(
        (compact_event(e) for e in after.log.entries if e.year == year + 1),
        "",
    )
    immediate_next_year_diff = "true" if left_next != right_next else "false"
    if not action:
        notes = "Could not parse changed action/project from log detail."

    return {
        "seed": seed,
        "first_diff_year": year,
        "first_diff_family": family,
        "first_diff_v13": compact_event(left) if left else "<end>",
        "first_diff_v14": compact_event(right) if right else "<end>",
        "changed_person_id": changed_person_id,
        "changed_person_name": changed_person,
        "changed_action_or_project": action,
        "supporters_v13": supporters_v13,
        "supporters_v14": supporters_v14,
        "supporter_added": added,
        "supporter_removed": removed,
        "project_result_v13": project_result_v13,
        "project_result_v14": project_result_v14,
        "immediate_next_year_diff": immediate_next_year_diff,
        "notes": notes,
    }


def total_memories(sim: object) -> tuple[int, float]:
    alive = sim.alive_people
    total = sum(len(person.memories) for person in alive)
    avg = total / max(1, len(alive))
    return total, avg


def yearly_rows(module: ModuleType, version: str, seed: int) -> list[dict[str, Any]]:
    sim = module.SocietyLab(seed=seed, verbose=False)
    rows = []
    for _ in range(YEARS):
        if sim.population == 0:
            break
        sim.step()
        summary = sim.summary()
        total, avg = total_memories(sim)
        rows.append(
            {
                "seed": seed,
                "version": version,
                "year": sim.year,
                "population": summary["final_population"],
                "food_stock": summary["final_food_stock"],
                "birth_count_cumulative": summary["birth_count"],
                "death_count_cumulative": summary["death_count"],
                "proposal_count_cumulative": summary["proposal_count"],
                "project_failure_count_cumulative": summary["project_failure_count"],
                "memory_shared_count_cumulative": summary["memory_shared_count"],
                "shared_narrative_count_cumulative": summary["shared_narrative_count"],
                "network_split_count_cumulative": summary["network_split_count"],
                "narrative_divergence_count_cumulative": summary["narrative_divergence_count"],
                "interpretation_divergence_count_cumulative": summary["interpretation_divergence_count"],
                "avg_bias_spiritual": summary["avg_bias_spiritual"],
                "avg_bias_practical": summary["avg_bias_practical"],
                "avg_bias_blame": summary["avg_bias_blame"],
                "total_memories": total,
                "avg_memories_per_person": round(avg, 4),
            }
        )
    return rows


def memory_event_from_detail(detail: str) -> str:
    match = re.search(r"about\s+([^\s]+)\s+intensity=", detail)
    return match.group(1) if match else ""


def memory_stats_rows(version: str, seed: int, sim: object) -> list[dict[str, Any]]:
    grouped: dict[str, list[object]] = defaultdict(list)
    source_years: dict[str, int] = {}
    for entry in sim.log.entries:
        if entry.event_type in {"project_success", "project_failure"}:
            key = project_key_from_detail(entry.detail)
            if key:
                event_kind, rest = entry.event_type, key
                action = rest.split(":", 1)[0]
                source_years.setdefault(f"{event_kind}:{action}", int(entry.year))
        elif entry.event_type in {"death", "food_shortage", "problem_detected"}:
            if entry.event_type == "problem_detected":
                if entry.detail.startswith("food_shortage"):
                    source_years.setdefault("food_shortage", int(entry.year))
            else:
                source_years.setdefault(entry.event_type, int(entry.year))
    for entry in sim.log.entries:
        if entry.event_type != "memory_shared":
            continue
        memory_event = memory_event_from_detail(entry.detail)
        if not memory_event:
            continue
        grouped[memory_event].append(entry)

    rows = []
    for memory_event, entries in sorted(grouped.items()):
        speakers = Counter(entry.persons[0] for entry in entries if entry.persons)
        listeners = Counter(entry.persons[1] for entry in entries if len(entry.persons) > 1)
        touched = set(speakers) | set(listeners)
        generations = []
        for entry in entries:
            match = re.search(r"generation=(\d+)", entry.detail)
            if match:
                generations.append(int(match.group(1)))
        project_match = re.match(r"project_(?:failure|success):(\w+)", memory_event)
        top_speaker_id, top_speaker_count = ("", 0) if not speakers else speakers.most_common(1)[0]
        top_listener_id, top_listener_count = ("", 0) if not listeners else listeners.most_common(1)[0]
        rows.append(
            {
                "seed": seed,
                "version": version,
                "memory_event": memory_event,
                "source_year": source_years.get(memory_event, ""),
                "source_project": project_match.group(1) if project_match else "",
                "transmission_edges": len(entries),
                "unique_speakers": len(speakers),
                "unique_listeners": len(listeners),
                "unique_people_touched": len(touched),
                "first_share_year": min(entry.year for entry in entries),
                "last_share_year": max(entry.year for entry in entries),
                "max_generation": max(generations) if generations else "",
                "top_speaker_id": top_speaker_id,
                "top_speaker_count": top_speaker_count,
                "top_listener_id": top_listener_id,
                "top_listener_count": top_listener_count,
            }
        )
    return rows


def make_instrumented_class(module: ModuleType) -> type:
    base = module.SocietyLab

    class InstrumentedSocietyLab(base):  # type: ignore[misc, valid-type]
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.nudge_details: list[dict[str, Any]] = []

        def _choose_project_action(self, problem: Any, proposer: Any, used_actions: set[str]) -> str:
            if problem.type == "food_shortage":
                weighted = [("store_food", 4), ("hunt_group", 4), ("move_camp", 2), ("hold_ritual", 1)]
            elif problem.type == "water_shortage":
                weighted = [("dig_well", 5), ("move_camp", 3), ("hold_ritual", 2), ("store_food", 1)]
            elif problem.type == "storage_damage":
                weighted = [("store_food", 5), ("hunt_group", 2), ("hold_ritual", 1), ("move_camp", 1)]
            else:
                weighted = [("hold_ritual", 3), ("store_food", 2), ("dig_well", 1), ("hunt_group", 1), ("move_camp", 1)]
            actions = [action for action, _ in weighted]
            weights = [weight for _, weight in weighted]
            original_weights = list(weights)
            interpretation = self._recent_interpretation_for_problem(proposer, problem)
            nudged_actions = []
            if interpretation != "none":
                adjusted = []
                nudged = False
                for action, weight in zip(actions, weights):
                    bonus = self._interpretation_action_nudge(interpretation, action)
                    adjusted_weight = weight * (1.0 + bonus)
                    adjusted.append(adjusted_weight)
                    if bonus > 0.0:
                        nudged = True
                        nudged_actions.append((action, weight, adjusted_weight))
                weights = adjusted
                if nudged:
                    self.interpretation_action_nudge_count += 1
                    for action, before_weight, after_weight in nudged_actions:
                        self.nudge_details.append(
                            {
                                "seed": self.seed,
                                "year": self.year,
                                "person_id": proposer.id,
                                "person_name": proposer.name,
                                "nudge_type": "action",
                                "target_action_or_project": action,
                                "before_score": before_weight,
                                "after_score": after_weight,
                                "changed_choice": "",
                                "old_choice": "",
                                "new_choice": "",
                                "notes": "Action nudge changes random-choice weights; old/new choice is not directly observable without counterfactual rerun.",
                            }
                        )
            if proposer.charisma > 0.75:
                weights = [
                    weight + (2 if action == "hold_ritual" else 0)
                    for action, weight in zip(actions, weights)
                ]
            for _ in range(6):
                action = self.rng.choices(actions, weights=weights)[0]
                if action not in used_actions:
                    return action
            return self.rng.choice(module.PROJECT_ACTIONS)

        def _support_proposals(self, problem: Any, proposals: list[Any]) -> None:
            if not proposals:
                return
            for person in self.alive_people:
                if person.age < 10:
                    continue
                scored = []
                scored_without_nudge = []
                for proposal in proposals:
                    proposer = self._person(proposal.proposer_id)
                    trust = person.trust.get(proposer.id, 0.15)
                    base_score = (
                        trust * 0.43
                        + proposer.charisma * 0.24
                        + proposer.voice_weight * 0.08
                        + self._project_relevance(problem, proposal, proposer) * 0.20
                        + person.fear * 0.10
                        + self.rng.uniform(-0.08, 0.08)
                    )
                    support_nudge = self._interpretation_support_nudge(person, problem, proposal, proposer)
                    score = base_score + support_nudge
                    scored.append((score, proposal, support_nudge, base_score))
                    scored_without_nudge.append((base_score, proposal))
                score, proposal, support_nudge, base_score = max(scored, key=lambda item: item[0])
                old_top = max(scored_without_nudge, key=lambda item: item[0])[1]
                if support_nudge != 0.0:
                    self.interpretation_support_nudge_count += 1
                    self.nudge_details.append(
                        {
                            "seed": self.seed,
                            "year": self.year,
                            "person_id": person.id,
                            "person_name": person.name,
                            "nudge_type": "support",
                            "target_action_or_project": proposal.action,
                            "before_score": round(base_score, 6),
                            "after_score": round(score, 6),
                            "changed_choice": str(old_top is not proposal).lower(),
                            "old_choice": old_top.action if old_top is not proposal else proposal.action,
                            "new_choice": proposal.action,
                            "notes": "",
                        }
                    )
                support_chance = self._clamp(0.12 + score * 0.42 + person.fear * 0.15)
                if self.rng.random() > support_chance:
                    continue
                proposal.support_ids.append(person.id)
                self.proposal_support_by_person[proposal.proposer_id] = (
                    self.proposal_support_by_person.get(proposal.proposer_id, 0) + 1
                )
                self.log.record(
                    self.year,
                    "proposal_supported",
                    [person.id, proposal.proposer_id],
                    f"{person.name} supported {proposal.action}",
                )

    return InstrumentedSocietyLab


def run_sim(module: ModuleType, seed: int, instrument: bool = False) -> object:
    if instrument:
        cls = make_instrumented_class(module)
        sim = cls(seed=seed, verbose=False)
    else:
        sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim


def group_for(before: object, after: object, first_diff: dict[str, Any]) -> str:
    before_summary = before.summary()
    after_summary = after.summary()
    summary_changed = any(before_summary[key] != after_summary[key] for key in SUMMARY_KEYS)
    if summary_changed:
        return "summary_changed"
    if first_diff["first_diff_family"] != "none":
        return "log_changed_absorbed"
    return "no_log_change"


def summary_row(seed: int, before: object, after: object, first_diff: dict[str, Any]) -> dict[str, Any]:
    before_summary = before.summary()
    after_summary = after.summary()
    row: dict[str, Any] = {"seed": seed, "group": group_for(before, after, first_diff)}
    mappings = [
        ("final_population", "final_population"),
        ("final_food", "final_food_stock"),
        ("birth_count", "birth_count"),
        ("death_count", "death_count"),
        ("proposal_count", "proposal_count"),
        ("project_failure_count", "project_failure_count"),
        ("memory_shared_count", "memory_shared_count"),
        ("shared_narrative_count", "shared_narrative_count"),
        ("network_split_count", "network_split_count"),
        ("narrative_divergence_count", "narrative_divergence_count"),
        ("interpretation_divergence_count", "interpretation_divergence_count"),
        ("avg_bias_spiritual", "avg_bias_spiritual"),
        ("avg_bias_practical", "avg_bias_practical"),
        ("avg_bias_blame", "avg_bias_blame"),
    ]
    for out_name, key in mappings:
        row[f"{out_name}_v13"] = before_summary[key]
        row[f"{out_name}_v14"] = after_summary[key]
        row[f"diff_{out_name.removesuffix('_count')}"] = (
            after_summary[key] - before_summary[key]
            if isinstance(before_summary[key], (int, float)) and isinstance(after_summary[key], (int, float))
            else ""
        )
    row["action_nudge_count"] = after_summary.get("interpretation_action_nudge_count", 0)
    row["support_nudge_count"] = after_summary.get("interpretation_support_nudge_count", 0)
    row["first_diff_year"] = first_diff["first_diff_year"]
    row["first_diff_family"] = first_diff["first_diff_family"]
    row["first_diff_description"] = first_diff["first_diff_v14"]
    return row


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    if not rows and fieldnames is None:
        return
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def build_report(summary_rows: list[dict[str, Any]], first_rows: list[dict[str, Any]]) -> str:
    group_counts = Counter(row["group"] for row in summary_rows)
    family_counts = Counter(row["first_diff_family"] for row in first_rows)
    changed = [row for row in summary_rows if row["group"] == "summary_changed"]
    group_by_seed = {row["seed"]: row["group"] for row in summary_rows}
    absorbed_first = [
        row for row in first_rows if group_by_seed.get(row["seed"]) == "log_changed_absorbed"
    ]

    def top(metric: str, reverse_abs: bool = True, n: int = 10) -> list[dict[str, Any]]:
        return sorted(changed, key=lambda row: abs(float(row[metric])) if reverse_abs else float(row[metric]), reverse=True)[:n]

    def near_1003_score(row: dict[str, Any]) -> float:
        score = 0.0
        checks = [
            ("diff_final_population", -1),
            ("diff_final_food", 1),
            ("diff_memory_shared", -1),
            ("diff_project_failure", 1),
            ("diff_avg_bias_blame", 1),
        ]
        for key, direction in checks:
            value = float(row[key])
            if value == 0:
                continue
            if (value > 0 and direction > 0) or (value < 0 and direction < 0):
                score += 1
        return score

    lines: list[str] = []
    lines.append("# society_lab v1.4 all-seed report")
    lines.append("")
    lines.append("Compared v1.3 and v1.4 for seeds 1000-1099 over 80 years.")
    lines.append("")
    lines.append("## Counts")
    lines.append("")
    lines.extend(md_table(["group", "count"], [[key, group_counts[key]] for key in sorted(group_counts)]))
    lines.append("")
    lines.append("## First Diff Families")
    lines.append("")
    lines.extend(md_table(["family", "count"], [[key, family_counts[key]] for key in sorted(family_counts)]))
    lines.append("")
    first_years = [int(row["first_diff_year"]) for row in first_rows if row["first_diff_year"] != ""]
    lines.append("## First Diff Year Distribution")
    lines.append("")
    bins = Counter(
        "Y01-20" if year <= 20 else "Y21-40" if year <= 40 else "Y41-60" if year <= 60 else "Y61-80"
        for year in first_years
    )
    lines.extend(md_table(["bucket", "count"], [[key, bins[key]] for key in ["Y01-20", "Y21-40", "Y41-60", "Y61-80"]]))
    lines.append("")
    lines.append("## Nudge Count vs Final Diffs")
    lines.append("")
    lines.append("Support/action nudge totals are included in the CSV. Large final differences can occur with modest nudge counts, so total nudge count should not be treated as the sole effect-size measure.")
    lines.append("")
    rank_specs = [
        ("Population delta", "diff_final_population"),
        ("Food delta", "diff_final_food"),
        ("Project failure delta", "diff_project_failure"),
        ("Memory shared delta", "diff_memory_shared"),
    ]
    for title, metric in rank_specs:
        lines.append(f"## {title} Ranking")
        lines.append("")
        rows = [
            [
                row["seed"],
                row[metric],
                row["action_nudge_count"],
                row["support_nudge_count"],
                row["first_diff_year"],
                row["first_diff_family"],
            ]
            for row in top(metric)
        ]
        lines.extend(md_table(["seed", "delta", "action nudges", "support nudges", "first diff year", "family"], rows))
        lines.append("")
    lines.append("## Seed 1003-like Candidates")
    lines.append("")
    candidates = sorted(changed, key=near_1003_score, reverse=True)[:15]
    lines.extend(
        md_table(
            ["seed", "score", "pop", "food", "memshare", "fail", "blame"],
            [
                [
                    row["seed"],
                    near_1003_score(row),
                    row["diff_final_population"],
                    row["diff_final_food"],
                    row["diff_memory_shared"],
                    row["diff_project_failure"],
                    row["diff_avg_bias_blame"],
                ]
                for row in candidates
            ],
        )
    )
    lines.append("")
    lines.append("## Population-Increase Candidates")
    lines.append("")
    inc = sorted(changed, key=lambda row: float(row["diff_final_population"]), reverse=True)[:10]
    lines.extend(md_table(["seed", "pop delta", "food delta", "first diff"], [[row["seed"], row["diff_final_population"], row["diff_final_food"], row["first_diff_year"]] for row in inc]))
    lines.append("")
    lines.append("## Absorbed Candidates")
    lines.append("")
    lines.extend(
        md_table(
            ["seed", "first diff year", "family", "description"],
            [
                [row["seed"], row["first_diff_year"], row["first_diff_family"], row["first_diff_v14"]]
                for row in absorbed_first[:20]
            ],
        )
    )
    lines.append("")
    lines.append("## High Nudge But Small Summary Delta")
    lines.append("")
    high_nudge = sorted(
        changed,
        key=lambda row: float(row["support_nudge_count"]) - abs(float(row["diff_final_population"])) * 10,
        reverse=True,
    )[:10]
    lines.extend(md_table(["seed", "support nudges", "pop delta", "food delta", "failure delta"], [[row["seed"], row["support_nudge_count"], row["diff_final_population"], row["diff_final_food"], row["diff_project_failure"]] for row in high_nudge]))
    lines.append("")
    lines.append("## Notes")
    lines.append("")
    lines.append("- `society_lab_v1_4_all_seed_events.csv` is annual cumulative state, not raw event log.")
    lines.append("- `society_lab_v1_4_all_seed_nudge_details.csv` is extra output beyond the requested five files. It records support-score nudges and action-weight nudges from an analysis-only subclass.")
    lines.append("- Action nudge old/new choice is blank because the current simulator does not store counterfactual random choices.")
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    v13 = load_module("society_lab_v1_3_all_export", V13_PATH)
    v14 = load_module("society_lab_v1_4_all_export", V14_PATH)

    summary_rows: list[dict[str, Any]] = []
    annual_rows: list[dict[str, Any]] = []
    first_rows: list[dict[str, Any]] = []
    memory_rows: list[dict[str, Any]] = []
    nudge_rows: list[dict[str, Any]] = []

    for seed in SEEDS:
        before = run_sim(v13, seed)
        after = run_sim(v14, seed, instrument=True)
        first = first_diff_detail(seed, before, after)
        first_rows.append(first)
        summary_rows.append(summary_row(seed, before, after, first))
        annual_rows.extend(yearly_rows(v13, "v1.3", seed))
        annual_rows.extend(yearly_rows(v14, "v1.4", seed))
        memory_rows.extend(memory_stats_rows("v1.3", seed, before))
        memory_rows.extend(memory_stats_rows("v1.4", seed, after))
        nudge_rows.extend(after.nudge_details)

    write_csv(SUMMARY_CSV, summary_rows)
    write_csv(EVENTS_CSV, annual_rows)
    write_csv(MEMORY_CSV, memory_rows)
    write_csv(FIRST_DIFF_CSV, first_rows)
    write_csv(NUDGE_CSV, nudge_rows)
    REPORT_MD.write_text(build_report(summary_rows, first_rows), encoding="utf-8")

    for path in (SUMMARY_CSV, EVENTS_CSV, MEMORY_CSV, FIRST_DIFF_CSV, NUDGE_CSV, REPORT_MD):
        print(path)


if __name__ == "__main__":
    main()
