from __future__ import annotations

import importlib.util
import statistics
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
REPORT_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs\society_lab_v1_4_changed_seed_common_points.md"
)

SEEDS = range(1000, 1100)
YEARS = 80
SUMMARY_KEYS = (
    "final_population",
    "final_food_stock",
    "avg_fear",
    "avg_hunger",
    "proposal_count",
    "project_success_count",
    "project_failure_count",
    "shared_narrative_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
    "avg_bias_spiritual",
    "avg_bias_practical",
    "avg_bias_blame",
    "death_count",
    "birth_count",
    "memory_shared_count",
    "behavior_copied_count",
)


@dataclass(frozen=True)
class FirstDiff:
    index: int
    year: int
    before_event: str
    after_event: str
    before_detail: str
    after_detail: str


@dataclass(frozen=True)
class SeedAnalysis:
    seed: int
    summary_changed: bool
    log_changed: bool
    first_diff: FirstDiff | None
    action_nudges: int
    support_nudges: int
    delta_population: float
    delta_food: float
    delta_failures: float
    delta_births: float
    delta_memory_shared: float
    delta_blame: float
    pre_population: int
    pre_food: float
    pre_failures: int
    pre_memory_shared: int
    pre_total_memories: int
    pre_avg_memories: float
    pre_shared_narratives: int
    pre_network_splits: int


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def run_sim(module: ModuleType, seed: int, years: int = YEARS) -> object:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=years)
    return sim


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def first_log_diff(before: object, after: object) -> FirstDiff | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        left = compact_event(before_entries[index])
        right = compact_event(after_entries[index])
        if left != right:
            return FirstDiff(
                index=index,
                year=int(after_entries[index].year),
                before_event=str(before_entries[index].event_type),
                after_event=str(after_entries[index].event_type),
                before_detail=str(before_entries[index].detail),
                after_detail=str(after_entries[index].detail),
            )
    if len(before_entries) != len(after_entries):
        entry = after_entries[limit] if len(after_entries) > limit else before_entries[limit]
        return FirstDiff(
            index=limit,
            year=int(entry.year),
            before_event="<end>" if len(before_entries) <= limit else str(before_entries[limit].event_type),
            after_event="<end>" if len(after_entries) <= limit else str(after_entries[limit].event_type),
            before_detail="<end>" if len(before_entries) <= limit else str(before_entries[limit].detail),
            after_detail="<end>" if len(after_entries) <= limit else str(after_entries[limit].detail),
        )
    return None


def total_memories(sim: object) -> tuple[int, float]:
    alive = sim.alive_people
    total = sum(len(person.memories) for person in alive)
    avg = total / max(1, len(alive))
    return total, avg


def pre_diff_state(module: ModuleType, seed: int, first_diff: FirstDiff | None) -> dict[str, float | int]:
    target_year = max(0, (first_diff.year - 1) if first_diff else YEARS)
    sim = module.SocietyLab(seed=seed, verbose=False)
    for _ in range(target_year):
        if sim.population == 0:
            break
        sim.step()
    summary = sim.summary()
    memory_total, memory_avg = total_memories(sim)
    return {
        "population": int(summary["final_population"]),
        "food": float(summary["final_food_stock"]),
        "failures": int(summary["project_failure_count"]),
        "memory_shared": int(summary["memory_shared_count"]),
        "total_memories": memory_total,
        "avg_memories": memory_avg,
        "shared_narratives": int(summary["shared_narrative_count"]),
        "network_splits": int(summary["network_split_count"]),
    }


def analyze() -> list[SeedAnalysis]:
    v13 = load_module("society_lab_v1_3_common_points", V13_PATH)
    v14 = load_module("society_lab_v1_4_common_points", V14_PATH)
    rows: list[SeedAnalysis] = []

    for seed in SEEDS:
        before_sim = run_sim(v13, seed)
        after_sim = run_sim(v14, seed)
        before = before_sim.summary()
        after = after_sim.summary()
        changed_keys = [
            key for key in SUMMARY_KEYS if key in before and key in after and before[key] != after[key]
        ]
        diff = first_log_diff(before_sim, after_sim)
        pre = pre_diff_state(v14, seed, diff)
        rows.append(
            SeedAnalysis(
                seed=seed,
                summary_changed=bool(changed_keys),
                log_changed=diff is not None,
                first_diff=diff,
                action_nudges=int(after.get("interpretation_action_nudge_count", 0)),
                support_nudges=int(after.get("interpretation_support_nudge_count", 0)),
                delta_population=float(after["final_population"]) - float(before["final_population"]),
                delta_food=float(after["final_food_stock"]) - float(before["final_food_stock"]),
                delta_failures=float(after["project_failure_count"]) - float(before["project_failure_count"]),
                delta_births=float(after["birth_count"]) - float(before["birth_count"]),
                delta_memory_shared=float(after["memory_shared_count"]) - float(before["memory_shared_count"]),
                delta_blame=float(after["avg_bias_blame"]) - float(before["avg_bias_blame"]),
                pre_population=int(pre["population"]),
                pre_food=float(pre["food"]),
                pre_failures=int(pre["failures"]),
                pre_memory_shared=int(pre["memory_shared"]),
                pre_total_memories=int(pre["total_memories"]),
                pre_avg_memories=float(pre["avg_memories"]),
                pre_shared_narratives=int(pre["shared_narratives"]),
                pre_network_splits=int(pre["network_splits"]),
            )
        )
    return rows


def mean(values: list[float]) -> str:
    if not values:
        return "-"
    return f"{statistics.mean(values):.2f}"


def median(values: list[float]) -> str:
    if not values:
        return "-"
    return f"{statistics.median(values):.2f}"


def fmt_delta(value: float) -> str:
    if value == int(value):
        return f"{int(value):+d}"
    return f"{value:+.3f}"


def md_table(headers: list[str], rows: list[list[object]]) -> list[str]:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def bucket_year(year: int | None) -> str:
    if year is None:
        return "no_log_change"
    if year <= 20:
        return "Y01-20"
    if year <= 40:
        return "Y21-40"
    if year <= 60:
        return "Y41-60"
    return "Y61-80"


def event_family(diff: FirstDiff | None) -> str:
    if diff is None:
        return "no_log_change"
    if diff.after_event == "proposal_supported":
        return "support_choice"
    if diff.after_event == "proposal_made":
        return "proposal_choice"
    if diff.after_event in {"project_started", "project_success", "project_failure"}:
        return "project_path"
    if diff.after_event == "memory_shared":
        return "memory_path"
    if diff.after_event == "birth":
        return "birth_path"
    if diff.after_event == "death":
        return "death_path"
    return diff.after_event


def build_report(rows: list[SeedAnalysis]) -> str:
    changed = [row for row in rows if row.summary_changed]
    absorbed = [row for row in rows if row.log_changed and not row.summary_changed]
    unchanged = [row for row in rows if not row.log_changed]
    log_changed = [row for row in rows if row.log_changed]

    lines: list[str] = []
    lines.append("# society_lab v1.4 changed-seed common points")
    lines.append("")
    lines.append("Compared v1.3 and v1.4 over seeds 1000-1099, 80 years each.")
    lines.append("")
    lines.append("## Main Split")
    lines.append("")
    lines.extend(
        md_table(
            ["group", "count", "mean action nudge", "mean support nudge", "median first diff year"],
            [
                [
                    "summary changed",
                    len(changed),
                    mean([row.action_nudges for row in changed]),
                    mean([row.support_nudges for row in changed]),
                    median([row.first_diff.year for row in changed if row.first_diff]),
                ],
                [
                    "log changed, summary returned",
                    len(absorbed),
                    mean([row.action_nudges for row in absorbed]),
                    mean([row.support_nudges for row in absorbed]),
                    median([row.first_diff.year for row in absorbed if row.first_diff]),
                ],
                [
                    "no log change",
                    len(unchanged),
                    mean([row.action_nudges for row in unchanged]),
                    mean([row.support_nudges for row in unchanged]),
                    "-",
                ],
            ],
        )
    )
    lines.append("")
    lines.append("## First-Difference Timing")
    lines.append("")
    timing_rows = []
    for label, subset in (
        ("summary changed", changed),
        ("absorbed", absorbed),
        ("all log changed", log_changed),
    ):
        counter = Counter(bucket_year(row.first_diff.year if row.first_diff else None) for row in subset)
        timing_rows.append(
            [
                label,
                counter["Y01-20"],
                counter["Y21-40"],
                counter["Y41-60"],
                counter["Y61-80"],
            ]
        )
    lines.extend(md_table(["group", "Y01-20", "Y21-40", "Y41-60", "Y61-80"], timing_rows))
    lines.append("")
    lines.append("## First-Difference Event Families")
    lines.append("")
    family_counter: dict[str, Counter[str]] = {
        "summary changed": Counter(event_family(row.first_diff) for row in changed),
        "absorbed": Counter(event_family(row.first_diff) for row in absorbed),
    }
    family_names = sorted(set(family_counter["summary changed"]) | set(family_counter["absorbed"]))
    family_rows = [
        [name, family_counter["summary changed"][name], family_counter["absorbed"][name]]
        for name in family_names
    ]
    lines.extend(md_table(["first diff family", "summary changed", "absorbed"], family_rows))
    lines.append("")
    lines.append("## Pre-Divergence State Averages")
    lines.append("")
    lines.append(
        "For changed/absorbed seeds, this is the v1.4 state at the year before the first log difference. "
        "For no-log-change seeds, this is the year-80 state."
    )
    lines.append("")
    state_rows = []
    for label, subset in (
        ("summary changed", changed),
        ("absorbed", absorbed),
        ("no log change", unchanged),
    ):
        state_rows.append(
            [
                label,
                mean([row.pre_population for row in subset]),
                mean([row.pre_food for row in subset]),
                mean([row.pre_failures for row in subset]),
                mean([row.pre_memory_shared for row in subset]),
                mean([row.pre_total_memories for row in subset]),
                mean([row.pre_avg_memories for row in subset]),
            ]
        )
    lines.extend(
        md_table(
            ["group", "pop", "food", "failures", "memory shares", "total memories", "avg memories/person"],
            state_rows,
        )
    )
    lines.append("")
    lines.append("## Changed Seeds Detail")
    lines.append("")
    detail_rows = []
    for row in changed:
        diff = row.first_diff
        detail_rows.append(
            [
                row.seed,
                diff.year if diff else "-",
                event_family(diff),
                f"{row.action_nudges}/{row.support_nudges}",
                fmt_delta(row.delta_population),
                fmt_delta(row.delta_food),
                fmt_delta(row.delta_failures),
                fmt_delta(row.delta_births),
                fmt_delta(row.delta_memory_shared),
                fmt_delta(row.delta_blame),
            ]
        )
    lines.extend(
        md_table(
            ["seed", "first diff", "family", "nudges", "pop", "food", "fail", "birth", "memshare", "blame"],
            detail_rows,
        )
    )
    lines.append("")
    lines.append("## Working Hypotheses")
    lines.append("")
    lines.append("1. The changed seeds are not defined by nudge existence. Every seed in this range has some nudge activity.")
    lines.append(
        "2. Changed seeds have higher average support-nudge volume than no-log-change seeds, but high volume alone is not sufficient."
    )
    lines.append(
        "3. First differences are often late. Seed 1003 is unusually readable because it diverges early at Year 14."
    )
    lines.append(
        "4. The first log difference is usually a support choice, with a smaller proposal-choice group. "
        "The later consequences still vary, so there is not one universal 1003-style chain."
    )
    lines.append(
        "5. A useful next check is to deep-read one seed from each outcome type: early support change, "
        "proposal change, large late population swing, absorbed log change, and no-path-change."
    )
    lines.append("")
    lines.append("Recommended next sample:")
    lines.append("")
    lines.append("- 1003: early support-choice divergence")
    lines.append("- 1012: high nudge volume")
    lines.append("- 1043: large population loss with later first divergence")
    lines.append("- 1008 or 1019: log changes but final summary returns")
    lines.append("- 1002: nudge-only, no path change")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    rows = analyze()
    report = build_report(rows)
    REPORT_PATH.write_text(report, encoding="utf-8")
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
