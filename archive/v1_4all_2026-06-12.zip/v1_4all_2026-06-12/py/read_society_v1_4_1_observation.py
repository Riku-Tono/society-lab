from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from pathlib import Path
from statistics import mean
from typing import Any


def load_payload(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def root_memory(memory_id: str, parent_by_id: dict[str, str]) -> str:
    current = memory_id
    seen: set[str] = set()
    while parent_by_id.get(current):
        if current in seen:
            break
        seen.add(current)
        current = parent_by_id[current]
    return current


def lineage_depth(memory_id: str, children_by_id: dict[str, list[str]]) -> int:
    best = 0
    queue: deque[tuple[str, int]] = deque([(memory_id, 0)])
    while queue:
        current, depth = queue.popleft()
        best = max(best, depth)
        for child in children_by_id.get(current, []):
            queue.append((child, depth + 1))
    return best


def summarize_memories(memories: list[dict[str, Any]]) -> dict[str, Any]:
    by_id = {entry["memory_id"]: entry for entry in memories}
    parent_by_id = {
        entry["memory_id"]: entry.get("parent_memory_id", "")
        for entry in memories
    }
    children_by_id: dict[str, list[str]] = defaultdict(list)
    for entry in memories:
        parent = entry.get("parent_memory_id", "")
        if parent:
            children_by_id[parent].append(entry["memory_id"])

    root_counts: Counter[str] = Counter()
    root_holders: dict[str, set[str]] = defaultdict(set)
    for entry in memories:
        root = root_memory(entry["memory_id"], parent_by_id)
        root_counts[root] += 1
        root_holders[root].add(entry["holder_id"])

    most_talked = []
    for memory_id, count in root_counts.most_common(10):
        root = by_id[memory_id]
        most_talked.append(
            {
                "root_memory_id": memory_id,
                "event": root["event"],
                "root_year": root["year"],
                "root_holder": root["holder_id"],
                "interpretation": root["interpretation"],
                "lineage_events": count,
                "unique_holders": len(root_holders[memory_id]),
                "max_depth": lineage_depth(memory_id, children_by_id),
            }
        )

    longest = sorted(
        [
            {
                "root_memory_id": memory_id,
                "event": by_id[memory_id]["event"],
                "root_year": by_id[memory_id]["year"],
                "root_holder": by_id[memory_id]["holder_id"],
                "interpretation": by_id[memory_id]["interpretation"],
                "max_depth": lineage_depth(memory_id, children_by_id),
                "lineage_events": root_counts[memory_id],
                "unique_holders": len(root_holders[memory_id]),
            }
            for memory_id in root_counts
        ],
        key=lambda item: (item["max_depth"], item["lineage_events"]),
        reverse=True,
    )[:10]

    return {
        "most_talked_memories": most_talked,
        "longest_lineages": longest,
    }


def summarize_support(supports: list[dict[str, Any]]) -> dict[str, Any]:
    nudged = [entry for entry in supports if entry.get("support_nudge", 0.0) != 0.0]
    by_action = Counter(entry["action"] for entry in nudged)
    by_problem = Counter(entry["problem"] for entry in nudged)
    by_supporter = Counter(entry["supporter_id"] for entry in nudged)
    by_proposer = Counter(entry["proposer_id"] for entry in nudged)
    return {
        "nudged_support_count": len(nudged),
        "nudged_support_events": nudged,
        "nudged_by_action": dict(by_action.most_common()),
        "nudged_by_problem": dict(by_problem.most_common()),
        "top_nudged_supporters": by_supporter.most_common(10),
        "top_nudged_proposers": by_proposer.most_common(10),
    }


def summarize_projects(projects: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in projects:
        grouped[entry["event"]].append(entry)

    result = {}
    for event, rows in grouped.items():
        result[event] = {
            "count": len(rows),
            "avg_supporters": round(mean(row["supporters"] for row in rows), 3),
            "avg_success_chance": round(mean(row["success_chance"] for row in rows), 3),
            "avg_food_stock_delta": round(mean(row["food_stock_delta"] for row in rows), 3),
            "avg_food_capacity_delta": round(mean(row["food_capacity_delta"] for row in rows), 3),
            "avg_supporter_fear_delta": round(mean(row["supporter_fear_delta"] for row in rows), 3),
            "avg_supporter_trust_to_proposer_delta": round(
                mean(row["supporter_trust_to_proposer_delta"] for row in rows), 3
            ),
            "events": rows,
        }
    return result


def summarize_roles(role_labels: dict[str, list[str]], actor_bio: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    role_counts = Counter(role for labels in role_labels.values() for role in labels)
    people = []
    for person_id, labels in role_labels.items():
        entries = actor_bio.get(person_id, [])
        people.append(
            {
                "person_id": person_id,
                "roles": labels,
                "role_count": len(labels),
                "biography_events": len(entries),
            }
        )
    people.sort(key=lambda item: (item["role_count"], item["biography_events"]), reverse=True)
    return {
        "role_counts": dict(role_counts.most_common()),
        "top_role_people": people[:20],
    }


def find_death_memory_support_proximity(
    memories: list[dict[str, Any]],
    supports: list[dict[str, Any]],
    window: int,
) -> list[dict[str, Any]]:
    supports_by_person: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for support in supports:
        supports_by_person[support["supporter_id"]].append(support)

    cases = []
    for memory in memories:
        if memory["event"] != "death":
            continue
        holder_id = memory["holder_id"]
        for support in supports_by_person.get(holder_id, []):
            gap = support["year"] - memory["year"]
            if 0 <= gap <= window:
                cases.append(
                    {
                        "gap_years": gap,
                        "memory_id": memory["memory_id"],
                        "memory_year": memory["year"],
                        "holder_supporter_id": holder_id,
                        "memory_source_id": memory["source_id"],
                        "memory_generation": memory["generation"],
                        "memory_interpretation": memory["interpretation"],
                        "support_year": support["year"],
                        "proposer_id": support["proposer_id"],
                        "action": support["action"],
                        "problem": support["problem"],
                        "support_nudge": support["support_nudge"],
                        "support_chance": support["support_chance"],
                    }
                )
    cases.sort(key=lambda item: (item["gap_years"], item["memory_year"], item["holder_supporter_id"]))
    return cases


def markdown_table(rows: list[dict[str, Any]], columns: list[str], limit: int = 10) -> str:
    if not rows:
        return "_none_\n"
    selected = rows[:limit]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    for row in selected:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    return "\n".join(lines) + "\n"


def build_report(payload: dict[str, Any], analysis: dict[str, Any]) -> str:
    summary = payload["summary"]
    lines = [
        f"# society_lab v1.4_1 reader report seed {summary['seed']}",
        "",
        "## Run Summary",
        "",
        f"- years: {summary['years']}",
        f"- population: {summary['initial_population']} -> {summary['final_population']}",
        f"- memory lineage events: {summary['memory_lineage_trace_count']}",
        f"- support chain events: {summary['support_chain_trace_count']}",
        f"- project aftermath events: {summary['project_aftermath_trace_count']}",
        f"- shared narratives: {summary['shared_narrative_count']}",
        f"- narrative divergences: {summary['narrative_divergence_count']}",
        "",
        "## Most Talked Memories",
        "",
        markdown_table(
            analysis["memory"]["most_talked_memories"],
            [
                "root_memory_id",
                "event",
                "root_year",
                "root_holder",
                "interpretation",
                "lineage_events",
                "unique_holders",
                "max_depth",
            ],
        ),
        "## Longest Lineages",
        "",
        markdown_table(
            analysis["memory"]["longest_lineages"],
            [
                "root_memory_id",
                "event",
                "root_year",
                "root_holder",
                "interpretation",
                "max_depth",
                "lineage_events",
                "unique_holders",
            ],
        ),
        "## Nudged Support",
        "",
        f"- nudged support events: {analysis['support']['nudged_support_count']}",
        f"- by action: {analysis['support']['nudged_by_action']}",
        f"- by problem: {analysis['support']['nudged_by_problem']}",
        "",
        markdown_table(
            analysis["support"]["nudged_support_events"],
            [
                "year",
                "supporter_id",
                "proposer_id",
                "action",
                "problem",
                "support_nudge",
                "support_chance",
            ],
            limit=20,
        ),
        "## Project Aftermath",
        "",
    ]
    for event, block in analysis["projects"].items():
        lines.extend(
            [
                f"### {event}",
                "",
                f"- count: {block['count']}",
                f"- avg supporters: {block['avg_supporters']}",
                f"- avg success chance: {block['avg_success_chance']}",
                f"- avg food stock delta: {block['avg_food_stock_delta']}",
                f"- avg food capacity delta: {block['avg_food_capacity_delta']}",
                f"- avg supporter fear delta: {block['avg_supporter_fear_delta']}",
                f"- avg supporter trust to proposer delta: {block['avg_supporter_trust_to_proposer_delta']}",
                "",
            ]
        )
    lines.extend(
        [
            "## Role Labels",
            "",
            f"- role counts: {analysis['roles']['role_counts']}",
            "",
            markdown_table(
                analysis["roles"]["top_role_people"],
                ["person_id", "roles", "role_count", "biography_events"],
                limit=20,
            ),
            "## Death Memory Near Support",
            "",
            f"- cases within window: {len(analysis['death_memory_support_proximity'])}",
            "",
            markdown_table(
                analysis["death_memory_support_proximity"],
                [
                    "gap_years",
                    "memory_year",
                    "holder_supporter_id",
                    "memory_source_id",
                    "memory_interpretation",
                    "support_year",
                    "proposer_id",
                    "action",
                    "problem",
                    "support_nudge",
                ],
                limit=30,
            ),
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Read society_lab v1.4_1 observation JSON.")
    parser.add_argument(
        "input",
        type=Path,
        nargs="?",
        default=Path("society_lab_v1_4_1_observation_seed1003.json"),
    )
    parser.add_argument("--window", type=int, default=5)
    parser.add_argument("--json-out", type=Path, default=Path("seed1003_reader_summary.json"))
    parser.add_argument("--md-out", type=Path, default=Path("seed1003_reader_report.md"))
    args = parser.parse_args()

    payload = load_payload(args.input)
    analysis = {
        "memory": summarize_memories(payload["memory_lineage_trace"]),
        "support": summarize_support(payload["support_chain_trace"]),
        "projects": summarize_projects(payload["project_aftermath_trace"]),
        "roles": summarize_roles(
            payload["observation_summary"]["role_labels"],
            payload["actor_biography"],
        ),
        "death_memory_support_proximity": find_death_memory_support_proximity(
            payload["memory_lineage_trace"],
            payload["support_chain_trace"],
            args.window,
        ),
    }

    args.json_out.write_text(
        json.dumps(analysis, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    args.md_out.write_text(build_report(payload, analysis), encoding="utf-8")
    print(args.md_out)
    print(args.json_out)


if __name__ == "__main__":
    main()
