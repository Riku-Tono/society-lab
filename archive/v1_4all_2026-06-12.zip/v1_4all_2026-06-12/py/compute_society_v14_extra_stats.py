from __future__ import annotations

import csv
import importlib.util
import math
import statistics
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
REPORT_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs\society_lab_v1_4_extra_statistics.md"
)
CSV_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs\society_lab_v1_4_seed_1000_1099_stats.csv"
)

SEEDS = range(1000, 1100)
YEARS = 80
SUMMARY_KEYS = (
    "final_population",
    "final_food_stock",
    "project_failure_count",
    "birth_count",
    "memory_shared_count",
    "narrative_divergence_count",
    "avg_bias_blame",
)


@dataclass(frozen=True)
class Row:
    seed: int
    summary_changed: bool
    log_changed: bool
    first_diff_year: int | None
    action_nudges: int
    support_nudges: int
    final_population_v13: float
    final_population_v14: float
    food_v13: float
    food_v14: float
    failures_v13: float
    failures_v14: float
    births_v13: float
    births_v14: float
    memshare_v13: float
    memshare_v14: float
    narrdiv_v13: float
    narrdiv_v14: float
    blame_v13: float
    blame_v14: float

    def delta(self, name: str) -> float:
        pairs = {
            "population": (self.final_population_v13, self.final_population_v14),
            "food": (self.food_v13, self.food_v14),
            "failures": (self.failures_v13, self.failures_v14),
            "births": (self.births_v13, self.births_v14),
            "memshare": (self.memshare_v13, self.memshare_v14),
            "narrdiv": (self.narrdiv_v13, self.narrdiv_v14),
            "blame": (self.blame_v13, self.blame_v14),
        }
        left, right = pairs[name]
        return right - left


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def run_sim(module: ModuleType, seed: int) -> object:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim


def first_log_diff_year(before: object, after: object) -> int | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return int(after_entries[index].year)
    if len(before_entries) != len(after_entries):
        entry = after_entries[limit] if len(after_entries) > limit else before_entries[limit]
        return int(entry.year)
    return None


def collect() -> list[Row]:
    v13 = load_module("society_lab_v1_3_extra_stats", V13_PATH)
    v14 = load_module("society_lab_v1_4_extra_stats", V14_PATH)
    rows: list[Row] = []
    for seed in SEEDS:
        before_sim = run_sim(v13, seed)
        after_sim = run_sim(v14, seed)
        before = before_sim.summary()
        after = after_sim.summary()
        summary_changed = any(before[key] != after[key] for key in SUMMARY_KEYS)
        first_diff_year = first_log_diff_year(before_sim, after_sim)
        rows.append(
            Row(
                seed=seed,
                summary_changed=summary_changed,
                log_changed=first_diff_year is not None,
                first_diff_year=first_diff_year,
                action_nudges=int(after.get("interpretation_action_nudge_count", 0)),
                support_nudges=int(after.get("interpretation_support_nudge_count", 0)),
                final_population_v13=float(before["final_population"]),
                final_population_v14=float(after["final_population"]),
                food_v13=float(before["final_food_stock"]),
                food_v14=float(after["final_food_stock"]),
                failures_v13=float(before["project_failure_count"]),
                failures_v14=float(after["project_failure_count"]),
                births_v13=float(before["birth_count"]),
                births_v14=float(after["birth_count"]),
                memshare_v13=float(before["memory_shared_count"]),
                memshare_v14=float(after["memory_shared_count"]),
                narrdiv_v13=float(before["narrative_divergence_count"]),
                narrdiv_v14=float(after["narrative_divergence_count"]),
                blame_v13=float(before["avg_bias_blame"]),
                blame_v14=float(after["avg_bias_blame"]),
            )
        )
    return rows


def corr(xs: list[float], ys: list[float]) -> str:
    if len(xs) < 2 or len(xs) != len(ys):
        return "-"
    mean_x = statistics.mean(xs)
    mean_y = statistics.mean(ys)
    num = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    den_x = math.sqrt(sum((x - mean_x) ** 2 for x in xs))
    den_y = math.sqrt(sum((y - mean_y) ** 2 for y in ys))
    if den_x == 0 or den_y == 0:
        return "-"
    return f"{num / (den_x * den_y):.3f}"


def mean(values: list[float]) -> str:
    return "-" if not values else f"{statistics.mean(values):.2f}"


def median(values: list[float]) -> str:
    return "-" if not values else f"{statistics.median(values):.2f}"


def md_table(headers: list[str], rows: list[list[object]]) -> list[str]:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def write_csv(rows: list[Row]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            [
                "seed",
                "summary_changed",
                "log_changed",
                "first_diff_year",
                "action_nudges",
                "support_nudges",
                "delta_population",
                "delta_food",
                "delta_failures",
                "delta_births",
                "delta_memshare",
                "delta_narrdiv",
                "delta_blame",
            ]
        )
        for row in rows:
            writer.writerow(
                [
                    row.seed,
                    row.summary_changed,
                    row.log_changed,
                    row.first_diff_year or "",
                    row.action_nudges,
                    row.support_nudges,
                    row.delta("population"),
                    row.delta("food"),
                    row.delta("failures"),
                    row.delta("births"),
                    row.delta("memshare"),
                    row.delta("narrdiv"),
                    row.delta("blame"),
                ]
            )


def build_report(rows: list[Row]) -> str:
    changed = [row for row in rows if row.summary_changed]
    absorbed = [row for row in rows if row.log_changed and not row.summary_changed]
    no_path = [row for row in rows if not row.log_changed]

    lines: list[str] = []
    lines.append("# society_lab v1.4 extra statistics")
    lines.append("")
    lines.append("Seed range: 1000-1099. Compared v1.3 and v1.4 over 80 years.")
    lines.append("")
    lines.append("## Group Means")
    lines.append("")
    group_rows = []
    for label, subset in (
        ("summary changed", changed),
        ("absorbed", absorbed),
        ("no path change", no_path),
    ):
        group_rows.append(
            [
                label,
                len(subset),
                mean([row.action_nudges for row in subset]),
                mean([row.support_nudges for row in subset]),
                median([row.first_diff_year for row in subset if row.first_diff_year]),
                mean([abs(row.delta("population")) for row in subset]),
                mean([abs(row.delta("food")) for row in subset]),
                mean([abs(row.delta("failures")) for row in subset]),
                mean([abs(row.delta("memshare")) for row in subset]),
            ]
        )
    lines.extend(
        md_table(
            [
                "group",
                "count",
                "mean action nudges",
                "mean support nudges",
                "median first diff year",
                "mean abs pop delta",
                "mean abs food delta",
                "mean abs failure delta",
                "mean abs memshare delta",
            ],
            group_rows,
        )
    )
    lines.append("")
    lines.append("## Correlations In Summary-Changed Seeds")
    lines.append("")
    metric_rows = []
    variables = {
        "support_nudges": [row.support_nudges for row in changed],
        "action_nudges": [row.action_nudges for row in changed],
        "first_diff_year": [float(row.first_diff_year or YEARS) for row in changed],
    }
    outcomes = {
        "abs_pop_delta": [abs(row.delta("population")) for row in changed],
        "abs_food_delta": [abs(row.delta("food")) for row in changed],
        "abs_failure_delta": [abs(row.delta("failures")) for row in changed],
        "abs_memshare_delta": [abs(row.delta("memshare")) for row in changed],
        "blame_delta": [row.delta("blame") for row in changed],
    }
    for var_name, xs in variables.items():
        for outcome_name, ys in outcomes.items():
            metric_rows.append([var_name, outcome_name, corr([float(x) for x in xs], [float(y) for y in ys])])
    lines.extend(md_table(["x", "y", "Pearson r"], metric_rows))
    lines.append("")
    lines.append("## Largest Absolute Deltas")
    lines.append("")
    for label, metric in (
        ("population", "population"),
        ("food", "food"),
        ("failures", "failures"),
        ("memory sharing", "memshare"),
    ):
        lines.append(f"### {label}")
        lines.append("")
        top = sorted(changed, key=lambda row: abs(row.delta(metric)), reverse=True)[:10]
        lines.extend(
            md_table(
                ["seed", "delta", "first diff year", "nudges"],
                [
                    [
                        row.seed,
                        f"{row.delta(metric):+.3f}",
                        row.first_diff_year or "-",
                        f"{row.action_nudges}/{row.support_nudges}",
                    ]
                    for row in top
                ],
            )
        )
        lines.append("")
    lines.append("## Reading")
    lines.append("")
    lines.append(
        "Support-nudge volume is associated with whether a path can change, but it is a weak predictor of the size of the final change. "
        "Large effects can come from modest nudge counts, as in 1003 and 1043."
    )
    lines.append("")
    lines.append(
        "The most useful next statistic is not only total nudge count. It is the first nudge that changes a support/proposal choice, "
        "plus whether that changed choice enters a project failure or memory-sharing chain."
    )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    rows = collect()
    write_csv(rows)
    REPORT_PATH.write_text(build_report(rows), encoding="utf-8")
    print(REPORT_PATH)
    print(CSV_PATH)


if __name__ == "__main__":
    main()
