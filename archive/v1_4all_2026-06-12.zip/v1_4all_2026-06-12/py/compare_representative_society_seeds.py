from __future__ import annotations

import csv
import importlib.util
import re
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
CSV_PATH = OUT_DIR / "society_lab_v1_4_representative_seed_table.csv"
REPORT_PATH = OUT_DIR / "society_lab_v1_4_representative_seed_comparison.md"

SEED_TYPES = {
    1003: "A_failure_memory_shrink",
    1043: "A_failure_memory_shrink",
    1012: "B_memory_composition_shrink",
    1024: "C_collapse_avoidance_or_growth",
    1008: "D_absorbed",
    1002: "E_no_log_change",
}
SEEDS = tuple(SEED_TYPES)
YEARS = 80
MILESTONES = tuple(range(10, 81, 10))


@dataclass(frozen=True)
class FirstDiff:
    year: int | None
    family: str
    v13: str
    v14: str
    changed_person_id: str
    changed_person_name: str
    changed_action: str
    changed_problem: str
    changed_project_memory: str
    participant_changed: bool
    project_result_changed: bool
    supporters_v13: int | str
    supporters_v14: int | str
    supporter_added: str
    supporter_removed: str


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def run_sim(module: ModuleType, seed: int) -> object:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim


def compact_event(entry: object | None) -> str:
    if entry is None:
        return ""
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def first_log_diff(before: object, after: object) -> tuple[object | None, object | None] | None:
    before_entries = before.log.entries
    after_entries = after.log.entries
    limit = min(len(before_entries), len(after_entries))
    for index in range(limit):
        if compact_event(before_entries[index]) != compact_event(after_entries[index]):
            return before_entries[index], after_entries[index]
    if len(before_entries) != len(after_entries):
        left = None if len(before_entries) <= limit else before_entries[limit]
        right = None if len(after_entries) <= limit else after_entries[limit]
        return left, right
    return None


def family(entry: object | None) -> str:
    if entry is None:
        return "none"
    if entry.event_type == "proposal_supported":
        return "support_choice"
    if entry.event_type == "proposal_made":
        return "proposal_choice"
    if entry.event_type == "memory_shared":
        return "memory"
    return "event"


def parse_action(detail: str, verb: str) -> str:
    match = re.search(rf"{verb}\s+(\w+)", detail)
    return match.group(1) if match else ""


def parse_project(detail: str) -> tuple[str, str]:
    match = re.search(r"project_(?:started|success|failure):\s+(\w+)\s+for\s+(\w+)", detail)
    if match:
        return match.group(1), match.group(2)
    match = re.search(r"for\s+(\w+)", detail)
    return "", match.group(1) if match else ""


def person_name(sim: object, person_id: str) -> str:
    if not person_id:
        return ""
    try:
        return sim._person(person_id).name
    except Exception:
        return ""


def support_sets(sim: object, year: int) -> dict[str, set[str]]:
    rows: dict[str, set[str]] = {}
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type != "proposal_supported" or len(entry.persons) < 2:
            continue
        supporter, proposer = entry.persons[:2]
        action = parse_action(entry.detail, "supported")
        rows.setdefault(f"{proposer}:{action}", set()).add(supporter)
    return rows


def project_starts(sim: object, year: int) -> dict[str, set[str]]:
    rows: dict[str, set[str]] = {}
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type != "project_started":
            continue
        action, problem = parse_project(entry.detail)
        if action:
            rows[f"{action}:{problem}"] = set(entry.persons[1:])
    return rows


def project_results(sim: object, year: int) -> dict[str, str]:
    rows = {}
    for entry in sim.log.entries:
        if entry.year != year or entry.event_type not in {"project_success", "project_failure"}:
            continue
        action, problem = parse_project(entry.detail)
        if action:
            rows[f"{action}:{problem}"] = entry.event_type
    return rows


def first_diff(seed: int, before: object, after: object) -> FirstDiff:
    diff = first_log_diff(before, after)
    if diff is None:
        return FirstDiff(None, "none", "", "", "", "", "", "", "", False, False, "", "", "", "")
    left, right = diff
    entry = right or left
    year = int(entry.year)
    fam = family(entry)
    changed_person = ""
    action = ""
    problem = ""
    supporters_v13: int | str = ""
    supporters_v14: int | str = ""
    added = ""
    removed = ""

    if fam == "support_choice" and right is not None and len(right.persons) >= 2:
        changed_person = right.persons[0]
        proposer = right.persons[1]
        action = parse_action(right.detail, "supported")
        key = f"{proposer}:{action}"
        before_set = support_sets(before, year).get(key, set())
        after_set = support_sets(after, year).get(key, set())
        supporters_v13 = len(before_set)
        supporters_v14 = len(after_set)
        added = ",".join(sorted(after_set - before_set))
        removed = ",".join(sorted(before_set - after_set))
    elif fam == "proposal_choice" and right is not None and right.persons:
        changed_person = right.persons[0]
        action = parse_action(right.detail, "proposed")
        _, problem = parse_project(right.detail)

    if action and not problem:
        for key in project_starts(after, year):
            p_action, p_problem = key.split(":", 1)
            if p_action == action:
                problem = p_problem
                break

    project_key = f"{action}:{problem}" if action and problem else ""
    before_starts = project_starts(before, year)
    after_starts = project_starts(after, year)
    participant_changed = bool(project_key and before_starts.get(project_key, set()) != after_starts.get(project_key, set()))
    before_results = project_results(before, year)
    after_results = project_results(after, year)
    project_result_changed = bool(project_key and before_results.get(project_key) != after_results.get(project_key))
    result = after_results.get(project_key) or before_results.get(project_key) or ""
    memory = f"{result}:{action}" if result and action else ""

    return FirstDiff(
        year,
        fam,
        compact_event(left),
        compact_event(right),
        changed_person,
        person_name(after, changed_person),
        action,
        problem,
        memory,
        participant_changed,
        project_result_changed,
        supporters_v13,
        supporters_v14,
        added,
        removed,
    )


def memory_stats(sim: object, memory_event: str, start_year: int | None) -> dict[str, Any]:
    if not memory_event or start_year is None:
        return {
            "shares": 0,
            "unique_speakers": 0,
            "unique_listeners": 0,
            "unique_people_touched": 0,
            "last_share_year": "",
            "max_generation": "",
        }
    entries = []
    for entry in sim.log.entries:
        if entry.year < start_year or entry.event_type != "memory_shared":
            continue
        match = re.search(r"about\s+([^\s]+)\s+intensity=.*generation=(\d+)", entry.detail)
        if match and match.group(1) == memory_event:
            entries.append((entry, int(match.group(2))))
    speakers = Counter(entry.persons[0] for entry, _ in entries if entry.persons)
    listeners = Counter(entry.persons[1] for entry, _ in entries if len(entry.persons) > 1)
    touched = set(speakers) | set(listeners)
    return {
        "shares": len(entries),
        "unique_speakers": len(speakers),
        "unique_listeners": len(listeners),
        "unique_people_touched": len(touched),
        "last_share_year": max((entry.year for entry, _ in entries), default=""),
        "max_generation": max((generation for _, generation in entries), default=""),
    }


def snapshot_rows(module: ModuleType, seed: int) -> dict[int, dict[str, Any]]:
    sim = module.SocietyLab(seed=seed, verbose=False)
    rows = {}
    for _ in range(YEARS):
        if sim.population == 0:
            break
        sim.step()
        if sim.year in MILESTONES:
            s = sim.summary()
            rows[sim.year] = {
                "population": s["final_population"],
                "food": s["final_food_stock"],
                "birth": s["birth_count"],
                "death": s["death_count"],
                "project_failure": s["project_failure_count"],
                "memory_shared": s["memory_shared_count"],
                "shared_narrative": s["shared_narrative_count"],
                "narrative_divergence": s["narrative_divergence_count"],
                "avg_bias_blame": s["avg_bias_blame"],
            }
    return rows


def delta(before: object, after: object, key: str) -> float:
    return float(after.summary()[key]) - float(before.summary()[key])


def verdict(seed_type: str, fd: FirstDiff, v13_mem: dict[str, Any], v14_mem: dict[str, Any], before: object, after: object) -> str:
    if seed_type.startswith("E"):
        return "nudge present but no logged choice change"
    if seed_type.startswith("D"):
        return "choice changed but absorbed; no durable summary difference"
    if not fd.participant_changed and fd.family == "support_choice":
        return "summary changed, but first support difference did not clearly alter project participants"
    if fd.changed_project_memory and (v13_mem["shares"] or v14_mem["shares"]):
        return "first difference reaches project memory sharing"
    if delta(before, after, "final_population") > 0:
        return "population preserved or increased relative to v1.3"
    return "pathway remains partly unclear"


def analyze_seed(seed: int, v13: ModuleType, v14: ModuleType) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    before = run_sim(v13, seed)
    after = run_sim(v14, seed)
    fd = first_diff(seed, before, after)
    v13_mem = memory_stats(before, fd.changed_project_memory, fd.year)
    v14_mem = memory_stats(after, fd.changed_project_memory, fd.year)
    row = {
        "seed": seed,
        "type": SEED_TYPES[seed],
        "first_diff_year": fd.year or "",
        "first_diff_family": fd.family,
        "first_diff_v13": fd.v13,
        "first_diff_v14": fd.v14,
        "changed_person_id": fd.changed_person_id,
        "changed_person_name": fd.changed_person_name,
        "changed_action_or_project": fd.changed_action,
        "changed_problem": fd.changed_problem,
        "supporters_v13": fd.supporters_v13,
        "supporters_v14": fd.supporters_v14,
        "supporter_added": fd.supporter_added,
        "supporter_removed": fd.supporter_removed,
        "participant_changed": fd.participant_changed,
        "project_result_changed": fd.project_result_changed,
        "project_memory_event": fd.changed_project_memory,
        "project_memory_shared_v13": v13_mem["shares"],
        "project_memory_shared_v14": v14_mem["shares"],
        "project_memory_shared_delta": v14_mem["shares"] - v13_mem["shares"],
        "project_memory_speakers_v13": v13_mem["unique_speakers"],
        "project_memory_speakers_v14": v14_mem["unique_speakers"],
        "project_memory_listeners_v13": v13_mem["unique_listeners"],
        "project_memory_listeners_v14": v14_mem["unique_listeners"],
        "project_memory_people_touched_v13": v13_mem["unique_people_touched"],
        "project_memory_people_touched_v14": v14_mem["unique_people_touched"],
        "project_memory_last_share_year_v13": v13_mem["last_share_year"],
        "project_memory_last_share_year_v14": v14_mem["last_share_year"],
        "project_memory_max_generation_v13": v13_mem["max_generation"],
        "project_memory_max_generation_v14": v14_mem["max_generation"],
        "final_population_delta": delta(before, after, "final_population"),
        "final_food_delta": delta(before, after, "final_food_stock"),
        "birth_delta": delta(before, after, "birth_count"),
        "death_delta": delta(before, after, "death_count"),
        "project_failure_delta": delta(before, after, "project_failure_count"),
        "memory_shared_delta": delta(before, after, "memory_shared_count"),
        "shared_narrative_delta": delta(before, after, "shared_narrative_count"),
        "narrative_divergence_delta": delta(before, after, "narrative_divergence_count"),
        "avg_bias_blame_delta": delta(before, after, "avg_bias_blame"),
    }
    row["verdict"] = verdict(SEED_TYPES[seed], fd, v13_mem, v14_mem, before, after)

    v13_snaps = snapshot_rows(v13, seed)
    v14_snaps = snapshot_rows(v14, seed)
    timeline = []
    for year in MILESTONES:
        left = v13_snaps.get(year, {})
        right = v14_snaps.get(year, {})
        for metric in (
            "population",
            "food",
            "birth",
            "death",
            "project_failure",
            "memory_shared",
            "shared_narrative",
            "narrative_divergence",
            "avg_bias_blame",
        ):
            timeline.append(
                {
                    "seed": seed,
                    "year": year,
                    "metric": metric,
                    "v1.3": left.get(metric, ""),
                    "v1.4": right.get(metric, ""),
                    "delta": (
                        right.get(metric, 0) - left.get(metric, 0)
                        if metric in left and metric in right
                        else ""
                    ),
                }
            )
    return row, timeline


def write_csv(rows: list[dict[str, Any]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def build_report(rows: list[dict[str, Any]], timelines: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    lines.append("# society_lab v1.4 representative seed comparison")
    lines.append("")
    lines.append("Representative seeds compared in a shared format. Interpretation is intentionally restrained.")
    lines.append("")
    lines.append("## Cross Comparison")
    lines.append("")
    lines.extend(
        md_table(
            [
                "seed",
                "type",
                "first_diff_year",
                "family",
                "participant_changed",
                "project_result_changed",
                "project_memory",
                "memory_delta",
                "pop_delta",
                "food_delta",
                "birth_delta",
                "memory_shared_delta",
                "verdict",
            ],
            [
                [
                    row["seed"],
                    row["type"],
                    row["first_diff_year"],
                    row["first_diff_family"],
                    row["participant_changed"],
                    row["project_result_changed"],
                    row["project_memory_event"],
                    row["project_memory_shared_delta"],
                    row["final_population_delta"],
                    row["final_food_delta"],
                    row["birth_delta"],
                    row["memory_shared_delta"],
                    row["verdict"],
                ]
                for row in rows
            ],
        )
    )
    lines.append("")
    for row in rows:
        lines.append(f"## Seed {row['seed']} ({row['type']})")
        lines.append("")
        lines.append("### First Difference")
        lines.append("")
        lines.append("```text")
        lines.append(f"v1.3: {row['first_diff_v13']}")
        lines.append(f"v1.4: {row['first_diff_v14']}")
        lines.append("```")
        lines.append("")
        lines.extend(
            md_table(
                ["field", "value"],
                [
                    ["changed person", f"{row['changed_person_id']} {row['changed_person_name']}"],
                    ["changed action/problem", f"{row['changed_action_or_project']} / {row['changed_problem']}"],
                    ["supporters v1.3 -> v1.4", f"{row['supporters_v13']} -> {row['supporters_v14']}"],
                    ["supporter added", row["supporter_added"] or "-"],
                    ["supporter removed", row["supporter_removed"] or "-"],
                    ["participant_changed", row["participant_changed"]],
                    ["project_result_changed", row["project_result_changed"]],
                ],
            )
        )
        lines.append("")
        lines.append("### Project Memory")
        lines.append("")
        lines.extend(
            md_table(
                ["metric", "v1.3", "v1.4", "delta"],
                [
                    [
                        "shares",
                        row["project_memory_shared_v13"],
                        row["project_memory_shared_v14"],
                        row["project_memory_shared_delta"],
                    ],
                    [
                        "unique speakers",
                        row["project_memory_speakers_v13"],
                        row["project_memory_speakers_v14"],
                        row["project_memory_speakers_v14"] - row["project_memory_speakers_v13"],
                    ],
                    [
                        "unique listeners",
                        row["project_memory_listeners_v13"],
                        row["project_memory_listeners_v14"],
                        row["project_memory_listeners_v14"] - row["project_memory_listeners_v13"],
                    ],
                    [
                        "people touched",
                        row["project_memory_people_touched_v13"],
                        row["project_memory_people_touched_v14"],
                        row["project_memory_people_touched_v14"] - row["project_memory_people_touched_v13"],
                    ],
                    [
                        "last share year",
                        row["project_memory_last_share_year_v13"],
                        row["project_memory_last_share_year_v14"],
                        "",
                    ],
                    [
                        "max generation",
                        row["project_memory_max_generation_v13"],
                        row["project_memory_max_generation_v14"],
                        "",
                    ],
                ],
            )
        )
        lines.append("")
        lines.append("### 10-Year Timeline")
        lines.append("")
        seed_timeline = [item for item in timelines if item["seed"] == row["seed"]]
        table_rows = []
        for year in MILESTONES:
            values = {item["metric"]: item for item in seed_timeline if item["year"] == year}
            table_rows.append(
                [
                    year,
                    f"{values['population']['v1.3']}->{values['population']['v1.4']}",
                    f"{values['food']['v1.3']}->{values['food']['v1.4']}",
                    f"{values['birth']['v1.3']}->{values['birth']['v1.4']}",
                    f"{values['death']['v1.3']}->{values['death']['v1.4']}",
                    f"{values['project_failure']['v1.3']}->{values['project_failure']['v1.4']}",
                    f"{values['memory_shared']['v1.3']}->{values['memory_shared']['v1.4']}",
                    f"{values['shared_narrative']['v1.3']}->{values['shared_narrative']['v1.4']}",
                    f"{values['narrative_divergence']['v1.3']}->{values['narrative_divergence']['v1.4']}",
                    f"{values['avg_bias_blame']['v1.3']}->{values['avg_bias_blame']['v1.4']}",
                ]
            )
        lines.extend(
            md_table(
                ["year", "pop", "food", "birth", "death", "failure", "memshare", "shared narrative", "narr div", "blame"],
                table_rows,
            )
        )
        lines.append("")
        lines.append(f"Verdict: {row['verdict']}")
        lines.append("")
    lines.append("## Overall Reading")
    lines.append("")
    lines.append(
        "The A/B/C/D/E labels are useful but not final. The representative set shows at least three distinct outcomes: "
        "project-memory-linked shrinkage, memory-composition change, and collapse avoidance/growth. "
        "The absorbed and no-log-change examples are useful controls."
    )
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    v13 = load_module("society_lab_v1_3_representatives", V13_PATH)
    v14 = load_module("society_lab_v1_4_representatives", V14_PATH)
    rows = []
    timelines = []
    for seed in SEEDS:
        row, timeline = analyze_seed(seed, v13, v14)
        rows.append(row)
        timelines.extend(timeline)
    write_csv(rows)
    REPORT_PATH.write_text(build_report(rows, timelines), encoding="utf-8")
    print(CSV_PATH)
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
