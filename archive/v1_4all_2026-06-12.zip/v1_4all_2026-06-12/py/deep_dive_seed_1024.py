from __future__ import annotations

import csv
import importlib.util
import re
import sys
from collections import Counter
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
REPORT_PATH = OUT_DIR / "society_lab_seed_1024_deep_dive.md"
CSV_PATH = OUT_DIR / "society_lab_seed_1024_yearly_delta.csv"

SEED = 1024
YEARS = 80


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def run_yearly(module: ModuleType) -> tuple[object, list[dict[str, Any]]]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    rows: list[dict[str, Any]] = []
    for _ in range(YEARS):
        if sim.population == 0:
            break
        sim.step()
        s = sim.summary()
        rows.append(
            {
                "year": sim.year,
                "population": s["final_population"],
                "food": s["final_food_stock"],
                "birth": s["birth_count"],
                "death": s["death_count"],
                "proposal": s["proposal_count"],
                "project_success": s["project_success_count"],
                "project_failure": s["project_failure_count"],
                "memory_shared": s["memory_shared_count"],
                "shared_narrative": s["shared_narrative_count"],
                "network_split": s["network_split_count"],
                "narrative_divergence": s["narrative_divergence_count"],
                "interpretation_divergence": s["interpretation_divergence_count"],
                "avg_fear": s["avg_fear"],
                "avg_hunger": s["avg_hunger"],
                "avg_bias_blame": s["avg_bias_blame"],
            }
        )
    return sim, rows


def compact(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def first_log_diff(before: object, after: object) -> tuple[object, object] | None:
    limit = min(len(before.log.entries), len(after.log.entries))
    for index in range(limit):
        if compact(before.log.entries[index]) != compact(after.log.entries[index]):
            return before.log.entries[index], after.log.entries[index]
    return None


def yearly_delta_rows(v13_rows: list[dict[str, Any]], v14_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for left, right in zip(v13_rows, v14_rows):
        row = {"year": left["year"]}
        for key in left:
            if key == "year":
                continue
            row[f"{key}_v13"] = left[key]
            row[f"{key}_v14"] = right[key]
            row[f"diff_{key}"] = right[key] - left[key]
        rows.append(row)
    return rows


def event_window(sim: object, start: int, end: int) -> list[str]:
    return [compact(entry) for entry in sim.log.entries if start <= entry.year <= end]


def memory_counts(sim: object, start: int, end: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if not (start <= entry.year <= end) or entry.event_type != "memory_shared":
            continue
        match = re.search(r"about\s+([^\s]+)\s+intensity=", entry.detail)
        if match:
            counts[match.group(1)] += 1
    return counts


def project_counts(sim: object, start: int, end: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if not (start <= entry.year <= end) or entry.event_type not in {"project_success", "project_failure"}:
            continue
        match = re.search(r"(project_(?:success|failure)):\s+(\w+)\s+for\s+(\w+)", entry.detail)
        if match:
            counts[f"{match.group(1)}:{match.group(2)}:{match.group(3)}"] += 1
    return counts


def births_deaths_by_window(sim: object, start: int, end: int) -> Counter[str]:
    counts: Counter[str] = Counter()
    for entry in sim.log.entries:
        if start <= entry.year <= end and entry.event_type in {"birth", "death"}:
            counts[entry.event_type] += 1
    return counts


def top_diffs(left: Counter[str], right: Counter[str], limit: int = 12) -> list[list[Any]]:
    keys = set(left) | set(right)
    rows = []
    for key in keys:
        diff = right[key] - left[key]
        if diff:
            rows.append([key, left[key], right[key], diff])
    rows.sort(key=lambda row: abs(row[3]), reverse=True)
    return rows[:limit]


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(item) for item in row) + " |")
    return lines


def write_csv(rows: list[dict[str, Any]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def find_opening_year(delta_rows: list[dict[str, Any]]) -> int:
    for row in delta_rows:
        if abs(row["diff_population"]) >= 4 or abs(row["diff_birth"]) >= 4:
            return int(row["year"])
    return 50


def build_report() -> str:
    v13 = load_module("society_lab_v1_3_seed1024", V13_PATH)
    v14 = load_module("society_lab_v1_4_seed1024", V14_PATH)
    before, before_rows = run_yearly(v13)
    after, after_rows = run_yearly(v14)
    deltas = yearly_delta_rows(before_rows, after_rows)
    write_csv(deltas)

    first = first_log_diff(before, after)
    opening = find_opening_year(deltas)
    windows = [(38, 45), (46, 55), (56, 70), (71, 80)]

    lines: list[str] = []
    lines.append("# society_lab seed 1024 deep dive")
    lines.append("")
    lines.append("Focus: why v1.3 collapses while v1.4 survives with higher population.")
    lines.append("")
    lines.append("## First Log Difference")
    lines.append("")
    lines.append("```text")
    if first:
        lines.append(f"v1.3: {compact(first[0])}")
        lines.append(f"v1.4: {compact(first[1])}")
    else:
        lines.append("No log difference.")
    lines.append("```")
    lines.append("")

    lines.append("## Yearly Delta")
    lines.append("")
    years = {10, 20, 30, 38, 40, 45, 50, 55, 60, 65, 70, 75, 80}
    table_rows = []
    for row in deltas:
        if row["year"] in years:
            table_rows.append(
                [
                    row["year"],
                    f"{row['population_v13']}->{row['population_v14']} ({row['diff_population']:+})",
                    f"{row['food_v13']:.3f}->{row['food_v14']:.3f} ({row['diff_food']:+.3f})",
                    f"{row['birth_v13']}->{row['birth_v14']} ({row['diff_birth']:+})",
                    f"{row['death_v13']}->{row['death_v14']} ({row['diff_death']:+})",
                    f"{row['project_failure_v13']}->{row['project_failure_v14']} ({row['diff_project_failure']:+})",
                    f"{row['memory_shared_v13']}->{row['memory_shared_v14']} ({row['diff_memory_shared']:+})",
                    f"{row['avg_bias_blame_v13']:.3f}->{row['avg_bias_blame_v14']:.3f} ({row['diff_avg_bias_blame']:+.3f})",
                ]
            )
    lines.extend(
        md_table(
            ["year", "pop", "food", "birth", "death", "failure", "memshare", "blame"],
            table_rows,
        )
    )
    lines.append("")
    lines.append(f"First year with population/birth gap >= 4: Year {opening}")
    lines.append("")

    lines.append("## Window Diffs")
    lines.append("")
    for start, end in windows:
        lines.append(f"### Years {start}-{end}")
        lines.append("")
        bbd = births_deaths_by_window(before, start, end)
        abd = births_deaths_by_window(after, start, end)
        lines.extend(md_table(["event", "v1.3", "v1.4", "delta"], top_diffs(bbd, abd, 10)))
        lines.append("")
        pc13 = project_counts(before, start, end)
        pc14 = project_counts(after, start, end)
        lines.append("Project result differences:")
        lines.extend(md_table(["project event", "v1.3", "v1.4", "delta"], top_diffs(pc13, pc14, 10)))
        lines.append("")
        mc13 = memory_counts(before, start, end)
        mc14 = memory_counts(after, start, end)
        lines.append("Memory-share differences:")
        lines.extend(md_table(["memory event", "v1.3", "v1.4", "delta"], top_diffs(mc13, mc14, 10)))
        lines.append("")

    lines.append("## Event Windows")
    lines.append("")
    for start, end in ((38, 42), (50, 55), (60, 65)):
        lines.append(f"### v1.3 Years {start}-{end}")
        lines.append("")
        lines.append("```text")
        lines.extend(event_window(before, start, end))
        lines.append("```")
        lines.append("")
        lines.append(f"### v1.4 Years {start}-{end}")
        lines.append("")
        lines.append("```text")
        lines.extend(event_window(after, start, end))
        lines.append("```")
        lines.append("")

    lines.append("## Reading")
    lines.append("")
    lines.append(
        "Seed 1024 should not be treated as a simple first-diff project-memory case. "
        "The first support difference does not clearly enter a project in the same year. "
        "The important divergence is delayed: v1.3 loses births and population after the middle years, "
        "while v1.4 maintains a larger living population."
    )
    lines.append("")
    lines.append(
        "The window tables are the main evidence. If the birth/death gap opens without a matching project-memory path, "
        "1024 belongs in a different `collapse avoidance` family rather than the 1003/1043 failure-memory family."
    )
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(build_report(), encoding="utf-8")
    print(REPORT_PATH)
    print(CSV_PATH)


if __name__ == "__main__":
    main()
