from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType


V14_PATH = Path(__file__).with_name("society_lab_v1_4.py")
SEED = 1003
YEARS = 80
TARGET_YEAR = 14
TARGET_ACTION = "store_food"
TARGET_PROBLEM = "water_shortage"


def load_module(label: str, path: Path) -> ModuleType:
    module_name = label.replace(".", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def compact(entry: object) -> str:
    persons = ",".join(entry.persons)
    return f"Y{entry.year:02d} {entry.event_type} [{persons}] {entry.detail}"


def run_sim() -> object:
    module = load_module("society_lab_v1_4", V14_PATH)
    sim = module.SocietyLab(seed=SEED, verbose=False)
    sim.run(years=YEARS)
    return sim


def find_target_project(sim: object) -> tuple[str, set[str]]:
    for entry in sim.log.entries:
        if (
            entry.year == TARGET_YEAR
            and entry.event_type == "project_started"
            and f"{TARGET_ACTION} for {TARGET_PROBLEM}" in entry.detail
        ):
            proposer_id = entry.persons[0]
            supporter_ids = set(entry.persons[1:])
            return proposer_id, supporter_ids
    raise RuntimeError("Target project not found")


def count_after(sim: object, person_id: str, after_year: int) -> dict[str, int]:
    counts = {
        "events_involved": 0,
        "memory_shared_as_speaker": 0,
        "memory_shared_as_listener": 0,
        "proposal_supported_as_supporter": 0,
        "proposal_supported_as_proposer": 0,
        "project_started_participant": 0,
        "project_success_participant": 0,
        "project_failure_participant": 0,
        "birth_parent": 0,
        "death_self": 0,
    }
    for entry in sim.log.entries:
        if entry.year < after_year or person_id not in entry.persons:
            continue
        counts["events_involved"] += 1
        if entry.event_type == "memory_shared":
            if entry.persons[0] == person_id:
                counts["memory_shared_as_speaker"] += 1
            if len(entry.persons) > 1 and entry.persons[1] == person_id:
                counts["memory_shared_as_listener"] += 1
        elif entry.event_type == "proposal_supported":
            if entry.persons[0] == person_id:
                counts["proposal_supported_as_supporter"] += 1
            if len(entry.persons) > 1 and entry.persons[1] == person_id:
                counts["proposal_supported_as_proposer"] += 1
        elif entry.event_type == "project_started":
            counts["project_started_participant"] += 1
        elif entry.event_type == "project_success":
            counts["project_success_participant"] += 1
        elif entry.event_type == "project_failure":
            counts["project_failure_participant"] += 1
        elif entry.event_type == "birth" and entry.persons[0] == person_id:
            counts["birth_parent"] += 1
        elif entry.event_type == "death" and entry.persons[0] == person_id:
            counts["death_self"] += 1
    return counts


def death_year(sim: object, person_id: str) -> int | None:
    for entry in sim.log.entries:
        if entry.event_type == "death" and entry.persons and entry.persons[0] == person_id:
            return entry.year
    return None


def person_snapshot(sim: object, person_id: str) -> dict[str, object]:
    person = sim._person(person_id)
    incoming_trust = sim._incoming_trust(person_id)
    return {
        "id": person.id,
        "name": person.name,
        "alive": person.alive,
        "death_year": death_year(sim, person_id),
        "final_age": person.age,
        "charisma": round(person.charisma, 3),
        "food_skill": round(person.food_skill, 3),
        "voice_weight": round(person.voice_weight, 3),
        "incoming_trust": round(incoming_trust, 3),
        "trust_links": len(person.trust),
        "memory_count": len(person.memories),
        "bias_spiritual": round(person.interpretation_bias.get("spiritual", 0.0), 4),
        "bias_practical": round(person.interpretation_bias.get("practical", 0.0), 4),
        "bias_blame": round(person.interpretation_bias.get("blame", 0.0), 4),
    }


def print_relevant_events(sim: object, person_id: str) -> None:
    print(f"Events involving {person_id} after Year {TARGET_YEAR}:")
    printed = 0
    for entry in sim.log.entries:
        if entry.year < TARGET_YEAR or person_id not in entry.persons:
            continue
        if entry.event_type in {
            "memory_shared",
            "proposal_supported",
            "project_started",
            "project_success",
            "project_failure",
            "birth",
            "death",
        }:
            print(f"  {compact(entry)}")
            printed += 1
        if printed >= 40:
            print("  ...")
            break


def main() -> None:
    sim = run_sim()
    proposer_id, supporter_ids = find_target_project(sim)

    # From the previous v1.3/v1.4 comparison, v1.3 had the same supporters
    # except p019. Keep this explicit so the trace remains readable.
    v13_supporters = {
        "p001",
        "p002",
        "p011",
        "p021",
        "p024",
        "p027",
        "p031",
        "p032",
        "p034",
        "p035",
    }
    extra_supporters = sorted(supporter_ids - v13_supporters)

    print(f"seed {SEED}, v1.4, Year {TARGET_YEAR}")
    print(f"target project: {TARGET_ACTION} for {TARGET_PROBLEM}")
    print(f"proposer: {proposer_id}")
    print(f"supporters: {sorted(supporter_ids)}")
    print(f"extra supporters compared with v1.3: {extra_supporters}")
    print()

    for person_id in extra_supporters:
        print(f"Person snapshot: {person_snapshot(sim, person_id)}")
        print(f"Post-Year-{TARGET_YEAR} counts: {count_after(sim, person_id, TARGET_YEAR)}")
        print()
        print_relevant_events(sim, person_id)
        print()


if __name__ == "__main__":
    main()
