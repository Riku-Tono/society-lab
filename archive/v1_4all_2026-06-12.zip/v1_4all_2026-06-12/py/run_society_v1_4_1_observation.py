from __future__ import annotations

import argparse
import json
from pathlib import Path

from society_lab_v1_4_1 import SocietyLab


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run society_lab v1.4_1 and export observation traces."
    )
    parser.add_argument("--seed", type=int, default=1003)
    parser.add_argument("--years", type=int, default=80)
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("society_lab_v1_4_1_observation_seed1003.json"),
    )
    args = parser.parse_args()

    sim = SocietyLab(seed=args.seed, verbose=False)
    sim.run(args.years)

    payload = {
        "summary": sim.summary(),
        "observation_summary": sim.observation_summary(),
        "actor_biography": sim.actor_biography,
        "memory_lineage_trace": sim.memory_lineage_trace,
        "support_chain_trace": sim.support_chain_trace,
        "project_aftermath_trace": sim.project_aftermath_trace,
    }
    args.out.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(args.out)


if __name__ == "__main__":
    main()
