from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from types import MethodType
from typing import Any


V14_PATH = Path(
    r"D:\2026年4月\ドキュメント\chatgpt\chatgptログ2026年\6月5日"
    r"\文明シミュレーション\py\v1.3-1.4\py\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-09"
    r"\files-mentioned-by-the-user-society\outputs"
)

SEED = 1003
YEARS = 80
HANA = "p019"
P000 = "p000"
TARGET_EVENT = "project_failure:store_food"
TARGET_YEAR = 14


def load_module(label: str, path: Path):
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


v14 = load_module("society_lab_v1_4_death_memory_tests", V14_PATH)


@dataclass
class Experiment:
    code: str
    label: str
    mode: str


EXPERIMENTS = [
    Experiment("DTH_BASE", "baseline v1.4", "baseline"),
    Experiment("DTH_NO_P000_DEATH_MEMORY", "block only p000 receiving p019 death memory", "no_p000_death"),
    Experiment("DTH_ONLY_P000_DEATH_MEMORY", "NO_KEY plus manual p000 p019 death memory", "only_death_no_key"),
    Experiment("DTH_FAKE_DEATH_MEMORY", "NO_KEY plus fake death memory for p000", "fake_death_no_key"),
    Experiment("DTH_STRONGEST_FIXED", "p000 receives p019 death but strongest_memory ignores death", "strongest_ignore_death"),
    Experiment("DTH_MEMORY_COUNT_ONLY", "NO_KEY plus neutral dummy memory count for p000", "memory_count_only"),
]


def is_target_memory(memory: object) -> bool:
    return (
        getattr(memory, "event", None) == TARGET_EVENT
        and getattr(memory, "year", None) == TARGET_YEAR
    )


def compact_event(entry: object) -> str:
    return f"Y{entry.year:02d} {entry.event_type} [{','.join(entry.persons)}] {entry.detail}"


def selected_summary(sim: object) -> dict[str, Any]:
    summary = sim.summary()
    keys = [
        "final_population",
        "final_food_stock",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "shared_narrative_count",
        "memory_shared_count",
        "network_split_count",
        "narrative_divergence_count",
        "interpretation_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    ]
    return {key: summary.get(key) for key in keys}


def first_log_difference(left: object, right: object) -> dict[str, Any] | None:
    limit = min(len(left.log.entries), len(right.log.entries))
    for index in range(limit):
        baseline = compact_event(left.log.entries[index])
        experiment = compact_event(right.log.entries[index])
        if baseline != experiment:
            return {"index": index, "baseline": baseline, "experiment": experiment}
    if len(left.log.entries) != len(right.log.entries):
        return {
            "index": limit,
            "baseline": "<none>" if len(left.log.entries) <= limit else compact_event(left.log.entries[limit]),
            "experiment": "<none>" if len(right.log.entries) <= limit else compact_event(right.log.entries[limit]),
        }
    return None


def memory_summary(memory: object) -> dict[str, Any]:
    return {
        "event": memory.event,
        "year": memory.year,
        "intensity": round(memory.intensity, 4),
        "generation": memory.generation,
        "source": memory.source,
        "interpretation": memory.interpretation,
    }


def make_memory(event: str, year: int, intensity: float, interpretation: str, source: str = "manual"):
    return v14.Memory(
        event=event,
        year=year,
        intensity=intensity,
        decay_rate=0.02,
        source=source,
        generation=0,
        interpretation=interpretation,
    )


class DeathMemoryLab(v14.SocietyLab):
    def __init__(self, *args, exp: Experiment, **kwargs):
        super().__init__(*args, **kwargs)
        self.exp = exp
        self.edge_audit: dict[str, Any] | None = None
        self.death_grants: list[dict[str, Any]] = []
        self.p000_years: list[dict[str, Any]] = []
        self.p000_events_after_y28: list[str] = []
        if self.exp.mode == "strongest_ignore_death":
            self._patch_p000_strongest()

    def _patch_p000_strongest(self) -> None:
        p000 = super()._person(P000)
        def strongest_without_death(person_self):
            memories = [m for m in person_self.memories if m.event != "death"]
            if not memories:
                return None
            return max(memories, key=lambda memory: memory.intensity)
        p000.strongest_memory = MethodType(strongest_without_death, p000)

    def step(self) -> None:
        super().step()
        if 27 <= self.year <= 30:
            self._capture_p000_year()

    def _capture_p000_year(self) -> None:
        p = self._person(P000)
        strongest = p.strongest_memory()
        self.p000_years.append(
            {
                "year": self.year,
                "alive": p.alive,
                "age": p.age,
                "health": round(p.health, 4),
                "hunger": round(p.hunger, 4),
                "fear": round(p.fear, 4),
                "action": p.action,
                "top_trusted": p.top_trusted(5),
                "memory_count": len(p.memories),
                "strongest_memory": None if strongest is None else memory_summary(strongest),
                "memories": [memory_summary(memory) for memory in p.memories],
            }
        )

    def _adjust_trust(self, person, other_id: str, delta: float) -> None:
        if (
            self.year == 21
            and person.id == P000
            and other_id == HANA
            and self.edge_audit is not None
            and self.edge_audit.get("awaiting_trust_adjust")
        ):
            self.edge_audit["trust_before_has_key"] = HANA in person.trust
            if self.exp.mode in {
                "only_death_no_key",
                "fake_death_no_key",
                "memory_count_only",
            }:
                self.edge_audit["trust_action"] = "no_key"
            else:
                person.trust[HANA] = self._clamp(person.trust.get(HANA, 0.0) + 0.012)
                self.edge_audit["trust_action"] = "baseline_key"
            self.edge_audit["trust_after_has_key"] = HANA in person.trust
            self.edge_audit["trust_after_value"] = person.trust.get(HANA)
            self.edge_audit["awaiting_trust_adjust"] = False
            return
        super()._adjust_trust(person, other_id, delta)

    def _dialogue_phase(self) -> None:
        for speaker in self.alive_people:
            memory = speaker.strongest_memory()
            if memory is None:
                continue
            share_probability = (
                0.05
                + memory.intensity * 0.18
                + speaker.fear * 0.15
                + (0.12 if speaker.action == "share_memory" else 0.0)
            )
            if memory.generation >= 4:
                share_probability *= 0.55
            if self.rng.random() > min(0.55, share_probability):
                continue
            listener_count = 2 if self.rng.random() < 0.10 + speaker.fear * 0.20 else 1
            listeners = [
                self._person(person_id)
                for person_id in speaker.top_trusted(listener_count)
                if self._person(person_id).alive
            ]
            for listener in listeners:
                target_edge = (
                    self.year == 21
                    and speaker.id == HANA
                    and listener.id == P000
                    and is_target_memory(memory)
                )
                if target_edge:
                    self.edge_audit = {
                        "year": self.year,
                        "speaker": speaker.id,
                        "listener": listener.id,
                        "awaiting_trust_adjust": True,
                    }
                distorted = self._distort_memory(memory, speaker, listener)
                listener.remember(distorted)
                self.log.record(
                    self.year,
                    "memory_shared",
                    [speaker.id, listener.id],
                    (
                        f"{speaker.name} told {listener.name} about "
                        f"{distorted.event} intensity={distorted.intensity:.2f} "
                        f"generation={distorted.generation}"
                    ),
                )
                self._adjust_trust(listener, speaker.id, 0.012)

    def _grant_manual_p000_memory_for_hana_death(self, p000) -> v14.Memory | None:
        baseline_intensity = 0.35 + 0.012 * 0.45
        if self.exp.mode == "only_death_no_key":
            memory = self._make_memory(p000, event="death", intensity=baseline_intensity)
            memory.source = "manual_p019_death"
            return memory
        if self.exp.mode == "fake_death_no_key":
            memory = self._make_memory(p000, event="death", intensity=baseline_intensity)
            memory.source = "manual_fake_death"
            return memory
        if self.exp.mode == "memory_count_only":
            memory = self._make_memory(p000, event="neutral_marker", intensity=baseline_intensity)
            memory.source = "manual_dummy"
            return memory
        return None

    def _update_phase(self) -> None:
        for person in self.alive_people:
            person.age += 1
            person.voice_weight = self._clamp(person.voice_weight * 0.97)
            person.fear = self._clamp(person.fear * 0.86)
            if person.hunger > 0.75:
                person.health = self._clamp(person.health - 0.045 * person.hunger)
            else:
                person.health = self._clamp(person.health + 0.02)
            person.hunger = self._clamp(person.hunger * 0.92)

            for memory in person.memories:
                memory.decay()
            person.memories = [
                memory for memory in person.memories
                if memory.intensity >= 0.05
            ]

            age_risk = max(0.0, (person.age - 76) / 95.0)
            health_risk = max(0.0, 0.25 - person.health) * 0.22
            if self.rng.random() < age_risk + health_risk:
                person.alive = False
                self.log.record(
                    self.year,
                    "death",
                    [person.id],
                    f"{person.name} died age={person.age} health={person.health:.2f}",
                )
                recipients = []
                for other in self.alive_people:
                    grant_regular = person.id in other.trust
                    if (
                        person.id == HANA
                        and other.id == P000
                        and self.exp.mode == "no_p000_death"
                    ):
                        # Preserve the baseline interpretation RNG/update path while dropping the memory.
                        _ = self._make_memory(
                            other,
                            event="death",
                            intensity=0.35 + 0.012 * 0.45,
                        )
                        grant_regular = False
                    if grant_regular:
                        memory = self._make_memory(
                            other,
                            event="death",
                            intensity=0.35 + other.trust[person.id] * 0.45,
                        )
                        other.remember(memory)
                        recipients.append(
                            {
                                "id": other.id,
                                "name": other.name,
                                "mode": "regular",
                                "trust": other.trust[person.id],
                                "memory": memory_summary(memory),
                            }
                        )
                    if person.id == HANA and other.id == P000:
                        manual = self._grant_manual_p000_memory_for_hana_death(other)
                        if manual is not None:
                            other.remember(manual)
                            recipients.append(
                                {
                                    "id": other.id,
                                    "name": other.name,
                                    "mode": "manual",
                                    "trust": other.trust.get(person.id),
                                    "memory": memory_summary(manual),
                                }
                            )
                if 27 <= self.year <= 30:
                    self.death_grants.append(
                        {
                            "year": self.year,
                            "dead_person": person.id,
                            "dead_name": person.name,
                            "recipients": recipients,
                        }
                    )


def run(exp: Experiment) -> DeathMemoryLab:
    sim = DeathMemoryLab(seed=SEED, verbose=False, exp=exp)
    sim.run(YEARS)
    sim.p000_events_after_y28 = [
        compact_event(entry)
        for entry in sim.log.entries
        if 28 <= entry.year <= 38 and P000 in entry.persons
    ]
    return sim


baseline = run(EXPERIMENTS[0])
baseline_summary = selected_summary(baseline)
rows = []
details = {
    "seed": SEED,
    "years": YEARS,
    "baseline_summary": baseline_summary,
    "experiments": {},
}

for exp in EXPERIMENTS:
    sim = baseline if exp.code == "DTH_BASE" else run(exp)
    summary = selected_summary(sim)
    first_diff = None if exp.code == "DTH_BASE" else first_log_difference(baseline, sim)
    changed = [key for key, value in summary.items() if baseline_summary[key] != value]
    hana_death = [
        grant for grant in sim.death_grants
        if grant["dead_person"] == HANA
    ]
    p000_hana_death_memories = [
        recipient for grant in hana_death
        for recipient in grant["recipients"]
        if recipient["id"] == P000
    ]
    p000_y28 = next((row for row in sim.p000_years if row["year"] == 28), None)
    p000_y29 = next((row for row in sim.p000_years if row["year"] == 29), None)
    row = {
        "experiment": exp.code,
        "label": exp.label,
        **summary,
        "first_diff_index": "" if first_diff is None else first_diff["index"],
        "changed_key_count": len(changed),
        "changed_keys": ",".join(changed),
        "p000_got_hana_death_memory": bool(p000_hana_death_memories),
        "p000_hana_death_memory_mode": "" if not p000_hana_death_memories else p000_hana_death_memories[0]["mode"],
        "p000_y28_memory_count": "" if p000_y28 is None else p000_y28["memory_count"],
        "p000_y28_strongest": "" if p000_y28 is None or p000_y28["strongest_memory"] is None else p000_y28["strongest_memory"]["event"],
        "p000_y29_action": "" if p000_y29 is None else p000_y29["action"],
    }
    rows.append(row)
    details["experiments"][exp.code] = {
        "label": exp.label,
        "summary": summary,
        "changed_keys_vs_baseline": changed,
        "first_diff_vs_baseline": first_diff,
        "edge_audit": sim.edge_audit,
        "death_grants_Y27_Y30": sim.death_grants,
        "p000_years_Y27_Y30": sim.p000_years,
        "p000_events_Y28_Y38": sim.p000_events_after_y28,
    }

OUT_DIR.mkdir(parents=True, exist_ok=True)
script_path = OUT_DIR / "society_lab_seed1003_death_memory_cut_tests.py"
report_path = OUT_DIR / "society_lab_seed1003_death_memory_report.md"
csv_path = OUT_DIR / "society_lab_seed1003_death_memory_results.csv"
json_path = OUT_DIR / "society_lab_seed1003_death_memory_details.json"

script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
json_path.write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

report = [
    "# seed1003 death memory cut tests",
    "",
    "## Purpose",
    "",
    "This batch tests whether Y28 p019 Hana death memory entering p000 Zol is necessary or sufficient for the v1.4 trajectory. It keeps factual mechanism separate from narrative interpretation.",
    "",
    "## Results",
    "",
    "| exp | intervention | final pop | births | failures | memory shares | first diff | changed keys | p000 got Hana death | mode | Y28 strongest | Y29 action |",
    "|---|---|---:|---:|---:|---:|---:|---:|---|---|---|---|",
]
for row in rows:
    report.append(
        f"| {row['experiment']} | {row['label']} | {row['final_population']} | "
        f"{row['birth_count']} | {row['project_failure_count']} | {row['memory_shared_count']} | "
        f"{row['first_diff_index']} | {row['changed_key_count']} | {row['p000_got_hana_death_memory']} | "
        f"{row['p000_hana_death_memory_mode']} | {row['p000_y28_strongest']} | {row['p000_y29_action']} |"
    )

report.extend(
    [
        "",
        "## P000 State Y27-Y30",
        "",
    ]
)
for code in [exp.code for exp in EXPERIMENTS]:
    report.extend([f"### {code}", "", "```json"])
    report.append(json.dumps(details["experiments"][code]["p000_years_Y27_Y30"], ensure_ascii=False, indent=2))
    report.extend(["```", ""])

report.extend(
    [
        "## Cautious Reading",
        "",
        "- DTH_NO_P000_DEATH_MEMORY tests necessity: if it diverges, p000's Hana-death memory is needed for the baseline path.",
        "- DTH_ONLY_P000_DEATH_MEMORY tests sufficiency under NO_KEY: if it returns to baseline, the death memory itself is sufficient.",
        "- DTH_FAKE_DEATH_MEMORY tests whether a generic death memory is enough in this code, where event/source are what downstream logic can inspect.",
        "- DTH_STRONGEST_FIXED tests whether p000 speaking from death as strongest_memory is required.",
        "- DTH_MEMORY_COUNT_ONLY tests whether merely adding one memory-like object is enough.",
        "",
        "## Narrative Boundary",
        "",
        "The factual chain is death memory / strongest_memory / action / trajectory. Any reading about grief, regret, or re-meaning is interpretive and is not directly represented as a model variable.",
    ]
)
report_path.write_text("\n".join(report) + "\n", encoding="utf-8")

print(report_path)
print(csv_path)
print(json_path)
print(script_path)
print(json.dumps(rows, ensure_ascii=False, indent=2))
