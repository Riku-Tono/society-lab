from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(__file__).with_name("society_lab_v1_4.py")

SEEDS = (42, 1000, 1001, 1002, 1003)
YEARS = 80

REPORT_KEYS = (
    "final_population",
    "final_food_stock",
    "avg_fear",
    "avg_hunger",
    "proposal_count",
    "project_success_count",
    "project_failure_count",
    "shared_narrative_count",
    "authority_pattern_count",
    "faction_pattern_count",
    "ritualization_pattern_count",
    "network_split_count",
    "narrative_divergence_count",
    "interpretation_divergence_count",
    "interpretation_convergence_count",
    "avg_bias_spiritual",
    "avg_bias_practical",
    "avg_bias_blame",
    "death_count",
    "birth_count",
    "memory_shared_count",
    "behavior_copied_count",
    "interpretation_action_nudge_count",
    "interpretation_support_nudge_count",
)


def load_module(label: str, path: Path) -> ModuleType:
    module_name = label.replace(".", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def run_summary(module: ModuleType, seed: int) -> dict[str, object]:
    sim = module.SocietyLab(seed=seed, verbose=False)
    sim.run(years=YEARS)
    return sim.summary()


def compare_summaries(before: dict[str, object], after: dict[str, object]) -> dict[str, tuple[object, object]]:
    return {
        key: (before[key], after[key])
        for key in REPORT_KEYS
        if key in before and key in after and before[key] != after[key]
    }


def format_difference(seed: int, diff: dict[str, tuple[object, object]]) -> str:
    if not diff:
        return f"seed {seed}:\n  no summary differences"

    lines = [f"seed {seed}:"]
    for key, (before, after) in diff.items():
        lines.append(f"  {key}: {before} -> {after}")
    return "\n".join(lines)


def main() -> None:
    before_module = load_module("society_lab_v1_3", V13_PATH)
    after_module = load_module("society_lab_v1_4", V14_PATH)

    print(f"Comparing v1.3 and v1.4 over {YEARS} years")
    print()
    for seed in SEEDS:
        before = run_summary(before_module, seed)
        after = run_summary(after_module, seed)
        diff = compare_summaries(before, after)
        print(format_difference(seed, diff))
        print()


if __name__ == "__main__":
    main()
