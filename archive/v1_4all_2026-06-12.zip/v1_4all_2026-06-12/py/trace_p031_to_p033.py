from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any


def load_payload(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def lineage_root(memory_id: str, parent_by_id: dict[str, str]) -> str:
    current = memory_id
    seen: set[str] = set()
    while parent_by_id.get(current):
        if current in seen:
            break
        seen.add(current)
        current = parent_by_id[current]
    return current


def descendants(memory_id: str, by_id: dict[str, dict[str, Any]], children: dict[str, list[str]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    queue: deque[tuple[str, int]] = deque([(memory_id, 0)])
    while queue:
        current, depth = queue.popleft()
        entry = dict(by_id[current])
        entry["depth_from_anchor"] = depth
        out.append(entry)
        for child in children.get(current, []):
            queue.append((child, depth + 1))
    return out


def support_near_years(
    supports: list[dict[str, Any]],
    person_id: str,
    years: set[int],
    window: int,
) -> list[dict[str, Any]]:
    rows = []
    for support in supports:
        if support["supporter_id"] != person_id and support["proposer_id"] != person_id:
            continue
        nearest = min((abs(support["year"] - year) for year in years), default=999)
        if nearest <= window:
            rows.append({**support, "nearest_memory_gap": nearest})
    rows.sort(key=lambda item: (item["year"], item["nearest_memory_gap"]))
    return rows


def build_trace(payload: dict[str, Any], source_id: str, relay_id: str, window: int) -> dict[str, Any]:
    memories = payload["memory_lineage_trace"]
    supports = payload["support_chain_trace"]
    actor_bio = payload["actor_biography"].get(relay_id, [])
    role_labels = payload["observation_summary"]["role_labels"].get(relay_id, [])

    by_id = {entry["memory_id"]: entry for entry in memories}
    parent_by_id = {entry["memory_id"]: entry.get("parent_memory_id", "") for entry in memories}
    children: dict[str, list[str]] = defaultdict(list)
    for entry in memories:
        parent = entry.get("parent_memory_id", "")
        if parent:
            children[parent].append(entry["memory_id"])

    received_from_source = [
        entry
        for entry in memories
        if entry["holder_id"] == relay_id and entry["source_id"] == source_id
    ]
    received_from_source.sort(key=lambda item: (item["year"], item["memory_id"]))

    relay_transmissions = []
    interpretation_changes = []
    third_person_counts: Counter[str] = Counter()
    rooted: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for received in received_from_source:
        root_id = lineage_root(received["memory_id"], parent_by_id)
        root = by_id[root_id]
        branch = descendants(received["memory_id"], by_id, children)
        third_people = [
            item
            for item in branch
            if item["holder_id"] not in {source_id, relay_id}
        ]
        for item in third_people:
            third_person_counts[item["holder_id"]] += 1
            if item["interpretation"] != received["interpretation"]:
                interpretation_changes.append(
                    {
                        "from_memory_id": received["memory_id"],
                        "to_memory_id": item["memory_id"],
                        "root_memory_id": root_id,
                        "event": item["event"],
                        "year": item["year"],
                        "holder_id": item["holder_id"],
                        "source_id": item["source_id"],
                        "from_interpretation": received["interpretation"],
                        "to_interpretation": item["interpretation"],
                        "depth_from_relay": item["depth_from_anchor"],
                    }
                )
        rooted[root_id].append(
            {
                "received_memory_id": received["memory_id"],
                "received_year": received["year"],
                "root_memory_id": root_id,
                "root_year": root["year"],
                "root_event": root["event"],
                "root_interpretation": root["interpretation"],
                "received_interpretation": received["interpretation"],
                "received_intensity": received["intensity"],
                "branch_events_from_relay": len(branch),
                "third_person_events": len(third_people),
                "third_person_holders": sorted({item["holder_id"] for item in third_people}),
                "max_depth_from_relay": max(item["depth_from_anchor"] for item in branch),
            }
        )
        for item in third_people:
            relay_transmissions.append(
                {
                    "root_memory_id": root_id,
                    "received_memory_id": received["memory_id"],
                    "memory_id": item["memory_id"],
                    "year": item["year"],
                    "event": item["event"],
                    "holder_id": item["holder_id"],
                    "source_id": item["source_id"],
                    "interpretation": item["interpretation"],
                    "depth_from_relay": item["depth_from_anchor"],
                }
            )

    memory_years = {entry["year"] for entry in received_from_source}
    relay_support_near_memory = support_near_years(supports, relay_id, memory_years, window)

    relay_bio_focus = [
        entry
        for entry in actor_bio
        if entry.get("speaker_id") == source_id
        or entry.get("listener_id")
        or entry.get("support_nudge", 0.0) != 0.0
        or entry.get("bio_event") in {"proposal_supported", "project_started", "project_success", "project_failure"}
    ]

    return {
        "source_id": source_id,
        "relay_id": relay_id,
        "relay_roles": role_labels,
        "received_from_source": received_from_source,
        "rooted_received_summary": dict(rooted),
        "relay_transmissions_to_third_people": relay_transmissions,
        "third_person_counts": third_person_counts.most_common(),
        "interpretation_changes_after_relay": interpretation_changes,
        "relay_support_near_source_memory": relay_support_near_memory,
        "relay_biography_focus": relay_bio_focus,
    }


def table(rows: list[dict[str, Any]], columns: list[str], limit: int = 40) -> str:
    if not rows:
        return "_none_\n"
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    for row in rows[:limit]:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    return "\n".join(lines) + "\n"


def build_report(trace: dict[str, Any], seed: int, window: int) -> str:
    lines = [
        f"# {trace['source_id']} to {trace['relay_id']} trace seed {seed}",
        "",
        "## Overview",
        "",
        f"- relay roles: {trace['relay_roles']}",
        f"- memories received from source: {len(trace['received_from_source'])}",
        f"- relay transmissions to third people: {len(trace['relay_transmissions_to_third_people'])}",
        f"- interpretation changes after relay: {len(trace['interpretation_changes_after_relay'])}",
        f"- third person counts: {trace['third_person_counts']}",
        "",
        "## Memories Received From Source",
        "",
        table(
            trace["received_from_source"],
            [
                "year",
                "memory_id",
                "parent_memory_id",
                "event",
                "intensity",
                "generation",
                "interpretation",
            ],
            limit=80,
        ),
        "## Rooted Received Summary",
        "",
    ]
    root_rows = []
    for rows in trace["rooted_received_summary"].values():
        root_rows.extend(rows)
    lines.append(
        table(
            root_rows,
            [
                "root_memory_id",
                "root_event",
                "root_year",
                "root_interpretation",
                "received_memory_id",
                "received_year",
                "received_interpretation",
                "branch_events_from_relay",
                "third_person_events",
                "third_person_holders",
                "max_depth_from_relay",
            ],
            limit=80,
        )
    )
    lines.extend(
        [
            "## Relay Transmissions To Third People",
            "",
            table(
                trace["relay_transmissions_to_third_people"],
                [
                    "root_memory_id",
                    "received_memory_id",
                    "memory_id",
                    "year",
                    "event",
                    "holder_id",
                    "source_id",
                    "interpretation",
                    "depth_from_relay",
                ],
                limit=80,
            ),
            "## Interpretation Changes After Relay",
            "",
            table(
                trace["interpretation_changes_after_relay"],
                [
                    "root_memory_id",
                    "from_memory_id",
                    "to_memory_id",
                    "year",
                    "holder_id",
                    "from_interpretation",
                    "to_interpretation",
                    "depth_from_relay",
                ],
                limit=80,
            ),
            f"## Relay Support Near Source Memories Within {window} Years",
            "",
            table(
                trace["relay_support_near_source_memory"],
                [
                    "year",
                    "supporter_id",
                    "proposer_id",
                    "action",
                    "problem",
                    "support_nudge",
                    "support_chance",
                    "nearest_memory_gap",
                ],
                limit=80,
            ),
            "## Relay Biography Focus",
            "",
            table(
                trace["relay_biography_focus"],
                [
                    "year",
                    "bio_event",
                    "memory_id",
                    "parent_memory_id",
                    "speaker_id",
                    "listener_id",
                    "event",
                    "proposer_id",
                    "action",
                    "problem",
                    "support_nudge",
                ],
                limit=120,
            ),
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Trace memories from one actor through a relay actor.")
    parser.add_argument(
        "input",
        type=Path,
        nargs="?",
        default=Path("society_lab_v1_4_1_observation_seed1003.json"),
    )
    parser.add_argument("--source", default="p031")
    parser.add_argument("--relay", default="p033")
    parser.add_argument("--window", type=int, default=5)
    parser.add_argument("--json-out", type=Path, default=Path("p031_to_p033_trace_summary.json"))
    parser.add_argument("--md-out", type=Path, default=Path("p031_to_p033_trace_report.md"))
    args = parser.parse_args()

    payload = load_payload(args.input)
    trace = build_trace(payload, args.source, args.relay, args.window)
    seed = payload["summary"]["seed"]

    args.json_out.write_text(json.dumps(trace, ensure_ascii=False, indent=2), encoding="utf-8")
    args.md_out.write_text(build_report(trace, seed, args.window), encoding="utf-8")
    print(args.md_out)
    print(args.json_out)


if __name__ == "__main__":
    main()
