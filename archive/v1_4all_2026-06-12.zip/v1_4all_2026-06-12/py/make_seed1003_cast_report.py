from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


DEFAULT_ACTORS = [
    "p031",
    "p033",
    "p013",
    "p030",
    "p008",
    "p026",
    "p016",
    "p029",
    "p007",
    "p037",
]


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location("society_lab_v1_4_1_cast", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["society_lab_v1_4_1_cast"] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def actor_baseline(module_path: Path, seed: int, actors: list[str]) -> dict[str, dict[str, Any]]:
    module = load_module(module_path)
    sim = module.SocietyLab(seed=seed, verbose=False)
    final_sim = module.SocietyLab(seed=seed, verbose=False)
    final_sim.run(80)
    rows: dict[str, dict[str, Any]] = {}
    for actor_id in actors:
        born_later = False
        try:
            person = sim._person(actor_id)
        except KeyError:
            person = final_sim._person(actor_id)
            born_later = True
        trust_top = [
            {
                "person_id": other_id,
                "trust": round(value, 4),
            }
            for other_id, value in sorted(
                person.trust.items(),
                key=lambda item: item[1],
                reverse=True,
            )[:8]
        ]
        rows[actor_id] = {
            "person_id": actor_id,
            "name": person.name,
            "age": person.age,
            "born_later": born_later,
            "sex": person.sex,
            "charisma": round(person.charisma, 3),
            "food_skill": round(person.food_skill, 3),
            "initial_action": person.action,
            "interpretation_bias": {
                key: round(value, 3)
                for key, value in person.interpretation_bias.items()
            },
            "initial_trust_top": trust_top,
        }
    return rows


def actor_observation(payload: dict[str, Any], actor_id: str) -> dict[str, Any]:
    biography = payload["actor_biography"].get(actor_id, [])
    roles = payload["observation_summary"]["role_labels"].get(actor_id, [])

    def count(event: str) -> int:
        return sum(1 for entry in biography if entry.get("bio_event") == event)

    supports = [
        entry
        for entry in payload["support_chain_trace"]
        if entry["supporter_id"] == actor_id or entry["proposer_id"] == actor_id
    ]
    roots = [
        entry
        for entry in payload["memory_lineage_trace"]
        if entry["holder_id"] == actor_id and not entry.get("parent_memory_id")
    ]
    received = [
        entry
        for entry in payload["memory_lineage_trace"]
        if entry["holder_id"] == actor_id and entry.get("parent_memory_id")
    ]
    told = [
        entry for entry in biography if entry.get("bio_event") == "memory_told"
    ]
    death_entries = [entry for entry in biography if entry.get("bio_event") == "death"]
    final_status = "dead" if death_entries else "alive_or_unobserved_dead"
    death_year = death_entries[0]["year"] if death_entries else None

    important_roots = sorted(
        roots,
        key=lambda entry: (entry["year"], entry["memory_id"]),
    )[:8]
    recent_supports = sorted(
        supports,
        key=lambda entry: (entry["year"], entry["supporter_id"], entry["proposer_id"]),
    )[:12]

    return {
        "roles": roles,
        "biography_events": len(biography),
        "memory_created": count("memory_created"),
        "memory_received": count("memory_received"),
        "memory_told": count("memory_told"),
        "proposal_made": count("proposal_made"),
        "proposal_supported": count("proposal_supported"),
        "project_started": count("project_started"),
        "project_success": count("project_success"),
        "project_failure": count("project_failure"),
        "final_status": final_status,
        "death_year": death_year,
        "root_memories": important_roots,
        "received_memory_count": len(received),
        "support_events": recent_supports,
        "told_events": told[:12],
    }


def trust_text(baseline: dict[str, Any], cast: dict[str, dict[str, Any]]) -> str:
    parts = []
    for item in baseline["initial_trust_top"][:5]:
        other_id = item["person_id"]
        other = cast.get(other_id, {})
        label = f"{other_id}"
        if other.get("name"):
            label += f"({other['name']})"
        parts.append(f"{label}:{item['trust']}")
    return ", ".join(parts)


def memories_text(memories: list[dict[str, Any]]) -> str:
    if not memories:
        return "なし"
    parts = []
    for memory in memories[:5]:
        parts.append(
            f"Y{memory['year']} {memory['memory_id']} {memory['event']} / {memory['interpretation']}"
        )
    return "<br>".join(parts)


def supports_text(supports: list[dict[str, Any]]) -> str:
    if not supports:
        return "なし"
    parts = []
    for support in supports[:6]:
        if support["supporter_id"] == support["proposer_id"]:
            relation = "self-support"
        else:
            relation = f"{support['supporter_id']}→{support['proposer_id']}"
        parts.append(
            f"Y{support['year']} {relation} {support['action']} "
            f"nudge={support['support_nudge']}"
        )
    return "<br>".join(parts)


def build_report(
    payload: dict[str, Any],
    cast: dict[str, dict[str, Any]],
    observations: dict[str, dict[str, Any]],
    actors: list[str],
) -> str:
    seed = payload["summary"]["seed"]
    lines = [
        f"# seed{seed} cast report",
        "",
        "ChatGPTへ渡すための登場人物表です。まずこれを読ませてから、人物間traceを渡してください。",
        "",
        "## 読む順番",
        "",
        "1. この `cast report` で人物の前提を掴む",
        "2. `seed1003_p031_to_p033_trace_report.md`",
        "3. `seed1003_p033_to_p013_trace_report.md`",
        "4. `seed1003_p013_to_p030_trace_report.md`",
        "",
        "## 主要人物の短い読み",
        "",
        "- p031: 強い記憶の震源。p033を最も信頼しており、失敗と死の記憶をp033へ繰り返し渡す。",
        "- p033: p031から受け取った記憶を、信頼先のp013/p008へ渡す一次媒介者。意味が変わる配管。",
        "- p013: p033から受け取った記憶を、最も信頼するp030へ渡す二次媒介者。",
        "- p030: p013から受け取った記憶をp026へ渡す一方、Year15に提案者として支持場に出る人物。",
        "- p026/p016/p029/p007/p037: p030以後に伸びる別の信頼枝。ここで記憶がさらに長くなる。",
        "",
        "## Cast Table",
        "",
        "| id | name | age | sex | charisma | food_skill | initial trust top | roles | activity counts | root memories | support events |",
        "| --- | --- | ---: | --- | ---: | ---: | --- | --- | --- | --- | --- |",
    ]
    for actor_id in actors:
        base = cast[actor_id]
        obs = observations[actor_id]
        activity = (
            f"created={obs['memory_created']}, received={obs['memory_received']}, "
            f"told={obs['memory_told']}, supported={obs['proposal_supported']}, "
            f"proposed={obs['proposal_made']}"
        )
        status = obs["final_status"]
        if obs["death_year"] is not None:
            status += f" Y{obs['death_year']}"
        lines.append(
            "| "
            + " | ".join(
                [
                    actor_id,
                    str(base["name"]),
                    f"{base['age']}{' (born later)' if base.get('born_later') else ''}",
                    str(base["sex"]),
                    str(base["charisma"]),
                    str(base["food_skill"]),
                    trust_text(base, cast),
                    ", ".join(obs["roles"]) if obs["roles"] else "なし",
                    activity + f"<br>{status}",
                    memories_text(obs["root_memories"]),
                    supports_text(obs["support_events"]),
                ]
            )
            + " |"
        )

    lines.extend(
        [
            "",
            "## ChatGPTへの依頼文",
            "",
            "```text",
            "このcast reportとtrace reportを読んで、seed1003を人間関係の物語として整理してください。",
            "",
            "注意:",
            "- 人物を単なる情報ノードとして扱わないでください。",
            "- p031, p033, p013, p030 の関係を中心に読んでください。",
            "- p033は教祖と断定せず、媒介者/伝道者の前身として慎重に読んでください。",
            "- p030は別集団への拡散者と断定せず、語りの流れと支持の場が交差した人物として読んでください。",
            "- これは因果証明ではなく、seed1003のworld-readingです。",
            "```",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a cast report for seed1003 story reading.")
    parser.add_argument(
        "--module",
        type=Path,
        default=Path("society_lab_v1_4_1.py"),
    )
    parser.add_argument(
        "--observation",
        type=Path,
        default=Path("society_lab_v1_4_1_observation_seed1003.json"),
    )
    parser.add_argument("--seed", type=int, default=1003)
    parser.add_argument("--actors", nargs="*", default=DEFAULT_ACTORS)
    parser.add_argument("--out", type=Path, default=Path("seed1003_cast_report.md"))
    args = parser.parse_args()

    payload = load_json(args.observation)
    cast = actor_baseline(args.module, args.seed, args.actors)
    observations = {
        actor_id: actor_observation(payload, actor_id)
        for actor_id in args.actors
    }
    args.out.write_text(
        build_report(payload, cast, observations, args.actors),
        encoding="utf-8",
    )
    print(args.out)


if __name__ == "__main__":
    main()
