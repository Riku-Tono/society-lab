from __future__ import annotations

import csv
import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from typing import Any


V13_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-05"
    r"\files-mentioned-by-the-user-civilization\outputs\society_lab_v1_3.py"
)
V14_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\files-mentioned-by-the-user-society\outputs\society_lab_v1_4.py"
)
OUT_DIR = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-06"
    r"\python-chatgpt-claude-codex\outputs"
)
REPORT_PATH = OUT_DIR / "society_lab_seed_1024_birth_probability_trace.md"
CSV_PATH = OUT_DIR / "society_lab_seed_1024_birth_probability_trace.csv"

SEED = 1024
START_YEAR = 42
END_YEAR = 46


def load_module(label: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module


def person_brief(person: object) -> str:
    return (
        f"{person.id}:{person.name}:age={person.age}:sex={person.sex}:"
        f"health={person.health:.2f}:hunger={person.hunger:.2f}:"
        f"fear={person.fear:.3f}"
    )


def trace_births(module: ModuleType, version: str) -> tuple[object, list[dict[str, Any]]]:
    sim = module.SocietyLab(seed=SEED, verbose=False)
    rows: list[dict[str, Any]] = []

    def traced_generation_phase() -> None:
        adults = [person for person in sim.alive_people if person.age >= 18]
        candidates = [person for person in sim.alive_people if person.can_give_birth()]
        if len(adults) < 2 or not candidates:
            return

        food_per_person = sim.food.stock / max(1, sim.population)
        food_factor = min(1.25, max(0.25, food_per_person / 3.0))
        fear_factor = max(0.35, 1.0 - sim._avg("fear") * 0.75)
        population_factor = max(0.05, 1.0 - max(0, sim.population - 35) / 45.0)
        chance = 0.075 * food_factor * fear_factor * population_factor
        threshold = min(0.14, chance)

        birth_count = 0
        for parent in candidates:
            draw = sim.rng.random()
            born = draw <= threshold
            child_id = ""
            child_name = ""
            if born:
                child = sim._create_child(parent)
                sim.people.append(child)
                birth_count += 1
                child_id = child.id
                child_name = child.name
                sim.log.record(
                    sim.year,
                    "birth",
                    [parent.id, child.id],
                    f"{parent.name} had a child: {child.name}",
                )

            if START_YEAR <= sim.year <= END_YEAR:
                rows.append(
                    {
                        "version": version,
                        "year": sim.year,
                        "population": sim.population,
                        "food_stock": round(sim.food.stock, 6),
                        "food_per_person": round(food_per_person, 6),
                        "avg_fear": round(sim._avg("fear"), 6),
                        "food_factor": round(food_factor, 6),
                        "fear_factor": round(fear_factor, 6),
                        "population_factor": round(population_factor, 6),
                        "birth_probability": round(threshold, 6),
                        "candidate_id": parent.id,
                        "candidate_name": parent.name,
                        "candidate_age": parent.age,
                        "candidate_health": round(parent.health, 6),
                        "candidate_hunger": round(parent.hunger, 6),
                        "candidate_fear": round(parent.fear, 6),
                        "draw": round(draw, 12),
                        "birth": born,
                        "child_id": child_id,
                        "child_name": child_name,
                        "candidate_count": len(candidates),
                        "candidate_list": " | ".join(person_brief(person) for person in candidates),
                    }
                )

        if birth_count:
            sim.food.stock = max(0.0, sim.food.stock - birth_count * 0.4)

    sim._generation_phase = traced_generation_phase
    for _ in range(END_YEAR):
        if sim.population == 0:
            break
        sim.step()
    return sim, rows


def write_csv(rows: list[dict[str, Any]]) -> None:
    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def md_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    def cell(value: Any) -> str:
        return str(value).replace("|", "\\|")

    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(cell(item) for item in row) + " |")
    return lines


def build_report() -> str:
    v13 = load_module("society_lab_v1_3_seed1024_birthprob", V13_PATH)
    v14 = load_module("society_lab_v1_4_seed1024_birthprob", V14_PATH)
    _sim13, rows13 = trace_births(v13, "v1.3")
    _sim14, rows14 = trace_births(v14, "v1.4")
    rows = rows13 + rows14
    write_csv(rows)

    lines: list[str] = []
    lines.append("# seed 1024 birth probability trace")
    lines.append("")
    lines.append("Focus: Year42-46 birth candidates, probability, and random draw.")
    lines.append("")
    lines.append("## Candidate-Level Birth Checks")
    lines.append("")
    lines.extend(
        md_table(
            [
                "version",
                "year",
                "candidate",
                "prob",
                "draw",
                "birth",
                "child",
                "pop",
                "food_per_person",
                "avg_fear",
                "food_factor",
                "fear_factor",
                "population_factor",
            ],
            [
                [
                    row["version"],
                    row["year"],
                    f"{row['candidate_id']}:{row['candidate_name']}:age={row['candidate_age']}",
                    row["birth_probability"],
                    row["draw"],
                    row["birth"],
                    f"{row['child_id']}:{row['child_name']}" if row["child_id"] else "-",
                    row["population"],
                    row["food_per_person"],
                    row["avg_fear"],
                    row["food_factor"],
                    row["fear_factor"],
                    row["population_factor"],
                ]
                for row in rows
            ],
        )
    )
    lines.append("")
    lines.append("## Year-Level Comparison")
    lines.append("")
    for year in range(START_YEAR, END_YEAR + 1):
        y13 = [row for row in rows13 if row["year"] == year]
        y14 = [row for row in rows14 if row["year"] == year]
        lines.append(f"### Year {year}")
        lines.append("")
        lines.extend(
            md_table(
                ["version", "candidates", "probabilities", "draws", "births", "candidate_list"],
                [
                    [
                        "v1.3",
                        len(y13),
                        ", ".join(str(row["birth_probability"]) for row in y13),
                        ", ".join(str(row["draw"]) for row in y13),
                        ", ".join(
                            f"{row['candidate_name']}->{row['child_name']}"
                            for row in y13
                            if row["birth"]
                        )
                        or "-",
                        y13[0]["candidate_list"] if y13 else "-",
                    ],
                    [
                        "v1.4",
                        len(y14),
                        ", ".join(str(row["birth_probability"]) for row in y14),
                        ", ".join(str(row["draw"]) for row in y14),
                        ", ".join(
                            f"{row['candidate_name']}->{row['child_name']}"
                            for row in y14
                            if row["birth"]
                        )
                        or "-",
                        y14[0]["candidate_list"] if y14 else "-",
                    ],
                ],
            )
        )
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(build_report(), encoding="utf-8")
    print(REPORT_PATH)
    print(CSV_PATH)


if __name__ == "__main__":
    main()
