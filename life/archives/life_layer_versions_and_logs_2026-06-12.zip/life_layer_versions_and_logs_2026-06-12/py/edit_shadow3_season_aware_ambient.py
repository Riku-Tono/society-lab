from pathlib import Path
import os


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        path = Path(dirpath) / "society_lab_v1_4_life_senses_memory_shadow3.py"
        break
else:
    raise SystemExit("shadow3 not found")

text = path.read_text(encoding="utf-8")

season_weights = '''

SEASON_AMBIENT_PLACE_WEIGHTS = {
    "early_summer": {
        "spring": 3.0,
        "rice_field": 2.4,
        "river_bank": 1.8,
        "shade_tree": 1.6,
        "engawa": 1.2,
    },
    "midsummer": {
        "festival_square": 3.2,
        "engawa": 2.4,
        "spring": 2.0,
        "river_bank": 1.8,
        "shade_tree": 1.5,
    },
    "late_summer": {
        "festival_square": 2.4,
        "rice_field": 2.1,
        "engawa": 1.8,
        "river_bank": 1.4,
    },
    "harvest_time": {
        "rice_field": 3.4,
        "weaving_house": 1.8,
        "book_house": 1.5,
        "engawa": 1.2,
    },
    "cold_rain": {
        "book_house": 3.0,
        "weaving_house": 2.4,
        "engawa": 2.0,
        "spring": 0.8,
    },
    "first_frost": {
        "book_house": 2.6,
        "weaving_house": 2.2,
        "engawa": 1.8,
        "spring": 0.7,
    },
}

SEASON_DETAIL_WEIGHTS = {
    "midsummer": {
        "festival_square": {
            "objects": {
                "paper_lantern": 3.0,
                "small_drum": 2.4,
                "drum_stick": 2.0,
                "festival_mask": 2.0,
                "watermelon_slice": 2.6,
                "shaved_ice_bowl": 2.6,
            },
            "scents": {
                "festival_smoke": 2.8,
                "summer_grass": 2.4,
                "sweet_shaved_ice": 2.8,
            },
            "sounds": {
                "distant_drum": 3.0,
                "festival_noise": 2.8,
                "wind_bell_sound": 2.0,
            },
            "scenes": {
                "many_people_gathered": 2.4,
                "lanterns_before_evening": 2.8,
                "festival_preparation_nearby": 2.8,
            },
        },
        "engawa": {
            "objects": {"wind_bell": 3.0, "fan": 2.4, "tea_cup_nearby": 1.6},
            "scents": {"cool_evening_air": 2.6, "summer_insects": 2.2},
            "sounds": {"wind_bell_sound": 3.0, "summer_insects": 2.4},
            "scenes": {"cool_evening_at_the_edge": 2.8, "shade_on_old_wood": 2.0},
        },
    },
    "late_summer": {
        "festival_square": {
            "objects": {"paper_lantern": 2.4, "wind_bell": 2.2, "watermelon_slice": 2.0},
            "scents": {"summer_grass": 2.2, "festival_smoke": 1.8},
            "sounds": {"wind_bell_sound": 2.4, "distant_drum": 2.0},
            "scenes": {"lanterns_before_evening": 2.4, "festival_preparation_nearby": 2.0},
        },
        "rice_field": {
            "objects": {"rice_heads_bending": 2.6, "golden_field": 2.2},
            "scents": {"harvest_smell": 2.2, "fresh_rice": 2.0},
            "sounds": {"frogs_at_night": 2.0, "wind_through_rice": 2.2},
            "scenes": {"golden_field_under_clouds": 2.2, "field_water_reflecting_sky": 1.8},
        },
    },
    "harvest_time": {
        "rice_field": {
            "objects": {
                "golden_field": 3.2,
                "rice_heads_bending": 3.0,
                "sickle": 2.2,
                "hoe": 2.0,
            },
            "scents": {"harvest_smell": 3.0, "fresh_rice": 2.6},
            "sounds": {"wind_through_rice": 2.6, "frogs_at_night": 1.8},
            "scenes": {"golden_field_under_clouds": 3.0, "field_water_reflecting_sky": 2.0},
        },
        "weaving_house": {
            "objects": {"thread_spool": 2.4, "unfinished_cloth": 2.4, "loom": 2.0},
            "scents": {"loom_dust": 2.2, "dry_reed": 2.0},
            "sounds": {"loom_clicking": 2.6, "thread_pulled_tight": 2.0},
            "scenes": {"cloth_half_finished": 2.4, "threads_hung_to_dry": 2.2},
        },
    },
    "cold_rain": {
        "book_house": {
            "objects": {"old_book": 3.0, "worn_pages": 2.8, "copied_text": 2.0},
            "scents": {"ink_smell": 3.0, "old_paper": 2.8},
            "sounds": {"pages_turning": 3.0, "quiet_reading": 2.6},
            "scenes": {"quiet_reading_corner": 3.0, "books_stacked_low": 2.4},
        },
        "weaving_house": {
            "objects": {"loom": 2.4, "thread_spool": 2.6, "unfinished_cloth": 2.6},
            "scents": {"loom_dust": 2.8, "old_thread": 2.2},
            "sounds": {"loom_clicking": 2.8, "needle_against_cloth": 2.4},
            "scenes": {"cloth_half_finished": 2.4, "hands_worked_somewhere_nearby": 2.0},
        },
    },
    "first_frost": {
        "book_house": {
            "objects": {"old_book": 2.8, "worn_pages": 2.8},
            "scents": {"old_paper": 2.8, "ink_smell": 2.2},
            "sounds": {"pages_turning": 2.6, "quiet_reading": 2.4},
            "scenes": {"quiet_reading_corner": 2.8, "copied_pages_drying": 2.0},
        },
        "weaving_house": {
            "objects": {"folded_cloth": 2.6, "thread_spool": 2.4, "needle": 2.0},
            "scents": {"loom_dust": 2.4, "dry_reed": 2.2},
            "sounds": {"loom_clicking": 2.4, "needle_against_cloth": 2.2},
            "scenes": {"threads_hung_to_dry": 2.4, "cloth_half_finished": 2.2},
        },
    },
    "early_summer": {
        "spring": {
            "objects": {
                "cold_water": 3.0,
                "mossy_stone": 2.6,
                "water_reflection": 2.6,
                "fern_near_water": 2.4,
            },
            "scents": {"cold_stream": 2.6, "wet_moss": 2.6, "clean_stone": 2.0},
            "sounds": {"spring_water_sound": 3.0, "water_from_spring": 2.6},
            "scenes": {
                "water_reflection_under_leaves": 3.0,
                "ferns_bent_near_water": 2.6,
                "stone_pool_in_shade": 2.2,
            },
        },
        "rice_field": {
            "objects": {"green_shoots": 3.0, "muddy_water": 2.4},
            "scents": {"wet_soil": 2.6, "fresh_rice": 1.8},
            "sounds": {"water_in_field_rows": 2.4, "frogs_at_night": 2.2},
            "scenes": {"green_shoots_after_rain": 3.0, "field_water_reflecting_sky": 2.2},
        },
    },
}
'''

anchor = '''AMBIENT_PLACE_DETAILS = {
'''
if "SEASON_AMBIENT_PLACE_WEIGHTS" not in text:
    if anchor not in text:
        raise SystemExit("AMBIENT_PLACE_DETAILS anchor not found")
    text = text.replace(anchor, season_weights + "\n" + anchor, 1)

old = '''        self.life_time_shadow_marks: set[tuple[str, str, int]] = set()
'''
new = '''        self.life_time_shadow_marks: set[tuple[str, str, int]] = set()
        self.life_current_season: str = SEASONS[0]
'''
if new not in text:
    if old not in text:
        raise SystemExit("init insertion point not found")
    text = text.replace(old, new, 1)

old = '''        self._record_life(
            "season",
            [],
            f"season={season}; weather={weather}",
        )
'''
new = '''        self.life_current_season = season
        self._record_life(
            "season",
            [],
            f"season={season}; weather={weather}",
        )
'''
if new not in text:
    if old not in text:
        raise SystemExit("season assignment point not found")
    text = text.replace(old, new, 1)

old = '''    def _observe_ambient_place_details(self, rng: random.Random, weather: str) -> None:
        place = rng.choice(tuple(AMBIENT_PLACE_DETAILS))
        details = AMBIENT_PLACE_DETAILS[place]
'''
new = '''    def _observe_ambient_place_details(self, rng: random.Random, weather: str) -> None:
        season = self.life_current_season
        place = self._choose_ambient_detail_place(season, rng)
        details = AMBIENT_PLACE_DETAILS[place]
'''
if old not in text:
    raise SystemExit("ambient place detail header not found")
text = text.replace(old, new, 1)

repls = [
    (
        '''                f"place={place}; object={obj}; weather={weather}",''',
        '''                f"place={place}; object={obj}; season={season}; weather={weather}",''',
    ),
    (
        '''                f"place={place}; scent={scent}; weather={weather}",''',
        '''                f"place={place}; scent={scent}; season={season}; weather={weather}",''',
    ),
    (
        '''                f"place={place}; sound={sound}; weather={weather}",''',
        '''                f"place={place}; sound={sound}; season={season}; weather={weather}",''',
    ),
    (
        '''                f"place={place}; scene={scene}; weather={weather}",''',
        '''                f"place={place}; scene={scene}; season={season}; weather={weather}",''',
    ),
]
for old, new in repls:
    if old not in text:
        raise SystemExit(f"missing detail format {old}")
    text = text.replace(old, new, 1)

old = '''        if rng.random() < 0.42:
            scene = rng.choice(details["scenes"])
            self._record_life(
                "ambient_place_scene",
                [],
                f"place={place}; scene={scene}; season={season}; weather={weather}",
            )

    def _observe_people_in_places(
'''
new = '''        if rng.random() < 0.42:
            scene = self._choose_ambient_detail_value(season, place, "scenes", rng)
            self._record_life(
                "ambient_place_scene",
                [],
                f"place={place}; scene={scene}; season={season}; weather={weather}",
            )

    def _choose_ambient_detail_place(self, season: str, rng: random.Random) -> str:
        places = list(AMBIENT_PLACE_DETAILS)
        seasonal = SEASON_AMBIENT_PLACE_WEIGHTS.get(season, {})
        weights = [seasonal.get(place, 1.0) for place in places]
        return rng.choices(places, weights=weights, k=1)[0]

    def _choose_ambient_detail_value(
        self,
        season: str,
        place: str,
        category: str,
        rng: random.Random,
    ) -> str:
        values = list(AMBIENT_PLACE_DETAILS[place][category])
        seasonal = (
            SEASON_DETAIL_WEIGHTS
            .get(season, {})
            .get(place, {})
            .get(category, {})
        )
        weights = [seasonal.get(value, 1.0) for value in values]
        return rng.choices(values, weights=weights, k=1)[0]

    def _observe_people_in_places(
'''
if old not in text:
    raise SystemExit("method insertion point not found")
text = text.replace(old, new, 1)

for category in ["objects", "scents", "sounds"]:
    old = f'''            {category[:-1] if category != "scents" else "scent"} = rng.choice(details["{category}"])'''
    if old in text:
        new = f'''            {category[:-1] if category != "scents" else "scent"} = self._choose_ambient_detail_value(season, place, "{category}", rng)'''
        text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")
print(path)
