"""
society_lab v1.4 life bridge trust nudge experiment
====================================================

Experimental, intentionally polluting branch from shadow3.

This file keeps the observation-only shadow3 build intact and adds a very small
life-side trust nudge from relation potential. It does not write to the main
ObservationLog; nudge records are life observations only.
"""

from __future__ import annotations

from typing import Optional

from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab


class LifeBridgeTrustNudgeExperiment(LifeObservedSocietyLab):
    """Experimental bridge: life relation potential can weakly nudge trust."""

    # D proposal: a narrow, controlled body-intervention experiment.
    # Only memory_shadow-sourced bridge potential can touch trust.
    life_trust_nudge_threshold = 10.0
    life_trust_nudge_delta = 0.0005
    life_trust_nudge_cooldown = 16
    life_trust_nudge_max_per_year = 1
    life_trust_nudge_max_per_pair_total: int | None = 1
    life_trust_nudge_allowed_sources: set[str] | None = {"memory_shadow"}

    def __init__(
        self,
        seed: Optional[int] = None,
        verbose: bool = False,
        life_verbose: bool = False,
    ):
        super().__init__(seed=seed, verbose=verbose, life_verbose=life_verbose)
        self.life_trust_nudge_last_year: dict[tuple[str, str], int] = {}
        self.life_trust_nudge_counts: dict[tuple[str, str], int] = {}
        self.life_trust_nudges_by_year: dict[int, int] = {}

    def _note_relation_potential_by_ids(
        self,
        left_id: str,
        right_id: str,
        place: str,
        weather: str,
        weight: float,
        source: str,
    ) -> None:
        super()._note_relation_potential_by_ids(
            left_id,
            right_id,
            place,
            weather,
            weight,
            source,
        )
        pair = tuple(sorted((left_id, right_id)))
        potential = self.life_relation_potential.get(pair, 0.0)
        self._maybe_apply_life_trust_nudge(pair, potential, place, weather, source)

    def _maybe_apply_life_trust_nudge(
        self,
        pair: tuple[str, str],
        potential: float,
        place: str,
        weather: str,
        source: str,
    ) -> None:
        if potential < self.life_trust_nudge_threshold:
            return
        allowed_sources = self.life_trust_nudge_allowed_sources
        if allowed_sources is not None and source not in allowed_sources:
            return
        max_pair_total = self.life_trust_nudge_max_per_pair_total
        if max_pair_total is not None and self.life_trust_nudge_counts.get(pair, 0) >= max_pair_total:
            return
        if self.life_trust_nudges_by_year.get(self.year, 0) >= self.life_trust_nudge_max_per_year:
            return
        last_year = self.life_trust_nudge_last_year.get(pair)
        if last_year is not None and self.year - last_year < self.life_trust_nudge_cooldown:
            return

        left = self._person(pair[0])
        right = self._person(pair[1])
        if not left.alive or not right.alive:
            return

        before_left = left.trust.get(right.id, 0.0)
        before_right = right.trust.get(left.id, 0.0)
        after_left = self._clamp(before_left + self.life_trust_nudge_delta)
        after_right = self._clamp(before_right + self.life_trust_nudge_delta)
        left.trust[right.id] = after_left
        right.trust[left.id] = after_right

        self.life_trust_nudge_last_year[pair] = self.year
        self.life_trust_nudge_counts[pair] = self.life_trust_nudge_counts.get(pair, 0) + 1
        self.life_trust_nudges_by_year[self.year] = (
            self.life_trust_nudges_by_year.get(self.year, 0) + 1
        )
        self._record_life(
            "life_trust_nudge",
            [left.id, right.id],
            (
                f"potential={potential:.1f}; delta={self.life_trust_nudge_delta:.4f}; "
                f"threshold={self.life_trust_nudge_threshold:.1f}; "
                f"cooldown={self.life_trust_nudge_cooldown}; "
                f"max_per_year={self.life_trust_nudge_max_per_year}; "
                f"max_per_pair_total={self.life_trust_nudge_max_per_pair_total}; "
                f"source={source}; place={place}; weather={weather}; "
                f"trust_before={before_left:.4f},{before_right:.4f}; "
                f"trust_after={after_left:.4f},{after_right:.4f}"
            ),
        )

    def life_summary(self) -> dict[str, object]:
        summary = super().life_summary()
        summary["life_trust_nudge_count"] = sum(self.life_trust_nudge_counts.values())
        summary["life_trust_nudge_pair_counts"] = {
            f"{pair[0]}|{pair[1]}": count
            for pair, count in sorted(
                self.life_trust_nudge_counts.items(),
                key=lambda item: (-item[1], item[0]),
            )
        }
        summary["life_trust_nudge_by_year"] = dict(sorted(self.life_trust_nudges_by_year.items()))
        return summary


SocietyLab = LifeBridgeTrustNudgeExperiment


def main() -> None:
    sim = LifeBridgeTrustNudgeExperiment(seed=1000)
    sim.run(years=80)
    for key, value in sim.summary().items():
        print(f"{key}: {value}")
    for key, value in sim.life_summary().items():
        print(f"life_{key}: {value}")


if __name__ == "__main__":
    main()
