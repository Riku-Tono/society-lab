from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\新しいフォルダー\society_lab_v1_4_1.py")
if not BASE_PATH.exists():
    BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
LIFE_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(r"C:\Users\yauki\Documents\Codex\2026-06-11\files-mentioned-by-the-user-society-2\work\society_lab_v1_4_life_senses.py")


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


load(BASE_PATH, "society_lab_v1_4_1")
life = load(LIFE_PATH, "life_senses")

sim = life.LifeObservedSocietyLab(seed=42, verbose=False)
sim.run(years=80)

keys = [
    "life_observation_count",
    "scent_count",
    "touch_count",
    "affect_object_count",
    "animal_presence_count",
    "repeat_place_count",
    "rainy_tea_house_count",
    "same_place_nearby_count",
    "gesture_count",
    "world_gesture_count",
    "distant_social_count",
    "conversation_shadow_count",
    "familiarity_shadow_count",
    "memory_shadow_count",
]
summary = sim.life_summary()
print(json.dumps({key: summary.get(key) for key in keys}, ensure_ascii=False, indent=2))

for observation in [
    item
    for item in sim.life_observations
    if item.event_type in {
        "scent",
        "touch",
        "affect_object",
        "animal_presence",
        "gesture",
        "world_gesture",
        "same_place_nearby",
        "distant_social",
        "conversation_shadow",
        "familiarity_shadow",
        "memory_shadow",
    }
][:12]:
    print(observation)
