from pathlib import Path
from collections import Counter
import os
import re
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        sl3 = Path(dirpath)
        break
else:
    raise SystemExit("SL3 not found")

sys.path.insert(0, str(sl3))
from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab  # noqa: E402

TARGET = [
    "place_presence",
    "repeat_place",
    "same_place_nearby",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "time_shadow",
]


def place(detail):
    for pattern in [r"place=([^;]+)", r"near ([^;]+)", r" at ([^;]+);"]:
        m = re.search(pattern, detail)
        if m:
            return m.group(1)
    return "unknown"


for seed in [1003, 1061]:
    sim = LifeObservedSocietyLab(seed=seed, verbose=False)
    sim.run(80)
    selected = [o for o in sim.life_observations if o.event_type in TARGET]
    counts = Counter(o.event_type for o in selected)
    places = Counter(place(o.detail) for o in selected)
    people = Counter(pid for o in selected for pid in o.persons)
    print(f"\nSEED {seed}")
    print("world_summary", sim.summary())
    print("counts", {k: counts.get(k, 0) for k in TARGET})
    print("places", places.most_common(8))
    print("people", people.most_common(8))
    print("shadow_timeline")
    for o in selected:
        if o.event_type in {"distant_social", "conversation_shadow", "familiarity_shadow", "memory_shadow", "time_shadow"}:
            print(f"Y{o.year:02d} {o.event_type:19s} {o.persons} {o.detail}")
    print("time_shadow_only")
    for o in selected:
        if o.event_type == "time_shadow":
            print(f"Y{o.year:02d} {o.persons} {o.detail}")
    print("memory_shadow_only")
    for o in selected:
        if o.event_type == "memory_shadow":
            print(f"Y{o.year:02d} {o.persons} {o.detail}")
