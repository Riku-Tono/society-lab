from __future__ import annotations

import copy
from collections import Counter, defaultdict
import importlib.util
import json
import os
from pathlib import Path
import py_compile
import re
import sys


sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

ROOT = Path.cwd()
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def find_sl3() -> Path:
    home = Path.home()
    for root, dirs, files in os.walk(home / "OneDrive"):
        if "society_lab_v1_4_1.py" in files and "society_lab_v1_4_life_senses_memory_shadow3.py" in files:
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


SL3 = find_sl3()
BASE_PATH = SL3 / "society_lab_v1_4_1.py"
LIFE_PATH = SL3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
READER_PATH = SL3 / "life_observation_reader.py"
if str(SL3) not in sys.path:
    sys.path.insert(0, str(SL3))


def import_from_path(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def clean_json(value):
    return json.loads(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str))


def world_snapshot(sim):
    return {
        "summary": clean_json(sim.summary()),
        "people": clean_json(sim.people),
        "food_stock": getattr(sim.food, "stock", None),
        "food_capacity": getattr(sim.food, "capacity", None),
        "log_entries": clean_json(getattr(sim.log, "entries", [])),
        "memory_lineage_trace": clean_json(getattr(sim, "memory_lineage_trace", [])),
        "support_chain_trace": clean_json(getattr(sim, "support_chain_trace", [])),
        "project_aftermath_trace": clean_json(getattr(sim, "project_aftermath_trace", [])),
    }


def run_sim(cls, seed: int, years: int = 80):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=years)
    return sim


def fields(detail: str) -> dict[str, str]:
    return {key: value.strip() for key, value in re.findall(r"([A-Za-z_]+)=([^;]+)", detail)}


def life_counts(sim, event_types: tuple[str, ...]) -> dict[str, int]:
    counts = Counter(ob.event_type for ob in sim.life_observations)
    return {event: counts.get(event, 0) for event in event_types}


def stats(values: list[int]) -> dict[str, float | int]:
    if not values:
        return {"min": 0, "max": 0, "avg": 0.0, "nonzero": 0}
    return {
        "min": min(values),
        "max": max(values),
        "avg": round(sum(values) / len(values), 2),
        "nonzero": sum(1 for value in values if value),
    }


def event_signature(sim, event_types: tuple[str, ...]) -> list[tuple]:
    selected = []
    for ob in sim.life_observations:
        if ob.event_type in event_types:
            selected.append((ob.year, ob.event_type, tuple(ob.persons), ob.detail))
    return selected


py_compile.compile(str(LIFE_PATH), cfile=str(ROOT / "work" / "_shadow3.pyc"), doraise=True)
py_compile.compile(str(READER_PATH), cfile=str(ROOT / "work" / "_reader.pyc"), doraise=True)

base_mod = import_from_path("society_lab_base_current", BASE_PATH)
life_mod = import_from_path("society_lab_life_current", LIFE_PATH)

BaseLab = base_mod.SocietyLab
LifeLab = life_mod.LifeObservedSocietyLab


class NoSeasonAwareAmbientLab(LifeLab):
    def _observe_ambient_place_details(self, rng, weather):
        place = rng.choice(list(life_mod.AMBIENT_PLACE_DETAILS))
        details = life_mod.AMBIENT_PLACE_DETAILS[place]
        season = self.life_current_season

        if rng.random() < 0.70:
            obj = rng.choice(details["objects"])
            self._record_life(
                "ambient_place_object",
                [],
                f"place={place}; object={obj}; season={season}; weather={weather}",
            )
        if rng.random() < 0.52:
            scent = rng.choice(details["scents"])
            self._record_life(
                "ambient_place_scent",
                [],
                f"place={place}; scent={scent}; season={season}; weather={weather}",
            )
        if rng.random() < 0.55:
            sound = rng.choice(details["sounds"])
            self._record_life(
                "ambient_place_sound",
                [],
                f"place={place}; sound={sound}; season={season}; weather={weather}",
            )
        if rng.random() < 0.42:
            scene = rng.choice(details["scenes"])
            self._record_life(
                "ambient_place_scene",
                [],
                f"place={place}; scene={scene}; season={season}; weather={weather}",
            )


stable_events = (
    "weather",
    "season",
    "ambient_object",
    "ambient_scent",
    "ambient_sound",
    "crowd_mood",
    "place_presence",
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "time_shadow",
)

count_events = (
    "season",
    "ambient_place_object",
    "ambient_place_scent",
    "ambient_place_sound",
    "ambient_place_scene",
    "life_observation",
)

all_counts = defaultdict(list)
pollution_diffs = []
stable_diffs = []
season_place = Counter()
seed_details = {}

for seed in range(1000, 1100):
    base = run_sim(BaseLab, seed)
    life = run_sim(LifeLab, seed)
    old_ambient = run_sim(NoSeasonAwareAmbientLab, seed)

    if world_snapshot(base) != world_snapshot(life):
        pollution_diffs.append(seed)

    if event_signature(life, stable_events) != event_signature(old_ambient, stable_events):
        stable_diffs.append(seed)

    counts = life_counts(life, count_events[:-1])
    counts["life_observation"] = len(life.life_observations)
    for event, count in counts.items():
        all_counts[event].append(count)

    for ob in life.life_observations:
        if ob.event_type.startswith("ambient_place_"):
            f = fields(ob.detail)
            season = f.get("season", "unknown")
            place = f.get("place", "unknown")
            season_place[(season, place)] += 1

    if seed in (1003, 1061):
        key_events = (
            "life_contact",
            "passing_greeting",
            "conversation_shadow",
            "familiarity_shadow",
            "memory_shadow",
            "time_shadow",
            "ambient_place_object",
            "ambient_place_scent",
            "ambient_place_sound",
            "ambient_place_scene",
        )
        seed_counter = life_counts(life, key_events)
        seed_sp = Counter()
        examples = defaultdict(list)
        for ob in life.life_observations:
            if ob.event_type.startswith("ambient_place_"):
                f = fields(ob.detail)
                season = f.get("season", "unknown")
                place = f.get("place", "unknown")
                seed_sp[(season, place)] += 1
                if len(examples[(season, place)]) < 3:
                    examples[(season, place)].append(ob.detail)
        seed_details[seed] = {
            "counts": seed_counter,
            "top_season_places": seed_sp.most_common(8),
            "examples": {f"{s}/{p}": v for (s, p), v in sorted(examples.items())},
        }

season_lines = []
for season in sorted({season for season, _place in season_place}):
    top = [
        (place, count)
        for (sp_season, place), count in season_place.most_common()
        if sp_season == season
    ][:6]
    season_lines.append((season, top))

report = {
    "files": {
        "base": str(BASE_PATH),
        "life": str(LIFE_PATH),
        "reader": str(READER_PATH),
    },
    "compile_ok": True,
    "pollution_diffs": pollution_diffs,
    "stable_event_diffs_vs_unweighted_ambient_places": stable_diffs,
    "count_stats": {event: stats(values) for event, values in sorted(all_counts.items())},
    "season_place_top": season_lines,
    "seed_details": seed_details,
}

report_path = OUTPUTS / "season_aware_ambient_places_check.json"
report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

print(json.dumps(report, indent=2, ensure_ascii=False))
