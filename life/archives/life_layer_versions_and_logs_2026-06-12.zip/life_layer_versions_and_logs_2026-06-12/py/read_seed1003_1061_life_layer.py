from pathlib import Path
from collections import Counter, defaultdict
import os
import re
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        sl3 = Path(dirpath)
        break
else:
    raise SystemExit("SL3 not found")

sys.path.insert(0, str(sl3))
from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab  # noqa: E402

TARGET_TYPES = {
    "place_presence",
    "repeat_place",
    "same_place_nearby",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "time_shadow",
}


def extract_place(detail: str) -> str:
    match = re.search(r"place=([^;]+)", detail)
    if match:
        return match.group(1)
    match = re.search(r"near ([^;]+)", detail)
    if match:
        return match.group(1)
    match = re.search(r" at ([^;]+);", detail)
    if match:
        return match.group(1)
    return "unknown"


def run(seed: int):
    sim = LifeObservedSocietyLab(seed=seed, verbose=False)
    sim.run(80)
    observations = [obs for obs in sim.life_observations if obs.event_type in TARGET_TYPES]
    by_type = Counter(obs.event_type for obs in observations)
    by_place = Counter(extract_place(obs.detail) for obs in observations)
    by_person = Counter(person for obs in observations for person in obs.persons)
    by_year = defaultdict(list)
    for obs in observations:
        by_year[obs.year].append(obs)
    print(f"\n=== seed {seed} ===")
    print("summary", sim.summary())
    print("life_summary_selected", {key: sim.life_summary()[key] for key in [
        "place_presence_count",
        "repeat_place_count",
        "same_place_nearby_count",
        "distant_social_count",
        "conversation_shadow_count",
        "familiarity_shadow_count",
        "memory_shadow_count",
        "time_shadow_count",
    ]})
    print("by_type", dict(sorted(by_type.items())))
    print("top_places", by_place.most_common(10))
    print("top_person_ids", by_person.most_common(12))
    print("\ncondensed_timeline")
    for year in sorted(by_year):
        important = [
            obs for obs in by_year[year]
            if obs.event_type in {"conversation_shadow", "familiarity_shadow", "memory_shadow", "time_shadow"}
        ]
        if not important:
            continue
        print(f"Y{year}")
        for obs in important:
            print(f"  {obs.event_type}: {obs.persons} {obs.detail}")
    print("\nall_selected_events")
    for obs in observations:
        print(f"Y{obs.year:02d} {obs.event_type:20s} {obs.persons} {obs.detail}")


for seed in [1003, 1061]:
    run(seed)
