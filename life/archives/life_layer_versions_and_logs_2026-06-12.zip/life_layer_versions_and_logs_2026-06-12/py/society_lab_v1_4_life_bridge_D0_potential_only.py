"""
society_lab v1.4 life bridge D0 potential-only control
======================================================

Control branch for the D trust-nudge experiment.

D0 keeps the observation-only shadow3 behavior, including life_bridge_potential
records, but never emits life_trust_nudge and never writes to main trust.
"""

from __future__ import annotations

import sys
from pathlib import Path


SL3 = Path("C:/Users/yauki/OneDrive/デスクトップ/SL3")
if str(SL3) not in sys.path:
    sys.path.insert(0, str(SL3))

from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab


class LifeBridgeD0PotentialOnly(LifeObservedSocietyLab):
    """Potential-only control: observe bridge candidates, do not intervene."""

    def life_summary(self) -> dict[str, object]:
        summary = super().life_summary()
        summary["life_trust_nudge_count"] = 0
        summary["life_trust_nudge_pair_counts"] = {}
        summary["life_trust_nudge_by_year"] = {}
        return summary


SocietyLab = LifeBridgeD0PotentialOnly


def main() -> None:
    sim = LifeBridgeD0PotentialOnly(seed=1000, verbose=False)
    sim.run(years=80)
    print(sim.summary())
    print(sim.life_summary())


if __name__ == "__main__":
    main()
