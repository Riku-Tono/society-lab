from pathlib import Path
import os


def find_sl3() -> Path:
    for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
        if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
            return Path(dirpath)
    raise SystemExit("SL3 not found")


sl3 = find_sl3()
path = sl3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
text = path.read_text(encoding="utf-8")

replacements = [
    (
        """society_lab v1.4_life (shadow3)
================================

Observation-only life layer for society_lab v1.4_1.
shadow3: memory_shadow fire rate adjusted 0.12 -> 0.20""",
        """society_lab v1.4_life (shadow3)
================================

Observation-only life layer for society_lab v1.4_1.
shadow3: life observation RNG streams are separated by purpose.""",
    ),
    (
        """    def _life_rng(self) -> random.Random:
        material = f"{self.seed}|{self.year}|life_observation".encode()
        digest = hashlib.sha256(material).hexdigest()
        return random.Random(int(digest[:16], 16))
""",
        """    def _life_rng(self, stream_name: str) -> random.Random:
        material = f"{self.seed}|{self.year}|life_observation|{stream_name}".encode()
        digest = hashlib.sha256(material).hexdigest()
        return random.Random(int(digest[:16], 16))
""",
    ),
    (
        """        rng = self._life_rng()

        # 世界側の空気をまず記録する（茶屋と独立）
        weather = self._year_weather(rng)
        time_of_day = rng.choice(TIME_OF_DAY)
        fire = rng.choice(FIRE_DETAIL)
        sound = rng.choice(SOUNDS)
""",
        """        weather_rng = self._life_rng("weather")
        world_sense_rng = self._life_rng("world_sense")
        person_place_rng = self._life_rng("person_place")
        person_sense_rng = self._life_rng("person_sense")
        pair_social_rng = self._life_rng("pair_social")
        memory_shadow_rng = self._life_rng("memory_shadow")
        time_shadow_rng = self._life_rng("time_shadow")

        # 世界側の空気をまず記録する（茶屋と独立）
        weather = self._year_weather(weather_rng)
        time_of_day = weather_rng.choice(TIME_OF_DAY)
        fire = weather_rng.choice(FIRE_DETAIL)
        sound = weather_rng.choice(SOUNDS)
""",
    ),
    ("        sound = rng.choice(SOUNDS)\n", "        sound = world_sense_rng.choice(SOUNDS)\n"),
    ("        if rng.random() < 0.40:\n            trace = rng.choice(OBJECT_TRACES)\n            place = rng.choice(TRACE_PLACES)\n", "        if world_sense_rng.random() < 0.40:\n            trace = world_sense_rng.choice(OBJECT_TRACES)\n            place = world_sense_rng.choice(TRACE_PLACES)\n"),
    ("        if rng.random() < 0.35:\n            place = self._choose_world_sense_place(weather, rng)\n            scent = rng.choice(SCENTS_BY_PLACE[place])\n", "        if world_sense_rng.random() < 0.35:\n            place = self._choose_world_sense_place(weather, world_sense_rng)\n            scent = world_sense_rng.choice(SCENTS_BY_PLACE[place])\n"),
    ("        if rng.random() < 0.18:\n            gesture = rng.choice(WORLD_GESTURES)\n            if gesture != \"nothing_moved\":\n                place = self._choose_world_sense_place(weather, rng)\n", "        if world_sense_rng.random() < 0.18:\n            gesture = world_sense_rng.choice(WORLD_GESTURES)\n            if gesture != \"nothing_moved\":\n                place = self._choose_world_sense_place(weather, world_sense_rng)\n"),
    (
        """        self._observe_people_in_places(rng, weather)

    def _observe_people_in_places(self, rng: random.Random, weather: str) -> None:
""",
        """        self._observe_people_in_places(
            person_place_rng,
            person_sense_rng,
            pair_social_rng,
            memory_shadow_rng,
            time_shadow_rng,
            weather,
        )

    def _observe_people_in_places(
        self,
        place_rng: random.Random,
        sense_rng: random.Random,
        pair_rng: random.Random,
        memory_rng: random.Random,
        time_rng: random.Random,
        weather: str,
    ) -> None:
""",
    ),
    ("            if rng.random() < self._place_observation_chance(person, weather)\n", "            if place_rng.random() < self._place_observation_chance(person, weather)\n"),
    ("            if rng.random() >= 0.22:\n                return\n            visitors = [rng.choice(self.alive_people)]\n\n        rng.shuffle(visitors)\n", "            if place_rng.random() >= 0.22:\n                return\n            visitors = [place_rng.choice(self.alive_people)]\n\n        place_rng.shuffle(visitors)\n"),
    (
        """            place = self._choose_life_place(person, weather, rng)
            self._record_place_presence(person, place, weather, rng)
            self._observe_memory_shadow(person, place, weather, rng)
            self._observe_sense_detail(person, place, weather, rng)
            if place == "tea_house":
                self._observe_tea_house_visit(person, weather, rng)
            elif place == "hearth":
                self._observe_hearth(person, weather, rng)
            elif place == "well":
                self._observe_well(person, weather, rng)
            elif place == "storehouse":
                self._observe_storehouse(person, weather, rng)
""",
        """            place = self._choose_life_place(person, weather, place_rng)
            self._record_place_presence(person, place, weather, time_rng)
            self._observe_memory_shadow(person, place, weather, memory_rng)
            self._observe_sense_detail(person, place, weather, sense_rng)
            if place == "tea_house":
                self._observe_tea_house_visit(person, weather, sense_rng)
            elif place == "hearth":
                self._observe_hearth(person, weather, sense_rng)
            elif place == "well":
                self._observe_well(person, weather, sense_rng)
            elif place == "storehouse":
                self._observe_storehouse(person, weather, sense_rng)
""",
    ),
    ("                    if rng.random() < 0.20:\n                        gesture = rng.choice(DISTANT_SOCIAL_GESTURES)\n", "                    if pair_rng.random() < 0.20:\n                        gesture = pair_rng.choice(DISTANT_SOCIAL_GESTURES)\n"),
    ("                        if rng.random() < 0.28:\n                            shadow = rng.choice(CONVERSATION_SHADOWS)\n", "                        if pair_rng.random() < 0.28:\n                            shadow = pair_rng.choice(CONVERSATION_SHADOWS)\n"),
    ("            if rng.random() >= 0.20:\n", "            if rng.random() >= 0.12:\n"),
]

for old, new in replacements:
    if old not in text:
        raise SystemExit(f"missing pattern: {old[:120]!r}")
    text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")
print(path)
