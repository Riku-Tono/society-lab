from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


SOURCE_DIR = Path(r"C:\Users\yauki\OneDrive\デスクトップ\新しいフォルダー")
SL2_DIR = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2")
BASE_PATH = SOURCE_DIR / "society_lab_v1_4_1.py"
if not BASE_PATH.exists():
    BASE_PATH = SL2_DIR / "society_lab_v1_4_1.py"
DEFAULT_LIFE_PATH = SOURCE_DIR / "society_lab_v1_4_life_sound.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run(cls, seed: int, years: int):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=years)
    return sim


def main() -> int:
    if not BASE_PATH.exists():
        print(json.dumps({"status": "missing_base", "path": str(BASE_PATH)}))
        return 2
    life_path = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_LIFE_PATH

    if not life_path.exists():
        print(json.dumps({"status": "missing_life", "path": str(life_path)}))
        return 2

    base_module = load_module(BASE_PATH, "society_lab_v1_4_1")
    life_module = load_module(life_path, "society_lab_v1_4_life_sound")

    mismatches = []
    life_counts = []
    for seed in range(1000, 1100):
        base = run(base_module.SocietyLab, seed, 80)
        life = run(life_module.LifeObservedSocietyLab, seed, 80)

        base_summary = base.summary()
        life_summary = life.summary()
        if base_summary != life_summary:
            changed = {
                key: [base_summary.get(key), life_summary.get(key)]
                for key in sorted(set(base_summary) | set(life_summary))
                if base_summary.get(key) != life_summary.get(key)
            }
            mismatches.append({"seed": seed, "changed": changed})

        life_counts.append(life.life_summary())

    if mismatches:
        print(json.dumps({"status": "mismatch", "mismatches": mismatches}, ensure_ascii=False, indent=2))
        return 1

    compact = {
        "status": "ok",
        "life_path": str(life_path),
        "seeds": "1000-1099",
        "years": 80,
        "min_life_observations": min(item["life_observation_count"] for item in life_counts),
        "max_life_observations": max(item["life_observation_count"] for item in life_counts),
        "min_tea_house": min(item["tea_house_count"] for item in life_counts),
        "max_tea_house": max(item["tea_house_count"] for item in life_counts),
        "min_trace": min(item["trace_count"] for item in life_counts),
        "max_trace": max(item["trace_count"] for item in life_counts),
        "min_sound": min(item["sound_count"] for item in life_counts),
        "max_sound": max(item["sound_count"] for item in life_counts),
    }
    print(json.dumps(compact, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
