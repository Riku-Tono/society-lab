from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
import json
import os
from pathlib import Path
import py_compile
import re
import sys


sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

ROOT = Path.cwd()
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def find_sl3() -> Path:
    home = Path.home()
    for root, _dirs, files in os.walk(home / "OneDrive"):
        if (
            "society_lab_v1_4_1.py" in files
            and "society_lab_v1_4_life_senses_memory_shadow3.py" in files
            and "society_lab_v1_4_life_bridge_trust_nudge_experiment.py" in files
        ):
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


SL3 = find_sl3()
BASE_PATH = SL3 / "society_lab_v1_4_1.py"
SHADOW_PATH = SL3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
EXPERIMENT_PATH = SL3 / "society_lab_v1_4_life_bridge_trust_nudge_experiment.py"
if str(SL3) not in sys.path:
    sys.path.insert(0, str(SL3))


def import_from_path(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


py_compile.compile(str(EXPERIMENT_PATH), cfile=str(ROOT / "work" / "_trust_nudge.pyc"), doraise=True)

base_mod = import_from_path("society_lab_base_trust_nudge", BASE_PATH)
shadow_mod = import_from_path("society_lab_shadow_trust_nudge", SHADOW_PATH)
experiment_mod = import_from_path("society_lab_experiment_trust_nudge", EXPERIMENT_PATH)

BaseLab = base_mod.SocietyLab
ShadowLab = shadow_mod.LifeObservedSocietyLab
ExperimentLab = experiment_mod.LifeBridgeTrustNudgeExperiment


VARIANTS = {
    "A_threshold10_delta001": {
        "threshold": 10.0,
        "delta": 0.001,
        "cooldown": 8,
    },
    "B_threshold12_delta001": {
        "threshold": 12.0,
        "delta": 0.001,
        "cooldown": 8,
    },
    "C_threshold10_delta0005": {
        "threshold": 10.0,
        "delta": 0.0005,
        "cooldown": 8,
    },
}

SUMMARY_KEYS = (
    "final_population",
    "death_count",
    "birth_count",
    "project_success_count",
    "project_failure_count",
    "proposal_count",
    "memory_shared_count",
    "support_chain_trace_count",
    "project_aftermath_trace_count",
    "network_split_count",
    "shared_narrative_count",
    "authority_pattern_count",
)


def run_sim(cls, seed: int, years: int = 80):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=years)
    return sim


def trust_pairs(sim) -> dict[tuple[str, str], tuple[float, float]]:
    pairs: dict[tuple[str, str], tuple[float, float]] = {}
    ids = [person.id for person in sim.people]
    people = {person.id: person for person in sim.people}
    for i, left_id in enumerate(ids):
        for right_id in ids[i + 1 :]:
            left = people[left_id]
            right = people[right_id]
            pairs[(left_id, right_id)] = (
                left.trust.get(right_id, 0.0),
                right.trust.get(left_id, 0.0),
            )
    return pairs


def trust_delta(base, other) -> dict[str, float | int]:
    base_pairs = trust_pairs(base)
    other_pairs = trust_pairs(other)
    changed = 0
    total = 0.0
    max_delta = 0.0
    for pair, values in other_pairs.items():
        before = base_pairs.get(pair, (0.0, 0.0))
        delta_a = values[0] - before[0]
        delta_b = values[1] - before[1]
        pair_abs = abs(delta_a) + abs(delta_b)
        if pair_abs > 1e-12:
            changed += 1
            total += delta_a + delta_b
            max_delta = max(max_delta, abs(delta_a), abs(delta_b))
    return {
        "trust_changed_pair_count": changed,
        "trust_delta_sum": round(total, 6),
        "trust_delta_max": round(max_delta, 6),
    }


def summary_diff(base_summary: dict, other_summary: dict) -> dict[str, object]:
    return {
        key: {
            "base": base_summary.get(key),
            "experiment": other_summary.get(key),
            "delta": (
                other_summary.get(key) - base_summary.get(key)
                if isinstance(base_summary.get(key), (int, float))
                and isinstance(other_summary.get(key), (int, float))
                else None
            ),
        }
        for key in SUMMARY_KEYS
        if base_summary.get(key) != other_summary.get(key)
    }


def fields(detail: str) -> dict[str, str]:
    return {key: value.strip() for key, value in re.findall(r"([A-Za-z_]+)=([^;]+)", detail)}


def stats(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {"min": 0, "max": 0, "avg": 0.0, "nonzero": 0}
    return {
        "min": round(min(values), 4),
        "max": round(max(values), 4),
        "avg": round(sum(values) / len(values), 4),
        "nonzero": sum(1 for value in values if value),
    }


def make_variant_class(name: str, params: dict[str, float | int]):
    return type(
        name,
        (ExperimentLab,),
        {
            "life_trust_nudge_threshold": params["threshold"],
            "life_trust_nudge_delta": params["delta"],
            "life_trust_nudge_cooldown": params["cooldown"],
        },
    )


variant_reports = {}
focus_seeds = (1003, 1061, 1042, 1096)

for variant_name, params in VARIANTS.items():
    VariantLab = make_variant_class(variant_name, params)
    nudge_counts = []
    changed_pair_counts = []
    trust_delta_sums = []
    trust_delta_maxes = []
    summary_diff_counts = []
    changed_summary_keys = Counter()
    bridge_counts = []
    potential_gte_10_counts = []
    focus = {}

    for seed in range(1000, 1100):
        base = run_sim(BaseLab, seed)
        shadow = run_sim(ShadowLab, seed)
        experiment = run_sim(VariantLab, seed)

        base_summary = base.summary()
        exp_summary = experiment.summary()
        diffs = summary_diff(base_summary, exp_summary)
        summary_diff_counts.append(len(diffs))
        changed_summary_keys.update(diffs.keys())

        delta = trust_delta(shadow, experiment)
        changed_pair_counts.append(delta["trust_changed_pair_count"])
        trust_delta_sums.append(delta["trust_delta_sum"])
        trust_delta_maxes.append(delta["trust_delta_max"])

        nudge_count = sum(
            1 for ob in experiment.life_observations if ob.event_type == "life_trust_nudge"
        )
        bridge_count = sum(
            1 for ob in experiment.life_observations if ob.event_type == "life_bridge_potential"
        )
        nudge_counts.append(nudge_count)
        bridge_counts.append(bridge_count)
        potential_gte_10_counts.append(
            sum(1 for value in experiment.life_relation_potential.values() if value >= 10.0)
        )

        if seed in focus_seeds:
            nudge_rows = [
                {
                    "year": ob.year,
                    "persons": ob.persons,
                    "detail": ob.detail,
                    "fields": fields(ob.detail),
                }
                for ob in experiment.life_observations
                if ob.event_type == "life_trust_nudge"
            ]
            bridge_rows = [
                {
                    "year": ob.year,
                    "persons": ob.persons,
                    "detail": ob.detail,
                }
                for ob in experiment.life_observations
                if ob.event_type == "life_bridge_potential"
            ]
            focus[seed] = {
                "summary_diff": diffs,
                "trust_delta": delta,
                "counts": {
                    event: sum(1 for ob in experiment.life_observations if ob.event_type == event)
                    for event in (
                        "life_bridge_potential",
                        "life_trust_nudge",
                        "conversation_shadow",
                        "familiarity_shadow",
                        "memory_shadow",
                        "time_shadow",
                    )
                },
                "top_potentials": [
                    {"pair": f"{pair[0]}|{pair[1]}", "potential": round(value, 2)}
                    for pair, value in sorted(
                        experiment.life_relation_potential.items(),
                        key=lambda item: (-item[1], item[0]),
                    )[:8]
                ],
                "nudge_rows": nudge_rows,
                "bridge_rows": bridge_rows[:8],
            }

    variant_reports[variant_name] = {
        "params": params,
        "stats": {
            "nudge_count": stats(nudge_counts),
            "trust_changed_pair_count": stats(changed_pair_counts),
            "trust_delta_sum": stats(trust_delta_sums),
            "trust_delta_max": stats(trust_delta_maxes),
            "summary_diff_key_count": stats(summary_diff_counts),
            "life_bridge_potential_count": stats(bridge_counts),
            "potential_gte_10_pair_count": stats(potential_gte_10_counts),
        },
        "changed_summary_keys": dict(changed_summary_keys.most_common()),
        "focus": focus,
    }

report = {
    "files": {
        "base": str(BASE_PATH),
        "shadow3": str(SHADOW_PATH),
        "experiment": str(EXPERIMENT_PATH),
    },
    "variants": variant_reports,
}

json_path = OUTPUTS / "trust_nudge_experiment_comparison.json"
json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

lines = []
lines.append("# trust nudge experiment comparison")
lines.append("")
lines.append("## setup")
lines.append("")
lines.append("- Experiment file: `society_lab_v1_4_life_bridge_trust_nudge_experiment.py`")
lines.append("- Observation-only shadow3 is preserved.")
lines.append("- Nudge writes directly to `Person.trust` and records only `life_trust_nudge` in life observations.")
lines.append("- Main ObservationLog is not directly written by the nudge.")
lines.append("")
lines.append("## 3 variant comparison")
lines.append("")
lines.append("| variant | threshold | delta | nudge avg/max | changed trust pairs avg/max | trust delta sum avg/max | summary diff keys avg/max |")
lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
for variant_name, data in variant_reports.items():
    p = data["params"]
    s = data["stats"]
    lines.append(
        f"| `{variant_name}` | {p['threshold']} | {p['delta']} | "
        f"{s['nudge_count']['avg']}/{s['nudge_count']['max']} | "
        f"{s['trust_changed_pair_count']['avg']}/{s['trust_changed_pair_count']['max']} | "
        f"{s['trust_delta_sum']['avg']}/{s['trust_delta_sum']['max']} | "
        f"{s['summary_diff_key_count']['avg']}/{s['summary_diff_key_count']['max']} |"
    )
lines.append("")

for variant_name, data in variant_reports.items():
    lines.append(f"## {variant_name}")
    lines.append("")
    changed = data["changed_summary_keys"]
    if changed:
        lines.append("- Changed summary keys across 100 seeds: " + ", ".join(f"`{k}`={v}" for k, v in changed.items()))
    else:
        lines.append("- Changed summary keys across 100 seeds: none")
    for seed in focus_seeds:
        focus = data["focus"][seed]
        counts = ", ".join(f"`{k}={v}`" for k, v in focus["counts"].items())
        lines.append(f"- seed{seed}: {counts}; trust_delta={focus['trust_delta']}")
        if focus["nudge_rows"]:
            for row in focus["nudge_rows"][:4]:
                pair = "|".join(row["persons"])
                lines.append(f"  - Y{row['year']:02d} `{pair}` {row['detail']}")
        else:
            lines.append("  - nudge: none")
    lines.append("")

lines.append("## recommendation")
lines.append("")
lines.append("Initial read: prefer the smallest variant that still catches seed1061's bridge path. If A and C affect the same seeds, C is safer because it halves the trust delta while preserving the candidate selection.")

md_path = OUTPUTS / "trust_nudge_experiment_comparison.md"
md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

print(json.dumps(report, indent=2, ensure_ascii=False))
print(md_path)
