from pathlib import Path
import os


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        path = Path(dirpath) / "society_lab_v1_4_life_senses_memory_shadow3.py"
        break
else:
    raise SystemExit("shadow3 not found")

text = path.read_text(encoding="utf-8")

old = '''CROWD_MOODS = (
    "many_people_gathered",
    "music_somewhere",
    "festival_preparation",
    "shared_waiting",
    "crowd_nearby",
)
'''
new = old + '''
PASSING_GREETINGS = (
    "nodded_once",
    "raised_a_hand_briefly",
    "said_a_short_greeting",
    "paused_before_passing",
    "made_room_on_the_path",
)
'''
if old not in text:
    raise SystemExit("CROWD_MOODS block not found")
text = text.replace(old, new, 1)

old = '''    memory_shadow_chance = 0.50
'''
new = '''    memory_shadow_chance = 0.50
    life_contact_chance = 0.72
    passing_greeting_chance = 0.22
    life_contact_familiarity_weight = 1
    passing_greeting_familiarity_weight = 2
    distant_social_familiarity_weight = 2
    conversation_shadow_familiarity_weight = 4
    familiarity_mark_divisor = 4
'''
if old not in text:
    raise SystemExit("class attrs insertion point not found")
text = text.replace(old, new, 1)

old = '''        pair_social_rng = self._life_rng("pair_social")
        memory_shadow_rng = self._life_rng("memory_shadow")
'''
new = '''        pair_social_rng = self._life_rng("pair_social")
        life_contact_rng = self._life_rng("life_contact")
        memory_shadow_rng = self._life_rng("memory_shadow")
'''
if old not in text:
    raise SystemExit("rng insertion point not found")
text = text.replace(old, new, 1)

old = '''            pair_social_rng,
            memory_shadow_rng,
'''
new = '''            pair_social_rng,
            life_contact_rng,
            memory_shadow_rng,
'''
if old not in text:
    raise SystemExit("observe_people call not found")
text = text.replace(old, new, 1)

old = '''        pair_rng: random.Random,
        memory_rng: random.Random,
'''
new = '''        pair_rng: random.Random,
        contact_rng: random.Random,
        memory_rng: random.Random,
'''
if old not in text:
    raise SystemExit("observe_people signature not found")
text = text.replace(old, new, 1)

old = '''                    self._record_life(
                        "same_place_nearby",
                        [pa.id, pb.id],
                        f"{pa.name} and {pb.name} both near {place}; weather={weather}",
                    )
                    self._note_familiarity_shadow(pa, pb, place, weather, 1, "same_place_nearby")
                    # distant_social: ~20% chance when two people are nearby.
                    # No contact. No relationship asserted. Just what was seen.
                    if pair_rng.random() < 0.20:
                        gesture = pair_rng.choice(DISTANT_SOCIAL_GESTURES)
                        self._record_life(
                            "distant_social",
                            [pa.id, pb.id],
                            f"{pa.name} and {pb.name}: {gesture}; place={place}; weather={weather}",
                        )
                        self._note_familiarity_shadow(pa, pb, place, weather, 2, "distant_social")
                        if pair_rng.random() < 0.28:
                            shadow = pair_rng.choice(CONVERSATION_SHADOWS)
                            self._record_life(
                                "conversation_shadow",
                                [pa.id, pb.id],
                                f"{pa.name} and {pb.name}: {shadow}; place={place}; weather={weather}",
                            )
                            self._note_familiarity_shadow(
                                pa,
                                pb,
                                place,
                                weather,
                                4,
                                "conversation_shadow",
                            )
'''
new = '''                    self._record_life(
                        "same_place_nearby",
                        [pa.id, pb.id],
                        f"{pa.name} and {pb.name} both near {place}; weather={weather}",
                    )
                    if contact_rng.random() < self.life_contact_chance:
                        self._record_life(
                            "life_contact",
                            [pa.id, pb.id],
                            f"{pa.name} and {pb.name}: shared a brief ordinary moment; place={place}; weather={weather}",
                        )
                        if self.life_contact_familiarity_weight:
                            self._note_familiarity_shadow(
                                pa,
                                pb,
                                place,
                                weather,
                                self.life_contact_familiarity_weight,
                                "life_contact",
                            )
                        if contact_rng.random() < self.passing_greeting_chance:
                            greeting = contact_rng.choice(PASSING_GREETINGS)
                            self._record_life(
                                "passing_greeting",
                                [pa.id, pb.id],
                                f"{pa.name} and {pb.name}: {greeting}; place={place}; weather={weather}",
                            )
                            if self.passing_greeting_familiarity_weight:
                                self._note_familiarity_shadow(
                                    pa,
                                    pb,
                                    place,
                                    weather,
                                    self.passing_greeting_familiarity_weight,
                                    "passing_greeting",
                                )
                    # distant_social: ~20% chance when two people are nearby.
                    # No contact. No relationship asserted. Just what was seen.
                    if pair_rng.random() < 0.20:
                        gesture = pair_rng.choice(DISTANT_SOCIAL_GESTURES)
                        self._record_life(
                            "distant_social",
                            [pa.id, pb.id],
                            f"{pa.name} and {pb.name}: {gesture}; place={place}; weather={weather}",
                        )
                        if self.distant_social_familiarity_weight:
                            self._note_familiarity_shadow(
                                pa,
                                pb,
                                place,
                                weather,
                                self.distant_social_familiarity_weight,
                                "distant_social",
                            )
                        if pair_rng.random() < 0.28:
                            shadow = pair_rng.choice(CONVERSATION_SHADOWS)
                            self._record_life(
                                "conversation_shadow",
                                [pa.id, pb.id],
                                f"{pa.name} and {pb.name}: {shadow}; place={place}; weather={weather}",
                            )
                            if self.conversation_shadow_familiarity_weight:
                                self._note_familiarity_shadow(
                                    pa,
                                    pb,
                                    place,
                                    weather,
                                    self.conversation_shadow_familiarity_weight,
                                    "conversation_shadow",
                                )
'''
if old not in text:
    raise SystemExit("pair event block not found")
text = text.replace(old, new, 1)

old = '''        mark = score // 4
'''
new = '''        mark = score // self.familiarity_mark_divisor
'''
if old not in text:
    raise SystemExit("mark divisor not found")
text = text.replace(old, new, 1)

old = '''        same_place_pair_counts: dict[tuple[str, str], int] = {}
        distant_social_pair_counts: dict[tuple[str, str], int] = {}
'''
new = '''        same_place_pair_counts: dict[tuple[str, str], int] = {}
        life_contact_pair_counts: dict[tuple[str, str], int] = {}
        passing_greeting_pair_counts: dict[tuple[str, str], int] = {}
        distant_social_pair_counts: dict[tuple[str, str], int] = {}
'''
if old not in text:
    raise SystemExit("pair count init not found")
text = text.replace(old, new, 1)

old = '''            if observation.event_type == "distant_social":
                pair = tuple(sorted(observation.persons))
                distant_social_pair_counts[pair] = distant_social_pair_counts.get(pair, 0) + 1
'''
new = '''            if observation.event_type == "life_contact":
                pair = tuple(sorted(observation.persons))
                life_contact_pair_counts[pair] = life_contact_pair_counts.get(pair, 0) + 1
            if observation.event_type == "passing_greeting":
                pair = tuple(sorted(observation.persons))
                passing_greeting_pair_counts[pair] = passing_greeting_pair_counts.get(pair, 0) + 1
            if observation.event_type == "distant_social":
                pair = tuple(sorted(observation.persons))
                distant_social_pair_counts[pair] = distant_social_pair_counts.get(pair, 0) + 1
'''
if old not in text:
    raise SystemExit("pair count loop insertion not found")
text = text.replace(old, new, 1)

old = '''            "same_place_nearby_pair_counts": {
                f"{pair[0]}|{pair[1]}": count
                for pair, count in sorted(
                    same_place_pair_counts.items(),
                    key=lambda item: (-item[1], item[0]),
                )
            },
            "gesture_count": sum(
'''
new = '''            "same_place_nearby_pair_counts": {
                f"{pair[0]}|{pair[1]}": count
                for pair, count in sorted(
                    same_place_pair_counts.items(),
                    key=lambda item: (-item[1], item[0]),
                )
            },
            "life_contact_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "life_contact"
            ),
            "life_contact_pair_counts": {
                f"{pair[0]}|{pair[1]}": count
                for pair, count in sorted(
                    life_contact_pair_counts.items(),
                    key=lambda item: (-item[1], item[0]),
                )
            },
            "passing_greeting_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "passing_greeting"
            ),
            "passing_greeting_pair_counts": {
                f"{pair[0]}|{pair[1]}": count
                for pair, count in sorted(
                    passing_greeting_pair_counts.items(),
                    key=lambda item: (-item[1], item[0]),
                )
            },
            "gesture_count": sum(
'''
if old not in text:
    raise SystemExit("summary counts insertion not found")
text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")
print(path)
