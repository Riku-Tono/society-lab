from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
FAMILIARITY_PATH = Path(r"C:\Users\yauki\Documents\Codex\2026-06-11\files-mentioned-by-the-user-society-2\outputs\society_lab_v1_4_life_senses_familiarity_shadow.py")
MEMORY_PATH = Path(r"C:\Users\yauki\Documents\Codex\2026-06-11\files-mentioned-by-the-user-society-2\outputs\society_lab_v1_4_life_senses_memory_shadow.py")


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run(cls, seed: int):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=80)
    return sim.summary(), sim.life_summary()


def main() -> int:
    load(BASE_PATH, "society_lab_v1_4_1")
    familiarity = load(FAMILIARITY_PATH, "life_familiarity_rank")
    memory = load(MEMORY_PATH, "life_memory_rank")

    rows = []
    for seed in range(1000, 1100):
        summary, fam = run(familiarity.LifeObservedSocietyLab, seed)
        _, mem = run(memory.LifeObservedSocietyLab, seed)
        row = {
            "seed": seed,
            "final_population": summary["final_population"],
            "death_count": summary["death_count"],
            "birth_count": summary["birth_count"],
            "network_split_count": summary["network_split_count"],
            "narrative_divergence_count": summary["narrative_divergence_count"],
            "interpretation_divergence_count": summary["interpretation_divergence_count"],
            "same_place_nearby": fam.get("same_place_nearby_count", 0),
            "distant_social": fam.get("distant_social_count", 0),
            "conversation_shadow": fam.get("conversation_shadow_count", 0),
            "familiarity_shadow": fam.get("familiarity_shadow_count", 0),
            "memory_shadow": mem.get("memory_shadow_count", 0),
            "repeat_place": fam.get("repeat_place_count", 0),
            "world_gesture": fam.get("world_gesture_count", 0),
        }
        row["interest_score"] = (
            row["memory_shadow"] * 12
            + row["familiarity_shadow"] * 7
            + row["conversation_shadow"] * 5
            + row["distant_social"] * 2
            + row["network_split_count"] * 3
            + min(row["narrative_divergence_count"], 30) * 0.25
        )
        rows.append(row)

    rows.sort(key=lambda item: (-item["interest_score"], item["seed"]))
    print(json.dumps(rows[:20], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
