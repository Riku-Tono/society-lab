from pathlib import Path
import os
import statistics
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        sl3 = Path(dirpath)
        break
else:
    raise SystemExit("SL3 not found")

sys.path.insert(0, str(sl3))
from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab  # noqa: E402


def make_lab(chance):
    return type(f"MemoryShadowChance{int(chance * 1000)}", (LifeObservedSocietyLab,), {"memory_shadow_chance": chance})


seeds = range(1000, 1100)
for chance in [0.20, 0.24, 0.30, 0.36, 0.42, 0.50, 0.60]:
    cls = make_lab(chance)
    counts = []
    for seed in seeds:
        sim = cls(seed=seed, verbose=False)
        sim.run(80)
        counts.append(sim.life_summary()["memory_shadow_count"])
    print(
        chance,
        "min",
        min(counts),
        "max",
        max(counts),
        "avg",
        round(statistics.mean(counts), 2),
        "nonzero",
        sum(count > 0 for count in counts),
    )
