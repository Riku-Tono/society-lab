from __future__ import annotations

from dataclasses import asdict, is_dataclass
import importlib.util
import json
from pathlib import Path
import sys
from typing import Any


sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

ROOT = Path.cwd()
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)

SL3 = Path("C:/Users/yauki/OneDrive/デスクトップ/SL3")
SHADOW_PATH = SL3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
D0_PATH = ROOT / "work" / "society_lab_v1_4_life_bridge_D0_potential_only.py"

if str(SL3) not in sys.path:
    sys.path.insert(0, str(SL3))
if str(D0_PATH.parent) not in sys.path:
    sys.path.insert(0, str(D0_PATH.parent))


def import_from_path(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


shadow_mod = import_from_path("society_lab_shadow_D0_check", SHADOW_PATH)
d0_mod = import_from_path("society_lab_D0_potential_only_check", D0_PATH)

ShadowLab = shadow_mod.LifeObservedSocietyLab
D0Lab = d0_mod.LifeBridgeD0PotentialOnly


def clean(value: Any) -> Any:
    return json.loads(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str))


def dataclass_clean(value: Any) -> Any:
    if is_dataclass(value):
        return clean(asdict(value))
    return clean(value)


def person_without_trust(person) -> dict[str, Any]:
    data = asdict(person)
    data.pop("trust", None)
    return clean(data)


def trust_snapshot(sim) -> dict[str, float]:
    values: dict[str, float] = {}
    for person in sim.people:
        for other_id, trust in person.trust.items():
            values[f"{person.id}->{other_id}"] = round(float(trust), 8)
    return dict(sorted(values.items()))


def count_diff(left: Any, right: Any) -> int:
    return 0 if left == right else 1


def body_without_rng_or_sections(sim) -> dict[str, Any]:
    return {
        "year": sim.year,
        "people_without_trust": [person_without_trust(person) for person in sim.people],
        "food": {
            "stock": round(float(sim.food.stock), 8),
            "capacity": round(float(sim.food.capacity), 8),
        },
        "current_problems": [dataclass_clean(problem) for problem in sim.current_problems],
        "current_proposals": [dataclass_clean(proposal) for proposal in sim.current_proposals],
    }


def main_log_snapshot(sim) -> list[Any]:
    return [dataclass_clean(entry) for entry in sim.log.entries]


def life_event_count(sim, event_type: str) -> int:
    return sum(1 for row in sim.life_observations if row.event_type == event_type)


def life_summary_value(sim, key: str) -> Any:
    return clean(sim.life_summary().get(key))


def first_bridge_rows(sim, limit: int = 3) -> list[str]:
    rows = []
    for row in sim.life_observations:
        if row.event_type == "life_bridge_potential":
            people = ",".join(row.persons) if row.persons else "-"
            rows.append(f"Y{row.year:02d} {people} {row.detail}")
            if len(rows) >= limit:
                break
    return rows


def analyze_seed(seed: int, years: int) -> dict[str, Any]:
    shadow = ShadowLab(seed=seed, verbose=False)
    d0 = D0Lab(seed=seed, verbose=False)
    shadow.run(years=years)
    d0.run(years=years)

    summary_diff = count_diff(clean(shadow.summary()), clean(d0.summary()))
    main_log_diff = count_diff(main_log_snapshot(shadow), main_log_snapshot(d0))
    memory_lineage_diff = count_diff(
        clean(shadow.memory_lineage_trace), clean(d0.memory_lineage_trace)
    )
    support_chain_diff = count_diff(clean(shadow.support_chain_trace), clean(d0.support_chain_trace))
    project_aftermath_diff = count_diff(
        clean(shadow.project_aftermath_trace), clean(d0.project_aftermath_trace)
    )
    trust_diff = count_diff(trust_snapshot(shadow), trust_snapshot(d0))
    rng_diff = count_diff(repr(shadow.rng.getstate()), repr(d0.rng.getstate()))
    body_diff = count_diff(body_without_rng_or_sections(shadow), body_without_rng_or_sections(d0))

    d0_life = d0.life_summary()
    shadow_life = shadow.life_summary()
    bridge_potential_count = int(d0_life.get("life_bridge_potential_count", 0))
    life_trust_nudge_count = int(d0_life.get("life_trust_nudge_count", 0))

    return {
        "seed": seed,
        "bridge_potential_count": bridge_potential_count,
        "shadow_bridge_potential_count": int(shadow_life.get("life_bridge_potential_count", 0)),
        "memory_shadow_count": int(d0_life.get("memory_shadow_count", 0)),
        "life_trust_nudge_count": life_trust_nudge_count,
        "trust_diff_count": trust_diff,
        "body_diff_count": body_diff,
        "rng_diff_count": rng_diff,
        "summary_diff_count": summary_diff,
        "main_log_diff_count": main_log_diff,
        "memory_lineage_diff_count": memory_lineage_diff,
        "support_chain_diff_count": support_chain_diff,
        "project_aftermath_diff_count": project_aftermath_diff,
        "life_observation_diff_count": count_diff(
            [dataclass_clean(row) for row in shadow.life_observations],
            [dataclass_clean(row) for row in d0.life_observations],
        ),
        "bridge_pair_counts": life_summary_value(d0, "life_bridge_potential_pair_counts"),
        "first_bridge_rows": first_bridge_rows(d0),
    }


DIFF_KEYS = (
    "trust_diff_count",
    "body_diff_count",
    "rng_diff_count",
    "summary_diff_count",
    "main_log_diff_count",
    "memory_lineage_diff_count",
    "support_chain_diff_count",
    "project_aftermath_diff_count",
    "life_observation_diff_count",
)


def aggregate(results: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "seed_count": len(results),
        "bridge_potential_count": sum(item["bridge_potential_count"] for item in results),
        "bridge_potential_seed_count": sum(
            1 for item in results if item["bridge_potential_count"] > 0
        ),
        "memory_shadow_count": sum(item["memory_shadow_count"] for item in results),
        "life_trust_nudge_count": sum(item["life_trust_nudge_count"] for item in results),
        **{key: sum(item[key] for item in results) for key in DIFF_KEYS},
        "any_diff_seed_count": sum(
            1 for item in results if any(item[key] for key in DIFF_KEYS)
        ),
    }


def run(seeds: list[int], years: int) -> dict[str, Any]:
    results = [analyze_seed(seed, years) for seed in seeds]
    return {
        "reader": "check_bridge_D0_potential_only_30_seed",
        "shadow_path": str(SHADOW_PATH),
        "d0_path": str(D0_PATH),
        "years": years,
        "seed_range": f"{seeds[0]}-{seeds[-1]}",
        "seeds": seeds,
        "aggregate": aggregate(results),
        "results": results,
    }


def write_markdown(report: dict[str, Any], path: Path) -> None:
    agg = report["aggregate"]
    lines = [
        "# bridge D0 potential-only 30 seed check",
        "",
        f"- seeds: `{report['seed_range']}` ({agg['seed_count']} consecutive seeds)",
        f"- years: `{report['years']}`",
        "- fixed baseline: `society_lab_v1_4_life_senses_memory_shadow3.py`",
        "- D0: `work/society_lab_v1_4_life_bridge_D0_potential_only.py`",
        "",
        "## Aggregate",
        "",
        "| metric | count |",
        "| --- | ---: |",
        f"| seed_count | {agg['seed_count']} |",
        f"| bridge_potential_count | {agg['bridge_potential_count']} |",
        f"| bridge_potential_seed_count | {agg['bridge_potential_seed_count']} |",
        f"| memory_shadow_count | {agg['memory_shadow_count']} |",
        f"| life_trust_nudge_count | {agg['life_trust_nudge_count']} |",
        f"| trust_diff_count | {agg['trust_diff_count']} |",
        f"| body_diff_count | {agg['body_diff_count']} |",
        f"| rng_diff_count | {agg['rng_diff_count']} |",
        f"| summary_diff_count | {agg['summary_diff_count']} |",
        f"| main_log_diff_count | {agg['main_log_diff_count']} |",
        f"| memory_lineage_diff_count | {agg['memory_lineage_diff_count']} |",
        f"| support_chain_diff_count | {agg['support_chain_diff_count']} |",
        f"| project_aftermath_diff_count | {agg['project_aftermath_diff_count']} |",
        f"| life_observation_diff_count | {agg['life_observation_diff_count']} |",
        f"| any_diff_seed_count | {agg['any_diff_seed_count']} |",
        "",
        "## Seed Table",
        "",
        "| seed | bridge_potential | memory_shadow | life_trust_nudge | trust diff | body diff | rng diff | summary diff | main log diff | memory diff | support diff | project diff |",
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for item in report["results"]:
        lines.append(
            f"| {item['seed']} | {item['bridge_potential_count']} | "
            f"{item['memory_shadow_count']} | {item['life_trust_nudge_count']} | "
            f"{item['trust_diff_count']} | {item['body_diff_count']} | "
            f"{item['rng_diff_count']} | {item['summary_diff_count']} | "
            f"{item['main_log_diff_count']} | {item['memory_lineage_diff_count']} | "
            f"{item['support_chain_diff_count']} | {item['project_aftermath_diff_count']} |"
        )

    lines.extend(["", "## Bridge Examples", ""])
    for item in report["results"]:
        if item["bridge_potential_count"] == 0:
            continue
        lines.append(f"### seed{item['seed']}")
        lines.append("")
        for row in item["first_bridge_rows"]:
            lines.append(f"- {row}")
        lines.append("")

    if agg["any_diff_seed_count"] == 0 and agg["life_trust_nudge_count"] == 0:
        judgment = (
            "D0 passed: bridge candidates were recorded, but no trust nudge fired and "
            "the main body, RNG, summaries, logs, memory lineage, support chains, and "
            "project aftermath stayed identical to shadow3."
        )
    else:
        judgment = (
            "D0 did not fully pass; inspect the nonzero diff counts above before using it "
            "as a control."
        )
    lines.extend(["## Judgment", "", judgment, ""])
    lines.append(
        "This separates candidate recording from intervention: potential-only observation is safe here; D divergence belongs to the trust write."
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    seeds = list(range(1000, 1030))
    report = run(seeds, years=80)
    json_path = OUTPUTS / "bridge_D0_potential_only_30_seed_check.json"
    md_path = OUTPUTS / "bridge_D0_potential_only_30_seed_check.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(report, md_path)
    print(json.dumps(report["aggregate"], indent=2, ensure_ascii=False))
    print(md_path)


if __name__ == "__main__":
    main()
