from pathlib import Path
import dataclasses
import json
import os
import py_compile
import statistics
import subprocess
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if (
        dirpath.endswith("SL3")
        and "society_lab_v1_4_1.py" in filenames
        and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames
    ):
        sl3 = Path(dirpath)
        break
else:
    raise SystemExit("SL3 not found")

shadow3 = sl3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
reader = sl3 / "life_observation_reader.py"
py_compile.compile(
    str(shadow3),
    cfile=r"C:/Users/yauki/Documents/Codex/2026-06-12/files-mentioned-by-the-user-society/work/shadow3_ambient_place_details.pyc",
    doraise=True,
)
py_compile.compile(
    str(reader),
    cfile=r"C:/Users/yauki/Documents/Codex/2026-06-12/files-mentioned-by-the-user-society/work/life_observation_reader_ambient_place.pyc",
    doraise=True,
)

sys.path.insert(0, str(sl3))
from society_lab_v1_4_1 import SocietyLab  # noqa: E402
from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab  # noqa: E402


class NoAmbientPlaceDetailsLab(LifeObservedSocietyLab):
    def _observe_ambient_place_details(self, *args, **kwargs) -> None:
        return None


def conv(value):
    if dataclasses.is_dataclass(value):
        return {key: conv(item) for key, item in dataclasses.asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): conv(item) for key, item in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple)):
        return [conv(item) for item in value]
    if isinstance(value, set):
        return sorted(conv(item) for item in value)
    return value


def normalized(value):
    return json.loads(json.dumps(value, sort_keys=True, default=str))


def world_snapshot(sim):
    keys = [
        "year",
        "last_detection",
        "current_problems",
        "current_proposals",
        "proposal_support_by_person",
        "project_success_by_person",
        "project_failure_by_person",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
        "ritual_success_count",
        "next_memory_index",
        "actor_biography",
        "memory_lineage_trace",
        "support_chain_trace",
        "project_aftermath_trace",
        "age_profile",
        "charisma_profile",
        "people",
        "next_person_index",
        "food",
        "initial_population",
        "initial_food_stock",
        "initial_food_capacity",
    ]
    snapshot = {key: conv(getattr(sim, key)) for key in keys}
    snapshot["log_entries"] = conv(sim.log.entries)
    snapshot["summary"] = conv(sim.summary())
    return normalized(snapshot)


def run(cls, seed):
    sim = cls(seed=seed, verbose=False)
    sim.run(80)
    return sim


def filtered_events(sim, event_types):
    allowed = set(event_types)
    return [
        conv(observation)
        for observation in sim.life_observations
        if observation.event_type in allowed
    ]


stable_events = [
    "weather",
    "season",
    "ambient_object",
    "ambient_scent",
    "ambient_sound",
    "crowd_mood",
    "place_presence",
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "time_shadow",
]

new_keys = [
    "ambient_place_object_count",
    "ambient_place_scent_count",
    "ambient_place_sound_count",
    "ambient_place_scene_count",
    "life_observation_count",
]

pollution = []
stable_diffs = []
rows = []
focus = {}

for seed in range(1000, 1100):
    base = run(SocietyLab, seed)
    life = run(LifeObservedSocietyLab, seed)
    no_details = run(NoAmbientPlaceDetailsLab, seed)

    if world_snapshot(base) != world_snapshot(life):
        pollution.append(seed)
    if filtered_events(life, stable_events) != filtered_events(no_details, stable_events):
        stable_diffs.append(seed)

    summary = life.life_summary()
    rows.append({key: summary[key] for key in new_keys})
    if seed in {1003, 1061}:
        focus[seed] = {key: summary[key] for key in new_keys}

print("compiled ok")
print("world_snapshot_diffs", len(pollution), pollution[:20])
print("stable_event_diffs_without_ambient_place_details", len(stable_diffs), stable_diffs[:20])
for key in new_keys:
    values = [row[key] for row in rows]
    print(
        key,
        "min",
        min(values),
        "max",
        max(values),
        "avg",
        round(statistics.mean(values), 2),
        "nonzero",
        sum(value > 0 for value in values),
    )
for seed in [1003, 1061]:
    print("seed", seed, focus[seed])

out = Path(r"C:/Users/yauki/Documents/Codex/2026-06-12/files-mentioned-by-the-user-society/outputs/life_observation_reader_seed1003_1061_ambient_places.txt")
env = os.environ.copy()
env["PYTHONIOENCODING"] = "utf-8"
result = subprocess.run(
    [sys.executable, "life_observation_reader.py", "1003", "1061", "--contact-limit", "8"],
    cwd=str(sl3),
    text=True,
    encoding="utf-8",
    errors="backslashreplace",
    capture_output=True,
    timeout=120,
    env=env,
)
out.write_text(result.stdout + ("\nSTDERR:\n" + result.stderr if result.stderr else ""), encoding="utf-8")
print("reader_output", out)
