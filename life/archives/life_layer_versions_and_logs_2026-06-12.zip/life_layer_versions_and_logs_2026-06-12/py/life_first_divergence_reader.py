"""
Read first divergence between fixed shadow3 and trust-nudge experiment D.

This reader compares the observation-only shadow3 build against the isolated
trust-nudge experiment year by year. It assumes shadow3 is fixed and treats
trust nudge as an intentional body intervention.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, is_dataclass
import json
import re
import sys
from typing import Any

from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab
from society_lab_v1_4_life_bridge_trust_nudge_experiment import (
    LifeBridgeTrustNudgeExperiment,
)


sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")


SUMMARY_KEYS = (
    "final_population",
    "death_count",
    "birth_count",
    "project_success_count",
    "project_failure_count",
    "proposal_count",
    "memory_shared_count",
    "support_chain_trace_count",
    "project_aftermath_trace_count",
    "network_split_count",
    "shared_narrative_count",
    "authority_pattern_count",
)


WATCH_CATEGORIES = (
    "trust",
    "summary",
    "main_log",
    "memory_lineage_trace",
    "support_chain_trace",
    "project_aftermath_trace",
    "food",
    "people_without_trust",
)


def parse_fields(detail: str) -> dict[str, str]:
    return {key: value.strip() for key, value in re.findall(r"([A-Za-z_]+)=([^;]+)", detail)}


def clean(value: Any) -> Any:
    return json.loads(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str))


def dataclass_clean(value: Any) -> Any:
    if is_dataclass(value):
        return clean(asdict(value))
    return clean(value)


def person_without_trust(person) -> dict[str, Any]:
    data = asdict(person)
    data.pop("trust", None)
    return clean(data)


def people_without_trust(sim) -> list[dict[str, Any]]:
    return [person_without_trust(person) for person in sim.people]


def trust_snapshot(sim) -> dict[str, float]:
    values: dict[str, float] = {}
    for person in sim.people:
        for other_id, trust in person.trust.items():
            values[f"{person.id}->{other_id}"] = round(float(trust), 6)
    return dict(sorted(values.items()))


def food_snapshot(sim) -> dict[str, float]:
    return {
        "stock": round(float(sim.food.stock), 6),
        "capacity": round(float(sim.food.capacity), 6),
    }


def log_snapshot(sim) -> list[dict[str, Any]]:
    return [dataclass_clean(entry) for entry in sim.log.entries]


def summary_snapshot(sim) -> dict[str, Any]:
    summary = sim.summary()
    return {key: summary.get(key) for key in SUMMARY_KEYS}


def category_snapshot(sim, category: str) -> Any:
    if category == "trust":
        return trust_snapshot(sim)
    if category == "summary":
        return summary_snapshot(sim)
    if category == "main_log":
        return log_snapshot(sim)
    if category == "memory_lineage_trace":
        return clean(sim.memory_lineage_trace)
    if category == "support_chain_trace":
        return clean(sim.support_chain_trace)
    if category == "project_aftermath_trace":
        return clean(sim.project_aftermath_trace)
    if category == "food":
        return food_snapshot(sim)
    if category == "people_without_trust":
        return people_without_trust(sim)
    raise KeyError(category)


def dict_diff(left: dict[str, Any], right: dict[str, Any]) -> dict[str, dict[str, Any]]:
    keys = sorted(set(left) | set(right))
    return {
        key: {"shadow3": left.get(key), "experiment": right.get(key)}
        for key in keys
        if left.get(key) != right.get(key)
    }


def sequence_first_diff(left: list[Any], right: list[Any]) -> dict[str, Any]:
    limit = min(len(left), len(right))
    for index in range(limit):
        if left[index] != right[index]:
            return {
                "index": index,
                "shadow3": left[index],
                "experiment": right[index],
                "shadow3_len": len(left),
                "experiment_len": len(right),
            }
    if len(left) != len(right):
        return {
            "index": limit,
            "shadow3": left[limit] if limit < len(left) else None,
            "experiment": right[limit] if limit < len(right) else None,
            "shadow3_len": len(left),
            "experiment_len": len(right),
        }
    return {}


def person_brief_diff(left: dict[str, Any] | None, right: dict[str, Any] | None) -> dict[str, Any]:
    if left is None or right is None:
        return {"shadow3": left, "experiment": right}
    keys = sorted((set(left) | set(right)) - {"memories"})
    changed = {
        key: {"shadow3": left.get(key), "experiment": right.get(key)}
        for key in keys
        if left.get(key) != right.get(key)
    }
    left_memories = left.get("memories", [])
    right_memories = right.get("memories", [])
    memory_note: dict[str, Any] = {
        "shadow3_count": len(left_memories),
        "experiment_count": len(right_memories),
    }
    limit = min(len(left_memories), len(right_memories))
    first_memory_index = None
    for index in range(limit):
        if left_memories[index] != right_memories[index]:
            first_memory_index = index
            break
    if first_memory_index is None and len(left_memories) != len(right_memories):
        first_memory_index = limit
    if first_memory_index is not None:
        memory_note["first_diff_index"] = first_memory_index
        memory_note["shadow3"] = (
            left_memories[first_memory_index]
            if first_memory_index < len(left_memories)
            else None
        )
        memory_note["experiment"] = (
            right_memories[first_memory_index]
            if first_memory_index < len(right_memories)
            else None
        )
    return {
        "id": left.get("id") or right.get("id"),
        "changed_fields": changed,
        "memories": memory_note,
    }


def people_first_diff(left: list[Any], right: list[Any]) -> dict[str, Any]:
    by_left = {person.get("id"): person for person in left}
    by_right = {person.get("id"): person for person in right}
    for person_id in sorted(set(by_left) | set(by_right)):
        if by_left.get(person_id) != by_right.get(person_id):
            return {
                "person_id": person_id,
                "shadow3_len": len(left),
                "experiment_len": len(right),
                "brief": person_brief_diff(by_left.get(person_id), by_right.get(person_id)),
            }
    return {}


def summarize_diff(category: str, left: Any, right: Any) -> dict[str, Any]:
    if isinstance(left, dict) and isinstance(right, dict):
        diff = dict_diff(left, right)
        return {"type": "dict", "diff": diff}
    if category == "people_without_trust" and isinstance(left, list) and isinstance(right, list):
        return {"type": "people", "diff": people_first_diff(left, right)}
    if isinstance(left, list) and isinstance(right, list):
        return {"type": "sequence", "diff": sequence_first_diff(left, right)}
    return {"type": "value", "diff": {"shadow3": left, "experiment": right}}


def new_rows(rows: list, start: int, event_type: str | None = None) -> list:
    selected = rows[start:]
    if event_type is not None:
        selected = [row for row in selected if row.event_type == event_type]
    return selected


def format_life_row(row) -> str:
    people = ",".join(row.persons) if row.persons else "-"
    return f"Y{row.year:02d} {row.event_type:<22} {people:<13} {row.detail}"


def run_seed(seed: int, years: int) -> dict[str, Any]:
    shadow = LifeObservedSocietyLab(seed=seed, verbose=False)
    experiment = LifeBridgeTrustNudgeExperiment(seed=seed, verbose=False)

    firsts: dict[str, dict[str, Any]] = {}
    nudge_rows = []
    yearly_notes = []
    prev_shadow_life_len = 0
    prev_experiment_life_len = 0

    for _ in range(years):
        if shadow.population == 0 or experiment.population == 0:
            break
        shadow.step()
        experiment.step()

        new_nudges = new_rows(
            experiment.life_observations,
            prev_experiment_life_len,
            "life_trust_nudge",
        )
        for row in new_nudges:
            nudge_rows.append(row)
            yearly_notes.append(
                {
                    "year": row.year,
                    "event": "life_trust_nudge",
                    "row": row,
                    "fields": parse_fields(row.detail),
                }
            )

        for category in WATCH_CATEGORIES:
            if category in firsts:
                continue
            shadow_value = category_snapshot(shadow, category)
            experiment_value = category_snapshot(experiment, category)
            if shadow_value != experiment_value:
                firsts[category] = {
                    "year": shadow.year,
                    "category": category,
                    "summary": summarize_diff(category, shadow_value, experiment_value),
                }

        prev_shadow_life_len = len(shadow.life_observations)
        prev_experiment_life_len = len(experiment.life_observations)

    final_diff = {
        "summary": summarize_diff("summary", shadow.summary(), experiment.summary()),
        "trust": summarize_diff("trust", trust_snapshot(shadow), trust_snapshot(experiment)),
    }
    return {
        "seed": seed,
        "years_run": shadow.year,
        "nudge_rows": nudge_rows,
        "firsts": firsts,
        "final_diff": final_diff,
        "shadow": shadow,
        "experiment": experiment,
    }


def print_first(category: str, firsts: dict[str, dict[str, Any]]) -> None:
    first = firsts.get(category)
    if not first:
        print(f"  {category}: no divergence")
        return
    print(f"  {category}: Y{first['year']:02d}")
    diff = first["summary"]["diff"]
    if isinstance(diff, dict) and diff:
        if first["summary"]["type"] == "dict":
            for key, value in list(diff.items())[:8]:
                print(f"    {key}: {value['shadow3']} -> {value['experiment']}")
        elif first["summary"]["type"] == "sequence":
            print(f"    index={diff.get('index')} len={diff.get('shadow3_len')}->{diff.get('experiment_len')}")
            shadow_value = diff.get("shadow3")
            experiment_value = diff.get("experiment")
            print(f"    shadow3={shadow_value}")
            print(f"    experiment={experiment_value}")
        elif first["summary"]["type"] == "people":
            print(f"    person_id={diff.get('person_id')} len={diff.get('shadow3_len')}->{diff.get('experiment_len')}")
            brief = diff.get("brief", {})
            changed_fields = brief.get("changed_fields", {})
            for key, value in list(changed_fields.items())[:8]:
                print(f"    {key}: {value['shadow3']} -> {value['experiment']}")
            memories = brief.get("memories", {})
            print(
                "    memories: "
                f"{memories.get('shadow3_count')} -> {memories.get('experiment_count')}, "
                f"first_diff_index={memories.get('first_diff_index')}"
            )
            if "shadow3" in memories or "experiment" in memories:
                print(f"    memory_shadow3={memories.get('shadow3')}")
                print(f"    memory_experiment={memories.get('experiment')}")
        else:
            print(f"    {diff}")


def print_seed_report(seed: int, years: int) -> None:
    result = run_seed(seed, years)
    experiment = result["experiment"]
    shadow = result["shadow"]
    print(f"\n=== seed {seed} / first divergence reader ===")
    print(f"Years run: {result['years_run']}")
    print(f"Shadow3 summary: {shadow.summary()}")
    print(f"Experiment summary: {experiment.summary()}")

    print("\nNudges")
    if not result["nudge_rows"]:
        print("  life_trust_nudge: none")
    else:
        for row in result["nudge_rows"]:
            print("  " + format_life_row(row))

    print("\nFirst divergences")
    for category in WATCH_CATEGORIES:
        print_first(category, result["firsts"])

    print("\nNudge paths")
    if not result["nudge_rows"]:
        print("  no nudge paths")
    for nudge in result["nudge_rows"]:
        pair = tuple(sorted(nudge.persons))
        fields = parse_fields(nudge.detail)
        place = fields.get("place", "unknown")
        print(f"  pair={pair[0]}|{pair[1]} place={place} nudge_year={nudge.year}")
        path_rows = [
            row
            for row in experiment.life_observations
            if tuple(sorted(row.persons)) == pair
            and row.year <= nudge.year
            and (
                row.event_type
                in {
                    "same_place_nearby",
                    "life_contact",
                    "passing_greeting",
                    "distant_social",
                    "conversation_shadow",
                    "familiarity_shadow",
                    "memory_shadow",
                    "life_bridge_potential",
                    "life_trust_nudge",
                }
            )
        ]
        for row in path_rows:
            print("    " + format_life_row(row))

    print("\nFinal watched summary diffs")
    summary_diff = result["final_diff"]["summary"]["diff"]
    if not summary_diff:
        print("  summary: none")
    else:
        for key, value in summary_diff.items():
            print(f"  {key}: {value['shadow3']} -> {value['experiment']}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read first divergence between fixed shadow3 and trust-nudge experiment D."
    )
    parser.add_argument("seeds", nargs="*", type=int, default=[1061, 1042, 1096])
    parser.add_argument("--years", type=int, default=80)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    for seed in args.seeds:
        print_seed_report(seed, args.years)


if __name__ == "__main__":
    main()
