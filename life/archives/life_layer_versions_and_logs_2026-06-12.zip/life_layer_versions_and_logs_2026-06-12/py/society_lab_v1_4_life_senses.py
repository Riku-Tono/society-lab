"""
society_lab v1.4_life
=====================

Observation-only life layer for society_lab v1.4_1.

This file must live next to society_lab_v1_4_1.py, or the directory containing
society_lab_v1_4_1.py must be on PYTHONPATH.

Design rule:
Do not change world dynamics. Tea-house observations use a separate deterministic
RNG stream and write only to life_observations. They do not affect food, health,
trust, memory, support, births, deaths, proposals, project outcomes, or the main
ObservationLog.
"""

from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass
from typing import Optional

from society_lab_v1_4_1 import SocietyLab


TEAS = (
    "sencha",
    "hojicha",
    "genmaicha",
    "black_tea",
    "barley_tea",
)

TEA_VESSELS = (
    "yunomi",
    "small_cup",
    "wooden_bowl",
)

VESSEL_CONDITIONS = (
    "plain",
    "plain",
    "plain",
    "plain",
    "chipped",
)

TEA_HOUSE_MOODS = (
    "quiet",
    "rainy",
    "windy",
    "warm",
)

# 世界側の空気。人物状態に依存しない。
WEATHER = (
    "clear",
    "overcast",
    "rain_on_roof",
    "dry_wind",
    "heavy_rain",
    "light_mist",
)

TIME_OF_DAY = (
    "cold_morning",
    "midday",
    "late_afternoon",
    "evening_steam",
)

FIRE_DETAIL = (
    "fire_going",
    "embers_only",
    "no_fire",
    "smoke_lingering",
)

# Object traces. No person, no intent, no causation.
OBJECT_TRACES = (
    "worn_threshold",
    "patched_roof",
    "stacked_firewood",
    "forgotten_cup",
    "muddy_footprints",
    "mended_basket",
    "cracked_vessel",
    "ash_pile",
)

TRACE_PLACES = (
    "tea_house",
    "storehouse",
    "well",
    "gate",
    "hearth",
    "path",
)

LIFE_PLACES = (
    "tea_house",
    "well",
    "storehouse",
    "hearth",
    "gate",
    "path",
)

AFFECT_OBJECTS = (
    "chipped_cup",
    "damp_sleeve",
    "warm_bowl",
    "old_cloth",
    "small_blanket",
    "cracked_ladle",
    "shared_umbrella",
    "burnt_rice_smell",
    "childs_wooden_spoon",
    "mended_sandal",
)

SCENTS_BY_PLACE = {
    "tea_house": (
        "boiled_barley",
        "smoke_in_cloth",
        "old_wood",
        "steam_from_cups",
    ),
    "well": (
        "wet_soil",
        "cold_stone",
        "rain_on_dust",
    ),
    "storehouse": (
        "old_straw",
        "dry_grain",
        "dust_in_sacks",
        "mended_rope",
    ),
    "hearth": (
        "ash_after_rain",
        "smoke_in_cloth",
        "burnt_rice_smell",
        "old_wood",
    ),
    "gate": (
        "wind_from_fields",
        "dry_grass",
        "rain_on_dust",
    ),
    "path": (
        "wet_soil",
        "dry_grass",
        "damp_straw",
        "wind_from_fields",
    ),
}

TOUCHES_BY_PLACE = {
    "tea_house": (
        "warm_bowl_in_hands",
        "rough_wood_against_palm",
        "straw_mat_under_knees",
        "steam_on_face",
    ),
    "well": (
        "cold_rope_in_hands",
        "wet_stone_under_fingers",
        "cold_mud_underfoot",
    ),
    "storehouse": (
        "rough_sackcloth",
        "small_splinter_in_palm",
        "dust_on_fingers",
    ),
    "hearth": (
        "warm_bowl_in_hands",
        "steam_on_face",
        "ash_on_sleeve",
        "straw_mat_under_knees",
    ),
    "gate": (
        "wind_on_neck",
        "rough_wood_against_palm",
        "small_stone_in_sandal",
    ),
    "path": (
        "cold_mud_underfoot",
        "wind_on_neck",
        "small_stone_in_sandal",
        "damp_sleeve_on_skin",
    ),
}

ANIMAL_PRESENCES = (
    "cat_near_doorway",
    "dog_sleeping_far_off",
    "birds_under_eaves",
    "cat_brushing_ankle",
)

# Sounds. No source, no person, no direction given.
SOUNDS = (
    "wind_through_thatch",
    "distant_rain",
    "someone_grinding",
    "fire_crackling",
    "distant_axe",
    "wind_through_grass",
    "child_somewhere",
    "birds_before_rain",
    "dog_far_off",
    "rain_on_thatch",
    "silence",
    "water_moving",
    "wood_settling",
    "wood_splitting",
    "something_dropped",
    "footsteps_leaving",
    "nothing",
    "nothing",
    "nothing",
)


@dataclass(frozen=True)
class LifeObservation:
    year: int
    event_type: str
    persons: list[str]
    detail: str


class LifeObservedSocietyLab(SocietyLab):
    """v1.4_1 with zero-effect life observations.

    The base simulation is advanced first. After that, a separate per-year life
    RNG may record tea-house details. The base class never reads these records.
    """

    def __init__(
        self,
        seed: Optional[int] = None,
        verbose: bool = False,
        life_verbose: bool = False,
    ):
        super().__init__(seed=seed, verbose=verbose)
        self.life_verbose = life_verbose
        self.life_observations: list[LifeObservation] = []
        self.life_place_visits: dict[str, dict[str, int]] = {}

    def step(self) -> None:
        super().step()
        self._observe_life()

    def _life_rng(self) -> random.Random:
        material = f"{self.seed}|{self.year}|life_observation".encode()
        digest = hashlib.sha256(material).hexdigest()
        return random.Random(int(digest[:16], 16))

    def _year_weather(self, rng: random.Random) -> str:
        """その年の空気。人物状態に依存しない。"""
        return rng.choice(WEATHER)

    def _observe_life(self) -> None:
        if self.population == 0:
            return

        rng = self._life_rng()

        # 世界側の空気をまず記録する（茶屋と独立）
        weather = self._year_weather(rng)
        time_of_day = rng.choice(TIME_OF_DAY)
        fire = rng.choice(FIRE_DETAIL)
        sound = rng.choice(SOUNDS)
        self._record_life(
            "weather",
            [],
            f"weather={weather}; time={time_of_day}; fire={fire}; sound={sound}",
        )

        # Sound: sourceless, ~55% of years. "nothing" weighted higher in SOUNDS.
        sound = rng.choice(SOUNDS)
        if sound != "nothing":
            self._record_life(
                "sound",
                [],
                f"sound={sound}; weather={weather}",
            )

        # Object trace: independent of persons, appears ~40% of years
        if rng.random() < 0.40:
            trace = rng.choice(OBJECT_TRACES)
            place = rng.choice(TRACE_PLACES)
            self._record_life(
                "trace",
                [],
                f"place={place}; trace={trace}; weather={weather}",
            )

        if rng.random() < 0.35:
            place = self._choose_world_sense_place(weather, rng)
            scent = rng.choice(SCENTS_BY_PLACE[place])
            self._record_life(
                "scent",
                [],
                f"scent={scent}; place={place}; weather={weather}",
            )

        self._observe_people_in_places(rng, weather)

    def _observe_people_in_places(self, rng: random.Random, weather: str) -> None:
        visitors = [
            person
            for person in self.alive_people
            if rng.random() < self._place_observation_chance(person, weather)
        ]
        if not visitors:
            if rng.random() >= 0.22:
                return
            visitors = [rng.choice(self.alive_people)]

        rng.shuffle(visitors)
        for person in visitors[:6]:
            place = self._choose_life_place(person, weather, rng)
            self._record_place_presence(person, place, weather)
            self._observe_sense_detail(person, place, weather, rng)
            if place == "tea_house":
                self._observe_tea_house_visit(person, weather, rng)
            elif place == "hearth":
                self._observe_hearth(person, weather, rng)
            elif place == "well":
                self._observe_well(person, weather, rng)
            elif place == "storehouse":
                self._observe_storehouse(person, weather, rng)

    def _place_observation_chance(self, person, weather: str) -> float:
        chance = 0.045
        if person.age < 12 or person.age >= 65:
            chance += 0.018
        if person.hunger > 0.65:
            chance += 0.020
        if person.fear > 0.55:
            chance -= 0.018
        if self._is_rainy(weather):
            chance += 0.018
        return self._clamp(chance)

    def _choose_life_place(self, person, weather: str, rng: random.Random) -> str:
        weights = {
            "tea_house": 1.00,
            "well": 0.90,
            "storehouse": 0.75,
            "hearth": 0.70,
            "gate": 0.55,
            "path": 0.80,
        }

        if person.age < 12:
            weights["tea_house"] += 0.30
            weights["hearth"] += 0.35
            weights["gate"] -= 0.15
        elif person.age >= 65:
            weights["tea_house"] += 0.35
            weights["hearth"] += 0.45
            weights["path"] -= 0.20

        if person.hunger > 0.65:
            weights["storehouse"] += 0.55
            weights["well"] += 0.30
            weights["tea_house"] -= 0.25

        if person.fear > 0.55:
            weights["tea_house"] -= 0.35
            weights["gate"] -= 0.25
            weights["path"] += 0.25
            weights["well"] += 0.20

        if self._is_rainy(weather):
            weights["tea_house"] += 0.35
            weights["hearth"] += 0.30
            weights["storehouse"] += 0.20
            weights["gate"] -= 0.20
            weights["path"] -= 0.25

        places = list(weights)
        normalized = [max(0.05, weights[place]) for place in places]
        return rng.choices(places, weights=normalized, k=1)[0]

    def _choose_world_sense_place(self, weather: str, rng: random.Random) -> str:
        weights = {
            "tea_house": 1.0,
            "well": 0.8,
            "storehouse": 0.7,
            "hearth": 0.8,
            "gate": 0.6,
            "path": 0.8,
        }
        if self._is_rainy(weather):
            weights["tea_house"] += 0.25
            weights["hearth"] += 0.20
            weights["path"] += 0.15
            weights["gate"] -= 0.15
        places = list(weights)
        normalized = [max(0.05, weights[place]) for place in places]
        return rng.choices(places, weights=normalized, k=1)[0]

    def _record_place_presence(self, person, place: str, weather: str) -> None:
        visits = self.life_place_visits.setdefault(person.id, {})
        visits[place] = visits.get(place, 0) + 1
        self._record_life(
            "place_presence",
            [person.id],
            (
                f"{person.name} appeared at {place}; weather={weather}; "
                f"age={person.age}; hunger={person.hunger:.2f}; fear={person.fear:.2f}"
            ),
        )
        if visits[place] in {2, 4, 7}:
            self._record_life(
                "repeat_place",
                [person.id],
                f"{person.name} appeared at {place} again; count={visits[place]}",
            )

    def _observe_sense_detail(self, person, place: str, weather: str, rng: random.Random) -> None:
        if rng.random() < 0.34:
            scent = rng.choice(SCENTS_BY_PLACE[place])
            self._record_life(
                "scent",
                [person.id],
                f"{person.name}; scent={scent}; place={place}; weather={weather}",
            )
        if rng.random() < 0.30:
            touch = rng.choice(TOUCHES_BY_PLACE[place])
            self._record_life(
                "touch",
                [person.id],
                f"{person.name}; touch={touch}; place={place}; weather={weather}",
            )
        if rng.random() < 0.20:
            obj = rng.choice(AFFECT_OBJECTS)
            self._record_life(
                "affect_object",
                [person.id],
                f"{person.name}; object={obj}; place={place}; weather={weather}",
            )
        if rng.random() < 0.10:
            animal = rng.choice(ANIMAL_PRESENCES)
            self._record_life(
                "animal_presence",
                [person.id],
                f"{person.name}; animal={animal}; place={place}; weather={weather}",
            )

    def _observe_tea_house_visit(self, person, weather: str, rng: random.Random) -> None:
        if rng.random() < 0.72:
            tea = rng.choice(TEAS)
            vessel = rng.choice(TEA_VESSELS)
            condition = rng.choice(VESSEL_CONDITIONS)
            mood = rng.choice(TEA_HOUSE_MOODS)
            self._record_life(
                "tea_house",
                [person.id],
                (
                    f"{person.name} drank {tea} from {vessel}; "
                    f"vessel={condition}; room={mood}; weather={weather}"
                ),
            )
        if self._is_rainy(weather):
            self._record_life(
                "rainy_tea_house",
                [person.id],
                f"{person.name} stopped by the tea house on a rainy day; weather={weather}",
            )
        if person.age < 12 and rng.random() < 0.34:
            self._record_life(
                "child_bowl",
                [person.id],
                f"{person.name} held a tea bowl near the doorway; weather={weather}",
            )
        if person.age >= 65 and rng.random() < 0.42:
            self._record_life(
                "elder_sitting",
                [person.id],
                f"{person.name} sat quietly in the tea house; weather={weather}",
            )

    def _observe_hearth(self, person, weather: str, rng: random.Random) -> None:
        if rng.random() < 0.70:
            self._record_life(
                "brazier_presence",
                [person.id],
                f"{person.name} stayed near the brazier; weather={weather}",
            )
        if person.age >= 65 and rng.random() < 0.35:
            self._record_life(
                "elder_sitting",
                [person.id],
                f"{person.name} sat by the hearth; weather={weather}",
            )

    def _observe_well(self, person, weather: str, rng: random.Random) -> None:
        if rng.random() < 0.62:
            self._record_life(
                "well_water",
                [person.id],
                f"{person.name} drew water at the well; weather={weather}",
            )

    def _observe_storehouse(self, person, weather: str, rng: random.Random) -> None:
        if rng.random() < 0.58:
            self._record_life(
                "storehouse_bag",
                [person.id],
                f"{person.name} mended a sack near the storehouse; weather={weather}",
            )

    def _is_rainy(self, weather: str) -> bool:
        return weather in {"rain_on_roof", "heavy_rain", "light_mist"}

    def _record_life(self, event_type: str, persons: list[str], detail: str) -> None:
        observation = LifeObservation(self.year, event_type, persons, detail)
        self.life_observations.append(observation)
        if self.life_verbose:
            person_text = ", ".join(persons) if persons else "-"
            print(f"[Year {self.year:>3}] life:{event_type}: {person_text} | {detail}")

    def life_summary(self) -> dict[str, object]:
        tea_counts = {tea: 0 for tea in TEAS}
        weather_counts = {w: 0 for w in WEATHER}
        for observation in self.life_observations:
            for tea in TEAS:
                if f"drank {tea} " in observation.detail:
                    tea_counts[tea] += 1
            if observation.event_type == "weather":
                for w in WEATHER:
                    if f"weather={w}" in observation.detail:
                        weather_counts[w] += 1
        return {
            "life_observation_count": len(self.life_observations),
            "tea_house_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "tea_house"
            ),
            "weather_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "weather"
            ),
            "tea_counts": tea_counts,
            "weather_counts": weather_counts,
            "trace_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "trace"
            ),
            "sound_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "sound"
            ),
            "place_presence_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "place_presence"
            ),
            "repeat_place_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "repeat_place"
            ),
            "rainy_tea_house_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "rainy_tea_house"
            ),
            "brazier_presence_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "brazier_presence"
            ),
            "well_water_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "well_water"
            ),
            "storehouse_bag_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "storehouse_bag"
            ),
            "child_bowl_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "child_bowl"
            ),
            "elder_sitting_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "elder_sitting"
            ),
            "scent_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "scent"
            ),
            "touch_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "touch"
            ),
            "affect_object_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "affect_object"
            ),
            "animal_presence_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "animal_presence"
            ),
        }


def main() -> None:
    sim = LifeObservedSocietyLab(seed=42, verbose=False, life_verbose=True)
    sim.run(years=80)
    print("\nSummary")
    for key, value in sim.summary().items():
        print(f"{key}: {value}")
    print("\nLife Summary")
    for key, value in sim.life_summary().items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()
