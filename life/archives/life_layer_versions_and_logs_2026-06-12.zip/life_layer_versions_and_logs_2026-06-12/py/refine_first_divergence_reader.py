from __future__ import annotations

import os
from pathlib import Path


def find_reader() -> Path:
    home = Path.home()
    for root, _dirs, files in os.walk(home / "OneDrive"):
        if "life_first_divergence_reader.py" in files:
            return Path(root) / "life_first_divergence_reader.py"
    raise FileNotFoundError("life_first_divergence_reader.py not found")


path = find_reader()
text = path.read_text(encoding="utf-8")

text = text.replace(
    '''def category_snapshot(sim, category: str) -> Any:
    if category == "trust":
        return trust_snapshot(sim)
    if category == "summary":
        return clean(sim.summary())
''',
    '''def summary_snapshot(sim) -> dict[str, Any]:
    summary = sim.summary()
    return {key: summary.get(key) for key in SUMMARY_KEYS}


def category_snapshot(sim, category: str) -> Any:
    if category == "trust":
        return trust_snapshot(sim)
    if category == "summary":
        return summary_snapshot(sim)
''',
)

insert_after = '''def sequence_first_diff(left: list[Any], right: list[Any]) -> dict[str, Any]:
    limit = min(len(left), len(right))
    for index in range(limit):
        if left[index] != right[index]:
            return {
                "index": index,
                "shadow3": left[index],
                "experiment": right[index],
                "shadow3_len": len(left),
                "experiment_len": len(right),
            }
    if len(left) != len(right):
        return {
            "index": limit,
            "shadow3": left[limit] if limit < len(left) else None,
            "experiment": right[limit] if limit < len(right) else None,
            "shadow3_len": len(left),
            "experiment_len": len(right),
        }
    return {}

'''

replacement = insert_after + r'''
def person_brief_diff(left: dict[str, Any] | None, right: dict[str, Any] | None) -> dict[str, Any]:
    if left is None or right is None:
        return {"shadow3": left, "experiment": right}
    keys = sorted((set(left) | set(right)) - {"memories"})
    changed = {
        key: {"shadow3": left.get(key), "experiment": right.get(key)}
        for key in keys
        if left.get(key) != right.get(key)
    }
    left_memories = left.get("memories", [])
    right_memories = right.get("memories", [])
    memory_note: dict[str, Any] = {
        "shadow3_count": len(left_memories),
        "experiment_count": len(right_memories),
    }
    limit = min(len(left_memories), len(right_memories))
    first_memory_index = None
    for index in range(limit):
        if left_memories[index] != right_memories[index]:
            first_memory_index = index
            break
    if first_memory_index is None and len(left_memories) != len(right_memories):
        first_memory_index = limit
    if first_memory_index is not None:
        memory_note["first_diff_index"] = first_memory_index
        memory_note["shadow3"] = (
            left_memories[first_memory_index]
            if first_memory_index < len(left_memories)
            else None
        )
        memory_note["experiment"] = (
            right_memories[first_memory_index]
            if first_memory_index < len(right_memories)
            else None
        )
    return {
        "id": left.get("id") or right.get("id"),
        "changed_fields": changed,
        "memories": memory_note,
    }


def people_first_diff(left: list[Any], right: list[Any]) -> dict[str, Any]:
    by_left = {person.get("id"): person for person in left}
    by_right = {person.get("id"): person for person in right}
    for person_id in sorted(set(by_left) | set(by_right)):
        if by_left.get(person_id) != by_right.get(person_id):
            return {
                "person_id": person_id,
                "shadow3_len": len(left),
                "experiment_len": len(right),
                "brief": person_brief_diff(by_left.get(person_id), by_right.get(person_id)),
            }
    return {}

'''

text = text.replace(insert_after, replacement)

text = text.replace(
    '''def summarize_diff(category: str, left: Any, right: Any) -> dict[str, Any]:
    if isinstance(left, dict) and isinstance(right, dict):
        diff = dict_diff(left, right)
        if category == "summary":
            diff = {key: value for key, value in diff.items() if key in SUMMARY_KEYS}
        return {"type": "dict", "diff": diff}
    if isinstance(left, list) and isinstance(right, list):
        return {"type": "sequence", "diff": sequence_first_diff(left, right)}
''',
    '''def summarize_diff(category: str, left: Any, right: Any) -> dict[str, Any]:
    if isinstance(left, dict) and isinstance(right, dict):
        diff = dict_diff(left, right)
        return {"type": "dict", "diff": diff}
    if category == "people_without_trust" and isinstance(left, list) and isinstance(right, list):
        return {"type": "people", "diff": people_first_diff(left, right)}
    if isinstance(left, list) and isinstance(right, list):
        return {"type": "sequence", "diff": sequence_first_diff(left, right)}
''',
)

text = text.replace(
    '''        elif first["summary"]["type"] == "sequence":
            print(f"    index={diff.get('index')} len={diff.get('shadow3_len')}->{diff.get('experiment_len')}")
            shadow_value = diff.get("shadow3")
            experiment_value = diff.get("experiment")
            print(f"    shadow3={shadow_value}")
            print(f"    experiment={experiment_value}")
        else:
            print(f"    {diff}")
''',
    '''        elif first["summary"]["type"] == "sequence":
            print(f"    index={diff.get('index')} len={diff.get('shadow3_len')}->{diff.get('experiment_len')}")
            shadow_value = diff.get("shadow3")
            experiment_value = diff.get("experiment")
            print(f"    shadow3={shadow_value}")
            print(f"    experiment={experiment_value}")
        elif first["summary"]["type"] == "people":
            print(f"    person_id={diff.get('person_id')} len={diff.get('shadow3_len')}->{diff.get('experiment_len')}")
            brief = diff.get("brief", {})
            changed_fields = brief.get("changed_fields", {})
            for key, value in list(changed_fields.items())[:8]:
                print(f"    {key}: {value['shadow3']} -> {value['experiment']}")
            memories = brief.get("memories", {})
            print(
                "    memories: "
                f"{memories.get('shadow3_count')} -> {memories.get('experiment_count')}, "
                f"first_diff_index={memories.get('first_diff_index')}"
            )
            if "shadow3" in memories or "experiment" in memories:
                print(f"    memory_shadow3={memories.get('shadow3')}")
                print(f"    memory_experiment={memories.get('experiment')}")
        else:
            print(f"    {diff}")
''',
)

path.write_text(text, encoding="utf-8", newline="\n")
print(path)
