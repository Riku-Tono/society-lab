from __future__ import annotations

from collections import Counter
from dataclasses import asdict, is_dataclass
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
from typing import Any


sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

ROOT = Path.cwd()
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def find_sl3() -> Path:
    home = Path.home()
    for root, _dirs, files in os.walk(home / "OneDrive"):
        if (
            "society_lab_v1_4_life_senses_memory_shadow3.py" in files
            and "society_lab_v1_4_life_bridge_trust_nudge_experiment.py" in files
        ):
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


SL3 = find_sl3()
SHADOW_PATH = SL3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
EXPERIMENT_PATH = SL3 / "society_lab_v1_4_life_bridge_trust_nudge_experiment.py"
if str(SL3) not in sys.path:
    sys.path.insert(0, str(SL3))


def import_from_path(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


shadow_mod = import_from_path("society_lab_shadow_pre_nudge", SHADOW_PATH)
experiment_mod = import_from_path("society_lab_experiment_pre_nudge", EXPERIMENT_PATH)

ShadowLab = shadow_mod.LifeObservedSocietyLab
ExperimentLab = experiment_mod.LifeBridgeTrustNudgeExperiment


def clean(value: Any) -> Any:
    return json.loads(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str))


def dataclass_clean(value: Any) -> Any:
    if is_dataclass(value):
        return clean(asdict(value))
    return clean(value)


def parse_fields(detail: str) -> dict[str, str]:
    return {key: value.strip() for key, value in re.findall(r"([A-Za-z_]+)=([^;]+)", detail)}


def person_without_trust(person) -> dict[str, Any]:
    data = asdict(person)
    data.pop("trust", None)
    return clean(data)


def trust_snapshot(sim) -> dict[str, float]:
    values: dict[str, float] = {}
    for person in sim.people:
        for other_id, trust in person.trust.items():
            values[f"{person.id}->{other_id}"] = round(float(trust), 8)
    return dict(sorted(values.items()))


def trust_diff(left, right) -> dict[str, dict[str, float | None]]:
    left_trust = trust_snapshot(left)
    right_trust = trust_snapshot(right)
    keys = sorted(set(left_trust) | set(right_trust))
    return {
        key: {"shadow3": left_trust.get(key), "experiment": right_trust.get(key)}
        for key in keys
        if left_trust.get(key) != right_trust.get(key)
    }


def body_snapshot(sim) -> dict[str, Any]:
    return {
        "year": sim.year,
        "summary": clean(sim.summary()),
        "people_without_trust": [person_without_trust(person) for person in sim.people],
        "food": {
            "stock": round(float(sim.food.stock), 8),
            "capacity": round(float(sim.food.capacity), 8),
        },
        "main_log": [dataclass_clean(entry) for entry in sim.log.entries],
        "memory_lineage_trace": clean(sim.memory_lineage_trace),
        "support_chain_trace": clean(sim.support_chain_trace),
        "project_aftermath_trace": clean(sim.project_aftermath_trace),
        "current_problems": [dataclass_clean(problem) for problem in sim.current_problems],
        "current_proposals": [dataclass_clean(proposal) for proposal in sim.current_proposals],
        "rng_state": repr(sim.rng.getstate()),
    }


def body_diff_categories(left, right) -> list[str]:
    left_body = body_snapshot(left)
    right_body = body_snapshot(right)
    return [key for key in left_body if left_body[key] != right_body[key]]


def first_sequence_diff(left: list[Any], right: list[Any]) -> dict[str, Any]:
    limit = min(len(left), len(right))
    for index in range(limit):
        if left[index] != right[index]:
            return {
                "index": index,
                "shadow3": left[index],
                "experiment": right[index],
                "shadow3_len": len(left),
                "experiment_len": len(right),
            }
    if len(left) != len(right):
        return {
            "index": limit,
            "shadow3": left[limit] if limit < len(left) else None,
            "experiment": right[limit] if limit < len(right) else None,
            "shadow3_len": len(left),
            "experiment_len": len(right),
        }
    return {}


def watched_summary(sim) -> dict[str, Any]:
    keys = (
        "final_population",
        "birth_count",
        "death_count",
        "proposal_count",
        "project_success_count",
        "project_failure_count",
        "memory_shared_count",
        "support_chain_trace_count",
        "project_aftermath_trace_count",
        "network_split_count",
        "shared_narrative_count",
        "narrative_divergence_count",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
    )
    summary = sim.summary()
    return {key: summary.get(key) for key in keys}


def dict_diff(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    return {
        key: {"shadow3": left.get(key), "experiment": right.get(key)}
        for key in sorted(set(left) | set(right))
        if left.get(key) != right.get(key)
    }


def new_life_rows(sim, start: int, event_type: str) -> list[Any]:
    return [row for row in sim.life_observations[start:] if row.event_type == event_type]


def format_life_row(row) -> str:
    people = ",".join(row.persons) if row.persons else "-"
    return f"Y{row.year:02d} {row.event_type:<22} {people:<13} {row.detail}"


def analyze_seed(seed: int, years: int) -> dict[str, Any]:
    shadow = ShadowLab(seed=seed, verbose=False)
    experiment = ExperimentLab(seed=seed, verbose=False)

    pre_step_mismatches = []
    after_clean_step_mismatches = []
    nudge_rows = []
    first_nudge_info = None
    first_body_divergence = None
    first_summary_divergence = None
    first_main_log_divergence = None
    first_memory_lineage_divergence = None
    first_interpretation_related = None
    prev_shadow_life_len = 0
    prev_experiment_life_len = 0

    for _ in range(years):
        next_year = shadow.year + 1
        pre_body_equal = body_snapshot(shadow) == body_snapshot(experiment)
        pre_trust_equal = trust_snapshot(shadow) == trust_snapshot(experiment)
        if first_nudge_info is None and (not pre_body_equal or not pre_trust_equal):
            pre_step_mismatches.append(
                {
                    "before_year": next_year,
                    "body_diff_categories": body_diff_categories(shadow, experiment),
                    "trust_diff_count": len(trust_diff(shadow, experiment)),
                }
            )

        shadow.step()
        experiment.step()

        new_nudges = new_life_rows(experiment, prev_experiment_life_len, "life_trust_nudge")
        if new_nudges:
            nudge_rows.extend(new_nudges)

        body_categories = body_diff_categories(shadow, experiment)
        current_trust_diff = trust_diff(shadow, experiment)

        if not new_nudges and first_nudge_info is None:
            if body_categories or current_trust_diff:
                after_clean_step_mismatches.append(
                    {
                        "year": shadow.year,
                        "body_diff_categories": body_categories,
                        "trust_diff_count": len(current_trust_diff),
                    }
                )

        if new_nudges and first_nudge_info is None:
            first = new_nudges[0]
            first_nudge_info = {
                "year": first.year,
                "row": format_life_row(first),
                "fields": parse_fields(first.detail),
                "body_diff_categories_after_nudge_year": body_categories,
                "rng_equal_after_nudge_year": body_snapshot(shadow)["rng_state"]
                == body_snapshot(experiment)["rng_state"],
                "trust_diff_after_nudge_year": current_trust_diff,
            }

        if first_nudge_info is not None:
            if first_body_divergence is None and body_categories:
                first_body_divergence = {
                    "year": shadow.year,
                    "body_diff_categories": body_categories,
                }
            summary_delta = dict_diff(watched_summary(shadow), watched_summary(experiment))
            if first_summary_divergence is None and summary_delta:
                first_summary_divergence = {
                    "year": shadow.year,
                    "diff": summary_delta,
                }
            main_log_delta = first_sequence_diff(
                [dataclass_clean(entry) for entry in shadow.log.entries],
                [dataclass_clean(entry) for entry in experiment.log.entries],
            )
            if first_main_log_divergence is None and main_log_delta:
                first_main_log_divergence = {
                    "year": shadow.year,
                    "diff": main_log_delta,
                }
            memory_delta = first_sequence_diff(
                clean(shadow.memory_lineage_trace),
                clean(experiment.memory_lineage_trace),
            )
            if first_memory_lineage_divergence is None and memory_delta:
                first_memory_lineage_divergence = {
                    "year": shadow.year,
                    "diff": memory_delta,
                }
            if first_interpretation_related is None:
                summary = watched_summary(experiment)
                shadow_summary = watched_summary(shadow)
                related_keys = (
                    "memory_shared_count",
                    "shared_narrative_count",
                    "narrative_divergence_count",
                    "interpretation_action_nudge_count",
                    "interpretation_support_nudge_count",
                )
                related_delta = {
                    key: {"shadow3": shadow_summary[key], "experiment": summary[key]}
                    for key in related_keys
                    if shadow_summary[key] != summary[key]
                }
                if related_delta:
                    first_interpretation_related = {
                        "year": shadow.year,
                        "diff": related_delta,
                    }

        prev_shadow_life_len = len(shadow.life_observations)
        prev_experiment_life_len = len(experiment.life_observations)

    nudge_paths = []
    for nudge in nudge_rows:
        pair = tuple(sorted(nudge.persons))
        fields = parse_fields(nudge.detail)
        place = fields.get("place", "unknown")
        path_rows = [
            format_life_row(row)
            for row in experiment.life_observations
            if tuple(sorted(row.persons)) == pair
            and row.year <= nudge.year
            and row.event_type
            in {
                "same_place_nearby",
                "life_contact",
                "passing_greeting",
                "distant_social",
                "conversation_shadow",
                "familiarity_shadow",
                "memory_shadow",
                "life_bridge_potential",
                "life_trust_nudge",
            }
        ]
        nudge_paths.append(
            {
                "pair": f"{pair[0]}|{pair[1]}",
                "place": place,
                "nudge_year": nudge.year,
                "rows": path_rows,
            }
        )

    return {
        "seed": seed,
        "nudge_count": len(nudge_rows),
        "nudge_rows": [format_life_row(row) for row in nudge_rows],
        "pre_step_mismatches_before_first_nudge": pre_step_mismatches,
        "after_clean_step_mismatches_before_first_nudge": after_clean_step_mismatches,
        "first_nudge": first_nudge_info,
        "first_body_divergence": first_body_divergence,
        "first_summary_divergence": first_summary_divergence,
        "first_main_log_divergence": first_main_log_divergence,
        "first_memory_lineage_divergence": first_memory_lineage_divergence,
        "first_interpretation_related_divergence": first_interpretation_related,
        "final_summary_diff": dict_diff(watched_summary(shadow), watched_summary(experiment)),
        "nudge_paths": nudge_paths,
    }


def run(seeds: list[int], years: int) -> dict[str, Any]:
    return {
        "reader": "pre_nudge_rng_containment_check",
        "years": years,
        "seeds": {str(seed): analyze_seed(seed, years) for seed in seeds},
    }


def write_markdown(report: dict[str, Any], path: Path) -> None:
    lines = []
    lines.append("# pre nudge rng containment check")
    lines.append("")
    lines.append("Compared fixed `shadow3` and trust-nudge experiment D year by year.")
    lines.append("")
    lines.append("Pass criteria:")
    lines.append("")
    lines.append("- before the first nudge: body and trust snapshots match")
    lines.append("- clean pre-nudge steps: no body/trust mismatches")
    lines.append("- first nudge year: body and RNG still match; only trust differs")
    lines.append("- after nudge: body divergence is allowed and should be readable")
    lines.append("")
    for seed, data in report["seeds"].items():
        lines.append(f"## seed{seed}")
        lines.append("")
        lines.append(f"- nudge_count: `{data['nudge_count']}`")
        lines.append(
            f"- pre-step mismatches before first nudge: `{len(data['pre_step_mismatches_before_first_nudge'])}`"
        )
        lines.append(
            f"- clean-step mismatches before first nudge: `{len(data['after_clean_step_mismatches_before_first_nudge'])}`"
        )
        first = data["first_nudge"]
        if first is None:
            lines.append("- first_nudge: none")
        else:
            lines.append(f"- first_nudge: {first['row']}")
            lines.append(
                "- body diff categories after nudge year: "
                + (", ".join(first["body_diff_categories_after_nudge_year"]) or "none")
            )
            lines.append(f"- rng equal after nudge year: `{first['rng_equal_after_nudge_year']}`")
            lines.append(f"- trust diff after nudge year: `{len(first['trust_diff_after_nudge_year'])}` directed edges")
        body = data["first_body_divergence"]
        if body:
            lines.append(
                f"- first body divergence: Y{body['year']:02d} "
                f"({', '.join(body['body_diff_categories'])})"
            )
        else:
            lines.append("- first body divergence: none")
        summary = data["first_summary_divergence"]
        if summary:
            keys = ", ".join(summary["diff"].keys())
            lines.append(f"- first watched summary divergence: Y{summary['year']:02d} ({keys})")
        main_log = data["first_main_log_divergence"]
        if main_log:
            diff = main_log["diff"]
            lines.append(f"- first main log divergence: Y{main_log['year']:02d}, index={diff.get('index')}")
            lines.append(f"  - shadow3: `{diff.get('shadow3')}`")
            lines.append(f"  - experiment: `{diff.get('experiment')}`")
        memory = data["first_memory_lineage_divergence"]
        if memory:
            diff = memory["diff"]
            lines.append(
                f"- first memory lineage divergence: Y{memory['year']:02d}, index={diff.get('index')}"
            )
        interpretation = data["first_interpretation_related_divergence"]
        if interpretation:
            keys = ", ".join(interpretation["diff"].keys())
            lines.append(
                f"- first interpretation-related summary divergence: Y{interpretation['year']:02d} ({keys})"
            )
        if data["nudge_paths"]:
            lines.append("")
            lines.append("Nudge paths:")
            for path_data in data["nudge_paths"]:
                lines.append(
                    f"- `{path_data['pair']}` place=`{path_data['place']}` nudge_year=Y{path_data['nudge_year']:02d}"
                )
                for row in path_data["rows"]:
                    lines.append(f"  - {row}")
        lines.append("")
    lines.append("## interpretation")
    lines.append("")
    lines.append(
        "All checked seeds contain RNG/body containment up to the nudge. "
        "The nudge year itself leaves the body snapshot and core RNG state aligned; only trust differs. "
        "Later divergence is therefore an intervention-driven branch, not a pre-existing RNG stream drift."
    )
    lines.append("")
    lines.append(
        "The interpretation path is delayed: trust changes first, then later death/birth/memory narration splits, "
        "and support/project differences appear after that."
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    seeds = [1061, 1042, 1096]
    report = run(seeds, years=80)
    json_path = OUTPUTS / "pre_nudge_rng_containment_check.json"
    md_path = OUTPUTS / "pre_nudge_rng_containment_check.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    write_markdown(report, md_path)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(md_path)


if __name__ == "__main__":
    main()
