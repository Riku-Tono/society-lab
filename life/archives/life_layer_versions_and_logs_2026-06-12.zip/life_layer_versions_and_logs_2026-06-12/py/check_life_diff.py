import ast
import difflib
import importlib.util
import sys
from pathlib import Path


BASE = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_1.py")
LIFE = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow.py")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def module_info(path: Path) -> dict[str, object]:
    tree = ast.parse(read(path), filename=str(path))
    classes = []
    funcs = []
    constants = []
    imports = []
    event_literals = set()

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            bases = []
            for base in node.bases:
                if isinstance(base, ast.Name):
                    bases.append(base.id)
                elif isinstance(base, ast.Attribute):
                    bases.append(base.attr)
                else:
                    bases.append(ast.unparse(base))
            classes.append((node.name, bases, node.lineno))
        elif isinstance(node, ast.FunctionDef):
            funcs.append((node.name, node.lineno))
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id.isupper():
                    constants.append((target.id, node.lineno))
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            imports.append(ast.unparse(node))

    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value in {
                "weather",
                "sound",
                "trace",
                "scent",
                "world_gesture",
                "place_presence",
                "repeat_place",
                "same_place_nearby",
                "distant_social",
                "conversation_shadow",
                "familiarity_shadow",
                "memory_shadow",
                "time_shadow",
            }:
                event_literals.add(node.value)

    return {
        "path": str(path),
        "lines": len(read(path).splitlines()),
        "classes": classes,
        "functions": funcs,
        "constants": constants,
        "imports": imports,
        "event_literals": sorted(event_literals),
    }


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify() -> tuple[list[int], list[tuple[int, int, int]]]:
    sys.path.insert(0, str(BASE.parent))
    base_mod = load_module("society_lab_v1_4_1", BASE)
    life_mod = load_module("life_shadow_checked", LIFE)
    seeds = [42, 1003, 1024, 1096] + list(range(1000, 1020))
    mismatches = []
    counts = []
    for seed in seeds:
        base = base_mod.SocietyLab(seed=seed, verbose=False)
        life = life_mod.LifeObservedSocietyLab(seed=seed, verbose=False, life_verbose=False)
        base.run(years=80)
        life.run(years=80)
        if base.summary() != life.summary():
            mismatches.append(seed)
        life_summary = life.life_summary()
        counts.append(
            (
                seed,
                life_summary["life_observation_count"],
                life_summary.get("time_shadow_count", None),
            )
        )
    return mismatches, counts


def main() -> None:
    base = module_info(BASE)
    life = module_info(LIFE)
    print("BASE_LINES", base["lines"])
    print("LIFE_LINES", life["lines"])
    print("BASE_CLASSES", base["classes"])
    print("LIFE_CLASSES", life["classes"])
    print("LIFE_EXTRA_CONSTANTS", [c for c in life["constants"] if c not in base["constants"]])
    print("LIFE_EVENT_TYPES", life["event_literals"])

    base_text = read(BASE).splitlines()
    life_text = read(LIFE).splitlines()
    diff_header = list(difflib.unified_diff(base_text[:80], life_text[:80], fromfile="base", tofile="life", lineterm=""))
    print("TOP_DIFF_SAMPLE")
    for line in diff_header[:80]:
        print(line)

    mismatches, counts = verify()
    print("SUMMARY_MISMATCHES", mismatches)
    print("COUNTS", counts)


if __name__ == "__main__":
    main()
