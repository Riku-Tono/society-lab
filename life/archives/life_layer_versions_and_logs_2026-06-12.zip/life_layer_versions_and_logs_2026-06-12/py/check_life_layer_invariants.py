from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


BASE_MODULE = "society_lab_v1_4_1.py"
LIFE_MODULE = "society_lab_v1_4_life_sound.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_sim(cls, seed: int, years: int):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=years)
    return sim


def comparable_state(sim):
    data = {
        "summary": sim.summary(),
    }
    for attr in ("population", "year"):
        if hasattr(sim, attr):
            data[attr] = getattr(sim, attr)
    for attr in ("observations", "observation_log", "log"):
        if hasattr(sim, attr):
            value = getattr(sim, attr)
            data[attr] = repr(value)
    return data


def main() -> int:
    folder = Path(__file__).resolve().parent
    if not (folder / BASE_MODULE).exists() or not (folder / LIFE_MODULE).exists():
        print(
            "Put this script next to "
            f"{BASE_MODULE} and {LIFE_MODULE}, then run it again."
        )
        return 2

    base_module = load_module(folder / BASE_MODULE, "society_lab_v1_4_1")
    life_module = load_module(folder / LIFE_MODULE, "society_lab_v1_4_life_sound")

    mismatches = []
    for seed in range(1000, 1100):
        base = run_sim(base_module.SocietyLab, seed, 80)
        life = run_sim(life_module.LifeObservedSocietyLab, seed, 80)

        base_state = comparable_state(base)
        life_state = comparable_state(life)
        if base_state != life_state:
            mismatches.append(
                {
                    "seed": seed,
                    "base": base_state,
                    "life": life_state,
                }
            )

    if mismatches:
        print(json.dumps({"status": "mismatch", "mismatches": mismatches}, indent=2))
        return 1

    print(json.dumps({"status": "ok", "seeds": "1000-1099", "years": 80}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
