from pathlib import Path
import dataclasses
import json
import os
import statistics
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")


def find_sl3() -> Path:
    for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
        if (
            dirpath.endswith("SL3")
            and "society_lab_v1_4_1.py" in filenames
            and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames
        ):
            return Path(dirpath)
    raise SystemExit("SL3 not found")


sl3 = find_sl3()
sys.path.insert(0, str(sl3))

from society_lab_v1_4_1 import SocietyLab  # noqa: E402
from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab  # noqa: E402


class LowMemoryShadowLab(LifeObservedSocietyLab):
    memory_shadow_chance = 0.12


class NoTimeShadowLab(LifeObservedSocietyLab):
    def _observe_time_shadow(self, *args, **kwargs) -> None:
        return None


def conv(value):
    if dataclasses.is_dataclass(value):
        return {key: conv(item) for key, item in dataclasses.asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): conv(item) for key, item in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple)):
        return [conv(item) for item in value]
    if isinstance(value, set):
        return sorted(conv(item) for item in value)
    return value


def normalized(value):
    return json.loads(json.dumps(value, sort_keys=True, default=str))


def world_snapshot(sim):
    keys = [
        "year",
        "last_detection",
        "current_problems",
        "current_proposals",
        "proposal_support_by_person",
        "project_success_by_person",
        "project_failure_by_person",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
        "ritual_success_count",
        "next_memory_index",
        "actor_biography",
        "memory_lineage_trace",
        "support_chain_trace",
        "project_aftermath_trace",
        "age_profile",
        "charisma_profile",
        "people",
        "next_person_index",
        "food",
        "initial_population",
        "initial_food_stock",
        "initial_food_capacity",
    ]
    snapshot = {key: conv(getattr(sim, key)) for key in keys}
    snapshot["log_entries"] = conv(sim.log.entries)
    snapshot["summary"] = conv(sim.summary())
    return normalized(snapshot)


def run(cls, seed: int):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=80)
    return sim


def filtered_events(sim, event_types):
    allowed = set(event_types)
    return [
        conv(observation)
        for observation in sim.life_observations
        if observation.event_type in allowed
    ]


def memory_events(sim):
    return filtered_events(sim, ["memory_shadow"])


seeds = list(range(1000, 1100))

world_diffs = []
time_disable_diffs = []
chance_stable_diffs = []
rows = []
seed_reads = {}

stable_without_memory_rate = [
    "weather",
    "place_presence",
    "same_place_nearby",
    "conversation_shadow",
    "time_shadow",
]

for seed in seeds:
    base = run(SocietyLab, seed)
    tuned = run(LifeObservedSocietyLab, seed)
    low = run(LowMemoryShadowLab, seed)
    no_time = run(NoTimeShadowLab, seed)

    if world_snapshot(base) != world_snapshot(tuned):
        world_diffs.append(seed)

    if filtered_events(tuned, ["memory_shadow", "conversation_shadow"]) != filtered_events(
        no_time, ["memory_shadow", "conversation_shadow"]
    ):
        time_disable_diffs.append(seed)

    if filtered_events(tuned, stable_without_memory_rate) != filtered_events(low, stable_without_memory_rate):
        chance_stable_diffs.append(seed)

    tuned_summary = tuned.life_summary()
    low_summary = low.life_summary()
    row = {
        "seed": seed,
        "memory_shadow_count": tuned_summary["memory_shadow_count"],
        "memory_shadow_count_at_012": low_summary["memory_shadow_count"],
        "conversation_shadow_count": tuned_summary["conversation_shadow_count"],
        "time_shadow_count": tuned_summary["time_shadow_count"],
        "life_observation_count": tuned_summary["life_observation_count"],
    }
    rows.append(row)
    if seed in {1003, 1061}:
        seed_reads[seed] = {
            "summary": row,
            "memory_shadow_events": memory_events(tuned),
        }

print("SL3", sl3)
print("memory_shadow_chance", LifeObservedSocietyLab.memory_shadow_chance)
print("world_snapshot_diffs", len(world_diffs), world_diffs[:20])
print("time_disabled_memory_or_conversation_diffs", len(time_disable_diffs), time_disable_diffs[:20])
print("chance_changed_stable_event_diffs", len(chance_stable_diffs), chance_stable_diffs[:20])

for key in [
    "memory_shadow_count",
    "memory_shadow_count_at_012",
    "conversation_shadow_count",
    "time_shadow_count",
    "life_observation_count",
]:
    values = [row[key] for row in rows]
    print(
        key,
        "min",
        min(values),
        "max",
        max(values),
        "avg",
        round(statistics.mean(values), 2),
        "nonzero",
        sum(value > 0 for value in values),
    )

print("top_memory_shadow")
for row in sorted(rows, key=lambda item: (-item["memory_shadow_count"], item["seed"]))[:12]:
    print(row)

for seed in [1003, 1061]:
    print("seed_read", seed, seed_reads[seed]["summary"])
    for event in seed_reads[seed]["memory_shadow_events"][:20]:
        print(event)

