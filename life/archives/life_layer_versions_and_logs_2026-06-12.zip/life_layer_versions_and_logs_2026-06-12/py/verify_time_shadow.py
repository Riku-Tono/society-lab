from society_lab_v1_4_1 import SocietyLab
from society_lab_v1_4_life_senses_memory_shadow import LifeObservedSocietyLab


def main() -> None:
    seeds = [42, 1003, 1024, 1096] + list(range(1000, 1020))
    mismatches = []
    counts = []
    observation_counts = []

    for seed in seeds:
        base = SocietyLab(seed=seed, verbose=False)
        life = LifeObservedSocietyLab(seed=seed, verbose=False, life_verbose=False)
        base.run(years=80)
        life.run(years=80)

        if base.summary() != life.summary():
            mismatches.append(seed)

        summary = life.life_summary()
        counts.append((seed, summary["time_shadow_count"]))
        observation_counts.append(summary["life_observation_count"])

    print("mismatches=", mismatches)
    print("time_shadow_counts=", counts)
    print("life_observation_min_max=", min(observation_counts), max(observation_counts))


if __name__ == "__main__":
    main()
