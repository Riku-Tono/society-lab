from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
LIFE_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-11\files-mentioned-by-the-user-society-2\outputs\society_lab_v1_4_life_senses_familiarity_shadow.py"
)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def obs_dict(obs):
    return {
        "year": obs.year,
        "event_type": obs.event_type,
        "persons": obs.persons,
        "detail": obs.detail,
    }


def main() -> int:
    load(BASE_PATH, "society_lab_v1_4_1")
    life = load(LIFE_PATH, "life_familiarity")
    sim = life.LifeObservedSocietyLab(seed=1003, verbose=False)
    sim.run(years=80)

    years = range(28, 35)
    target = "p033"
    out = {
        "summary": sim.summary(),
        "p031_death_events": [
            obs_dict(obs)
            for obs in sim.log.entries
            if obs.event_type == "death" and "p031" in obs.persons
        ],
        "p033_death_events": [
            obs_dict(obs)
            for obs in sim.log.entries
            if obs.event_type == "death" and "p033" in obs.persons
        ],
        "all_deaths_near_y31": [
            obs_dict(obs)
            for obs in sim.log.entries
            if obs.event_type == "death" and obs.year in years
        ],
        "life_events_near_p031_death_y65": [
            obs_dict(obs)
            for obs in sim.life_observations
            if obs.year in range(62, 68)
            and (
                target in obs.persons
                or "p031" in obs.persons
                or obs.event_type in {"weather", "world_gesture"}
            )
        ],
        "base_events_near_y31": [
            obs_dict(obs)
            for obs in sim.log.entries
            if obs.year in years and (target in obs.persons or "p031" in obs.persons)
        ],
        "life_events_near_y31": [
            obs_dict(obs)
            for obs in sim.life_observations
            if obs.year in years
            and (
                target in obs.persons
                or "p031" in obs.persons
                or obs.event_type in {"weather", "world_gesture"}
            )
        ],
        "p033_all_life_events": [
            obs_dict(obs)
            for obs in sim.life_observations
            if target in obs.persons
        ],
        "p033_pair_threads": [
            obs_dict(obs)
            for obs in sim.life_observations
            if target in obs.persons
            and len(obs.persons) == 2
            and obs.event_type
            in {
                "same_place_nearby",
                "distant_social",
                "conversation_shadow",
                "familiarity_shadow",
            }
        ],
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
