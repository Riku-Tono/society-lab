from pathlib import Path
import os


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        path = Path(dirpath) / "society_lab_v1_4_life_senses_memory_shadow3.py"
        break
else:
    raise SystemExit("shadow3 not found")

text = path.read_text(encoding="utf-8")
old = '''class LifeObservedSocietyLab(SocietyLab):
    """v1.4_1 with zero-effect life observations.

    The base simulation is advanced first. After that, a separate per-year life
    RNG may record tea-house details. The base class never reads these records.
    """
'''
new = '''class LifeObservedSocietyLab(SocietyLab):
    """v1.4_1 with zero-effect life observations.

    The base simulation is advanced first. After that, separate per-year life
    RNG streams may record tea-house details. The base class never reads these
    records.
    """

    memory_shadow_chance = 0.12
'''
if old not in text:
    raise SystemExit("class header pattern not found")
text = text.replace(old, new, 1)
old = "            if rng.random() >= 0.12:\n"
new = "            if rng.random() >= self.memory_shadow_chance:\n"
if old not in text:
    raise SystemExit("memory shadow threshold pattern not found")
text = text.replace(old, new, 1)
path.write_text(text, encoding="utf-8")
print(path)
