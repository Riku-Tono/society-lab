from pathlib import Path
import os


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        path = Path(dirpath) / "society_lab_v1_4_life_senses_memory_shadow3.py"
        break
else:
    raise SystemExit("shadow3 not found")

text = path.read_text(encoding="utf-8")

details = '''

AMBIENT_PLACE_DETAILS = {
    "book_house": {
        "objects": (
            "old_book",
            "copied_text",
            "borrowed_book",
            "worn_pages",
        ),
        "scents": (
            "ink_smell",
            "old_paper",
            "dry_wood",
        ),
        "sounds": (
            "pages_turning",
            "quiet_reading",
            "brush_on_paper",
        ),
        "scenes": (
            "quiet_reading_corner",
            "books_stacked_low",
            "copied_pages_drying",
        ),
    },
    "weaving_house": {
        "objects": (
            "loom",
            "thread_spool",
            "unfinished_cloth",
            "needle",
            "folded_cloth",
        ),
        "scents": (
            "loom_dust",
            "old_thread",
            "dry_reed",
        ),
        "sounds": (
            "loom_clicking",
            "needle_against_cloth",
            "thread_pulled_tight",
        ),
        "scenes": (
            "cloth_half_finished",
            "threads_hung_to_dry",
            "hands_worked_somewhere_nearby",
        ),
    },
    "spring": {
        "objects": (
            "cold_water",
            "mossy_stone",
            "water_reflection",
            "wet_stone",
            "fern_near_water",
        ),
        "scents": (
            "cold_stream",
            "wet_moss",
            "clean_stone",
        ),
        "sounds": (
            "spring_water_sound",
            "water_from_spring",
            "small_stream_over_stones",
        ),
        "scenes": (
            "water_reflection_under_leaves",
            "stone_pool_in_shade",
            "ferns_bent_near_water",
        ),
    },
    "rice_field": {
        "objects": (
            "green_shoots",
            "golden_field",
            "muddy_water",
            "sickle",
            "hoe",
            "rice_heads_bending",
        ),
        "scents": (
            "harvest_smell",
            "wet_soil",
            "fresh_rice",
        ),
        "sounds": (
            "frogs_at_night",
            "wind_through_rice",
            "water_in_field_rows",
        ),
        "scenes": (
            "golden_field_under_clouds",
            "green_shoots_after_rain",
            "field_water_reflecting_sky",
        ),
    },
    "festival_square": {
        "objects": (
            "paper_lantern",
            "wind_bell",
            "small_drum",
            "drum_stick",
            "festival_mask",
            "watermelon_slice",
            "shaved_ice_bowl",
        ),
        "scents": (
            "festival_smoke",
            "summer_grass",
            "sweet_shaved_ice",
        ),
        "sounds": (
            "distant_drum",
            "festival_noise",
            "wind_bell_sound",
        ),
        "scenes": (
            "many_people_gathered",
            "lanterns_before_evening",
            "festival_preparation_nearby",
        ),
    },
    "engawa": {
        "objects": (
            "fan",
            "wind_bell",
            "old_wood_floor",
            "damp_sleeve",
            "tea_cup_nearby",
        ),
        "scents": (
            "cool_evening_air",
            "old_wood",
            "summer_insects",
        ),
        "sounds": (
            "wind_bell_sound",
            "summer_insects",
            "someone_resting_in_shade",
        ),
        "scenes": (
            "shade_on_old_wood",
            "someone_resting_in_shade",
            "cool_evening_at_the_edge",
        ),
    },
}
'''

old = '''CROWD_MOODS = (
    "many_people_gathered",
    "music_somewhere",
    "festival_preparation",
    "shared_waiting",
    "crowd_nearby",
)
'''
if old not in text:
    raise SystemExit("CROWD_MOODS block not found")
if "AMBIENT_PLACE_DETAILS" not in text:
    text = text.replace(old, old + details, 1)

old = '''        ambient_rng = self._life_rng("ambient_layers")
'''
new = '''        ambient_rng = self._life_rng("ambient_layers")
        ambient_place_rng = self._life_rng("ambient_place_details")
'''
if new not in text:
    if old not in text:
        raise SystemExit("ambient rng block not found")
    text = text.replace(old, new, 1)

old = '''        self._observe_ambient_layers(ambient_rng, weather)

        self._observe_people_in_places(
'''
new = '''        self._observe_ambient_layers(ambient_rng, weather)
        self._observe_ambient_place_details(ambient_place_rng, weather)

        self._observe_people_in_places(
'''
if new not in text:
    if old not in text:
        raise SystemExit("ambient call insertion point not found")
    text = text.replace(old, new, 1)

method = '''    def _observe_ambient_place_details(self, rng: random.Random, weather: str) -> None:
        place = rng.choice(tuple(AMBIENT_PLACE_DETAILS))
        details = AMBIENT_PLACE_DETAILS[place]

        if rng.random() < 0.70:
            obj = rng.choice(details["objects"])
            self._record_life(
                "ambient_place_object",
                [],
                f"place={place}; object={obj}; weather={weather}",
            )

        if rng.random() < 0.52:
            scent = rng.choice(details["scents"])
            self._record_life(
                "ambient_place_scent",
                [],
                f"place={place}; scent={scent}; weather={weather}",
            )

        if rng.random() < 0.55:
            sound = rng.choice(details["sounds"])
            self._record_life(
                "ambient_place_sound",
                [],
                f"place={place}; sound={sound}; weather={weather}",
            )

        if rng.random() < 0.42:
            scene = rng.choice(details["scenes"])
            self._record_life(
                "ambient_place_scene",
                [],
                f"place={place}; scene={scene}; weather={weather}",
            )

'''

old = '''    def _observe_people_in_places(
'''
if method not in text:
    if old not in text:
        raise SystemExit("_observe_people_in_places not found")
    text = text.replace(old, method + old, 1)

old = '''            "crowd_mood_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "crowd_mood"
            ),
            "place_presence_count": sum(
'''
new = '''            "crowd_mood_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "crowd_mood"
            ),
            "ambient_place_object_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_place_object"
            ),
            "ambient_place_scent_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_place_scent"
            ),
            "ambient_place_sound_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_place_sound"
            ),
            "ambient_place_scene_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_place_scene"
            ),
            "place_presence_count": sum(
'''
if "ambient_place_object_count" not in text:
    if old not in text:
        raise SystemExit("life_summary insertion point not found")
    text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")
print(path)
