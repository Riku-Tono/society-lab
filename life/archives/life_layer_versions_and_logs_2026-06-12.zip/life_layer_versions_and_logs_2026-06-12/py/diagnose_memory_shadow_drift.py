"""
diagnose_memory_shadow_drift.py
================================
Finds the first year where society_lab_v1_4_1 and
society_lab_v1_4_life_senses_memory_shadow diverge.

Usage:
    python3 diagnose_memory_shadow_drift.py

Expects both modules to be importable from the same directory.
Reports the first diverging year, the diverging field, and the values.
"""

from __future__ import annotations

import importlib
import sys


SEEDS_TO_CHECK = list(range(1000, 1010))  # Start narrow; widen if needed
YEARS = 80

# Fields to compare each year
# These come from the base SocietyLab and must not be touched by life layer
YEAR_FIELDS = [
    "population",
    "food",
    "year",
]

# Summary fields to compare at end of run
SUMMARY_FIELDS = [
    "population",
    "years_run",
    "total_deaths",
    "total_births",
    "memory_shared_count",
    "support_chain_count",
]


def snapshot(sim) -> dict:
    """Cheap per-year snapshot from base attributes."""
    return {
        "population": sim.population,
        "food": round(sim.food, 6),
        "year": sim.year,
    }


def run_year_by_year(ModuleClass, seed: int) -> list[dict]:
    sim = ModuleClass(seed=seed, verbose=False)
    snapshots = []
    for _ in range(YEARS):
        sim.step()
        snapshots.append(snapshot(sim))
    return snapshots, sim.summary()


def diagnose(seed: int, BaseClass, LifeClass) -> dict | None:
    base_snapshots, base_summary = run_year_by_year(BaseClass, seed)
    life_snapshots, life_summary = run_year_by_year(LifeClass, seed)

    # Year-by-year check
    for i, (b, l) in enumerate(zip(base_snapshots, life_snapshots)):
        year = i + 1
        for field in YEAR_FIELDS:
            if b.get(field) != l.get(field):
                return {
                    "seed": seed,
                    "first_drift_year": year,
                    "field": field,
                    "base_value": b.get(field),
                    "life_value": l.get(field),
                    "source": "year_snapshot",
                }

    # End-of-run summary check
    for field in SUMMARY_FIELDS:
        bv = base_summary.get(field)
        lv = life_summary.get(field)
        if bv != lv:
            return {
                "seed": seed,
                "first_drift_year": YEARS,
                "field": field,
                "base_value": bv,
                "life_value": lv,
                "source": "final_summary",
            }

    return None  # No drift


def main():
    # Import base class
    try:
        base_mod = importlib.import_module("society_lab_v1_4_1")
        BaseClass = base_mod.SocietyLab
    except Exception as e:
        print(f"ERROR: could not import society_lab_v1_4_1: {e}")
        sys.exit(1)

    # Import life+memory_shadow class
    try:
        life_mod = importlib.import_module("society_lab_v1_4_life_senses_memory_shadow")
        LifeClass = life_mod.LifeObservedSocietyLab
    except Exception as e:
        print(f"ERROR: could not import society_lab_v1_4_life_senses_memory_shadow: {e}")
        sys.exit(1)

    print(f"Checking seeds: {SEEDS_TO_CHECK}")
    print(f"Years per seed: {YEARS}")
    print("-" * 60)

    drifted = []
    clean = []

    for seed in SEEDS_TO_CHECK:
        result = diagnose(seed, BaseClass, LifeClass)
        if result:
            drifted.append(result)
            print(
                f"DRIFT  seed={seed:5d} | "
                f"year={result['first_drift_year']:3d} | "
                f"field={result['field']:30s} | "
                f"base={result['base_value']} life={result['life_value']}"
            )
        else:
            clean.append(seed)
            print(f"OK     seed={seed:5d}")

    print("-" * 60)
    print(f"Drifted: {len(drifted)}/{len(SEEDS_TO_CHECK)}")
    print(f"Clean  : {len(clean)}/{len(SEEDS_TO_CHECK)}")

    if drifted:
        earliest = min(drifted, key=lambda r: r["first_drift_year"])
        print(f"\nEarliest drift: seed={earliest['seed']} year={earliest['first_drift_year']} field={earliest['field']}")
        print("\nSuspect: _observe_memory_shadow() is reading past state or")
        print("         iterating alive_people in a way that advances the base RNG.")
        print("Check:   Does memory_shadow use any self.people / self.alive_people")
        print("         access BEFORE super().step() returns?")
        print("         Does it call any method that writes to base state?")


if __name__ == "__main__":
    main()
