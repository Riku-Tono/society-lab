"""
Read-only life observation report for society_lab v1.4 life layer.

The reader does not change simulation dynamics. It imports
society_lab_v1_4_life_senses_memory_shadow3.py, runs selected seeds, and prints
the observation paths that make memory_shadow and time_shadow readable.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
import re
import sys
from typing import Iterable

from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab

sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")


PATH_EVENTS = {
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "life_bridge_potential",
}

CONTACT_PATH_EVENT_ORDER = (
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "life_bridge_potential",
)

CONTACT_PATH_EVENTS = set(CONTACT_PATH_EVENT_ORDER)

SUMMARY_EVENTS = (
    "season",
    "ambient_object",
    "ambient_scent",
    "ambient_sound",
    "crowd_mood",
    "ambient_place_object",
    "ambient_place_scent",
    "ambient_place_sound",
    "ambient_place_scene",
    "place_presence",
    "repeat_place",
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "life_bridge_potential",
    "time_shadow",
)


@dataclass(frozen=True)
class ObservationRow:
    year: int
    event_type: str
    persons: tuple[str, ...]
    pair: tuple[str, ...]
    place: str
    detail: str
    fields: dict[str, str]


def parse_fields(detail: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for key, value in re.findall(r"([A-Za-z_]+)=([^;]+)", detail):
        fields[key] = value.strip()
    return fields


def parse_place(detail: str, fields: dict[str, str]) -> str:
    if "place" in fields:
        return fields["place"]
    for pattern in (
        r"both near ([^;]+)",
        r"appeared at ([^;]+?) again",
        r"appeared at ([^;]+?);",
    ):
        match = re.search(pattern, detail)
        if match:
            return match.group(1).strip()
    return "unknown"


def to_row(observation) -> ObservationRow:
    persons = tuple(observation.persons)
    fields = parse_fields(observation.detail)
    return ObservationRow(
        year=observation.year,
        event_type=observation.event_type,
        persons=persons,
        pair=tuple(sorted(persons)) if len(persons) >= 2 else persons,
        place=parse_place(observation.detail, fields),
        detail=observation.detail,
        fields=fields,
    )


def run_seed(seed: int, years: int) -> tuple[dict, dict, list[ObservationRow]]:
    sim = LifeObservedSocietyLab(seed=seed, verbose=False)
    sim.run(years=years)
    rows = [to_row(observation) for observation in sim.life_observations]
    return sim.summary(), sim.life_summary(), rows


def event_counts(rows: Iterable[ObservationRow]) -> dict[str, int]:
    counts = Counter(row.event_type for row in rows)
    return {event_type: counts.get(event_type, 0) for event_type in SUMMARY_EVENTS}


def compact_world_summary(summary: dict) -> str:
    keys = (
        "initial_population",
        "final_population",
        "age_profile",
        "charisma_profile",
        "death_count",
        "birth_count",
        "memory_shared_count",
        "support_chain_trace_count",
    )
    return ", ".join(f"{key}={summary[key]}" for key in keys)


def print_event(row: ObservationRow, indent: str = "  ") -> None:
    people = ",".join(row.persons) if row.persons else "-"
    print(f"{indent}Y{row.year:02d} {row.event_type:<19} {people:<13} {row.detail}")


def compact_pair(pair: tuple[str, ...]) -> str:
    return ",".join(pair) if pair else "-"


def pair_stage_counts(rows: list[ObservationRow], pair: tuple[str, ...]) -> dict[str, int]:
    counts = Counter(
        row.event_type
        for row in rows
        if row.pair == pair and row.event_type in CONTACT_PATH_EVENTS
    )
    return {event_type: counts.get(event_type, 0) for event_type in CONTACT_PATH_EVENT_ORDER}


def memory_paths(rows: list[ObservationRow]) -> list[tuple[ObservationRow, list[ObservationRow]]]:
    memory_rows = [row for row in rows if row.event_type == "memory_shadow"]
    paths: list[tuple[ObservationRow, list[ObservationRow]]] = []
    for memory_row in memory_rows:
        history = [
            row
            for row in rows
            if row.event_type in PATH_EVENTS
            and row.event_type != "memory_shadow"
            and row.pair == memory_row.pair
            and row.place == memory_row.place
            and row.year <= memory_row.year
        ]
        paths.append((memory_row, history))
    return paths


def print_memory_paths(rows: list[ObservationRow]) -> None:
    paths = memory_paths(rows)
    if not paths:
        print("\nMemory paths")
        print("  memory_shadow: none")
        return

    print("\nMemory paths")
    for index, (memory_row, history) in enumerate(paths, start=1):
        prior_year = memory_row.fields.get("prior_year", "?")
        prior_score = memory_row.fields.get("prior_score", "?")
        pair = ",".join(memory_row.pair)
        print(
            f"  [{index}] pair={pair} place={memory_row.place} "
            f"prior_year={prior_year} prior_score={prior_score}"
        )
        if history:
            print("    lead-up")
            for row in history:
                print_event(row, indent="      ")
        else:
            print("    lead-up: none found")
        print("    return")
        print_event(memory_row, indent="      ")


def print_ambient_places(rows: list[ObservationRow]) -> None:
    ambient_types = {
        "ambient_place_object",
        "ambient_place_scent",
        "ambient_place_sound",
        "ambient_place_scene",
    }
    grouped: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        if row.event_type not in ambient_types or row.place == "unknown":
            continue
        if row.event_type == "ambient_place_object":
            value = row.fields.get("object", "?")
        elif row.event_type == "ambient_place_scent":
            value = row.fields.get("scent", "?")
        elif row.event_type == "ambient_place_sound":
            value = row.fields.get("sound", "?")
        else:
            value = row.fields.get("scene", "?")
        values = grouped[row.place][row.event_type]
        if value not in values:
            values.append(value)

    print("\nAmbient places")
    if not grouped:
        print("  ambient places: none")
        return

    for place in sorted(grouped):
        chunks = []
        for event_type in (
            "ambient_place_object",
            "ambient_place_scent",
            "ambient_place_sound",
            "ambient_place_scene",
        ):
            values = grouped[place].get(event_type, [])
            if values:
                label = event_type.replace("ambient_place_", "")
                chunks.append(f"{label}={', '.join(values[:4])}")
        print(f"  {place}: " + " | ".join(chunks))


def print_ambient_places_by_season(rows: list[ObservationRow]) -> None:
    ambient_types = {
        "ambient_place_object",
        "ambient_place_scent",
        "ambient_place_sound",
        "ambient_place_scene",
    }
    grouped: dict[str, dict[str, dict[str, list[str]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list))
    )
    for row in rows:
        if row.event_type not in ambient_types or row.place == "unknown":
            continue
        season = row.fields.get("season", "unknown")
        if row.event_type == "ambient_place_object":
            label = "object"
            value = row.fields.get("object", "?")
        elif row.event_type == "ambient_place_scent":
            label = "scent"
            value = row.fields.get("scent", "?")
        elif row.event_type == "ambient_place_sound":
            label = "sound"
            value = row.fields.get("sound", "?")
        else:
            label = "scene"
            value = row.fields.get("scene", "?")
        values = grouped[season][row.place][label]
        if value not in values:
            values.append(value)

    print("\nAmbient places by season")
    if not grouped:
        print("  ambient places by season: none")
        return

    for season in sorted(grouped):
        print(f"  {season}:")
        for place in sorted(grouped[season]):
            chunks = []
            for label in ("object", "scent", "sound", "scene"):
                values = grouped[season][place].get(label, [])
                if values:
                    chunks.append(f"{label}={', '.join(values[:3])}")
            print(f"    {place}: " + " | ".join(chunks))


def contact_paths(rows: list[ObservationRow]) -> list[tuple[tuple[str, ...], list[ObservationRow]]]:
    grouped: dict[tuple[str, ...], list[ObservationRow]] = defaultdict(list)
    for row in rows:
        if len(row.pair) >= 2 and row.event_type in CONTACT_PATH_EVENTS:
            grouped[row.pair].append(row)

    paths: list[tuple[tuple[str, ...], list[ObservationRow]]] = []
    for pair, pair_rows in grouped.items():
        event_types = {row.event_type for row in pair_rows}
        if event_types & {
            "passing_greeting",
            "distant_social",
            "conversation_shadow",
            "familiarity_shadow",
            "memory_shadow",
        }:
            event_order = {
                event_type: index for index, event_type in enumerate(CONTACT_PATH_EVENT_ORDER)
            }
            paths.append(
                (
                    pair,
                    sorted(
                        pair_rows,
                        key=lambda row: (
                            row.year,
                            event_order.get(row.event_type, len(event_order)),
                        ),
                    ),
                )
            )

    def rank(item: tuple[tuple[str, ...], list[ObservationRow]]) -> tuple[int, int, str]:
        pair, pair_rows = item
        event_types = {row.event_type for row in pair_rows}
        weight = 0
        if "memory_shadow" in event_types:
            weight += 100
        if "life_bridge_potential" in event_types:
            weight += 70
        if "familiarity_shadow" in event_types:
            weight += 40
        if "conversation_shadow" in event_types:
            weight += 25
        if "passing_greeting" in event_types:
            weight += 10
        if "life_contact" in event_types:
            weight += 3
        return (-weight, pair_rows[0].year, compact_pair(pair))

    return sorted(paths, key=rank)


def print_contact_paths(rows: list[ObservationRow], limit: int) -> None:
    paths = contact_paths(rows)
    print("\nContact paths")
    if not paths:
        print("  contact paths: none")
        return
    for index, (pair, pair_rows) in enumerate(paths[:limit], start=1):
        counts = pair_stage_counts(rows, pair)
        stages = ", ".join(
            f"{event_type}={count}"
            for event_type, count in counts.items()
            if count
        )
        places = Counter(row.place for row in pair_rows if row.place != "unknown")
        print(f"  [{index}] pair={compact_pair(pair)} stages: {stages}")
        if places:
            print(f"      places: {places.most_common(3)}")
        for row in pair_rows:
            print_event(row, indent="      ")
    if len(paths) > limit:
        print(f"  ... {len(paths) - limit} more contact paths omitted")


def print_relation_potentials(rows: list[ObservationRow]) -> None:
    potential_rows = [row for row in rows if row.event_type == "life_bridge_potential"]
    print("\nRelation potentials")
    if not potential_rows:
        print("  life_bridge_potential: none")
        return

    grouped: dict[tuple[str, ...], list[ObservationRow]] = defaultdict(list)
    for row in potential_rows:
        grouped[row.pair].append(row)

    def latest_potential(pair_rows: list[ObservationRow]) -> float:
        value = pair_rows[-1].fields.get("potential", "0")
        try:
            return float(value)
        except ValueError:
            return 0.0

    ranked = sorted(
        grouped.items(),
        key=lambda item: (-latest_potential(item[1]), item[1][0].year, compact_pair(item[0])),
    )
    for pair, pair_rows in ranked[:12]:
        latest = pair_rows[-1]
        sources = latest.fields.get("sources", latest.fields.get("source", "?"))
        potential = latest.fields.get("potential", "?")
        marks = len(pair_rows)
        print(
            f"  {compact_pair(pair)}: potential={potential}, "
            f"marks={marks}, sources={sources}"
        )
        for row in pair_rows:
            print_event(row, indent="      ")
    if len(ranked) > 12:
        print(f"  ... {len(ranked) - 12} more relation potentials omitted")


def print_time_shadows(rows: list[ObservationRow]) -> None:
    time_rows = [row for row in rows if row.event_type == "time_shadow"]
    print("\nTime shadows")
    if not time_rows:
        print("  time_shadow: none")
        return
    for row in time_rows:
        print_event(row)


def print_social_shadows(rows: list[ObservationRow]) -> None:
    social_types = {
        "life_contact",
        "passing_greeting",
        "distant_social",
        "conversation_shadow",
        "familiarity_shadow",
    }
    social_rows = [row for row in rows if row.event_type in social_types]
    print("\nSocial shadows")
    if not social_rows:
        print("  social shadows: none")
        return
    for row in social_rows:
        print_event(row)


def print_seed_report(seed: int, years: int, contact_limit: int) -> None:
    summary, _life_summary, rows = run_seed(seed, years)
    selected_rows = [row for row in rows if row.event_type in SUMMARY_EVENTS]
    places = Counter(row.place for row in selected_rows if row.place != "unknown")
    pairs = Counter(row.pair for row in selected_rows if len(row.pair) >= 2)

    print(f"\n=== seed {seed} / {years} years ===")
    print(f"World: {compact_world_summary(summary)}")
    print(f"Counts: {event_counts(selected_rows)}")
    print(f"Top places: {places.most_common(6)}")
    print(f"Top pairs: {pairs.most_common(6)}")
    print_ambient_places(selected_rows)
    print_ambient_places_by_season(selected_rows)
    print_memory_paths(selected_rows)
    print_contact_paths(selected_rows, contact_limit)
    print_relation_potentials(selected_rows)
    print_time_shadows(selected_rows)
    print_social_shadows(selected_rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read life observation paths without changing society_lab dynamics."
    )
    parser.add_argument(
        "seeds",
        nargs="*",
        type=int,
        default=[1003, 1061],
        help="Seeds to read. Defaults to 1003 1061.",
    )
    parser.add_argument("--years", type=int, default=80)
    parser.add_argument(
        "--contact-limit",
        type=int,
        default=8,
        help="Maximum contact paths to print per seed. Defaults to 8.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    for seed in args.seeds:
        print_seed_report(seed, args.years, args.contact_limit)


if __name__ == "__main__":
    main()
