from pathlib import Path
import dataclasses
import json
import os
import py_compile
import statistics
import subprocess
import sys

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if (
        dirpath.endswith("SL3")
        and "society_lab_v1_4_1.py" in filenames
        and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames
    ):
        sl3 = Path(dirpath)
        break
else:
    raise SystemExit("SL3 not found")

shadow3 = sl3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
reader = sl3 / "life_observation_reader.py"
py_compile.compile(
    str(shadow3),
    cfile=r"C:/Users/yauki/Documents/Codex/2026-06-12/files-mentioned-by-the-user-society/work/shadow3_life_contact.pyc",
    doraise=True,
)
py_compile.compile(
    str(reader),
    cfile=r"C:/Users/yauki/Documents/Codex/2026-06-12/files-mentioned-by-the-user-society/work/life_observation_reader.pyc",
    doraise=True,
)

sys.path.insert(0, str(sl3))
from society_lab_v1_4_1 import SocietyLab  # noqa: E402
from society_lab_v1_4_life_senses_memory_shadow3 import LifeObservedSocietyLab  # noqa: E402


class VariantA(LifeObservedSocietyLab):
    life_contact_familiarity_weight = 1
    familiarity_mark_divisor = 4


class VariantB(LifeObservedSocietyLab):
    life_contact_familiarity_weight = 0
    familiarity_mark_divisor = 4


class VariantC(LifeObservedSocietyLab):
    life_contact_familiarity_weight = 1
    familiarity_mark_divisor = 8


VARIANTS = {
    "A": VariantA,
    "B": VariantB,
    "C": VariantC,
}

COUNT_KEYS = [
    "life_observation_count",
    "same_place_nearby_count",
    "life_contact_count",
    "passing_greeting_count",
    "distant_social_count",
    "conversation_shadow_count",
    "familiarity_shadow_count",
    "memory_shadow_count",
    "time_shadow_count",
]

STABLE_EVENTS = [
    "weather",
    "season",
    "ambient_object",
    "ambient_scent",
    "ambient_sound",
    "crowd_mood",
    "place_presence",
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "time_shadow",
]


def conv(value):
    if dataclasses.is_dataclass(value):
        return {key: conv(item) for key, item in dataclasses.asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): conv(item) for key, item in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, (list, tuple)):
        return [conv(item) for item in value]
    if isinstance(value, set):
        return sorted(conv(item) for item in value)
    return value


def normalized(value):
    return json.loads(json.dumps(value, sort_keys=True, default=str))


def world_snapshot(sim):
    keys = [
        "year",
        "last_detection",
        "current_problems",
        "current_proposals",
        "proposal_support_by_person",
        "project_success_by_person",
        "project_failure_by_person",
        "interpretation_action_nudge_count",
        "interpretation_support_nudge_count",
        "ritual_success_count",
        "next_memory_index",
        "actor_biography",
        "memory_lineage_trace",
        "support_chain_trace",
        "project_aftermath_trace",
        "age_profile",
        "charisma_profile",
        "people",
        "next_person_index",
        "food",
        "initial_population",
        "initial_food_stock",
        "initial_food_capacity",
    ]
    snapshot = {key: conv(getattr(sim, key)) for key in keys}
    snapshot["log_entries"] = conv(sim.log.entries)
    snapshot["summary"] = conv(sim.summary())
    return normalized(snapshot)


def run(cls, seed):
    sim = cls(seed=seed, verbose=False)
    sim.run(80)
    return sim


def filtered_events(sim, event_types):
    allowed = set(event_types)
    return [
        conv(observation)
        for observation in sim.life_observations
        if observation.event_type in allowed
    ]


def summarize(values):
    return {
        "min": min(values),
        "max": max(values),
        "avg": round(statistics.mean(values), 2),
        "nonzero": sum(value > 0 for value in values),
    }


def event_rows(sim, event_types):
    allowed = set(event_types)
    return [
        {
            "year": observation.year,
            "event_type": observation.event_type,
            "persons": observation.persons,
            "detail": observation.detail,
        }
        for observation in sim.life_observations
        if observation.event_type in allowed
    ]


seeds = range(1000, 1100)
base_snapshots = {seed: world_snapshot(run(SocietyLab, seed)) for seed in seeds}
variant_sims = {
    name: {seed: run(cls, seed) for seed in seeds}
    for name, cls in VARIANTS.items()
}

pollution = {}
tables = {}
seed_focus = {}
for name, sims in variant_sims.items():
    pollution[name] = [
        seed for seed, sim in sims.items()
        if base_snapshots[seed] != world_snapshot(sim)
    ]
    tables[name] = {}
    for key in COUNT_KEYS:
        tables[name][key] = summarize([sim.life_summary()[key] for sim in sims.values()])
    seed_focus[name] = {}
    for seed in [1003, 1061]:
        sim = sims[seed]
        summary = sim.life_summary()
        seed_focus[name][seed] = {
            key: summary[key]
            for key in COUNT_KEYS
        }
        seed_focus[name][seed]["events"] = event_rows(
            sim,
            [
                "life_contact",
                "passing_greeting",
                "distant_social",
                "conversation_shadow",
                "familiarity_shadow",
                "memory_shadow",
                "time_shadow",
            ],
        )

stable_diffs = {"B_vs_A": [], "C_vs_A": []}
for seed in seeds:
    a = filtered_events(variant_sims["A"][seed], STABLE_EVENTS)
    b = filtered_events(variant_sims["B"][seed], STABLE_EVENTS)
    c = filtered_events(variant_sims["C"][seed], STABLE_EVENTS)
    if a != b:
        stable_diffs["B_vs_A"].append(seed)
    if a != c:
        stable_diffs["C_vs_A"].append(seed)

print("compiled ok")
print("SL3", sl3)
print("pollution", {name: (len(seeds), bad[:20]) for name, bad in pollution.items()})
print("stable_diffs", {key: (len(value), value[:20]) for key, value in stable_diffs.items()})
print("tables")
for name in ["A", "B", "C"]:
    print("VARIANT", name)
    for key in COUNT_KEYS:
        print(key, tables[name][key])
print("seed_focus")
for name in ["A", "B", "C"]:
    print("VARIANT", name)
    for seed in [1003, 1061]:
        print("SEED", seed, {key: seed_focus[name][seed][key] for key in COUNT_KEYS})
        for event in seed_focus[name][seed]["events"]:
            if event["event_type"] in {"passing_greeting", "conversation_shadow", "familiarity_shadow", "memory_shadow", "time_shadow"}:
                print(event)

