from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
import json
import os
from pathlib import Path
import py_compile
import subprocess
import sys


sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

ROOT = Path.cwd()
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def find_sl3() -> Path:
    home = Path.home()
    for root, _dirs, files in os.walk(home / "OneDrive"):
        if "society_lab_v1_4_1.py" in files and "society_lab_v1_4_life_senses_memory_shadow3.py" in files:
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


SL3 = find_sl3()
BASE_PATH = SL3 / "society_lab_v1_4_1.py"
LIFE_PATH = SL3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
READER_PATH = SL3 / "life_observation_reader.py"
if str(SL3) not in sys.path:
    sys.path.insert(0, str(SL3))


def import_from_path(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def clean_json(value):
    return json.loads(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str))


def world_snapshot(sim):
    return {
        "summary": clean_json(sim.summary()),
        "people": clean_json(sim.people),
        "food_stock": getattr(sim.food, "stock", None),
        "food_capacity": getattr(sim.food, "capacity", None),
        "log_entries": clean_json(getattr(sim.log, "entries", [])),
        "memory_lineage_trace": clean_json(getattr(sim, "memory_lineage_trace", [])),
        "support_chain_trace": clean_json(getattr(sim, "support_chain_trace", [])),
        "project_aftermath_trace": clean_json(getattr(sim, "project_aftermath_trace", [])),
    }


def run_sim(cls, seed: int, years: int = 80):
    sim = cls(seed=seed, verbose=False)
    sim.run(years=years)
    return sim


def stats(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {"min": 0, "max": 0, "avg": 0.0, "nonzero": 0}
    return {
        "min": round(min(values), 2),
        "max": round(max(values), 2),
        "avg": round(sum(values) / len(values), 2),
        "nonzero": sum(1 for value in values if value),
    }


def event_signature(sim, event_types: tuple[str, ...]) -> list[tuple]:
    return [
        (ob.year, ob.event_type, tuple(ob.persons), ob.detail)
        for ob in sim.life_observations
        if ob.event_type in event_types
    ]


py_compile.compile(str(LIFE_PATH), cfile=str(ROOT / "work" / "_shadow3_relation.pyc"), doraise=True)
py_compile.compile(str(READER_PATH), cfile=str(ROOT / "work" / "_reader_relation.pyc"), doraise=True)

base_mod = import_from_path("society_lab_base_relation", BASE_PATH)
life_mod = import_from_path("society_lab_life_relation", LIFE_PATH)

BaseLab = base_mod.SocietyLab
LifeLab = life_mod.LifeObservedSocietyLab


class NoRelationPotentialLab(LifeLab):
    def _note_relation_potential(self, *args, **kwargs):
        return None

    def _note_relation_potential_by_ids(self, *args, **kwargs):
        return None


stable_events = (
    "weather",
    "season",
    "ambient_object",
    "ambient_scent",
    "ambient_sound",
    "crowd_mood",
    "ambient_place_object",
    "ambient_place_scent",
    "ambient_place_sound",
    "ambient_place_scene",
    "place_presence",
    "same_place_nearby",
    "life_contact",
    "passing_greeting",
    "distant_social",
    "conversation_shadow",
    "familiarity_shadow",
    "memory_shadow",
    "time_shadow",
)

pollution_diffs = []
stable_diffs = []
bridge_counts = []
max_scores = []
avg_nonzero_scores = []
gte_8_counts = []
gte_16_counts = []
seed_details = {}

for seed in range(1000, 1100):
    base = run_sim(BaseLab, seed)
    life = run_sim(LifeLab, seed)
    disabled = run_sim(NoRelationPotentialLab, seed)

    if world_snapshot(base) != world_snapshot(life):
        pollution_diffs.append(seed)

    if event_signature(life, stable_events) != event_signature(disabled, stable_events):
        stable_diffs.append(seed)

    potentials = list(life.life_relation_potential.values())
    nonzero = [value for value in potentials if value > 0]
    bridge_count = sum(1 for ob in life.life_observations if ob.event_type == "life_bridge_potential")
    bridge_counts.append(bridge_count)
    max_scores.append(max(nonzero) if nonzero else 0.0)
    avg_nonzero_scores.append(sum(nonzero) / len(nonzero) if nonzero else 0.0)
    gte_8_counts.append(sum(1 for value in nonzero if value >= 8))
    gte_16_counts.append(sum(1 for value in nonzero if value >= 16))

    if seed in (1003, 1061):
        counts = Counter(ob.event_type for ob in life.life_observations)
        top_potentials = sorted(
            life.life_relation_potential.items(),
            key=lambda item: (-item[1], item[0]),
        )[:10]
        bridge_rows = [
            {
                "year": ob.year,
                "persons": ob.persons,
                "detail": ob.detail,
            }
            for ob in life.life_observations
            if ob.event_type == "life_bridge_potential"
        ]
        seed_details[seed] = {
            "counts": {
                event: counts.get(event, 0)
                for event in (
                    "life_contact",
                    "passing_greeting",
                    "distant_social",
                    "conversation_shadow",
                    "familiarity_shadow",
                    "memory_shadow",
                    "life_bridge_potential",
                    "time_shadow",
                )
            },
            "top_potentials": [
                {"pair": f"{pair[0]}|{pair[1]}", "potential": round(score, 2)}
                for pair, score in top_potentials
            ],
            "bridge_rows": bridge_rows,
        }

reader_result = subprocess.run(
    [
        sys.executable,
        str(READER_PATH),
        "1003",
        "1061",
        "--contact-limit",
        "8",
    ],
    cwd=SL3,
    check=True,
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="backslashreplace",
)
reader_output = OUTPUTS / "life_observation_reader_seed1003_1061_relation_potential.txt"
reader_output.write_text(reader_result.stdout, encoding="utf-8")

report = {
    "files": {
        "base": str(BASE_PATH),
        "life": str(LIFE_PATH),
        "reader": str(READER_PATH),
    },
    "compile_ok": True,
    "pollution_diffs": pollution_diffs,
    "stable_event_diffs_with_relation_potential_disabled": stable_diffs,
    "stats": {
        "life_bridge_potential_count": stats(bridge_counts),
        "relation_potential_max_score": stats(max_scores),
        "relation_potential_avg_score_among_nonzero_pairs": stats(avg_nonzero_scores),
        "relation_potential_gte_8_pair_count": stats(gte_8_counts),
        "relation_potential_gte_16_pair_count": stats(gte_16_counts),
    },
    "seed_details": seed_details,
    "reader_output": str(reader_output),
}

json_path = OUTPUTS / "relation_potential_check.json"
json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

lines = []
lines.append("# relation_potential check")
lines.append("")
lines.append("## changes")
lines.append("")
lines.append("- Added life-side `life_relation_potential` state.")
lines.append("- Added `life_bridge_potential` observations at potential marks `8, 16, 24...`.")
lines.append("- Sources: `passing_greeting +1`, `distant_social +1`, `conversation_shadow +3`, `familiarity_shadow +2`, `memory_shadow +4`.")
lines.append("- `life_contact` remains observation-only and contributes `+0`.")
lines.append("- No trust, support, main memory, food, health, birth, death, or base dynamics were changed.")
lines.append("")
lines.append("## checks")
lines.append("")
lines.append(f"- compile_ok: `{report['compile_ok']}`")
lines.append(f"- pollution_diffs seed1000-1099: `{len(pollution_diffs)}`")
lines.append(f"- stable_event_diffs_with_relation_potential_disabled: `{len(stable_diffs)}`")
lines.append("")
lines.append("Stable event comparison excludes only the new `life_bridge_potential` event and includes weather, season, ambient layers, place/co-presence, contact, social shadows, memory_shadow, and time_shadow.")
lines.append("")
lines.append("## 100 seed stats")
lines.append("")
lines.append("| metric | min | max | avg | nonzero |")
lines.append("| --- | ---: | ---: | ---: | ---: |")
for metric, metric_stats in report["stats"].items():
    lines.append(
        f"| `{metric}` | {metric_stats['min']} | {metric_stats['max']} | "
        f"{metric_stats['avg']} | {metric_stats['nonzero']} |"
    )
lines.append("")
for seed in (1003, 1061):
    details = seed_details[seed]
    lines.append(f"## seed{seed}")
    lines.append("")
    counts = ", ".join(f"`{key}={value}`" for key, value in details["counts"].items())
    lines.append(f"- Counts: {counts}")
    if details["top_potentials"]:
        top = ", ".join(
            f"`{item['pair']}={item['potential']}`" for item in details["top_potentials"][:5]
        )
        lines.append(f"- Top potentials: {top}")
    else:
        lines.append("- Top potentials: none")
    if details["bridge_rows"]:
        lines.append("- Bridge marks:")
        for row in details["bridge_rows"][:8]:
            pair = "|".join(row["persons"])
            lines.append(f"  - Y{row['year']:02d} `{pair}` {row['detail']}")
    else:
        lines.append("- Bridge marks: none")
    lines.append("")
lines.append("## reading")
lines.append("")
lines.append("seed1003 remains quiet if `life_bridge_potential` does not mark heavily: life_contact and greetings exist, but ordinary co-presence does not become a relation candidate by itself.")
lines.append("")
lines.append("seed1061 should show relation candidates where the prior conversation/familiarity/memory path gathers enough weight to become visible before any trust change exists.")
lines.append("")
lines.append(f"Reader output: `{reader_output}`")

md_path = OUTPUTS / "relation_potential_check.md"
md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

print(json.dumps(report, indent=2, ensure_ascii=False))
print(md_path)
