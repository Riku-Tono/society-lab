from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
LIFE_PATH = Path(r"C:\Users\yauki\Documents\Codex\2026-06-11\files-mentioned-by-the-user-society-2\work\society_lab_v1_4_life_senses_memory_shadow.py")


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    load(BASE_PATH, "society_lab_v1_4_1")
    life = load(LIFE_PATH, "life_memory_shadow")
    counts = {}
    for seed in range(1000, 1100):
        sim = life.LifeObservedSocietyLab(seed=seed, verbose=False)
        sim.run(years=80)
        counts[seed] = sim.life_summary().get("memory_shadow_count", 0)
    nonzero = {seed: count for seed, count in counts.items() if count}
    print(json.dumps({
        "nonzero_seed_count": len(nonzero),
        "total_memory_shadow": sum(counts.values()),
        "max_memory_shadow": max(counts.values()),
        "nonzero": nonzero,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
