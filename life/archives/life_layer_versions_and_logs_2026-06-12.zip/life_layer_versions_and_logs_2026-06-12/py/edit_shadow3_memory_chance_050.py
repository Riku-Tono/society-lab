from pathlib import Path
import os


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        path = Path(dirpath) / "society_lab_v1_4_life_senses_memory_shadow3.py"
        break
else:
    raise SystemExit("shadow3 not found")

text = path.read_text(encoding="utf-8")
old = "    memory_shadow_chance = 0.20\n"
new = "    memory_shadow_chance = 0.50\n"
if old not in text:
    raise SystemExit("memory_shadow_chance is not 0.20")
path.write_text(text.replace(old, new, 1), encoding="utf-8")
print(path)
