from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys


sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

ROOT = Path.cwd()
OUTPUTS = ROOT / "outputs"
DATA = json.loads((OUTPUTS / "season_aware_ambient_places_check.json").read_text(encoding="utf-8"))


def find_sl3() -> Path:
    home = Path.home()
    for root, dirs, files in os.walk(home / "OneDrive"):
        if "life_observation_reader.py" in files and "society_lab_v1_4_life_senses_memory_shadow3.py" in files:
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


SL3 = find_sl3()
reader_out = OUTPUTS / "life_observation_reader_seed1003_1061_season_aware.txt"
result = subprocess.run(
    [
        sys.executable,
        str(SL3 / "life_observation_reader.py"),
        "1003",
        "1061",
        "--contact-limit",
        "8",
    ],
    cwd=SL3,
    check=True,
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="backslashreplace",
)
reader_out.write_text(result.stdout, encoding="utf-8")


def stats_line(name: str) -> str:
    s = DATA["count_stats"][name]
    return f"| `{name}` | {s['min']} | {s['max']} | {s['avg']} | {s['nonzero']} |"


lines = []
lines.append("# season-aware ambient places check")
lines.append("")
lines.append("## changes")
lines.append("")
lines.append("- Added season-weighted ambient place selection inside the existing `ambient_place_details` stream.")
lines.append("- Added season-weighted place details for objects, scents, sounds, and scenes.")
lines.append("- Added `season=...` to ambient place detail strings.")
lines.append("- Added `Ambient places by season` to `life_observation_reader.py`.")
lines.append("- No trust, support, main memory, food, health, birth, death, or base dynamics were changed.")
lines.append("")
lines.append("## checks")
lines.append("")
lines.append(f"- compile_ok: `{DATA['compile_ok']}`")
lines.append(f"- pollution_diffs seed1000-1099: `{len(DATA['pollution_diffs'])}`")
lines.append(f"- stable_event_diffs_vs_unweighted_ambient_places: `{len(DATA['stable_event_diffs_vs_unweighted_ambient_places'])}`")
lines.append("")
lines.append("Stable event comparison includes weather, season, ambient_object, ambient_scent, ambient_sound, crowd_mood, place_presence, same_place_nearby, life_contact, passing_greeting, distant_social, conversation_shadow, familiarity_shadow, memory_shadow, and time_shadow.")
lines.append("")
lines.append("## 100 seed count stats")
lines.append("")
lines.append("| event | min | max | avg | nonzero |")
lines.append("| --- | ---: | ---: | ---: | ---: |")
for event in (
    "season",
    "ambient_place_object",
    "ambient_place_scent",
    "ambient_place_sound",
    "ambient_place_scene",
    "life_observation",
):
    lines.append(stats_line(event))
lines.append("")
lines.append("## ambient places by season")
lines.append("")
for season, top in DATA["season_place_top"]:
    joined = ", ".join(f"{place}={count}" for place, count in top)
    lines.append(f"- `{season}`: {joined}")
lines.append("")
lines.append("## seed1003")
lines.append("")
seed1003 = DATA["seed_details"]["1003"]
lines.append("- Social path stays quiet: `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `time_shadow=8`.")
lines.append(f"- Contact remains observational: `life_contact={seed1003['counts']['life_contact']}`, `passing_greeting={seed1003['counts']['passing_greeting']}`.")
lines.append("- Strongest seasonal place hints:")
for (season, place), count in seed1003["top_season_places"][:5]:
    lines.append(f"  - `{season}` / `{place}`: {count}")
lines.append("")
lines.append("## seed1061")
lines.append("")
seed1061 = DATA["seed_details"]["1061"]
lines.append("- Human crossing is preserved: `conversation_shadow=2`, `familiarity_shadow=3`, `memory_shadow=1`, `time_shadow=7`.")
lines.append(f"- Contact remains legible: `life_contact={seed1061['counts']['life_contact']}`, `passing_greeting={seed1061['counts']['passing_greeting']}`.")
lines.append("- Strongest seasonal place hints:")
for (season, place), count in seed1061["top_season_places"][:5]:
    lines.append(f"  - `{season}` / `{place}`: {count}")
lines.append("")
lines.append("## reading")
lines.append("")
lines.append("seed1003 remains the quiet old village: places age, seasons leave objects and sounds, but the social shadow path does not become a network. The added layer gives it a calendar of surfaces rather than new relationships.")
lines.append("")
lines.append("seed1061 remains the village where people cross: the existing tea-house/contact/memory path is still visible, now with midsummer festival_square, harvest/weaving, and early-summer spring/rice-field textures around it. The background is thicker, but it does not overwrite the social path.")
lines.append("")
lines.append(f"Reader output: `{reader_out}`")

report_path = OUTPUTS / "season_aware_ambient_places_check.md"
report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

print(report_path)
print(reader_out)
