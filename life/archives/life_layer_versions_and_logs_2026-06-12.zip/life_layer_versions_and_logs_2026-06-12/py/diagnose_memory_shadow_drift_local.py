from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
LIFE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow.py")
YEARS = 80
SEEDS = range(1000, 1100)


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def food_stock(sim) -> float | None:
    food = getattr(sim, "food", None)
    if food is None:
        return None
    if hasattr(food, "stock"):
        return round(food.stock, 6)
    if isinstance(food, (int, float)):
        return round(food, 6)
    return None


def snapshot(sim) -> dict[str, object]:
    return {
        "year": sim.year,
        "population": sim.population,
        "food_stock": food_stock(sim),
        "death_count": sim.log.count("death"),
        "birth_count": sim.log.count("birth"),
        "memory_shared_count": sim.log.count("memory_shared"),
        "support_chain_trace_count": len(getattr(sim, "support_chain_trace", [])),
        "memory_lineage_trace_count": len(getattr(sim, "memory_lineage_trace", [])),
    }


def run_years(cls, seed: int):
    sim = cls(seed=seed, verbose=False)
    snaps = []
    for _ in range(YEARS):
        sim.step()
        snaps.append(snapshot(sim))
    return snaps, sim.summary(), sim


def compare_seed(seed: int, base_cls, life_cls):
    base_snaps, base_summary, _ = run_years(base_cls, seed)
    life_snaps, life_summary, life_sim = run_years(life_cls, seed)

    for b, l in zip(base_snaps, life_snaps):
        for key in b:
            if b[key] != l[key]:
                return {
                    "seed": seed,
                    "year": b["year"],
                    "field": key,
                    "base": b[key],
                    "life": l[key],
                    "source": "year_snapshot",
                    "memory_shadow_count": getattr(life_sim, "life_summary", lambda: {})().get("memory_shadow_count"),
                }

    for key in sorted(set(base_summary) | set(life_summary)):
        if base_summary.get(key) != life_summary.get(key):
            return {
                "seed": seed,
                "year": YEARS,
                "field": key,
                "base": base_summary.get(key),
                "life": life_summary.get(key),
                "source": "summary",
                "memory_shadow_count": getattr(life_sim, "life_summary", lambda: {})().get("memory_shadow_count"),
            }

    return None


def main() -> int:
    base = load(BASE_PATH, "society_lab_v1_4_1")
    life = load(LIFE_PATH, "life_memory_shadow_under_test")
    drifted = []
    clean = []
    for seed in SEEDS:
        drift = compare_seed(seed, base.SocietyLab, life.LifeObservedSocietyLab)
        if drift:
            drifted.append(drift)
        else:
            clean.append(seed)

    result = {
        "checked": f"{min(SEEDS)}-{max(SEEDS)}",
        "years": YEARS,
        "drifted_count": len(drifted),
        "clean_count": len(clean),
        "earliest": min(drifted, key=lambda item: (item["year"], item["seed"])) if drifted else None,
        "drifted": drifted[:20],
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if drifted else 0


if __name__ == "__main__":
    raise SystemExit(main())
