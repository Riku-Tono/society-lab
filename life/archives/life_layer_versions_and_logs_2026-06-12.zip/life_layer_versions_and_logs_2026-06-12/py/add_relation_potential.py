from __future__ import annotations

import os
from pathlib import Path


def find_sl3() -> Path:
    home = Path.home()
    for root, _dirs, files in os.walk(home / "OneDrive"):
        if "society_lab_v1_4_life_senses_memory_shadow3.py" in files:
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


sl3 = find_sl3()
shadow = sl3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
reader = sl3 / "life_observation_reader.py"

text = shadow.read_text(encoding="utf-8")

text = text.replace(
    "    familiarity_mark_divisor = 4\n",
    (
        "    familiarity_mark_divisor = 4\n"
        "    relation_potential_mark_divisor = 8\n"
        "    relation_potential_passing_greeting_weight = 1.0\n"
        "    relation_potential_distant_social_weight = 1.0\n"
        "    relation_potential_conversation_shadow_weight = 3.0\n"
        "    relation_potential_familiarity_shadow_weight = 2.0\n"
        "    relation_potential_memory_shadow_weight = 4.0\n"
    ),
)

text = text.replace(
    "        self.life_memory_shadow_marks: set[tuple[tuple[str, str], str, int]] = set()\n",
    (
        "        self.life_memory_shadow_marks: set[tuple[tuple[str, str], str, int]] = set()\n"
        "        self.life_relation_potential: dict[tuple[str, str], float] = {}\n"
        "        self.life_relation_potential_marks: dict[tuple[str, str], int] = {}\n"
        "        self.life_relation_potential_sources: dict[tuple[str, str], dict[str, int]] = {}\n"
    ),
)

text = text.replace(
    """                            if self.passing_greeting_familiarity_weight:
                                self._note_familiarity_shadow(
                                    pa,
                                    pb,
                                    place,
                                    weather,
                                    self.passing_greeting_familiarity_weight,
                                    "passing_greeting",
                                )
""",
    """                            self._note_relation_potential(
                                pa,
                                pb,
                                place,
                                weather,
                                self.relation_potential_passing_greeting_weight,
                                "passing_greeting",
                            )
                            if self.passing_greeting_familiarity_weight:
                                self._note_familiarity_shadow(
                                    pa,
                                    pb,
                                    place,
                                    weather,
                                    self.passing_greeting_familiarity_weight,
                                    "passing_greeting",
                                )
""",
)

text = text.replace(
    """                        if self.distant_social_familiarity_weight:
                            self._note_familiarity_shadow(
                                pa,
                                pb,
                                place,
                                weather,
                                self.distant_social_familiarity_weight,
                                "distant_social",
                            )
""",
    """                        self._note_relation_potential(
                            pa,
                            pb,
                            place,
                            weather,
                            self.relation_potential_distant_social_weight,
                            "distant_social",
                        )
                        if self.distant_social_familiarity_weight:
                            self._note_familiarity_shadow(
                                pa,
                                pb,
                                place,
                                weather,
                                self.distant_social_familiarity_weight,
                                "distant_social",
                            )
""",
)

text = text.replace(
    """                            if self.conversation_shadow_familiarity_weight:
                                self._note_familiarity_shadow(
                                    pa,
                                    pb,
                                    place,
                                    weather,
                                    self.conversation_shadow_familiarity_weight,
                                    "conversation_shadow",
                                )
""",
    """                            self._note_relation_potential(
                                pa,
                                pb,
                                place,
                                weather,
                                self.relation_potential_conversation_shadow_weight,
                                "conversation_shadow",
                            )
                            if self.conversation_shadow_familiarity_weight:
                                self._note_familiarity_shadow(
                                    pa,
                                    pb,
                                    place,
                                    weather,
                                    self.conversation_shadow_familiarity_weight,
                                    "conversation_shadow",
                                )
""",
)

helper = r'''
    def _note_relation_potential(
        self,
        left,
        right,
        place: str,
        weather: str,
        weight: float,
        source: str,
    ) -> None:
        self._note_relation_potential_by_ids(
            left.id,
            right.id,
            place,
            weather,
            weight,
            source,
        )

    def _note_relation_potential_by_ids(
        self,
        left_id: str,
        right_id: str,
        place: str,
        weather: str,
        weight: float,
        source: str,
    ) -> None:
        if weight <= 0:
            return
        pair = tuple(sorted((left_id, right_id)))
        potential = self.life_relation_potential.get(pair, 0.0) + weight
        self.life_relation_potential[pair] = potential
        sources = self.life_relation_potential_sources.setdefault(pair, {})
        sources[source] = sources.get(source, 0) + 1

        mark = int(potential // self.relation_potential_mark_divisor)
        last_mark = self.life_relation_potential_marks.get(pair, 0)
        if mark <= last_mark:
            return

        self.life_relation_potential_marks[pair] = mark
        source_text = ",".join(
            source_name
            for source_name, _count in sorted(
                sources.items(),
                key=lambda item: (-item[1], item[0]),
            )
        )
        self._record_life(
            "life_bridge_potential",
            [left_id, right_id],
            (
                f"potential={potential:.1f}; mark={mark}; source={source}; "
                f"sources={source_text}; place={place}; weather={weather}"
            ),
        )

'''

text = text.replace(
    "\n    def _note_familiarity_shadow(\n",
    "\n" + helper + "    def _note_familiarity_shadow(\n",
)

text = text.replace(
    """        self._record_life(
            "familiarity_shadow",
            [left.id, right.id],
            (
                f"{left.name} and {right.name}: repeated brief nearness; "
                f"place={place}; weather={weather}; source={source}; score={score}"
            ),
        )
""",
    """        self._record_life(
            "familiarity_shadow",
            [left.id, right.id],
            (
                f"{left.name} and {right.name}: repeated brief nearness; "
                f"place={place}; weather={weather}; source={source}; score={score}"
            ),
        )
        self._note_relation_potential(
            left,
            right,
            place,
            weather,
            self.relation_potential_familiarity_shadow_weight,
            "familiarity_shadow",
        )
""",
)

text = text.replace(
    """            self._record_life(
                "memory_shadow",
                [person.id, other_id],
                (
                    f"{person.name}: {shadow}; place={place}; weather={weather}; "
                    f"prior_year={prior_year}; prior_score={score}"
                ),
            )
""",
    """            self._record_life(
                "memory_shadow",
                [person.id, other_id],
                (
                    f"{person.name}: {shadow}; place={place}; weather={weather}; "
                    f"prior_year={prior_year}; prior_score={score}"
                ),
            )
            self._note_relation_potential_by_ids(
                person.id,
                other_id,
                place,
                weather,
                self.relation_potential_memory_shadow_weight,
                "memory_shadow",
            )
""",
)

text = text.replace(
    "        memory_shadow_pair_counts: dict[tuple[str, str], int] = {}\n",
    (
        "        memory_shadow_pair_counts: dict[tuple[str, str], int] = {}\n"
        "        life_bridge_potential_pair_counts: dict[tuple[str, str], int] = {}\n"
    ),
)

text = text.replace(
    """            if observation.event_type == "memory_shadow":
                pair = tuple(sorted(observation.persons))
                memory_shadow_pair_counts[pair] = memory_shadow_pair_counts.get(pair, 0) + 1
            if observation.event_type == "time_shadow":
""",
    """            if observation.event_type == "memory_shadow":
                pair = tuple(sorted(observation.persons))
                memory_shadow_pair_counts[pair] = memory_shadow_pair_counts.get(pair, 0) + 1
            if observation.event_type == "life_bridge_potential":
                pair = tuple(sorted(observation.persons))
                life_bridge_potential_pair_counts[pair] = (
                    life_bridge_potential_pair_counts.get(pair, 0) + 1
                )
            if observation.event_type == "time_shadow":
""",
)

summary_insert = r'''            "life_bridge_potential_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "life_bridge_potential"
            ),
            "life_bridge_potential_pair_counts": {
                f"{pair[0]}|{pair[1]}": count
                for pair, count in sorted(
                    life_bridge_potential_pair_counts.items(),
                    key=lambda item: (-item[1], item[0]),
                )
            },
            "life_relation_potential_scores": {
                f"{pair[0]}|{pair[1]}": round(score, 2)
                for pair, score in sorted(
                    self.life_relation_potential.items(),
                    key=lambda item: (-item[1], item[0]),
                )
                if score >= self.relation_potential_mark_divisor
            },
            "life_relation_potential_source_counts": {
                f"{pair[0]}|{pair[1]}": dict(
                    sorted(sources.items(), key=lambda item: (-item[1], item[0]))
                )
                for pair, sources in sorted(
                    self.life_relation_potential_sources.items(),
                    key=lambda item: (-sum(item[1].values()), item[0]),
                )
                if self.life_relation_potential.get(pair, 0.0)
                >= self.relation_potential_mark_divisor
            },
'''

text = text.replace(
    """            "time_shadow_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "time_shadow"
            ),
""",
    summary_insert
    + """            "time_shadow_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "time_shadow"
            ),
""",
)

shadow.write_text(text, encoding="utf-8", newline="\n")

reader_text = reader.read_text(encoding="utf-8")

reader_text = reader_text.replace(
    '    "memory_shadow",\n}',
    '    "memory_shadow",\n    "life_bridge_potential",\n}',
)
reader_text = reader_text.replace(
    '    "memory_shadow",\n)',
    '    "memory_shadow",\n    "life_bridge_potential",\n)',
)
reader_text = reader_text.replace(
    '    "time_shadow",\n)',
    '    "life_bridge_potential",\n    "time_shadow",\n)',
)
reader_text = reader_text.replace(
    """        if "memory_shadow" in event_types:
            weight += 100
        if "familiarity_shadow" in event_types:
""",
    """        if "memory_shadow" in event_types:
            weight += 100
        if "life_bridge_potential" in event_types:
            weight += 70
        if "familiarity_shadow" in event_types:
""",
)

relation_function = r'''

def print_relation_potentials(rows: list[ObservationRow]) -> None:
    potential_rows = [row for row in rows if row.event_type == "life_bridge_potential"]
    print("\nRelation potentials")
    if not potential_rows:
        print("  life_bridge_potential: none")
        return

    grouped: dict[tuple[str, ...], list[ObservationRow]] = defaultdict(list)
    for row in potential_rows:
        grouped[row.pair].append(row)

    def latest_potential(pair_rows: list[ObservationRow]) -> float:
        value = pair_rows[-1].fields.get("potential", "0")
        try:
            return float(value)
        except ValueError:
            return 0.0

    ranked = sorted(
        grouped.items(),
        key=lambda item: (-latest_potential(item[1]), item[1][0].year, compact_pair(item[0])),
    )
    for pair, pair_rows in ranked[:12]:
        latest = pair_rows[-1]
        sources = latest.fields.get("sources", latest.fields.get("source", "?"))
        potential = latest.fields.get("potential", "?")
        marks = len(pair_rows)
        print(
            f"  {compact_pair(pair)}: potential={potential}, "
            f"marks={marks}, sources={sources}"
        )
        for row in pair_rows:
            print_event(row, indent="      ")
    if len(ranked) > 12:
        print(f"  ... {len(ranked) - 12} more relation potentials omitted")
'''

if "def print_relation_potentials" not in reader_text:
    reader_text = reader_text.replace("\n\ndef print_time_shadows(", relation_function + "\n\ndef print_time_shadows(")

reader_text = reader_text.replace(
    "    print_contact_paths(selected_rows, contact_limit)\n    print_time_shadows(selected_rows)\n",
    "    print_contact_paths(selected_rows, contact_limit)\n    print_relation_potentials(selected_rows)\n    print_time_shadows(selected_rows)\n",
)

reader.write_text(reader_text, encoding="utf-8", newline="\n")

print(shadow)
print(reader)
