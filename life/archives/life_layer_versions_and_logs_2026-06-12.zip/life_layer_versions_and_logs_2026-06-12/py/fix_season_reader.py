from __future__ import annotations

import os
from pathlib import Path


def find_sl3() -> Path:
    home = Path.home()
    for root, dirs, files in os.walk(home / "OneDrive"):
        if "society_lab_v1_4_life_senses_memory_shadow3.py" in files:
            return Path(root)
    raise FileNotFoundError("SL3 folder not found")


sl3 = find_sl3()
shadow = sl3 / "society_lab_v1_4_life_senses_memory_shadow3.py"
reader = sl3 / "life_observation_reader.py"

shadow_text = shadow.read_text(encoding="utf-8")
shadow_text = shadow_text.replace(
    '            obj = rng.choice(details["objects"])\n',
    '            obj = self._choose_ambient_detail_value(season, place, "objects", rng)\n',
)
shadow.write_text(shadow_text, encoding="utf-8", newline="\n")

reader_text = reader.read_text(encoding="utf-8")

if "def print_ambient_places_by_season" not in reader_text:
    marker = "\n\ndef contact_paths("
    function = r'''

def print_ambient_places_by_season(rows: list[ObservationRow]) -> None:
    ambient_types = {
        "ambient_place_object",
        "ambient_place_scent",
        "ambient_place_sound",
        "ambient_place_scene",
    }
    grouped: dict[str, dict[str, dict[str, list[str]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list))
    )
    for row in rows:
        if row.event_type not in ambient_types or row.place == "unknown":
            continue
        season = row.fields.get("season", "unknown")
        if row.event_type == "ambient_place_object":
            label = "object"
            value = row.fields.get("object", "?")
        elif row.event_type == "ambient_place_scent":
            label = "scent"
            value = row.fields.get("scent", "?")
        elif row.event_type == "ambient_place_sound":
            label = "sound"
            value = row.fields.get("sound", "?")
        else:
            label = "scene"
            value = row.fields.get("scene", "?")
        values = grouped[season][row.place][label]
        if value not in values:
            values.append(value)

    print("\nAmbient places by season")
    if not grouped:
        print("  ambient places by season: none")
        return

    for season in sorted(grouped):
        print(f"  {season}:")
        for place in sorted(grouped[season]):
            chunks = []
            for label in ("object", "scent", "sound", "scene"):
                values = grouped[season][place].get(label, [])
                if values:
                    chunks.append(f"{label}={', '.join(values[:3])}")
            print(f"    {place}: " + " | ".join(chunks))
'''
    reader_text = reader_text.replace(marker, function + marker)

reader_text = reader_text.replace(
    "    print_ambient_places(selected_rows)\n    print_memory_paths(selected_rows)\n",
    "    print_ambient_places(selected_rows)\n    print_ambient_places_by_season(selected_rows)\n    print_memory_paths(selected_rows)\n",
)
reader.write_text(reader_text, encoding="utf-8", newline="\n")

print(shadow)
print(reader)
