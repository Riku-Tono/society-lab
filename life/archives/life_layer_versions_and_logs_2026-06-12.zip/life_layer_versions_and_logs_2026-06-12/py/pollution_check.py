from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
YEARS = 80


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def food_stock(sim) -> float | None:
    food = getattr(sim, "food", None)
    if food is None:
        return None
    if hasattr(food, "stock"):
        return round(food.stock, 6)
    if isinstance(food, (int, float)):
        return round(food, 6)
    return None


def yearly_snapshot(sim) -> dict[str, object]:
    return {
        "year": sim.year,
        "population": sim.population,
        "food_stock": food_stock(sim),
        "death_count": sim.log.count("death"),
        "birth_count": sim.log.count("birth"),
        "memory_shared_count": sim.log.count("memory_shared"),
        "support_chain_trace_count": len(getattr(sim, "support_chain_trace", [])),
        "memory_lineage_trace_count": len(getattr(sim, "memory_lineage_trace", [])),
        "project_aftermath_trace_count": len(getattr(sim, "project_aftermath_trace", [])),
    }


def run_years(cls, seed: int):
    sim = cls(seed=seed, verbose=False)
    snapshots = []
    for _ in range(YEARS):
        sim.step()
        snapshots.append(yearly_snapshot(sim))
    return snapshots, sim.summary(), sim


def compare_seed(seed: int, base_cls, life_cls):
    base_snapshots, base_summary, _ = run_years(base_cls, seed)
    life_snapshots, life_summary, life_sim = run_years(life_cls, seed)

    for base_snapshot, life_snapshot in zip(base_snapshots, life_snapshots):
        for field in base_snapshot:
            if base_snapshot[field] != life_snapshot[field]:
                return {
                    "seed": seed,
                    "year": base_snapshot["year"],
                    "field": field,
                    "base": base_snapshot[field],
                    "life": life_snapshot[field],
                    "source": "yearly_snapshot",
                    "life_summary": safe_life_summary(life_sim),
                }

    for field in sorted(set(base_summary) | set(life_summary)):
        if base_summary.get(field) != life_summary.get(field):
            return {
                "seed": seed,
                "year": YEARS,
                "field": field,
                "base": base_summary.get(field),
                "life": life_summary.get(field),
                "source": "final_summary",
                "life_summary": safe_life_summary(life_sim),
            }

    return None


def safe_life_summary(sim) -> dict[str, object]:
    if not hasattr(sim, "life_summary"):
        return {}
    summary = sim.life_summary()
    return {
        key: value
        for key, value in summary.items()
        if key.endswith("_count") or key in {"life_observation_count"}
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("life_path", type=Path)
    parser.add_argument("--seed-start", type=int, default=1000)
    parser.add_argument("--seed-end", type=int, default=1099)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    base = load(BASE_PATH, "society_lab_v1_4_1")
    life = load(args.life_path, f"life_under_pollution_check_{args.life_path.stem}")

    seeds = range(args.seed_start, args.seed_end + 1)
    drifted = []
    clean = []
    for seed in seeds:
        drift = compare_seed(seed, base.SocietyLab, life.LifeObservedSocietyLab)
        if drift:
            drifted.append(drift)
        else:
            clean.append(seed)

    result = {
        "base_path": str(BASE_PATH),
        "life_path": str(args.life_path),
        "seeds": f"{args.seed_start}-{args.seed_end}",
        "years": YEARS,
        "checked_count": len(clean) + len(drifted),
        "clean_count": len(clean),
        "drifted_count": len(drifted),
        "earliest": min(drifted, key=lambda item: (item["year"], item["seed"])) if drifted else None,
        "drifted": drifted,
    }

    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 1 if drifted else 0


if __name__ == "__main__":
    raise SystemExit(main())
