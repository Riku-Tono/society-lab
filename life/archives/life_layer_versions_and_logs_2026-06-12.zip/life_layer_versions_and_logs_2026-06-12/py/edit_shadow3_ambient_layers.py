from pathlib import Path
import os


for dirpath, _, filenames in os.walk(r"C:/Users/yauki/OneDrive"):
    if dirpath.endswith("SL3") and "society_lab_v1_4_life_senses_memory_shadow3.py" in filenames:
        path = Path(dirpath) / "society_lab_v1_4_life_senses_memory_shadow3.py"
        break
else:
    raise SystemExit("shadow3 not found")

text = path.read_text(encoding="utf-8")

constants = '''

# Ambient scaffolding. These are observation-only cultural traces.
# They do not create relationships, trust, support, or main memories.
AMBIENT_OBJECTS = (
    "warm_blanket",
    "needle",
    "thread_spool",
    "loom",
    "wooden_box",
    "old_book",
    "borrowed_book",
    "basket",
    "lantern",
    "paper_lantern",
    "wind_bell",
    "water_bucket",
    "fan",
    "festival_mask",
    "drum_stick",
    "small_drum",
    "watermelon_slice",
    "shaved_ice_bowl",
)

AMBIENT_SCENTS = (
    "summer_grass",
    "festival_smoke",
    "river_water",
    "old_paper",
    "ink",
    "fresh_rice",
    "harvest_field",
    "wet_cloth",
    "wood_shavings",
    "loom_dust",
)

AMBIENT_SOUNDS = (
    "loom_clicking",
    "distant_drum",
    "festival_noise",
    "wind_bell_sound",
    "pages_turning",
    "needle_against_cloth",
    "frogs_at_night",
    "water_from_spring",
    "children_running",
)

AMBIENT_PLACES = (
    "spring",
    "rice_field",
    "weaving_house",
    "book_house",
    "festival_square",
    "river_bank",
    "bridge",
    "shade_tree",
    "engawa",
    "watch_hill",
)

SEASONS = (
    "early_summer",
    "midsummer",
    "late_summer",
    "harvest_time",
    "cold_rain",
    "first_frost",
)

CROWD_MOODS = (
    "many_people_gathered",
    "music_somewhere",
    "festival_preparation",
    "shared_waiting",
    "crowd_nearby",
)
'''

old = '''SOUNDS = (
    "wind_through_thatch",
    "distant_rain",
    "someone_grinding",
    "fire_crackling",
    "distant_axe",
    "wind_through_grass",
    "child_somewhere",
    "birds_before_rain",
    "dog_far_off",
    "rain_on_thatch",
    "silence",
    "water_moving",
    "wood_settling",
    "wood_splitting",
    "something_dropped",
    "footsteps_leaving",
    "nothing",
    "nothing",
    "nothing",
)
'''
new = old + constants
if old not in text:
    raise SystemExit("SOUNDS block not found")
text = text.replace(old, new, 1)

old = '''        time_shadow_rng = self._life_rng("time_shadow")

        # 世界側の空気をまず記録する（茶屋と独立）
'''
new = '''        time_shadow_rng = self._life_rng("time_shadow")
        ambient_rng = self._life_rng("ambient_layers")

        # 世界側の空気をまず記録する（茶屋と独立）
'''
if old not in text:
    raise SystemExit("rng block not found")
text = text.replace(old, new, 1)

old = '''        if world_sense_rng.random() < 0.18:
            gesture = world_sense_rng.choice(WORLD_GESTURES)
            if gesture != "nothing_moved":
                place = self._choose_world_sense_place(weather, world_sense_rng)
                self._record_life(
                    "world_gesture",
                    [],
                    f"gesture={gesture}; place={place}; weather={weather}",
                )

        self._observe_people_in_places(
'''
new = '''        if world_sense_rng.random() < 0.18:
            gesture = world_sense_rng.choice(WORLD_GESTURES)
            if gesture != "nothing_moved":
                place = self._choose_world_sense_place(weather, world_sense_rng)
                self._record_life(
                    "world_gesture",
                    [],
                    f"gesture={gesture}; place={place}; weather={weather}",
                )

        self._observe_ambient_layers(ambient_rng, weather)

        self._observe_people_in_places(
'''
if old not in text:
    raise SystemExit("observe_life insertion point not found")
text = text.replace(old, new, 1)

method = '''    def _observe_ambient_layers(self, rng: random.Random, weather: str) -> None:
        season = rng.choice(SEASONS)
        self._record_life(
            "season",
            [],
            f"season={season}; weather={weather}",
        )

        if rng.random() < 0.65:
            place = rng.choice(AMBIENT_PLACES)
            obj = rng.choice(AMBIENT_OBJECTS)
            self._record_life(
                "ambient_object",
                [],
                f"object={obj}; place={place}; season={season}; weather={weather}",
            )

        if rng.random() < 0.45:
            place = rng.choice(AMBIENT_PLACES)
            scent = rng.choice(AMBIENT_SCENTS)
            self._record_life(
                "ambient_scent",
                [],
                f"scent={scent}; place={place}; season={season}; weather={weather}",
            )

        if rng.random() < 0.50:
            place = rng.choice(AMBIENT_PLACES)
            sound = rng.choice(AMBIENT_SOUNDS)
            self._record_life(
                "ambient_sound",
                [],
                f"sound={sound}; place={place}; season={season}; weather={weather}",
            )

        if rng.random() < 0.24:
            place = rng.choice(AMBIENT_PLACES)
            mood = rng.choice(CROWD_MOODS)
            self._record_life(
                "crowd_mood",
                [],
                f"mood={mood}; place={place}; season={season}; weather={weather}",
            )

'''

old = '''    def _observe_people_in_places(
'''
if old not in text:
    raise SystemExit("_observe_people_in_places not found")
text = text.replace(old, method + old, 1)

old = '''            "sound_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "sound"
            ),
            "place_presence_count": sum(
'''
new = '''            "sound_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "sound"
            ),
            "season_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "season"
            ),
            "ambient_object_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_object"
            ),
            "ambient_scent_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_scent"
            ),
            "ambient_sound_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "ambient_sound"
            ),
            "crowd_mood_count": sum(
                1
                for observation in self.life_observations
                if observation.event_type == "crowd_mood"
            ),
            "place_presence_count": sum(
'''
if old not in text:
    raise SystemExit("life_summary insertion point not found")
text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")
print(path)
