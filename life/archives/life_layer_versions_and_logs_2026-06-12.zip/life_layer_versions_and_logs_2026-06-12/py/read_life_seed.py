from __future__ import annotations

import argparse
import importlib.util
from collections import Counter, defaultdict
from pathlib import Path
import sys


BASE_PATH = Path(r"C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py")
LIFE_PATH = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-11\files-mentioned-by-the-user-society-2\outputs\society_lab_v1_4_life_senses_conversation_shadow.py"
)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def summarize_detail(detail: str, keys: tuple[str, ...]) -> str:
    parts = []
    for key in keys:
        marker = f"{key}="
        if marker not in detail:
            continue
        value = detail.split(marker, 1)[1].split(";", 1)[0].strip()
        parts.append(f"{key}={value}")
    return ", ".join(parts)


def place_from_presence(detail: str) -> str | None:
    marker = " appeared at "
    if marker not in detail:
        return None
    return detail.split(marker, 1)[1].split(";", 1)[0].strip()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=1003)
    parser.add_argument("--years", type=int, default=80)
    parser.add_argument("--life-path", type=Path, default=LIFE_PATH)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    load_module(BASE_PATH, "society_lab_v1_4_1")
    life_module = load_module(args.life_path, "life_seed_reading_target")

    sim = life_module.LifeObservedSocietyLab(seed=args.seed, verbose=False)
    sim.run(years=args.years)

    event_counts = Counter(obs.event_type for obs in sim.life_observations)
    person_places: dict[str, Counter[str]] = defaultdict(Counter)
    pair_events: dict[tuple[str, str], Counter[str]] = defaultdict(Counter)
    year_lines: dict[int, list[str]] = defaultdict(list)

    for obs in sim.life_observations:
        if obs.event_type == "place_presence" and obs.persons:
            place = place_from_presence(obs.detail)
            if place:
                person_places[obs.persons[0]][place] += 1

        if len(obs.persons) == 2 and obs.event_type in {
            "same_place_nearby",
            "distant_social",
            "conversation_shadow",
            "familiarity_shadow",
        }:
            pair = tuple(sorted(obs.persons))
            pair_events[pair][obs.event_type] += 1

        if obs.event_type in {
            "repeat_place",
            "same_place_nearby",
            "distant_social",
            "conversation_shadow",
            "familiarity_shadow",
            "memory_shadow",
            "gesture",
            "world_gesture",
            "affect_object",
            "touch",
            "scent",
        }:
            social_thread = obs.event_type in {
                "same_place_nearby",
                "distant_social",
                "conversation_shadow",
                "familiarity_shadow",
                "memory_shadow",
            }
            if len(year_lines[obs.year]) < 8 or social_thread:
                year_lines[obs.year].append(
                    f"- `{obs.event_type}` {','.join(obs.persons) or '-'}: {obs.detail}"
                )

    interesting_pairs = sorted(
        pair_events.items(),
        key=lambda item: (
            -item[1].get("conversation_shadow", 0),
            -item[1].get("distant_social", 0),
            -item[1].get("same_place_nearby", 0),
            item[0],
        ),
    )[:12]

    repeated_people = sorted(
        person_places.items(),
        key=lambda item: (-sum(item[1].values()), item[0]),
    )[:12]

    active_years = sorted(
        year_lines,
        key=lambda year: (
            -sum(1 for obs in sim.life_observations if obs.year == year and obs.event_type == "memory_shadow"),
            -sum(1 for obs in sim.life_observations if obs.year == year and obs.event_type == "familiarity_shadow"),
            -sum(1 for obs in sim.life_observations if obs.year == year and obs.event_type == "conversation_shadow"),
            -sum(1 for obs in sim.life_observations if obs.year == year and obs.event_type == "distant_social"),
            -len(year_lines[year]),
            year,
        ),
    )[:10]

    lines = [
        f"# Life Seed Reading: seed {args.seed}",
        "",
        "## Base Summary",
        "",
    ]
    for key, value in sim.summary().items():
        lines.append(f"- `{key}`: {value}")

    lines.extend(["", "## Life Event Counts", ""])
    for key, value in event_counts.most_common():
        lines.append(f"- `{key}`: {value}")

    lines.extend(["", "## Repeated Place Presence", ""])
    for person_id, places in repeated_people:
        rendered = ", ".join(f"{place}:{count}" for place, count in places.most_common())
        lines.append(f"- `{person_id}`: {rendered}")

    lines.extend(["", "## Pair Threads", ""])
    for pair, counts in interesting_pairs:
        rendered = ", ".join(f"{kind}:{count}" for kind, count in counts.most_common())
        lines.append(f"- `{pair[0]}|{pair[1]}`: {rendered}")

    lines.extend(["", "## Years To Read Closely", ""])
    for year in active_years:
        lines.append(f"### Year {year}")
        lines.extend(year_lines[year])
        lines.append("")

    text = "\n".join(lines).rstrip() + "\n"
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
