# society_lab conversation shadow notes

Created:

`society_lab_v1_4_life_senses_conversation_shadow.py`

Based on:

`society_lab_v1_4_life_senses_nearby_reviewed.py`

## Added

`conversation_shadow`

Examples:

- `a_few_words_exchanged`
- `shared_a_short_remark`
- `spoke_briefly`
- `commented_on_the_weather`
- `mentioned_the_road`
- `talked_near_the_fire`
- `said_almost_nothing`

## Design rule

Conversation shadows only appear after a confirmed proximity chain:

```text
same_place_nearby
-> distant_social
-> conversation_shadow
```

So the log never invents conversation between people who were not first observed in the same place.

No quoted speech is generated.
No conversation content is generated.
No emotion is named.
No base simulation state changes.

## Verification

Compared frozen `SocietyLab` and `LifeObservedSocietyLab` for seeds 1000-1099, 80 years each.

```json
{
  "status": "ok",
  "life_path": "work\\society_lab_v1_4_life_senses_conversation_shadow.py",
  "seeds": "1000-1099",
  "years": 80,
  "min_life_observations": 406,
  "max_life_observations": 1113,
  "min_tea_house": 10,
  "max_tea_house": 54,
  "min_trace": 19,
  "max_trace": 42,
  "min_sound": 52,
  "max_sound": 74
}
```

The base `summary()` stayed identical for all checked seeds.

## Seed 42 sample counts

```json
{
  "life_observation_count": 1062,
  "scent_count": 105,
  "touch_count": 62,
  "affect_object_count": 54,
  "animal_presence_count": 21,
  "repeat_place_count": 64,
  "rainy_tea_house_count": 38,
  "same_place_nearby_count": 76,
  "gesture_count": 40,
  "world_gesture_count": 5,
  "distant_social_count": 12,
  "conversation_shadow_count": 3
}
```

Seed 42 conversation shadow examples:

```text
Year 25: リオ and ノア: said_almost_nothing; place=path; weather=light_mist
Year 45: セナ and オルン: spoke_briefly; place=tea_house; weather=rain_on_roof
Year 62: ケイ and リオ: said_almost_nothing; place=storehouse; weather=rain_on_roof
```

## Next step

Read a seed before adding `near_touch`.

The current stack is:

```text
same_place_nearby
-> distant_social
-> conversation_shadow
```

This is already close to relationship, but still not contact and still not trust.
