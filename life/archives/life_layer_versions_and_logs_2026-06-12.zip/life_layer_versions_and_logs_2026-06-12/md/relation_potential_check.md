# relation_potential check

## changes

- Added life-side `life_relation_potential` state.
- Added `life_bridge_potential` observations at potential marks `8, 16, 24...`.
- Sources: `passing_greeting +1`, `distant_social +1`, `conversation_shadow +3`, `familiarity_shadow +2`, `memory_shadow +4`.
- `life_contact` remains observation-only and contributes `+0`.
- No trust, support, main memory, food, health, birth, death, or base dynamics were changed.

## checks

- compile_ok: `True`
- pollution_diffs seed1000-1099: `0`
- stable_event_diffs_with_relation_potential_disabled: `0`

Stable event comparison excludes only the new `life_bridge_potential` event and includes weather, season, ambient layers, place/co-presence, contact, social shadows, memory_shadow, and time_shadow.

## 100 seed stats

| metric | min | max | avg | nonzero |
| --- | ---: | ---: | ---: | ---: |
| `life_bridge_potential_count` | 0 | 4 | 0.92 | 55 |
| `relation_potential_max_score` | 0.0 | 22.0 | 8.06 | 99 |
| `relation_potential_avg_score_among_nonzero_pairs` | 0.0 | 6.0 | 2.5 | 99 |
| `relation_potential_gte_8_pair_count` | 0 | 4 | 0.87 | 55 |
| `relation_potential_gte_16_pair_count` | 0 | 1 | 0.05 | 5 |

## seed1003

- Counts: `life_contact=21`, `passing_greeting=6`, `distant_social=3`, `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `life_bridge_potential=0`, `time_shadow=8`
- Top potentials: `p001|p015=1.0`, `p003|p014=1.0`, `p005|p019=1.0`, `p006|p036=1.0`, `p012|p013=1.0`
- Bridge marks: none

## seed1061

- Counts: `life_contact=38`, `passing_greeting=7`, `distant_social=8`, `conversation_shadow=2`, `familiarity_shadow=3`, `memory_shadow=1`, `life_bridge_potential=1`, `time_shadow=7`
- Top potentials: `p007|p051=10.0`, `p036|p044=6.0`, `p056|p057=4.0`, `p006|p053=1.0`, `p007|p027=1.0`
- Bridge marks:
  - Y60 `p007|p051` potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=rain_on_roof

## reading

seed1003 remains quiet if `life_bridge_potential` does not mark heavily: life_contact and greetings exist, but ordinary co-presence does not become a relation candidate by itself.

seed1061 should show relation candidates where the prior conversation/familiarity/memory path gathers enough weight to become visible before any trust change exists.

Reader output: `C:\Users\yauki\Documents\Codex\2026-06-12\files-mentioned-by-the-user-society\outputs\life_observation_reader_seed1003_1061_relation_potential.txt`
