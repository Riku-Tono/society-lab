# 時間の影 影響チェック

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_1.py`
- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow2.py`

## 結論

`time_shadow`を含む生活観察レイヤーは、世界本体の進行には影響していません。

seed `1000`から`1099`までの100ケースで、基準版と影版を80年実行し、以下がすべて完全一致しました。

- `summary()`
- 人物状態
- 食料状態
- 通常イベントログ
- 記憶系trace
- 支援trace
- project aftermath trace

差分は、影版だけが持つ`life_observations`と`life_summary()`に限定されます。

## 集計

影版の生活観察レイヤーでは、100 seedすべてで`time_shadow`が発生しました。

| 指標 | min | max | avg | nonzero |
|---|---:|---:|---:|---:|
| life_observation_count | 406 | 1168 | 743.12 | 100 |
| time_shadow_count | 1 | 18 | 7.25 | 100 |
| memory_shadow_count | 0 | 2 | 0.15 | 12 |
| familiarity_shadow_count | 0 | 8 | 1.84 | 75 |
| conversation_shadow_count | 0 | 8 | 1.70 | 74 |
| same_place_nearby_count | 3 | 78 | 30.76 | 100 |

`time_shadow`合計は100 seedで725件でした。

## 多く出たseed

| seed | time_shadow_count | life_observation_count |
|---:|---:|---:|
| 1087 | 18 | 946 |
| 1061 | 17 | 1135 |
| 1084 | 16 | 1168 |
| 1091 | 16 | 885 |
| 1035 | 15 | 1097 |
| 1041 | 15 | 1026 |

## seed 1087の例

- Year 28: `long_absence_at_the_place`, storehouse, first_year=12, previous_year=12
- Year 36: `path_found_again`, tea_house, first_year=1, previous_year=1
- Year 58: `years_laid_thinly_over_the_place`, hearth, first_year=3, previous_year=14
- Year 62: `old_place_under_same_weather`, tea_house, first_year=37, previous_year=37

## 注意点

`time_shadow`を無効化した派生クラスと比較すると、生活観察サマリは100/100 seedで変わりました。

これは世界本体への影響ではなく、同じ生活観察用RNGの中で`time_shadow`判定と記録が増えるため、後続の生活観察イベント列も少しずれるためです。

つまり:

- 世界シミュレーションへの影響: なし
- 読み物としての生活ログへの影響: あり
- `time_shadow`自体の出現: 100 seedすべてで確認

