# society_lab life micro places notes

Created:

`society_lab_v1_4_life_micro_places.py`

This is a derived play branch from the cleaned life/sound layer.

## Added as observation-only life

- `genmaicha` was added to tea.
- Tea vessels can now be `chipped`.
- People may appear at:
  - `tea_house`
  - `well`
  - `storehouse`
  - `hearth`
  - `gate`
  - `path`
- Rainy days can produce `rainy_tea_house`.
- Hearth observations can produce `brazier_presence`.
- Well observations can produce `well_water`.
- Storehouse observations can produce `storehouse_bag`.
- Children can produce `child_bowl`.
- Elders can produce `elder_sitting`.
- Repeated appearances at the same place produce `repeat_place`.

## Carefully state-shaped, but still non-causal

The observation layer now uses existing person state to choose where someone is likely to appear:

- age changes place preference a little
- high hunger nudges a person toward `storehouse` or `well`
- high fear nudges a person away from crowded or exposed places
- rainy weather nudges observations indoors

No base-world values are changed:

- no food changes
- no health changes
- no trust changes
- no memory changes
- no support changes
- no birth or death changes

## Verification

Compared frozen `SocietyLab` and `LifeObservedSocietyLab` for seeds 1000-1099, 80 years each.

```json
{
  "status": "ok",
  "life_path": "work\\society_lab_v1_4_life_micro_places.py",
  "seeds": "1000-1099",
  "years": 80,
  "min_life_observations": 294,
  "max_life_observations": 682,
  "min_tea_house": 13,
  "max_tea_house": 51,
  "min_trace": 19,
  "max_trace": 42,
  "min_sound": 52,
  "max_sound": 74
}
```

The base `summary()` stayed identical for all checked seeds.

## Next cautious causal step

The safest first causal change would be:

Repeated same-place appearances create a tiny, bounded familiarity nudge.

For example:

- only after `repeat_place`
- only between people observed in the same place in the same year
- trust delta no larger than `+0.003`
- never applied to food, health, birth, or death

This would let life observations start to bend memory/support routes without turning weather or hunger into direct outcome machinery.
