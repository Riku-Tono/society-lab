# shadow3 memory_shadow_chance調整チェック

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow3.py`

## 採用値

```python
memory_shadow_chance = 0.50
```

最初に`0.20`を試したが、発火量が弱かった。

| chance | min | max | avg | nonzero |
|---:|---:|---:|---:|---:|
| 0.20 | 0 | 3 | 0.31 | 22 |
| 0.24 | 0 | 3 | 0.38 | 24 |
| 0.30 | 0 | 4 | 0.43 | 26 |
| 0.36 | 0 | 4 | 0.52 | 30 |
| 0.42 | 0 | 4 | 0.60 | 32 |
| 0.50 | 0 | 5 | 0.68 | 35 |
| 0.60 | 0 | 6 | 0.80 | 37 |

`0.60`は平均だけ見ると良いが、maxが`6`に上がる。今回は「max 5以下」を優先し、`0.50`を採用した。

## 汚染チェック

seed `1000`から`1099`まで、80年実行。

base `SocietyLab` と `LifeObservedSocietyLab` で以下を比較し、完全一致。

- `summary()`
- 人物状態
- 食料状態
- 通常イベントログ
- 記憶系trace
- 支援trace
- project aftermath trace

結果:

```text
world_snapshot_diffs 0 []
```

## stream独立性チェック

`time_shadow`無効化時:

```text
time_disabled_memory_or_conversation_diffs 0 []
```

`memory_shadow_chance = 0.12`との比較で、以下はズレなし。

- `weather`
- `place_presence`
- `same_place_nearby`
- `conversation_shadow`
- `time_shadow`

結果:

```text
chance_changed_stable_event_diffs 0 []
```

## 採用値0.50での集計

| 指標 | min | max | avg | nonzero |
|---|---:|---:|---:|---:|
| memory_shadow_count | 0 | 5 | 0.68 | 35 |
| memory_shadow_count_at_0.12 | 0 | 2 | 0.16 | 14 |
| conversation_shadow_count | 0 | 7 | 1.60 | 74 |
| time_shadow_count | 1 | 18 | 7.75 | 100 |
| life_observation_count | 428 | 1086 | 744.73 | 100 |

## 多く出たseed

| seed | memory_shadow | at 0.12 | conversation_shadow | time_shadow |
|---:|---:|---:|---:|---:|
| 1042 | 5 | 2 | 3 | 13 |
| 1009 | 4 | 1 | 4 | 14 |
| 1059 | 4 | 1 | 4 | 8 |
| 1085 | 4 | 0 | 2 | 8 |
| 1096 | 4 | 2 | 6 | 16 |

## seed1003 / seed1061

seed1003:

```text
memory_shadow_count 0
conversation_shadow_count 0
time_shadow_count 8
```

seed1061:

```text
memory_shadow_count 1
conversation_shadow_count 2
time_shadow_count 7
```

seed1061のmemory_shadow:

```text
Year60 p007,p051
イシュ: looked_toward_the_old_place; place=tea_house; weather=rain_on_roof; prior_year=43; prior_score=7
```

## 判断

`0.50`は目標平均`0.8-1.5`には少し届かないが、`max 5以下`を守りつつ、`0.12`の約4倍の平均発火量になった。

生活ログの読みに対しては、まだ控えめだが「ほとんど出ない」状態からは脱している。次に強めるなら`0.60`だが、max `6`を許容するかの判断が必要。

