# seed1003: p033 around Year31

Source:

`society_lab_v1_4_life_senses_familiarity_shadow.py`

Important correction:

In the current run, `p031` does not die in Year31.

- `p031` is カイ.
- `p031` dies in Year65: `カイ died age=96 health=1.00`.
- `p033` is ファラ.
- `p033` dies in Year43: `ファラ died age=88 health=1.00`.
- The death in Year31 is `p005`, not `p031`.

So the readable scene below is:

`p033 / ファラ around Year31`, not `p033 around p031's death`.

## Facts Around Year31

### Base-layer facts

- Year28: a death-related shared narrative includes both `p031` and `p033`.
- Year29: `p031 / カイ` tells `p033 / ファラ` about a death.
- Year30: `p033 / ファラ` tells `p013 / ファラ` about a death.
- Year31: a death occurs, but it is `p005`, not `p031`.
- Year32: a project-failure shared narrative includes both `p031` and `p033`.
- Year33: `p031 / カイ` again tells `p033 / ファラ` about a death.
- Year34: `p033 / ファラ` tells others about a death.

### Life-layer facts

Year28:

- rain on roof, cold morning, no fire
- no direct `p033` life observation

Year29:

- overcast, midday, fire going
- no direct `p033` life observation

Year30:

- heavy rain, midday, smoke lingering
- a world gesture happens: someone stood still at the gate
- no direct `p033` life observation

Year31:

- dry wind
- evening steam
- no fire
- sound: rain on thatch
- `p033 / ファラ` appears at the gate
- `p033 / ファラ` touches rough wood with the palm
- `p033 / ファラ` is associated with a cracked ladle
- `p033 / ファラ` whispers to no one
- no `same_place_nearby` for `p033` in Year31
- no `distant_social` for `p033` in Year31
- no `conversation_shadow` for `p033` in Year31

Year32:

- overcast, midday, embers only
- no direct `p033` life observation

Year33:

- clear, cold morning, fire going
- no direct `p033` life observation

Year34:

- light mist, late afternoon, no fire
- world gesture: a whisper nearby at the tea house
- no direct `p033` life observation

## Story Reading

Around Year31, ファラ is not surrounded by people in the life layer.

Before that year, death has already moved through the village as a shared narrative. In Year29, カイ tells ファラ about a death. In Year30, ファラ passes a death story on to another person. So by the time Year31 arrives, ファラ is already inside a chain of death-memory, but the life layer does not place her in a group.

Year30 is heavy rain. Someone stands still at the gate, but the log does not say who. It is only a world gesture.

Then Year31 comes with dry wind and evening steam. There is no fire. The sound says rain on thatch, even though the weather is dry wind. ファラ appears alone at the gate.

She does not meet anyone there in the life layer.

There is no same-place pair.
There is no distant social gesture.
There is no conversation shadow.

Instead, the life layer gives three small details:

```text
rough_wood_against_palm
cracked_ladle
whispered_to_no_one
```

So the scene is not "ファラ and someone spoke at the gate."

It is quieter than that:

ファラ is at the gate in dry wind, with no fire in the year. Her palm is against rough wood. A cracked ladle is in the scene. She whispers to no one.

The base simulation says death stories are moving around her. The life layer says she is alone at the gate.

That is the shape.

## What Not To Overread

- Do not read Year31 as p031's death. It is not, in this run.
- Do not read a direct p031/p033 meeting in Year31. The life layer does not record one.
- Do not read a conversation shadow for p033 in Year31. There is none.
- Do not read trust or memory changes from the life layer. It still does not write those.

## If You Meant p031's Actual Death

`p031 / カイ` dies in Year65.

But `p033 / ファラ` died in Year43.

So there is no p033 life-layer presence around p031's actual death. Around Year65, the life layer records only world-level details related to this query:

- heavy rain
- midday
- fire going
- dog far off
- a world gesture: eyes from doorway at the tea house

That scene belongs to カイ's death year, but not to ファラ.
