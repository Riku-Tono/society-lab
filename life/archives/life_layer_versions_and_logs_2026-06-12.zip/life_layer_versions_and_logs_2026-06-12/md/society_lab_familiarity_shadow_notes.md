# society_lab familiarity shadow notes

Created:

`society_lab_v1_4_life_senses_familiarity_shadow.py`

Based on:

`society_lab_v1_4_life_senses_conversation_shadow.py`

## Added

`familiarity_shadow`

This is still life-layer-only. It does not change:

- trust
- memory
- support
- food
- health
- birth
- death
- proposal outcomes

## Scoring

Each pair gets a private life-layer familiarity score:

```text
same_place_nearby      +1
distant_social         +2
conversation_shadow    +4
```

Whenever the score crosses a multiple of 4, the model records:

```text
life:familiarity_shadow
```

This means:

- one `conversation_shadow` is enough to create a shadow
- repeated pure proximity can also create a shadow, but only after several repeats
- no direct relationship is asserted
- no trust is changed

## Example

```text
life:familiarity_shadow: p031,p045 |
カイ and セナ: repeated brief nearness; place=well; weather=dry_wind; source=conversation_shadow; score=7
```

## Verification

Compared frozen `SocietyLab` and `LifeObservedSocietyLab` for seeds 1000-1099, 80 years each.

```json
{
  "status": "ok",
  "life_path": "work\\society_lab_v1_4_life_senses_familiarity_shadow.py",
  "seeds": "1000-1099",
  "years": 80,
  "min_life_observations": 406,
  "max_life_observations": 1124,
  "min_tea_house": 10,
  "max_tea_house": 54,
  "min_trace": 19,
  "max_trace": 42,
  "min_sound": 52,
  "max_sound": 74
}
```

The base `summary()` stayed identical for all checked seeds.

## Seed 42 sample counts

```json
{
  "life_observation_count": 1065,
  "same_place_nearby_count": 76,
  "distant_social_count": 12,
  "conversation_shadow_count": 3,
  "familiarity_shadow_count": 3
}
```

## Seed 1003 reading

`life_seed_1003_familiarity_reading.md` now includes `familiarity_shadow`.

Seed 1003 produced:

```text
distant_social: 11
conversation_shadow: 4
familiarity_shadow: 4
```

All four familiarity shadows came through `conversation_shadow`, so the layer is not turning casual proximity into relationship too easily.

## Next caution

The next dangerous layer is not trust yet. It is probably `memory_shadow`, because that would make the life layer cross time.
