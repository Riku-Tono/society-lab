# seed1003 / seed1061 life観測層 読解

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow3.py`
- `memory_shadow_chance = 0.50`
- 80年実行

見る項目:

- `place_presence`
- `repeat_place`
- `same_place_nearby`
- `distant_social`
- `conversation_shadow`
- `familiarity_shadow`
- `memory_shadow`
- `time_shadow`

## ChatGPT用

### seed1003

seed1003は「場所の時間」が前面に出るseed。

本体summaryでは、老いた村。初期人口35、最終人口18。death_count 35、birth_count 18。共同記憶や支援traceはあるが、life層で見ると、人と人の会話の痕跡はほとんど立ち上がらない。

life層の主要カウント:

| event | count |
|---|---:|
| place_presence | 148 |
| repeat_place | 30 |
| same_place_nearby | 25 |
| distant_social | 3 |
| conversation_shadow | 0 |
| familiarity_shadow | 0 |
| memory_shadow | 0 |
| time_shadow | 8 |

特徴:

- `time_shadow`は8件ある。
- `memory_shadow`は0件。
- `conversation_shadow`も0件。
- つまり「人が人を思い出す」より、「場所が時間を抱えている」。
- 井戸、茶屋、炉辺が中心。特に井戸と茶屋が多い。

主なtime_shadow:

```text
Y25 シオン: well, first_year=5, previous_year=5, years_since_visit=20
Y27 シオン: hearth, first_year=12, previous_year=12, years_since_visit=15
Y40 ゾル: tea_house, first_year=1, previous_year=1, years_since_visit=39
Y50 シオン: well, first_year=5, previous_year=25, years_since_visit=25
Y58 ケイ: tea_house, first_year=45, previous_year=45, years_since_visit=13
Y63 ユラ: well, first_year=11, previous_year=60, place_age=52
Y66 ルト: hearth, first_year=36, previous_year=59, place_age=30
Y73 ユラ: tea_house, first_year=67, previous_year=67
```

読み:

seed1003では、交差はあるが関係として厚くならない。`same_place_nearby`は25件あるが、`conversation_shadow`にも`familiarity_shadow`にもならない。3件の`distant_social`も、困った顔や笑いが一瞬見えるだけで、記憶の線にはならない。

ここで残るのは、シオンが井戸と炉辺へ戻ること、ゾルがYear1の茶屋へYear40に戻ること、ユラが古い井戸や茶屋へ再び現れること。村の個性は「誰かとの関係」ではなく、「以前そこにいた場所が、後年また同じ人を受け止める」形で読める。

短く言うと:

```text
seed1003 = 場所だけが古びる村。
人の会話は沈黙し、井戸・茶屋・炉辺だけが時間を覚えている。
```

### seed1061

seed1061は「人の時間」が立ち上がるseed。

本体summaryでは、より人口が残る村。初期人口37、最終人口34。death_count 32、birth_count 29。seed1003より村が保たれ、人の交差も多い。

life層の主要カウント:

| event | count |
|---|---:|
| place_presence | 209 |
| repeat_place | 53 |
| same_place_nearby | 49 |
| distant_social | 8 |
| conversation_shadow | 2 |
| familiarity_shadow | 2 |
| memory_shadow | 1 |
| time_shadow | 7 |

特徴:

- `same_place_nearby`が49件あり、seed1003の約2倍。
- `conversation_shadow`が2件ある。
- `familiarity_shadow`が2件ある。
- `memory_shadow`が1件出る。
- `time_shadow`も7件あり、場所の時間も残る。

重要な流れ:

```text
Y41 ハナ and ゾル: spoke_briefly; place=well
Y41 ハナ and ゾル: familiarity_shadow; score=7

Y43 セナ and イシュ: talked_near_the_fire; place=tea_house
Y43 セナ and イシュ: familiarity_shadow; score=7

Y60 イシュ: looked_toward_the_old_place; place=tea_house; prior_year=43; prior_score=7
```

Year43の茶屋で、セナとイシュが短く言葉を交わす。その場で`familiarity_shadow`がつき、score=7になる。17年後のYear60、イシュが雨音のある茶屋に現れ、`looked_toward_the_old_place`が出る。ここで`memory_shadow`は本体memoryではなくlife観測上の影だが、読解上は「人の交差が場所に残り、後年その人の仕草として戻る」。

短く言うと:

```text
seed1061 = 人の交差が時間に残る村。
場所は古びるだけでなく、そこで交わされた短い言葉を後年に返す。
```

### 比較

| 観点 | seed1003 | seed1061 |
|---|---|---|
| 村の印象 | 老いた、静か | 人が残り、交差が多い |
| place_presence | 148 | 209 |
| same_place_nearby | 25 | 49 |
| conversation_shadow | 0 | 2 |
| familiarity_shadow | 0 | 2 |
| memory_shadow | 0 | 1 |
| time_shadow | 8 | 7 |
| 読み | 場所の時間 | 人の時間 |

読解テストとしては成功。

`life`層は本体を変えずに、seedごとの村の質感を分けて見せている。seed1003では場所だけが古び、seed1061では人の交差が場所を経由して後年の影になる。

## 私用 物語形式

### seed1003: 場所だけが古びる村

この村では、人はあまり言葉を残さない。

井戸のそばに並ぶことはある。門の近くで、誰かと誰かが同じ年に通り過ぎることもある。炉辺で笑いが一度だけ見える。けれど、それは会話にはならない。親しさの影にもならない。あとから誰かが誰かを思い出すほどの線にはならない。

だから、この村で古びていくのは人間関係ではなく、場所のほうだ。

Year25、シオンが井戸に戻る。そこはYear5に一度いた場所で、20年が過ぎている。井戸は何も語らない。ただ、前にもここにいたという形だけが残る。

Year27、シオンは炉辺に戻る。雨が屋根を打っている。15年前の炉辺が、もう一度同じ人を受け止める。

Year40、ゾルが茶屋に現れる。Year1の茶屋から39年が過ぎている。誰かと話したからではない。約束があったからでもない。ただ、そこに一度いた場所が、長い時間のあとにまた開く。

この村の時間は、人の胸ではなく、井戸と茶屋と炉辺に沈む。

人々は生まれ、死に、村は小さくなる。けれどlife層で見えるものは、濃い関係ではない。場所の上に薄く積もった年数だ。

seed1003は、誰かが誰かを覚えている村ではない。

それでも、完全に何も残らない村でもない。

井戸が覚えている。茶屋が覚えている。炉辺が覚えている。

人が静かすぎるぶん、場所だけが古くなる。

### seed1061: 人の交差が時間に残る村

この村では、人がよく同じ場所に現れる。

茶屋、井戸、倉庫、炉辺。誰かがそこにいて、別の誰かもそこにいる。最初はただ近くにいるだけだ。見返す。遠くから手を振る。短く言葉を交わす。

Year41、井戸でハナとゾルが短く話す。大きな出来事ではない。`spoke_briefly`、それだけ。けれど、その短さがこの村では消えず、`familiarity_shadow`になる。

Year43、茶屋でセナとイシュが火の近くで話す。これもまた短い。けれどscore=7の親しさの影になる。

そしてYear60、イシュが雨の日の茶屋に戻る。

そのとき出るのは、本体memoryではない。世界のtrustもsupportも動かない。誰かの人生を数値として変えるものではない。

でもlife層では、イシュが「古い場所のほうを見る」。

Year43にセナといた茶屋。そこから17年が過ぎた茶屋。雨が屋根を打つ茶屋。

この一件が、seed1061をseed1003から分ける。

seed1003では、場所が古びても人の記憶にはならなかった。seed1061では、人の交差が場所に残り、その場所が後年、ひとりの仕草として戻ってくる。

この村の時間は、場所だけのものではない。

人が通り、人が言葉を置き、その言葉が消えたあと、場所がそれを薄く返す。

seed1061は、誰かが誰かをはっきり覚えている村ではない。

でも、誰かといた場所を、身体が一瞬だけ向いてしまう村だ。

## 判断

この読解では、`life`層の追加は効いている。

本体の因果は動かしていない。それでも、seed1003とseed1061は違う村として読める。

- seed1003: 場所だけが古びる。
- seed1061: 人の交差が場所に残る。

次に進むなら、`season_return`の前に、まずログ整形を少し考えてもよい。今のままでも読めるが、`memory_shadow`の前提になる`conversation_shadow`と`familiarity_shadow`を追いやすくすると、観測層の意味がかなり見えやすくなる。

