# seed1003 familiarity_shadow story

This is a story-style reading from:

`society_lab_v1_4_life_senses_familiarity_shadow.py`

It does not claim hidden emotions, trust changes, or actual dialogue content.
It reads only what the life layer recorded.

## Shape Of The Village

Seed1003 begins as an old village.

- initial population: 35
- final population: 18
- death count: 35
- birth count: 18
- crisis count: 0
- network split count: 4

The village does not burn through open crisis.
It thins.

The life layer records many small things:

- 161 place presences
- 84 scents
- 53 touches
- 36 same-place nearness events
- 11 distant social gestures
- 4 conversation shadows
- 4 familiarity shadows

So the seed does not read like a village full of dramatic meetings.
It reads like a quiet old settlement where only a few contacts become legible.

## Year 4: Hearth, Clear Weather

The first familiarity shadow appears very early, in Year4.

The weather is clear.

Around the hearth, there are small bodily facts:

- ファラ has `straw_mat_under_knees`
- タロ has `ash_on_sleeve`
- タロ `sat_without_moving`

Then the life layer records:

```text
ファラ and タロ both near hearth
ファラ and タロ: smiled_toward_someone
ファラ and タロ: a_few_words_exchanged
ファラ and タロ: repeated brief nearness
```

This does not say they became close.
It does not say trust moved.

But the scene has enough pieces for the reader's mind to assemble a small human moment:

two people near the same fire,
one with knees on straw,
one with ash on a sleeve,
a smile not quite directed into certainty,
and a few words.

The first `familiarity_shadow` is not dramatic.
It is hearth-level.

## Year 37: Well, Rain On Roof

Much later, the second familiarity shadow appears at the well.

The weather is `rain_on_roof`.

Before the pair event, the log gives another person nearby:

- ファラ has `old_wood`
- ファラ has `straw_mat_under_knees`
- ファラ has `chipped_cup`

Then:

```text
メイ and ルト both near well
メイ and ルト: waved_from_a_distance
メイ and ルト: shared_a_short_remark
メイ and ルト: repeated brief nearness
```

This one is colder than the hearth scene.

The place is not inside warmth. It is the well, under rain. The gesture is from a distance. The conversation is only a short remark.

But it is enough for `familiarity_shadow`.

The village is beginning to show a pattern:

not friendship,
not trust,
not memory,
but repeated nearness with a small visible sign.

## Year 38: Tea House, Light Mist

The next year, Year38, the tea house becomes the place.

The weather is `light_mist`.

シオン appears at the tea house again.
The log says:

- `repeat_place`
- `steam_on_face`

Elsewhere in the same year, ノア is at the storehouse:

- `mended_rope`
- `rough_sackcloth`
- `whispered_to_no_one`

Then the pair event:

```text
セナ and シオン both near tea_house
セナ and シオン: waved_from_a_distance
セナ and シオン: talked_near_the_fire
セナ and シオン: repeated brief nearness
```

This one is the most explicitly social of the four, but still restrained.

They do not have a quoted conversation.
No one says what was discussed.
The life layer only says they talked near the fire.

The tea house now holds a different kind of warmth than the hearth in Year4:

not just shared place,
but a public room,
mist outside,
steam on a face,
and a short trace of words.

## Year 60: Well, Dry Wind

The last familiarity shadow comes much later, in Year60.

The village is older now.

At the well:

- カイ appears there again
- セナ appears there again
- カイ has `warm_bowl`
- セナ `sat_without_moving`

Then:

```text
カイ and セナ both near well
カイ and セナ: almost_called_out
カイ and セナ: spoke_briefly
カイ and セナ: repeated brief nearness
```

This is the sharpest scene.

The phrase `almost_called_out` matters because it is not yet a call.
It is a social motion that stops before becoming direct.

Then `spoke_briefly`.

Not a conversation with content.
Not confession.
Not trust.

Just a brief speech at the well, after both had appeared there again.

This is the moment where the seed feels most like it is approaching relationship without crossing into relationship mechanics.

## Overall Reading

Seed1003's `familiarity_shadow` does not form a dense social web.

It forms four small points:

```text
Year 4   hearth      ファラ / タロ
Year 37  well        メイ / ルト
Year 38  tea_house   セナ / シオン
Year 60  well        カイ / セナ
```

The places matter:

- hearth
- well
- tea house
- well again

So the familiarity is not abstract.
It grows out of places.

The hearth gives warmth.
The well gives repeated return.
The tea house gives public nearness.
The well returns later, older and drier.

The strongest thing about this seed is restraint.

The people do not become friends in the code.
The trust values do not move.
The base simulation does not change.

But the life layer makes the reader notice:

someone sat still,
someone waved from a distance,
someone spoke briefly,
someone almost called out.

That is enough.

## One-Sentence Reading

Seed1003 is an old village where familiarity does not become a social force yet; it appears only as a few brief shadows at the hearth, the well, and the tea house.
