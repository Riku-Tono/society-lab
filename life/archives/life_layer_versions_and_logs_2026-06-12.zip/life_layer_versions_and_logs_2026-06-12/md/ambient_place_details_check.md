# ambient place details追加チェック

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow3.py`
- `C:\Users\yauki\OneDrive\デスクトップ\SL3\life_observation_reader.py`

## 追加内容

`ambient_layers`の文化棚を拡張した。

追加した場所カテゴリ:

- `book_house`
- `weaving_house`
- `spring`
- `rice_field`
- `festival_square`
- `engawa`

各場所に専用の観測語彙を持たせた。

- objects
- scents
- sounds
- scenes

追加イベント:

- `ambient_place_object`
- `ambient_place_scent`
- `ambient_place_sound`
- `ambient_place_scene`

専用RNG stream:

```text
ambient_place_details
```

既存の`ambient_layers`、`life_contact`、`memory_shadow`、`time_shadow`のRNG streamは消費しない。

## やっていないこと

- festivalで人を集める
- dance / bon_odoriを人物ペアや集団行動にする
- book_exchangeを人物間関係にする
- rice_fieldをfoodに反映する
- harvest resultをfoodに接続する
- weavingをsupport / healthに接続する
- springをhealth / foodに接続する
- trust変更
- support変更
- main memory変更
- near_touch / gentle_contact追加

## 検証

seed `1000-1099`、80年。

```text
compiled ok
world_snapshot_diffs 0 []
stable_event_diffs_without_ambient_place_details 0 []
```

本体汚染なし。

`ambient_place_details`を無効化しても、以下の既存イベントはズレなし。

- `weather`
- `season`
- `ambient_object`
- `ambient_scent`
- `ambient_sound`
- `crowd_mood`
- `place_presence`
- `same_place_nearby`
- `life_contact`
- `passing_greeting`
- `distant_social`
- `conversation_shadow`
- `familiarity_shadow`
- `memory_shadow`
- `time_shadow`

## 新規イベント量

| event | min | max | avg | nonzero |
|---|---:|---:|---:|---:|
| ambient_place_object_count | 43 | 66 | 55.84 | 100 |
| ambient_place_scent_count | 33 | 52 | 41.84 | 100 |
| ambient_place_sound_count | 29 | 56 | 44.18 | 100 |
| ambient_place_scene_count | 25 | 44 | 33.52 | 100 |
| life_observation_count | 830 | 1566 | 1175.75 | 100 |

## seed1003

```text
ambient_place_object_count 57
ambient_place_scent_count 38
ambient_place_sound_count 49
ambient_place_scene_count 36
life_observation_count 1124
```

readerで見える例:

```text
festival_square:
  object=shaved_ice_bowl, festival_mask, paper_lantern, small_drum
  scent=sweet_shaved_ice, festival_smoke, summer_grass
  sound=festival_noise, distant_drum, wind_bell_sound
  scene=lanterns_before_evening, many_people_gathered, festival_preparation_nearby

rice_field:
  object=hoe, rice_heads_bending, muddy_water, golden_field
  scent=wet_soil, fresh_rice, harvest_smell
  sound=water_in_field_rows, frogs_at_night, wind_through_rice
```

seed1003は、文化棚が増えても社会経路は静かなまま。

## seed1061

```text
ambient_place_object_count 50
ambient_place_scent_count 51
ambient_place_sound_count 48
ambient_place_scene_count 29
life_observation_count 1387
```

readerで見える例:

```text
book_house:
  object=old_book, worn_pages, copied_text, borrowed_book
  scent=old_paper, dry_wood, ink_smell
  sound=pages_turning, brush_on_paper, quiet_reading
  scene=copied_pages_drying, quiet_reading_corner, books_stacked_low

engawa:
  object=wind_bell, old_wood_floor, tea_cup_nearby, fan
  scent=summer_insects, old_wood, cool_evening_air
  sound=summer_insects, wind_bell_sound, someone_resting_in_shade
```

seed1061は、人の交差が場所に残る読みを保ったまま、村の文化的な背景が濃くなった。

## reader改善

`life_observation_reader.py`に`Ambient places`サマリを追加した。

出力例:

```text
Ambient places
  book_house: object=old_book, copied_text | scent=ink_smell | sound=pages_turning
  weaving_house: object=loom, thread_spool | sound=loom_clicking
  spring: object=cold_water, mossy_stone | scene=stone_pool_in_shade
```

確認出力:

- `outputs/life_observation_reader_seed1003_1061_ambient_places.txt`

## 判断

これは社会機能ではなく、文化的観測棚。

「村に何があるか」を増やしただけで、「人が何をするか」や「関係がどう変わるか」にはまだ接続していない。今の段階としては安全。

