# life_contact A/B/C比較と採用結果

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_1.py`
- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow3.py`
- `C:\Users\yauki\OneDrive\デスクトップ\SL3\life_observation_reader.py`

## 実装

`life_contact`を採用した。

追加イベント:

- `life_contact`
- `passing_greeting`

`life_contact`は`same_place_nearby`から独立stream `life_contact`で派生する。

採用した方式は案B。

```python
life_contact_chance = 0.72
passing_greeting_chance = 0.22
life_contact_familiarity_weight = 0
passing_greeting_familiarity_weight = 2
distant_social_familiarity_weight = 2
conversation_shadow_familiarity_weight = 4
familiarity_mark_divisor = 4
```

意味:

- `same_place_nearby`: 同じ場所・同じ年にいた
- `life_contact`: 生活上の短い接触があった
- `passing_greeting`: 接触の中で軽い挨拶があった
- `life_contact`自体はfamiliarityに加算しない
- `passing_greeting`以上からfamiliarityに加算する

## 汚染チェック

seed `1000-1099`、80年。

案A/B/Cすべてで本体汚染なし。

```text
pollution A 0 []
pollution B 0 []
pollution C 0 []
```

採用案Bの最終確認:

```text
world_snapshot_diffs 0 []
```

比較対象:

- `summary()`
- 人物状態
- food状態
- main ObservationLog
- memory_lineage_trace
- support_chain_trace
- project_aftermath_trace

## 既存イベント安定性

案A/B/Cでfamiliarityへの接続方式を変えても、以下はズレなし。

- `weather`
- `season`
- `ambient_object`
- `ambient_scent`
- `ambient_sound`
- `crowd_mood`
- `place_presence`
- `same_place_nearby`
- `life_contact`
- `passing_greeting`
- `distant_social`
- `conversation_shadow`
- `time_shadow`

```text
B_vs_A stable_diffs 0 []
C_vs_A stable_diffs 0 []
```

## A/B/C 集計

| event | A avg | A max | A nonzero | B avg | B max | B nonzero | C avg | C max | C nonzero |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| life_observation_count | 1000.46 | 1378 | 100 | 1000.37 | 1378 | 100 | 997.21 | 1371 | 100 |
| same_place_nearby_count | 30.62 | 74 | 100 | 30.62 | 74 | 100 | 30.62 | 74 | 100 |
| life_contact_count | 22.01 | 53 | 100 | 22.01 | 53 | 100 | 22.01 | 53 | 100 |
| passing_greeting_count | 5.01 | 17 | 94 | 5.01 | 17 | 94 | 5.01 | 17 | 94 |
| distant_social_count | 5.85 | 19 | 97 | 5.85 | 19 | 97 | 5.85 | 19 | 97 |
| conversation_shadow_count | 1.60 | 7 | 74 | 1.60 | 7 | 74 | 1.60 | 7 | 74 |
| familiarity_shadow_count | 2.65 | 10 | 85 | 2.57 | 9 | 85 | 0.26 | 3 | 20 |
| memory_shadow_count | 0.97 | 6 | 50 | 0.96 | 6 | 50 | 0.11 | 2 | 9 |
| time_shadow_count | 7.75 | 18 | 100 | 7.75 | 18 | 100 | 7.75 | 18 | 100 |

比率:

- `life_contact / same_place_nearby`: 約71.9%
- `passing_greeting / life_contact`: 約22.8%

どちらも目標範囲内。

## seed1003

採用案B:

```text
same_place_nearby_count 25
life_contact_count 21
passing_greeting_count 6
distant_social_count 3
conversation_shadow_count 0
familiarity_shadow_count 0
memory_shadow_count 0
time_shadow_count 8
```

seed1003は壊れていない。

`life_contact`と`passing_greeting`は出るが、`conversation_shadow / familiarity_shadow / memory_shadow`は0のまま。つまり「みんな顔見知り村」にはなっていない。

読み:

```text
場所だけが古びる村。
ただし、同じ場所にいた人々の生活接触や短い挨拶は見える。
それでも関係の影や記憶の影には育たない。
```

## seed1061

採用案B:

```text
same_place_nearby_count 49
life_contact_count 38
passing_greeting_count 7
distant_social_count 8
conversation_shadow_count 2
familiarity_shadow_count 3
memory_shadow_count 1
time_shadow_count 7
```

seed1061は生活密度が上がっている。

重要イベント:

```text
Y41 ハナ and ゾル: conversation_shadow at well
Y41 familiarity_shadow score=6

Y43 セナ and イシュ: conversation_shadow at tea_house
Y43 familiarity_shadow score=6

Y60 イシュ: memory_shadow at tea_house
```

読み:

```text
人の交差が場所に残る村。
life_contact / passing_greeting で生活の密度が見えるが、
conversation_shadow は低頻度のまま。
memory_shadow も1件で rare のまま。
```

## 採用案

案Bを採用。

理由:

- 本体汚染なし
- 既存イベント安定性あり
- `life_contact`量が目標内
- `passing_greeting`量が目標内
- seed1003が壊れない
- seed1061の生活密度が上がる
- `conversation_shadow`は低頻度のまま
- `memory_shadow`はrare寄りのまま
- `life_contact`を「顔見知り化」させずに、生活の接触だけを見せられる

## 採用しない案

案A:

- 悪くはない。
- ただし`life_contact`自体をfamiliarityに加算するため、距離感が少し近すぎる。
- seed1003は今回壊れなかったが、今後placeやcontact候補が増えると「生活接触だけで関係が育つ」方向に寄りやすい。

案C:

- 安全すぎる。
- seed1061で`familiarity_shadow = 0`、`memory_shadow = 0`になり、「人の交差が場所に残る村」の読みが消える。
- `life_contact`採用の意味が観測だけに寄りすぎ、既存のmemory pathも薄くなる。

## 出力

reader確認:

- `outputs/life_observation_reader_seed1003_1061_life_contact.txt`

