# society_lab life layer pollution check

Base:

`C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py`

Checked seeds:

`1000-1099`

Years:

`80`

## Compared Base Fields

Year-by-year:

- `year`
- `population`
- `food_stock`
- `death_count`
- `birth_count`
- `memory_shared_count`
- `support_chain_trace_count`
- `memory_lineage_trace_count`
- `project_aftermath_trace_count`

Final:

- full `summary()`

Life-layer-only events were not treated as pollution.

## Results

| Life file | Checked | Clean | Drifted |
|---|---:|---:|---:|
| `society_lab_v1_4_life_senses_nearby_reviewed.py` | 100 | 100 | 0 |
| `society_lab_v1_4_life_senses_conversation_shadow.py` | 100 | 100 | 0 |
| `society_lab_v1_4_life_senses_familiarity_shadow.py` | 100 | 100 | 0 |
| `society_lab_v1_4_life_senses_memory_shadow.py` | 100 | 100 | 0 |

## Interpretation

No pollution was detected.

The life layers create their own observation streams, but they do not change the base simulation's yearly population, food stock, birth/death counts, memory sharing counts, support-chain trace counts, memory-lineage trace counts, project-aftermath trace counts, or final summary across the checked seeds.

So these are safe as reading layers:

```text
same_place_nearby
distant_social
conversation_shadow
familiarity_shadow
memory_shadow
```

They produce life-layer differences, but not base-world differences.

## Raw JSON Outputs

- `pollution_check_nearby_reviewed.json`
- `pollution_check_conversation_shadow.json`
- `pollution_check_familiarity_shadow.json`
- `pollution_check_memory_shadow.json`

## Script

Generic checker:

`work\pollution_check.py`
