# season-aware ambient places check

## changes

- Added season-weighted ambient place selection inside the existing `ambient_place_details` stream.
- Added season-weighted place details for objects, scents, sounds, and scenes.
- Added `season=...` to ambient place detail strings.
- Added `Ambient places by season` to `life_observation_reader.py`.
- No trust, support, main memory, food, health, birth, death, or base dynamics were changed.

## checks

- compile_ok: `True`
- pollution_diffs seed1000-1099: `0`
- stable_event_diffs_vs_unweighted_ambient_places: `0`

Stable event comparison includes weather, season, ambient_object, ambient_scent, ambient_sound, crowd_mood, place_presence, same_place_nearby, life_contact, passing_greeting, distant_social, conversation_shadow, familiarity_shadow, memory_shadow, and time_shadow.

## 100 seed count stats

| event | min | max | avg | nonzero |
| --- | ---: | ---: | ---: | ---: |
| `season` | 71 | 80 | 79.91 | 100 |
| `ambient_place_object` | 46 | 64 | 55.68 | 100 |
| `ambient_place_scent` | 29 | 55 | 41.97 | 100 |
| `ambient_place_sound` | 31 | 53 | 44.14 | 100 |
| `ambient_place_scene` | 24 | 42 | 32.17 | 100 |
| `life_observation` | 821 | 1567 | 1174.33 | 100 |

## ambient places by season

- `cold_rain`: book_house=777, weaving_house=696, engawa=572, festival_square=316, rice_field=300, spring=231
- `early_summer`: spring=950, rice_field=722, engawa=370, book_house=349, festival_square=313, weaving_house=296
- `first_frost`: book_house=756, weaving_house=684, engawa=569, festival_square=301, rice_field=274, spring=179
- `harvest_time`: rice_field=962, weaving_house=594, book_house=413, engawa=344, spring=310, festival_square=255
- `late_summer`: festival_square=744, rice_field=682, engawa=569, book_house=335, spring=306, weaving_house=277
- `midsummer`: festival_square=925, engawa=618, spring=540, book_house=303, weaving_house=297, rice_field=267

## seed1003

- Social path stays quiet: `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `time_shadow=8`.
- Contact remains observational: `life_contact=21`, `passing_greeting=6`.
- Strongest seasonal place hints:
  - `late_summer` / `rice_field`: 16
  - `late_summer` / `weaving_house`: 11
  - `first_frost` / `book_house`: 10
  - `midsummer` / `spring`: 8
  - `early_summer` / `weaving_house`: 8

## seed1061

- Human crossing is preserved: `conversation_shadow=2`, `familiarity_shadow=3`, `memory_shadow=1`, `time_shadow=7`.
- Contact remains legible: `life_contact=38`, `passing_greeting=7`.
- Strongest seasonal place hints:
  - `midsummer` / `festival_square`: 25
  - `harvest_time` / `weaving_house`: 15
  - `early_summer` / `spring`: 14
  - `first_frost` / `book_house`: 10
  - `late_summer` / `festival_square`: 10

## reading

seed1003 remains the quiet old village: places age, seasons leave objects and sounds, but the social shadow path does not become a network. The added layer gives it a calendar of surfaces rather than new relationships.

seed1061 remains the village where people cross: the existing tea-house/contact/memory path is still visible, now with midsummer festival_square, harvest/weaving, and early-summer spring/rice-field textures around it. The background is thicker, but it does not overwrite the social path.

Reader output: `C:\Users\yauki\Documents\Codex\2026-06-12\files-mentioned-by-the-user-society\outputs\life_observation_reader_seed1003_1061_season_aware.txt`
