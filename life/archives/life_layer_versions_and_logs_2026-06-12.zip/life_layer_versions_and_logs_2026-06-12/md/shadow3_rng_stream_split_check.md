# shadow3 RNG stream分離チェック

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_1.py`
- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow3.py`

## 実装

`society_lab_v1_4_life_senses_memory_shadow3.py`のlife観測層で、単一のlife RNGを用途別streamに分離した。

`_life_rng(stream_name: str)`は以下からdeterministic RNGを作る。

```text
seed | year | life_observation | stream_name
```

分離したstream:

- `weather`
- `world_sense`
- `person_place`
- `person_sense`
- `pair_social`
- `memory_shadow`
- `time_shadow`

`memory_shadow`発火率は変更していない。`memory_shadow_chance = 0.12`としてクラス属性化しただけ。

## 確認

seed `1000`から`1099`まで、80年実行で確認した。

### 1. 本体汚染なし

base `SocietyLab` と `LifeObservedSocietyLab` で以下を比較し、100/100 seedで完全一致。

- `summary()`
- 人物状態
- 食料状態
- 通常イベントログ
- 記憶系trace
- 支援trace
- project aftermath trace

結果:

```text
world_snapshot_diffs 0 []
```

### 2. time_shadow無効化チェック

検証用サブクラスで`_observe_time_shadow()`だけを無効化し、通常版と以下を比較。

- `memory_shadow`
- `conversation_shadow`

結果:

```text
time_disabled_memory_or_conversation_diffs 0 []
```

`time_shadow`を止めても、`memory_shadow`と`conversation_shadow`はズレない。

### 3. memory_shadow確率変更チェック

検証用サブクラスで`memory_shadow_chance = 0.60`に変更し、通常版と以下を比較。

- `weather`
- `place_presence`
- `same_place_nearby`
- `conversation_shadow`
- `time_shadow`

結果:

```text
memory_rate_changed_stable_event_diffs 0 []
```

`memory_shadow`の発火率を変えても、指定イベントはズレない。

## stream分離後のlife観測量

| 指標 | min | max | avg | nonzero |
|---|---:|---:|---:|---:|
| life_observation_count | 428 | 1086 | 744.21 | 100 |
| memory_shadow_count | 0 | 2 | 0.16 | 14 |
| conversation_shadow_count | 0 | 7 | 1.60 | 74 |
| time_shadow_count | 1 | 18 | 7.75 | 100 |
| same_place_nearby_count | 2 | 74 | 30.62 | 100 |

## 補足

`shadow3.py`は作業開始時点で`memory_shadow`発火率が`0.20`へ変更済みだったが、今回の条件に合わせて`0.12`へ戻した。

今回やっていないこと:

- trust nudge
- support変更
- memory本体への書き込み
- 新しい`season_return` / `place_age_shadow`追加
- `memory_shadow`発火率変更

