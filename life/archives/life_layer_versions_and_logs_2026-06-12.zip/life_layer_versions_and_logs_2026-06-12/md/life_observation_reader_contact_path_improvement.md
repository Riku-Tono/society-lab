# life_observation_reader contact path改善

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\life_observation_reader.py`

## 改善内容

`Contact paths`ビューを追加した。

pairごとに、以下の段階を同じまとまりで表示する。

```text
same_place_nearby
life_contact
passing_greeting
distant_social
conversation_shadow
familiarity_shadow
memory_shadow
```

これで、単なる同席から、生活接触、挨拶、遠い身振り、短い会話、親しさの影、記憶の影までが一本で追える。

追加オプション:

```bash
python life_observation_reader.py 1003 1061 --contact-limit 10
```

`--contact-limit`でseedごとに表示するcontact path数を調整できる。

## 出力

確認出力:

- `outputs/life_observation_reader_seed1003_1061_contact_paths.txt`

## 簡単な物語

### seed1003

seed1003では、人々はたしかに同じ場所に現れる。

門でギルとケイがすれ違い、道を譲る。茶屋でイシュとファラが短く挨拶する。炉辺でハナとセナが同じ年にそこにいて、軽く手を上げる。

でも、それ以上には育たない。

`life_contact`は21件、`passing_greeting`は6件ある。だから、この村は「誰も互いを見ていない村」ではなくなった。人は見える。挨拶もある。

それでも`conversation_shadow`は0、`familiarity_shadow`は0、`memory_shadow`も0。

つまり、seed1003はまだ静かだ。

場所は古びる。井戸や茶屋や炉辺に時間は残る。けれど、人の接触は深い線にはならない。生活の中ですれ違い、少しだけ挨拶し、それからまた村の空気へほどけていく。

seed1003は「場所だけが古びる村」のまま。ただし、そこにいた人の輪郭は前より見える。

### seed1061

seed1061では、接触が線になる。

Year43、セナとイシュが茶屋にいる。

最初は`same_place_nearby`。同じ場所、同じ年にいたというだけ。

そこから`life_contact`になる。生活の中で、短い普通の時間を共有する。

さらに`distant_social`が出る。笑いが同じ場所に見える。

そして`conversation_shadow`。火の近くで話した、という短い影が残る。

その年のうちに`familiarity_shadow`がつく。scoreは6。

そしてYear60、イシュが雨の茶屋で古い場所の方を見る。

これは本体memoryではない。trustもsupportも動かない。

でもreader上では、Year43の茶屋の接触が、Year60の`memory_shadow`へ戻ってくる道筋として読める。

seed1061は「人の交差が場所に残る村」のまま、より読みやすくなった。

## 他AIへの説明

`life_observation_reader.py`に`Contact paths`ビューを追加した。

目的は、`life_contact`採用後に、pair単位で以下の観測段階を自動で並べること。

```text
same_place_nearby
-> life_contact
-> passing_greeting
-> distant_social
-> conversation_shadow
-> familiarity_shadow
-> memory_shadow
```

重要点:

- readerのみの改善。
- `society_lab_v1_4_life_senses_memory_shadow3.py`の生成ロジックは変更していない。
- base本体、trust、support、main memoryには触れていない。
- `same_place_nearby`は接触ではなく、同じ場所・同じ年の共在。
- `life_contact`は生活接触。
- `passing_greeting`以上が、関係の足跡として読みやすくなる。

seed1003:

```text
life_contact=21
passing_greeting=6
conversation_shadow=0
familiarity_shadow=0
memory_shadow=0
time_shadow=8
```

解釈:

```text
人は見えるが、関係の影には育たない。
静かな老いた村は壊れていない。
```

seed1061:

```text
life_contact=38
passing_greeting=7
conversation_shadow=2
familiarity_shadow=3
memory_shadow=1
time_shadow=7
```

代表path:

```text
Y43 p051,p007 same_place_nearby at tea_house
Y43 p051,p007 life_contact at tea_house
Y43 p051,p007 distant_social at tea_house
Y43 p051,p007 conversation_shadow at tea_house
Y43 p051,p007 familiarity_shadow score=6
Y60 p007,p051 memory_shadow at tea_house
```

解釈:

```text
人の交差が場所に残り、後年のmemory_shadowとして戻る。
```

次に他AIへ渡すなら、依頼は「このreader出力を読んで、seed1003/1061/1042/1096の観測層の違いを物語化して」くらいがよい。まだ`season_return`や因果追加は不要。

