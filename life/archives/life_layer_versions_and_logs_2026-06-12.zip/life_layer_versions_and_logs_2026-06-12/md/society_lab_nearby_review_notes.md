# society_lab nearby review notes

Reviewed source:

`C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_life_senses_nearby.py`

Saved copies:

- `society_lab_v1_4_life_senses_nearby_original_copy.py`
- `society_lab_v1_4_life_senses_nearby_reviewed.py`

## What was already good

- `distant_social` only appears from `same_place_nearby` pairs.
- `distant_social` does not imply touch or trust.
- Events use weak forms:
  - `laughed_at_the_same_time`
  - `waved_from_a_distance`
  - `looked_back_once`
  - `smiled_toward_someone`
  - `almost_called_out`
  - `waited_without_speaking`
- No base simulation state is changed.

## Changes in the reviewed copy

1. Restored separate `world_gesture`
   - personless gestures stay separate from person-level `gesture`
   - examples: `someone_looked_up`, `a_whisper_nearby`, `eyes_from_doorway`

2. Replaced pair lists with pair count maps
   - `same_place_nearby_pair_counts`
   - `distant_social_pair_counts`

This keeps repeat information for later reading without introducing trust changes.

## Verification

Compared frozen `SocietyLab` and reviewed `LifeObservedSocietyLab` for seeds 1000-1099, 80 years each.

```json
{
  "status": "ok",
  "life_path": "work\\society_lab_v1_4_life_senses_nearby_reviewed.py",
  "seeds": "1000-1099",
  "years": 80,
  "min_life_observations": 406,
  "max_life_observations": 1109,
  "min_tea_house": 10,
  "max_tea_house": 54,
  "min_trace": 19,
  "max_trace": 42,
  "min_sound": 52,
  "max_sound": 74
}
```

The base `summary()` stayed identical for all checked seeds.

## Seed 42 sample counts

```json
{
  "life_observation_count": 1059,
  "scent_count": 105,
  "touch_count": 62,
  "affect_object_count": 54,
  "animal_presence_count": 21,
  "repeat_place_count": 64,
  "rainy_tea_house_count": 38,
  "same_place_nearby_count": 76,
  "gesture_count": 40,
  "world_gesture_count": 5,
  "distant_social_count": 12
}
```

`distant_social` appears often enough to read, but not enough to dominate the life layer.

## Suggested next step

Pause here and read one seed, probably seed 1003, before adding `near_touch`.

The next possible layer is:

```text
same_place_nearby
-> distant_social
-> near_touch
-> gentle_contact
-> familiarity_shadow
-> trust_nudge
```

The reviewed file stops at `distant_social`.
