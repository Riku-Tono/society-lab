# Life Seed Reading: seed 1003

## Base Summary

- `seed`: 1003
- `years`: 80
- `initial_population`: 35
- `final_population`: 18
- `age_profile`: old
- `charisma_profile`: normal
- `initial_food_stock`: 179.269
- `initial_food_capacity`: 41.964
- `final_food_stock`: 227.336
- `avg_fear`: 0.026
- `avg_hunger`: 0.0
- `avg_voice_weight`: 0.002
- `max_voice_weight`: 0.031
- `crisis_count`: 0
- `problem_count`: 14
- `council_count`: 13
- `proposal_count`: 23
- `project_success_count`: 3
- `project_failure_count`: 9
- `shared_narrative_count`: 45
- `authority_pattern_count`: 0
- `faction_pattern_count`: 0
- `ritualization_pattern_count`: 0
- `network_split_count`: 4
- `narrative_divergence_count`: 16
- `interpretation_divergence_count`: 4
- `interpretation_convergence_count`: 0
- `interpretation_action_nudge_count`: 7
- `interpretation_support_nudge_count`: 75
- `avg_bias_spiritual`: 0.117
- `avg_bias_practical`: 0.1206
- `avg_bias_blame`: 0.1333
- `death_count`: 35
- `birth_count`: 18
- `memory_shared_count`: 323
- `behavior_copied_count`: 0
- `biography_subject_count`: 53
- `memory_lineage_trace_count`: 608
- `support_chain_trace_count`: 126
- `project_aftermath_trace_count`: 12

## Life Event Counts

- `place_presence`: 161
- `scent`: 84
- `weather`: 80
- `sound`: 67
- `touch`: 53
- `affect_object`: 37
- `same_place_nearby`: 36
- `gesture`: 33
- `repeat_place`: 29
- `tea_house`: 25
- `well_water`: 25
- `trace`: 24
- `brazier_presence`: 24
- `rainy_tea_house`: 24
- `animal_presence`: 18
- `elder_sitting`: 18
- `world_gesture`: 16
- `storehouse_bag`: 14
- `distant_social`: 11
- `conversation_shadow`: 4
- `child_bowl`: 1

## Repeated Place Presence

- `p038`: hearth:2, path:2, gate:1, storehouse:1, well:1, tea_house:1
- `p043`: tea_house:2, path:2, storehouse:1, hearth:1, well:1
- `p008`: storehouse:2, gate:2, hearth:1, well:1
- `p027`: well:2, path:1, hearth:1, tea_house:1, storehouse:1
- `p030`: well:3, storehouse:1, path:1, hearth:1
- `p035`: storehouse:2, well:2, tea_house:2
- `p036`: storehouse:3, tea_house:2, well:1
- `p040`: storehouse:3, well:1, tea_house:1, hearth:1
- `p003`: hearth:3, tea_house:1, storehouse:1
- `p005`: gate:1, well:1, path:1, hearth:1, tea_house:1
- `p013`: hearth:3, well:1, tea_house:1
- `p021`: storehouse:2, hearth:1, well:1, tea_house:1

## Pair Threads

- `p011|p017`: same_place_nearby:1, distant_social:1, conversation_shadow:1
- `p013|p038`: same_place_nearby:1, distant_social:1, conversation_shadow:1
- `p021|p035`: same_place_nearby:1, distant_social:1, conversation_shadow:1
- `p031|p045`: same_place_nearby:1, distant_social:1, conversation_shadow:1
- `p002|p030`: same_place_nearby:1, distant_social:1
- `p009|p020`: same_place_nearby:1, distant_social:1
- `p020|p032`: same_place_nearby:1, distant_social:1
- `p022|p025`: same_place_nearby:1, distant_social:1
- `p027|p048`: same_place_nearby:1, distant_social:1
- `p032|p039`: same_place_nearby:1, distant_social:1
- `p045|p048`: same_place_nearby:1, distant_social:1
- `p027|p045`: same_place_nearby:2

## Years To Read Closely

### Year 4
- `touch` p013: ファラ; touch=straw_mat_under_knees; place=hearth; weather=clear
- `gesture` p036: サナ stood_at_the_threshold; place=well; weather=clear
- `touch` p038: タロ; touch=ash_on_sleeve; place=hearth; weather=clear
- `gesture` p038: タロ sat_without_moving; place=hearth; weather=clear
- `same_place_nearby` p013,p033: ファラ and ファラ both near hearth; weather=clear
- `same_place_nearby` p013,p038: ファラ and タロ both near hearth; weather=clear
- `distant_social` p013,p038: ファラ and タロ: smiled_toward_someone; place=hearth; weather=clear
- `conversation_shadow` p013,p038: ファラ and タロ: a_few_words_exchanged; place=hearth; weather=clear

### Year 38
- `touch` p003: ハナ; touch=straw_mat_under_knees; place=hearth; weather=light_mist
- `repeat_place` p011: シオン appeared at tea_house again; count=2
- `touch` p011: シオン; touch=steam_on_face; place=tea_house; weather=light_mist
- `scent` p002: ノア; scent=mended_rope; place=storehouse; weather=light_mist
- `touch` p002: ノア; touch=rough_sackcloth; place=storehouse; weather=light_mist
- `gesture` p002: ノア whispered_to_no_one; place=storehouse; weather=light_mist
- `same_place_nearby` p017,p011: セナ and シオン both near tea_house; weather=light_mist
- `distant_social` p017,p011: セナ and シオン: waved_from_a_distance; place=tea_house; weather=light_mist

### Year 37
- `repeat_place` p035: ルト appeared at well again; count=2
- `scent` p007: ファラ; scent=old_wood; place=hearth; weather=rain_on_roof
- `touch` p007: ファラ; touch=straw_mat_under_knees; place=hearth; weather=rain_on_roof
- `affect_object` p007: ファラ; object=chipped_cup; place=hearth; weather=rain_on_roof
- `same_place_nearby` p021,p035: メイ and ルト both near well; weather=rain_on_roof
- `distant_social` p021,p035: メイ and ルト: waved_from_a_distance; place=well; weather=rain_on_roof
- `conversation_shadow` p021,p035: メイ and ルト: shared_a_short_remark; place=well; weather=rain_on_roof

### Year 60
- `repeat_place` p031: カイ appeared at well again; count=2
- `affect_object` p031: カイ; object=warm_bowl; place=well; weather=dry_wind
- `repeat_place` p045: セナ appeared at well again; count=2
- `gesture` p045: セナ sat_without_moving; place=well; weather=dry_wind
- `same_place_nearby` p031,p045: カイ and セナ both near well; weather=dry_wind
- `distant_social` p031,p045: カイ and セナ: almost_called_out; place=well; weather=dry_wind
- `conversation_shadow` p031,p045: カイ and セナ: spoke_briefly; place=well; weather=dry_wind

### Year 6
- `affect_object` p008: ルト; object=childs_wooden_spoon; place=well; weather=rain_on_roof
- `gesture` p008: ルト turned_back_once; place=well; weather=rain_on_roof
- `affect_object` p032: ゾル; object=cracked_ladle; place=tea_house; weather=rain_on_roof
- `gesture` p039: ユラ put_something_down_slowly; place=tea_house; weather=rain_on_roof
- `repeat_place` p020: アルン appeared at tea_house again; count=2
- `scent` p020: アルン; scent=smoke_in_cloth; place=tea_house; weather=rain_on_roof
- `touch` p020: アルン; touch=steam_on_face; place=tea_house; weather=rain_on_roof
- `affect_object` p020: アルン; object=cracked_ladle; place=tea_house; weather=rain_on_roof

### Year 48
- `affect_object` p027: ユラ; object=childs_wooden_spoon; place=well; weather=light_mist
- `touch` p012: イシュ; touch=wind_on_neck; place=gate; weather=light_mist
- `affect_object` p012: イシュ; object=cracked_ladle; place=gate; weather=light_mist
- `scent` p045: セナ; scent=wet_soil; place=well; weather=light_mist
- `touch` p045: セナ; touch=wet_stone_under_fingers; place=well; weather=light_mist
- `affect_object` p048: ダン; object=childs_wooden_spoon; place=well; weather=light_mist
- `scent` p030: オルン; scent=old_wood; place=hearth; weather=light_mist
- `same_place_nearby` p027,p045: ユラ and セナ both near well; weather=light_mist

### Year 5
- `world_gesture` -: gesture=eyes_from_doorway; place=well; weather=rain_on_roof
- `scent` p003: ハナ; scent=boiled_barley; place=tea_house; weather=rain_on_roof
- `affect_object` p009: ミラ; object=cracked_ladle; place=tea_house; weather=rain_on_roof
- `touch` p008: ルト; touch=warm_bowl_in_hands; place=hearth; weather=rain_on_roof
- `scent` p020: アルン; scent=smoke_in_cloth; place=tea_house; weather=rain_on_roof
- `gesture` p020: アルン looked_at_the_sky; place=tea_house; weather=rain_on_roof
- `same_place_nearby` p021,p008: メイ and ルト both near hearth; weather=rain_on_roof
- `same_place_nearby` p003,p009: ハナ and ミラ both near tea_house; weather=rain_on_roof

### Year 54
- `scent` -: scent=wet_soil; place=well; weather=light_mist
- `affect_object` p031: カイ; object=small_blanket; place=storehouse; weather=light_mist
- `touch` p039: ユラ; touch=rough_sackcloth; place=storehouse; weather=light_mist
- `gesture` p039: ユラ stood_at_the_threshold; place=storehouse; weather=light_mist
- `gesture` p030: オルン held_still_a_moment; place=well; weather=light_mist
- `scent` p002: ノア; scent=wet_soil; place=well; weather=light_mist
- `touch` p002: ノア; touch=cold_mud_underfoot; place=well; weather=light_mist
- `affect_object` p002: ノア; object=childs_wooden_spoon; place=well; weather=light_mist

### Year 1
- `scent` -: scent=dry_grass; place=gate; weather=light_mist
- `scent` p025: シオン; scent=dust_in_sacks; place=storehouse; weather=light_mist
- `gesture` p022: メイ sat_without_moving; place=storehouse; weather=light_mist
- `same_place_nearby` p025,p022: シオン and メイ both near storehouse; weather=light_mist
- `distant_social` p025,p022: シオン and メイ: made_a_troubled_face_toward_someone; place=storehouse; weather=light_mist

### Year 18
- `scent` -: scent=wind_from_fields; place=path; weather=overcast
- `scent` p030: オルン; scent=cold_stone; place=well; weather=overcast
- `gesture` p030: オルン sat_without_moving; place=well; weather=overcast
- `repeat_place` p022: メイ appeared at storehouse again; count=2
- `scent` p022: メイ; scent=old_straw; place=storehouse; weather=overcast
- `gesture` p022: メイ did_not_go_in; place=storehouse; weather=overcast
- `scent` p043: アルン; scent=mended_rope; place=storehouse; weather=overcast
- `affect_object` p043: アルン; object=warm_bowl; place=storehouse; weather=overcast
