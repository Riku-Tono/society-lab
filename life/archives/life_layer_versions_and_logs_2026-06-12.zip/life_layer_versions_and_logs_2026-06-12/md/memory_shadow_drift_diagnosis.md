# memory_shadow drift diagnosis

Checked target:

`C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow.py`

Base:

`C:\Users\yauki\OneDrive\デスクトップ\SL2\society_lab_v1_4_1.py`

## Note on provided diagnostic script

`diagnose_memory_shadow_drift.py` needed adaptation for the current simulator shape:

- `sim.food` is an object, so the useful field is `sim.food.stock`
- summary keys are `death_count`, `birth_count`, `support_chain_trace_count`, etc.
- robust loading needed explicit file paths because the base file is in `SL2` and the memory-shadow file is in `SL3`

I created:

`work\diagnose_memory_shadow_drift_local.py`

## Result

Checked seeds 1000-1099, 80 years each.

```json
{
  "checked": "1000-1099",
  "years": 80,
  "drifted_count": 0,
  "clean_count": 100,
  "earliest": null,
  "drifted": []
}
```

## Interpretation

No drift was found.

The current `memory_shadow` file did not change base yearly snapshots or final summaries across the checked seeds.

Compared fields included:

- year
- population
- food stock
- death count
- birth count
- memory shared count
- support chain trace count
- memory lineage trace count
- full final `summary()`

So, in this checked version, `_observe_memory_shadow()` is not leaking into the base simulation path.
