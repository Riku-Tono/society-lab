# bridge D0 potential-only 30 seed check

- seeds: `1000-1029` (30 consecutive seeds)
- years: `80`
- fixed baseline: `society_lab_v1_4_life_senses_memory_shadow3.py`
- D0: `work/society_lab_v1_4_life_bridge_D0_potential_only.py`

## Aggregate

| metric | count |
| --- | ---: |
| seed_count | 30 |
| bridge_potential_count | 22 |
| bridge_potential_seed_count | 15 |
| memory_shadow_count | 23 |
| life_trust_nudge_count | 0 |
| trust_diff_count | 0 |
| body_diff_count | 0 |
| rng_diff_count | 0 |
| summary_diff_count | 0 |
| main_log_diff_count | 0 |
| memory_lineage_diff_count | 0 |
| support_chain_diff_count | 0 |
| project_aftermath_diff_count | 0 |
| life_observation_diff_count | 0 |
| any_diff_seed_count | 0 |

## Seed Table

| seed | bridge_potential | memory_shadow | life_trust_nudge | trust diff | body diff | rng diff | summary diff | main log diff | memory diff | support diff | project diff |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1000 | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1001 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1002 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1003 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1004 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1005 | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1006 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1007 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1008 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1009 | 4 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1010 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1011 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1012 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1013 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1014 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1015 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1016 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1017 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1018 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1019 | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1020 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1021 | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1022 | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1023 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1024 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1025 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1026 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1027 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1028 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1029 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

## Bridge Examples

### seed1000

- Y08 p026,p032 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=well; weather=heavy_rain
- Y14 p035,p014 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=tea_house; weather=rain_on_roof
- Y19 p006,p026 potential=8.0; mark=1; source=memory_shadow; sources=distant_social,familiarity_shadow,memory_shadow,passing_greeting; place=tea_house; weather=clear

### seed1005

- Y47 p040,p033 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=clear

### seed1006

- Y53 p013,p028 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=storehouse; weather=clear

### seed1007

- Y32 p018,p013 potential=8.0; mark=1; source=memory_shadow; sources=distant_social,familiarity_shadow,memory_shadow,passing_greeting; place=tea_house; weather=light_mist

### seed1008

- Y66 p033,p034 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=storehouse; weather=clear

### seed1009

- Y41 p004,p030 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=tea_house; weather=clear
- Y43 p018,p017 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=light_mist
- Y68 p032,p015 potential=8.0; mark=1; source=memory_shadow; sources=distant_social,familiarity_shadow,memory_shadow,passing_greeting; place=storehouse; weather=dry_wind

### seed1013

- Y37 p030,p034 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=well; weather=rain_on_roof

### seed1014

- Y45 p055,p008 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=well; weather=heavy_rain

### seed1015

- Y38 p005,p008 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=tea_house; weather=rain_on_roof

### seed1019

- Y42 p011,p023 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=hearth; weather=rain_on_roof

### seed1021

- Y39 p039,p026 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=heavy_rain
- Y46 p001,p043 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=path; weather=clear

### seed1022

- Y46 p000,p007 potential=8.0; mark=1; source=memory_shadow; sources=passing_greeting,familiarity_shadow,memory_shadow; place=storehouse; weather=light_mist
- Y73 p029,p015 potential=8.0; mark=1; source=memory_shadow; sources=distant_social,familiarity_shadow,memory_shadow,passing_greeting; place=storehouse; weather=overcast

### seed1023

- Y29 p019,p022 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=hearth; weather=heavy_rain

### seed1026

- Y40 p024,p002 potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=hearth; weather=light_mist

### seed1028

- Y51 p005,p024 potential=9.0; mark=1; source=familiarity_shadow; sources=familiarity_shadow,conversation_shadow,distant_social,passing_greeting; place=hearth; weather=light_mist

## Judgment

D0 passed: bridge candidates were recorded, but no trust nudge fired and the main body, RNG, summaries, logs, memory lineage, support chains, and project aftermath stayed identical to shadow3.

This separates candidate recording from intervention: potential-only observation is safe here; D divergence belongs to the trust write.
