# shadow3 ambient layer追加チェック

対象:

- `C:\Users\yauki\OneDrive\デスクトップ\SL3\society_lab_v1_4_life_senses_memory_shadow3.py`
- `C:\Users\yauki\OneDrive\デスクトップ\SL3\life_observation_reader.py`

## 追加したもの

観測専用の足場として、以下を追加した。

- `AMBIENT_OBJECTS`
- `AMBIENT_SCENTS`
- `AMBIENT_SOUNDS`
- `AMBIENT_PLACES`
- `SEASONS`
- `CROWD_MOODS`

追加イベント:

- `season`
- `ambient_object`
- `ambient_scent`
- `ambient_sound`
- `crowd_mood`

すべて`ambient_layers`専用RNG streamで記録する。既存の`weather / world_sense / person_place / person_sense / pair_social / memory_shadow / time_shadow` streamは消費しない。

## まだやっていないこと

- `trust`変更
- `support`変更
- main memory変更
- `near_touch`追加
- `gentle_contact`追加
- `season_return`追加
- 既存`LIFE_PLACES`への統合
- `place_presence`の場所選択ロジック変更

## 検証

seed `1000-1099`、80年実行。

```text
compiled ok
world_snapshot_diffs 0 []
old_event_diffs_with_ambient_disabled 0 []
```

本体汚染なし。

ambientを無効化しても、以下の既存イベントは完全一致。

- `weather`
- `sound`
- `trace`
- `world_gesture`
- `place_presence`
- `repeat_place`
- `same_place_nearby`
- `distant_social`
- `conversation_shadow`
- `familiarity_shadow`
- `memory_shadow`
- `time_shadow`

## 追加イベント量

| event | min | max | avg | nonzero |
|---|---:|---:|---:|---:|
| season_count | 71 | 80 | 79.91 | 100 |
| ambient_object_count | 42 | 62 | 52.38 | 100 |
| ambient_scent_count | 24 | 48 | 36.02 | 100 |
| ambient_sound_count | 30 | 50 | 39.56 | 100 |
| crowd_mood_count | 9 | 29 | 19.61 | 100 |
| life_observation_count | 653 | 1320 | 972.21 | 100 |

## seed1003 / seed1061

seed1003:

```text
season_count 80
ambient_object_count 50
ambient_scent_count 39
ambient_sound_count 32
crowd_mood_count 18
life_observation_count 917
```

seed1061:

```text
season_count 80
ambient_object_count 52
ambient_scent_count 38
ambient_sound_count 35
crowd_mood_count 14
life_observation_count 1163
```

reader出力:

- `outputs/life_observation_reader_seed1003_1061_ambient.txt`

## 判断

今回の追加は、社会因果ではなく観測層の質感を増やす足場として入っている。

既存の`memory_shadow`経路や`time_shadow`経路はズレていない。あとから`season_return`などを考える場合も、今回追加した`SEASONS`とambient系の語彙を参照できる。

