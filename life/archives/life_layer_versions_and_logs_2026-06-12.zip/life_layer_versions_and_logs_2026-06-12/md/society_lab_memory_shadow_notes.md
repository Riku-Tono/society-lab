# society_lab memory shadow notes

Created:

`society_lab_v1_4_life_senses_memory_shadow.py`

Based on:

`society_lab_v1_4_life_senses_familiarity_shadow.py`

## Added

`memory_shadow`

This is still life-layer-only. It does not write to the base simulation's memory system.

No changes are made to:

- trust
- memory lineage
- support
- food
- health
- birth
- death
- proposal outcomes

## Condition

`memory_shadow` can happen only when:

1. a pair previously reached `familiarity_shadow`
2. the place from that familiarity event is seen again in a later year
3. one member of that pair appears there
4. a low-probability observation draw succeeds

This makes the layer cross time, but only through an already established life-layer trace.

## Shadow phrases

- `returned_after_brief_nearness`
- `paused_where_words_once_passed`
- `looked_toward_the_old_place`
- `stood_still_at_the_same_place`
- `left_before_speaking_again`

No emotion is named.
No remembering is asserted in detail.
No conversation content is generated.

## Verification

Compared frozen `SocietyLab` and `LifeObservedSocietyLab` for seeds 1000-1099, 80 years each.

```json
{
  "status": "ok",
  "life_path": "work\\society_lab_v1_4_life_senses_memory_shadow.py",
  "seeds": "1000-1099",
  "years": 80,
  "min_life_observations": 406,
  "max_life_observations": 1116,
  "min_tea_house": 10,
  "max_tea_house": 54,
  "min_trace": 19,
  "max_trace": 42,
  "min_sound": 52,
  "max_sound": 74
}
```

The base `summary()` stayed identical for all checked seeds.

## Frequency check

Across seeds 1000-1099:

```json
{
  "nonzero_seed_count": 13,
  "total_memory_shadow": 15,
  "max_memory_shadow": 2
}
```

So this layer is rare. It is not flooding the life log.

## Seed readings

Seed 42:

```text
memory_shadow_count=0
```

Seed 1003:

```text
memory_shadow_count=0
```

Seed 1035 has two examples:

```text
Year 49: イシュ: returned_after_brief_nearness; place=well; weather=light_mist; prior_year=37; prior_score=7
Year 65: アルン: returned_after_brief_nearness; place=tea_house; weather=light_mist; prior_year=27; prior_score=7
```

That is the intended shape: not "I remembered someone", but a person returning to a place after a prior brief nearness.
