# life first divergence reader

Compared fixed `shadow3` against `trust_nudge_experiment` D, year by year.

Reader:
`C:\Users\yauki\OneDrive\デスクトップ\SL3\life_first_divergence_reader.py`

Raw output:
`C:\Users\yauki\Documents\Codex\2026-06-12\files-mentioned-by-the-user-society\outputs\life_first_divergence_seed1061_1042_1096.txt`

## seed1061

Nudge:

- Y60 `p007|p051`, place=`tea_house`, source=`memory_shadow`, delta=`0.0005`

Path:

- Y43 `same_place_nearby`
- Y43 `life_contact`
- Y43 `distant_social`
- Y43 `conversation_shadow`
- Y43 `familiarity_shadow`
- Y60 `memory_shadow`
- Y60 `life_bridge_potential`
- Y60 `life_trust_nudge`

First divergences:

- trust: Y60
- main_log: Y63
- memory_lineage_trace: Y63
- people_without_trust: Y63
- watched summary keys: Y64
- food: Y64
- support_chain_trace: Y80
- project_aftermath_trace: Y80

First main-log split:

- shadow3: Y63 `アルン died age=89 health=1.00`
- experiment: Y63 `ルト died age=82 health=1.00`

Reading:

The tea-house memory nudge happens at Y60, but the first visible body split is not immediate. The first main-world break appears in Y63 as a different death event; watched summary keys move in Y64. This is a delayed body divergence, not an instant trust-to-support jump.

## seed1042

Nudges:

- Y12 `p007|p020`, place=`tea_house`, source=`memory_shadow`, delta=`0.0005`
- Y18 `p025|p026`, place=`storehouse`, source=`memory_shadow`, delta=`0.0005`

First divergences:

- trust: Y12
- main_log: Y54
- memory_lineage_trace: Y54
- people_without_trust: Y54
- watched summary keys: Y55
- support_chain_trace: Y55
- food: Y55
- project_aftermath_trace: Y56

First main-log split:

- shadow3: Y54 `ギル had a child: シオン`
- experiment: Y54 `シオン had a child: シオン`

Reading:

This seed has early nudges, but the body stays aligned for a long time. The first visible split is a birth identity difference at Y54, followed by memory/support differences. D suppresses repeated same-pair nudges, but early trust contact can still sit quietly for decades before the world branches.

## seed1096

Nudges:

- Y27 `p014|p050`, place=`tea_house`, source=`memory_shadow`, delta=`0.0005`
- Y34 `p030|p033`, place=`tea_house`, source=`memory_shadow`, delta=`0.0005`

First divergences:

- trust: Y27
- main_log: Y46
- memory_lineage_trace: Y46
- people_without_trust: Y46
- watched summary keys: Y47
- food: Y48
- support_chain_trace: Y49
- project_aftermath_trace: Y57

First main-log split:

- shadow3: no event at that index
- experiment: Y46 `narrative_divergence: death, versions 0.36 vs 0.78`

Reading:

The first visible body split is narrative/memory oriented rather than project/support oriented. The Y27 tea-house memory nudge precedes a Y46 death narrative divergence, then food/support/project differences follow later.

## Overall read

D is not preventing body divergence. It is making the entrance legible.

Across all three seeds:

- trust diverges at the nudge year
- main-world divergence appears later
- first visible body split is often death/birth/memory narration, not direct support
- support/project effects appear after the first memory/log split

This supports the current interpretation: `memory_shadow -> life_trust_nudge -> trust state` is the entry point, but the world usually branches later through ordinary core dynamics.
