# society_lab life senses notes

Created:

`society_lab_v1_4_life_senses.py`

This branch extends `life_micro_places` with object, scent, and touch observations.

## Added

- `affect_object`
  - examples: `chipped_cup`, `damp_sleeve`, `warm_bowl`, `old_cloth`, `small_blanket`
- `scent`
  - can be world-only or person-associated
  - examples: `wet_soil`, `dry_grain`, `smoke_in_cloth`, `steam_from_cups`
- `touch`
  - person-associated but not interpersonal
  - examples: `warm_bowl_in_hands`, `wind_on_neck`, `cold_mud_underfoot`
- `animal_presence`
  - weak presence only
  - examples: `cat_near_doorway`, `dog_sleeping_far_off`, `birds_under_eaves`

## Deliberately not added

- no `felt=...`
- no explicit emotions
- no direct person-to-person touch
- no `trust` changes
- no `memory` changes
- no food, health, birth, or death changes

The design is:

object -> sense -> possible reader inference

not:

object -> named emotion -> social force

## Verification

Compared frozen `SocietyLab` and `LifeObservedSocietyLab` for seeds 1000-1099, 80 years each.

```json
{
  "status": "ok",
  "life_path": "work\\society_lab_v1_4_life_senses.py",
  "seeds": "1000-1099",
  "years": 80,
  "min_life_observations": 398,
  "max_life_observations": 969,
  "min_tea_house": 9,
  "max_tea_house": 59,
  "min_trace": 19,
  "max_trace": 42,
  "min_sound": 52,
  "max_sound": 74
}
```

The base `summary()` stayed identical for all checked seeds.

## Seed 42 sample counts

```json
{
  "life_observation_count": 923,
  "scent_count": 101,
  "touch_count": 68,
  "affect_object_count": 50,
  "animal_presence_count": 21,
  "repeat_place_count": 49,
  "rainy_tea_house_count": 40
}
```

## Next step

Before any trust change, the next safe addition would be `same_place_nearby`.

That would record that two people appeared in the same place in the same year, without claiming interaction or changing any social state.
