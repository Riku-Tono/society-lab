# Life Seed Reading: seed 1035

## Base Summary

- `seed`: 1035
- `years`: 80
- `initial_population`: 40
- `final_population`: 38
- `age_profile`: balanced
- `charisma_profile`: no_leader
- `initial_food_stock`: 223.255
- `initial_food_capacity`: 49.868
- `final_food_stock`: 124.949
- `avg_fear`: 0.0
- `avg_hunger`: 0.0
- `avg_voice_weight`: 0.0
- `max_voice_weight`: 0.0
- `crisis_count`: 0
- `problem_count`: 11
- `council_count`: 10
- `proposal_count`: 22
- `project_success_count`: 1
- `project_failure_count`: 3
- `shared_narrative_count`: 29
- `authority_pattern_count`: 0
- `faction_pattern_count`: 0
- `ritualization_pattern_count`: 0
- `network_split_count`: 17
- `narrative_divergence_count`: 17
- `interpretation_divergence_count`: 4
- `interpretation_convergence_count`: 0
- `interpretation_action_nudge_count`: 1
- `interpretation_support_nudge_count`: 32
- `avg_bias_spiritual`: 0.1153
- `avg_bias_practical`: 0.1103
- `avg_bias_blame`: 0.1216
- `death_count`: 36
- `birth_count`: 34
- `memory_shared_count`: 323
- `behavior_copied_count`: 0
- `biography_subject_count`: 74
- `memory_lineage_trace_count`: 563
- `support_chain_trace_count`: 157
- `project_aftermath_trace_count`: 4

## Life Event Counts

- `place_presence`: 241
- `scent`: 115
- `weather`: 80
- `same_place_nearby`: 70
- `sound`: 65
- `repeat_place`: 59
- `touch`: 57
- `tea_house`: 53
- `rainy_tea_house`: 50
- `gesture`: 45
- `affect_object`: 41
- `brazier_presence`: 39
- `animal_presence`: 30
- `well_water`: 29
- `trace`: 24
- `distant_social`: 15
- `elder_sitting`: 15
- `storehouse_bag`: 14
- `world_gesture`: 8
- `child_bowl`: 3
- `conversation_shadow`: 3
- `familiarity_shadow`: 3
- `memory_shadow`: 2

## Repeated Place Presence

- `p006`: tea_house:2, hearth:2, well:2, path:1, storehouse:1
- `p002`: tea_house:3, well:2, path:1, hearth:1
- `p011`: tea_house:3, well:2, path:2
- `p019`: path:2, tea_house:2, hearth:2, gate:1
- `p031`: storehouse:2, hearth:2, gate:1, path:1, tea_house:1
- `p039`: tea_house:4, hearth:1, storehouse:1, path:1
- `p010`: tea_house:2, hearth:1, gate:1, well:1, storehouse:1
- `p014`: hearth:2, tea_house:2, storehouse:1, gate:1
- `p018`: well:3, tea_house:2, hearth:1
- `p022`: tea_house:4, path:2
- `p029`: well:3, tea_house:2, storehouse:1
- `p036`: tea_house:3, hearth:2, gate:1

## Pair Threads

- `p002|p056`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p002|p066`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p018|p045`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p002|p061`: same_place_nearby:1, distant_social:1
- `p005|p041`: same_place_nearby:1, distant_social:1
- `p006|p033`: same_place_nearby:1, distant_social:1
- `p009|p031`: same_place_nearby:1, distant_social:1
- `p014|p050`: same_place_nearby:1, distant_social:1
- `p015|p050`: same_place_nearby:1, distant_social:1
- `p016|p020`: same_place_nearby:1, distant_social:1
- `p019|p027`: same_place_nearby:1, distant_social:1
- `p019|p043`: same_place_nearby:1, distant_social:1

## Years To Read Closely

### Year 49
- `memory_shadow` p018,p045: イシュ: returned_after_brief_nearness; place=well; weather=light_mist; prior_year=37; prior_score=7
- `touch` p060: ケイ; touch=rough_wood_against_palm; place=tea_house; weather=light_mist
- `affect_object` p060: ケイ; object=burnt_rice_smell; place=tea_house; weather=light_mist
- `affect_object` p004: ノア; object=damp_sleeve; place=tea_house; weather=light_mist
- `repeat_place` p013: シオン appeared at tea_house again; count=2
- `same_place_nearby` p060,p047: ケイ and セナ both near tea_house; weather=light_mist
- `distant_social` p060,p047: ケイ and セナ: waited_without_speaking; place=tea_house; weather=light_mist
- `same_place_nearby` p060,p004: ケイ and ノア both near tea_house; weather=light_mist
- `same_place_nearby` p060,p013: ケイ and シオン both near tea_house; weather=light_mist
- `same_place_nearby` p047,p004: セナ and ノア both near tea_house; weather=light_mist
- `same_place_nearby` p047,p013: セナ and シオン both near tea_house; weather=light_mist
- `same_place_nearby` p004,p013: ノア and シオン both near tea_house; weather=light_mist

### Year 65
- `memory_shadow` p002,p056: アルン: returned_after_brief_nearness; place=tea_house; weather=light_mist; prior_year=27; prior_score=7
- `scent` p002: アルン; scent=boiled_barley; place=tea_house; weather=light_mist
- `scent` p061: ティア; scent=steam_from_cups; place=tea_house; weather=light_mist
- `repeat_place` p009: ハナ appeared at hearth again; count=2
- `affect_object` p009: ハナ; object=burnt_rice_smell; place=hearth; weather=light_mist
- `scent` p006: ティア; scent=mended_rope; place=storehouse; weather=light_mist
- `same_place_nearby` p002,p061: アルン and ティア both near tea_house; weather=light_mist
- `distant_social` p002,p061: アルン and ティア: waited_without_speaking; place=tea_house; weather=light_mist
- `same_place_nearby` p062,p009: エリン and ハナ both near hearth; weather=light_mist
- `same_place_nearby` p016,p006: オルン and ティア both near storehouse; weather=light_mist

### Year 37
- `scent` -: scent=smoke_in_cloth; place=tea_house; weather=heavy_rain
- `gesture` p045: ミラ whispered_to_no_one; place=well; weather=heavy_rain
- `repeat_place` p018: イシュ appeared at well again; count=2
- `repeat_place` p022: メイ appeared at tea_house again; count=4
- `scent` p000: ミラ; scent=steam_from_cups; place=tea_house; weather=heavy_rain
- `touch` p000: ミラ; touch=straw_mat_under_knees; place=tea_house; weather=heavy_rain
- `affect_object` p000: ミラ; object=damp_sleeve; place=tea_house; weather=heavy_rain
- `same_place_nearby` p045,p018: ミラ and イシュ both near well; weather=heavy_rain
- `distant_social` p045,p018: ミラ and イシュ: made_a_troubled_face_toward_someone; place=well; weather=heavy_rain
- `conversation_shadow` p045,p018: ミラ and イシュ: shared_a_short_remark; place=well; weather=heavy_rain
- `familiarity_shadow` p045,p018: ミラ and イシュ: repeated brief nearness; place=well; weather=heavy_rain; source=conversation_shadow; score=7
- `same_place_nearby` p022,p000: メイ and ミラ both near tea_house; weather=heavy_rain

### Year 27
- `scent` -: scent=wet_soil; place=well; weather=dry_wind
- `scent` p013: シオン; scent=wet_soil; place=well; weather=dry_wind
- `touch` p013: シオン; touch=cold_mud_underfoot; place=well; weather=dry_wind
- `scent` p002: アルン; scent=boiled_barley; place=tea_house; weather=dry_wind
- `same_place_nearby` p056,p002: ゾル and アルン both near tea_house; weather=dry_wind
- `distant_social` p056,p002: ゾル and アルン: smiled_toward_someone; place=tea_house; weather=dry_wind
- `conversation_shadow` p056,p002: ゾル and アルン: a_few_words_exchanged; place=tea_house; weather=dry_wind
- `familiarity_shadow` p056,p002: ゾル and アルン: repeated brief nearness; place=tea_house; weather=dry_wind; source=conversation_shadow; score=7

### Year 66
- `repeat_place` p049: サナ appeared at tea_house again; count=2
- `scent` p066: レン; scent=burnt_rice_smell; place=hearth; weather=overcast
- `same_place_nearby` p002,p066: アルン and レン both near hearth; weather=overcast
- `distant_social` p002,p066: アルン and レン: looked_back_once; place=hearth; weather=overcast
- `conversation_shadow` p002,p066: アルン and レン: spoke_briefly; place=hearth; weather=overcast
- `familiarity_shadow` p002,p066: アルン and レン: repeated brief nearness; place=hearth; weather=overcast; source=conversation_shadow; score=7
- `same_place_nearby` p040,p049: ギル and サナ both near tea_house; weather=overcast

### Year 11
- `scent` -: scent=steam_from_cups; place=tea_house; weather=overcast
- `scent` p019: ハナ; scent=dry_grass; place=gate; weather=overcast
- `scent` p012: ユラ; scent=damp_straw; place=path; weather=overcast
- `scent` p039: メイ; scent=burnt_rice_smell; place=hearth; weather=overcast
- `touch` p039: メイ; touch=ash_on_sleeve; place=hearth; weather=overcast
- `scent` p023: アルン; scent=wet_soil; place=well; weather=overcast
- `affect_object` p023: アルン; object=shared_umbrella; place=well; weather=overcast
- `touch` p014: ケイ; touch=steam_on_face; place=hearth; weather=overcast
- `same_place_nearby` p050,p039: アルン and メイ both near hearth; weather=overcast
- `distant_social` p050,p039: アルン and メイ: made_a_troubled_face_toward_someone; place=hearth; weather=overcast
- `same_place_nearby` p050,p014: アルン and ケイ both near hearth; weather=overcast
- `distant_social` p050,p014: アルン and ケイ: almost_called_out; place=hearth; weather=overcast
- `same_place_nearby` p039,p014: メイ and ケイ both near hearth; weather=overcast

### Year 38
- `touch` p014: ケイ; touch=rough_wood_against_palm; place=tea_house; weather=light_mist
- `gesture` p014: ケイ stood_at_the_threshold; place=tea_house; weather=light_mist
- `touch` p057: エリン; touch=small_stone_in_sandal; place=path; weather=light_mist
- `repeat_place` p006: ティア appeared at tea_house again; count=2
- `scent` p006: ティア; scent=steam_from_cups; place=tea_house; weather=light_mist
- `touch` p011: エリン; touch=cold_mud_underfoot; place=path; weather=light_mist
- `repeat_place` p036: ゾル appeared at hearth again; count=2
- `scent` p036: ゾル; scent=old_wood; place=hearth; weather=light_mist
- `same_place_nearby` p044,p036: カイ and ゾル both near hearth; weather=light_mist
- `distant_social` p044,p036: カイ and ゾル: waited_without_speaking; place=hearth; weather=light_mist
- `same_place_nearby` p014,p006: ケイ and ティア both near tea_house; weather=light_mist
- `same_place_nearby` p057,p011: エリン and エリン both near path; weather=light_mist

### Year 15
- `touch` p009: ハナ; touch=rough_sackcloth; place=storehouse; weather=rain_on_roof
- `affect_object` p050: アルン; object=childs_wooden_spoon; place=tea_house; weather=rain_on_roof
- `gesture` p050: アルン looked_at_the_sky; place=tea_house; weather=rain_on_roof
- `repeat_place` p014: ケイ appeared at hearth again; count=2
- `scent` p014: ケイ; scent=old_wood; place=hearth; weather=rain_on_roof
- `touch` p014: ケイ; touch=straw_mat_under_knees; place=hearth; weather=rain_on_roof
- `affect_object` p014: ケイ; object=chipped_cup; place=hearth; weather=rain_on_roof
- `repeat_place` p015: ファラ appeared at tea_house again; count=2
- `same_place_nearby` p009,p024: ハナ and メイ both near storehouse; weather=rain_on_roof
- `same_place_nearby` p050,p015: アルン and ファラ both near tea_house; weather=rain_on_roof
- `distant_social` p050,p015: アルン and ファラ: made_a_troubled_face_toward_someone; place=tea_house; weather=rain_on_roof

### Year 40
- `scent` -: scent=burnt_rice_smell; place=hearth; weather=light_mist
- `world_gesture` -: gesture=someone_looked_up; place=hearth; weather=light_mist
- `scent` p052: ティア; scent=rain_on_dust; place=well; weather=light_mist
- `touch` p052: ティア; touch=cold_rope_in_hands; place=well; weather=light_mist
- `gesture` p033: メイ looked_at_the_sky; place=path; weather=light_mist
- `scent` p062: エリン; scent=wet_soil; place=path; weather=light_mist
- `gesture` p062: エリン looked_at_the_sky; place=path; weather=light_mist
- `same_place_nearby` p006,p033: ティア and メイ both near path; weather=light_mist
- `distant_social` p006,p033: ティア and メイ: laughed_at_the_same_time; place=path; weather=light_mist
- `same_place_nearby` p006,p062: ティア and エリン both near path; weather=light_mist
- `same_place_nearby` p033,p062: メイ and エリン both near path; weather=light_mist

### Year 55
- `repeat_place` p032: タロ appeared at well again; count=2
- `repeat_place` p019: ハナ appeared at tea_house again; count=2
- `touch` p019: ハナ; touch=warm_bowl_in_hands; place=tea_house; weather=heavy_rain
- `affect_object` p019: ハナ; object=childs_wooden_spoon; place=tea_house; weather=heavy_rain
- `repeat_place` p038: メイ appeared at hearth again; count=2
- `touch` p038: メイ; touch=steam_on_face; place=hearth; weather=heavy_rain
- `same_place_nearby` p019,p043: ハナ and エリン both near tea_house; weather=heavy_rain
- `distant_social` p019,p043: ハナ and エリン: smiled_toward_someone; place=tea_house; weather=heavy_rain
- `same_place_nearby` p055,p038: ケイ and メイ both near hearth; weather=heavy_rain
