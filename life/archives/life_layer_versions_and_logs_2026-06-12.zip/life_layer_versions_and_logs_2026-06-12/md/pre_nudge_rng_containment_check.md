# pre nudge rng containment check

Compared fixed `shadow3` and trust-nudge experiment D year by year.

Pass criteria:

- before the first nudge: body and trust snapshots match
- clean pre-nudge steps: no body/trust mismatches
- first nudge year: body and RNG still match; only trust differs
- after nudge: body divergence is allowed and should be readable

## seed1061

- nudge_count: `1`
- pre-step mismatches before first nudge: `0`
- clean-step mismatches before first nudge: `0`
- first_nudge: Y60 life_trust_nudge       p007,p051     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=rain_on_roof; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- body diff categories after nudge year: none
- rng equal after nudge year: `True`
- trust diff after nudge year: `2` directed edges
- first body divergence: Y63 (summary, people_without_trust, main_log, memory_lineage_trace, rng_state)
- first watched summary divergence: Y64 (death_count, final_population, memory_shared_count)
- first main log divergence: Y63, index=518
  - shadow3: `{'detail': 'アルン died age=89 health=1.00', 'event_type': 'death', 'persons': ['p028'], 'year': 63}`
  - experiment: `{'detail': 'ルト died age=82 health=1.00', 'event_type': 'death', 'persons': ['p026'], 'year': 63}`
- first memory lineage divergence: Y63, index=458
- first interpretation-related summary divergence: Y64 (memory_shared_count)

Nudge paths:
- `p007|p051` place=`tea_house` nudge_year=Y60
  - Y43 same_place_nearby      p051,p007     セナ and イシュ both near tea_house; weather=dry_wind
  - Y43 life_contact           p051,p007     セナ and イシュ: shared a brief ordinary moment; place=tea_house; weather=dry_wind
  - Y43 distant_social         p051,p007     セナ and イシュ: laughed_at_the_same_time; place=tea_house; weather=dry_wind
  - Y43 conversation_shadow    p051,p007     セナ and イシュ: talked_near_the_fire; place=tea_house; weather=dry_wind
  - Y43 familiarity_shadow     p051,p007     セナ and イシュ: repeated brief nearness; place=tea_house; weather=dry_wind; source=conversation_shadow; score=6
  - Y60 memory_shadow          p007,p051     イシュ: looked_toward_the_old_place; place=tea_house; weather=rain_on_roof; prior_year=43; prior_score=6
  - Y60 life_bridge_potential  p007,p051     potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=rain_on_roof
  - Y60 life_trust_nudge       p007,p051     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=rain_on_roof; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005

## seed1042

- nudge_count: `2`
- pre-step mismatches before first nudge: `0`
- clean-step mismatches before first nudge: `0`
- first_nudge: Y12 life_trust_nudge       p007,p020     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=dry_wind; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- body diff categories after nudge year: none
- rng equal after nudge year: `True`
- trust diff after nudge year: `2` directed edges
- first body divergence: Y54 (summary, people_without_trust, main_log, memory_lineage_trace, rng_state)
- first watched summary divergence: Y55 (interpretation_support_nudge_count, memory_shared_count, proposal_count, shared_narrative_count, support_chain_trace_count)
- first main log divergence: Y54, index=371
  - shadow3: `{'detail': 'ギル had a child: シオン', 'event_type': 'birth', 'persons': ['p042', 'p051'], 'year': 54}`
  - experiment: `{'detail': 'シオン had a child: シオン', 'event_type': 'birth', 'persons': ['p037', 'p051'], 'year': 54}`
- first memory lineage divergence: Y54, index=279
- first interpretation-related summary divergence: Y55 (memory_shared_count, shared_narrative_count, interpretation_support_nudge_count)

Nudge paths:
- `p007|p020` place=`tea_house` nudge_year=Y12
  - Y06 same_place_nearby      p020,p007     カイ and ヴァル both near tea_house; weather=rain_on_roof
  - Y06 distant_social         p020,p007     カイ and ヴァル: smiled_toward_someone; place=tea_house; weather=rain_on_roof
  - Y06 conversation_shadow    p020,p007     カイ and ヴァル: talked_near_the_fire; place=tea_house; weather=rain_on_roof
  - Y06 familiarity_shadow     p020,p007     カイ and ヴァル: repeated brief nearness; place=tea_house; weather=rain_on_roof; source=conversation_shadow; score=6
  - Y12 memory_shadow          p020,p007     カイ: looked_toward_the_old_place; place=tea_house; weather=dry_wind; prior_year=6; prior_score=6
  - Y12 life_bridge_potential  p020,p007     potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=dry_wind
  - Y12 life_trust_nudge       p007,p020     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=dry_wind; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- `p025|p026` place=`storehouse` nudge_year=Y18
  - Y02 same_place_nearby      p026,p025     ケイ and エリン both near storehouse; weather=light_mist
  - Y02 life_contact           p026,p025     ケイ and エリン: shared a brief ordinary moment; place=storehouse; weather=light_mist
  - Y02 passing_greeting       p026,p025     ケイ and エリン: paused_before_passing; place=storehouse; weather=light_mist
  - Y02 distant_social         p026,p025     ケイ and エリン: laughed_at_the_same_time; place=storehouse; weather=light_mist
  - Y02 familiarity_shadow     p026,p025     ケイ and エリン: repeated brief nearness; place=storehouse; weather=light_mist; source=distant_social; score=4
  - Y06 same_place_nearby      p025,p026     エリン and ケイ both near tea_house; weather=rain_on_roof
  - Y06 life_contact           p025,p026     エリン and ケイ: shared a brief ordinary moment; place=tea_house; weather=rain_on_roof
  - Y17 memory_shadow          p025,p026     エリン: looked_toward_the_old_place; place=storehouse; weather=light_mist; prior_year=2; prior_score=4
  - Y17 life_bridge_potential  p025,p026     potential=8.0; mark=1; source=memory_shadow; sources=distant_social,familiarity_shadow,memory_shadow,passing_greeting; place=storehouse; weather=light_mist
  - Y18 memory_shadow          p026,p025     ケイ: returned_after_brief_nearness; place=storehouse; weather=dry_wind; prior_year=2; prior_score=4
  - Y18 life_trust_nudge       p025,p026     potential=12.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=storehouse; weather=dry_wind; trust_before=0.0000,0.8594; trust_after=0.0005,0.8599

## seed1096

- nudge_count: `2`
- pre-step mismatches before first nudge: `0`
- clean-step mismatches before first nudge: `0`
- first_nudge: Y27 life_trust_nudge       p014,p050     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=light_mist; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- body diff categories after nudge year: none
- rng equal after nudge year: `True`
- trust diff after nudge year: `2` directed edges
- first body divergence: Y46 (summary, people_without_trust, main_log, memory_lineage_trace)
- first watched summary divergence: Y46 (narrative_divergence_count)
- first main log divergence: Y46, index=128
  - shadow3: `None`
  - experiment: `{'detail': 'narrative_divergence: death, versions 0.36 vs 0.78', 'event_type': 'narrative_divergence', 'persons': [], 'year': 46}`
- first memory lineage divergence: Y46, index=89
- first interpretation-related summary divergence: Y46 (narrative_divergence_count)

Nudge paths:
- `p014|p050` place=`tea_house` nudge_year=Y27
  - Y19 same_place_nearby      p050,p014     サナ and タロ both near tea_house; weather=light_mist
  - Y19 life_contact           p050,p014     サナ and タロ: shared a brief ordinary moment; place=tea_house; weather=light_mist
  - Y19 distant_social         p050,p014     サナ and タロ: smiled_toward_someone; place=tea_house; weather=light_mist
  - Y19 conversation_shadow    p050,p014     サナ and タロ: said_almost_nothing; place=tea_house; weather=light_mist
  - Y19 familiarity_shadow     p050,p014     サナ and タロ: repeated brief nearness; place=tea_house; weather=light_mist; source=conversation_shadow; score=6
  - Y27 memory_shadow          p014,p050     タロ: left_before_speaking_again; place=tea_house; weather=light_mist; prior_year=19; prior_score=6
  - Y27 life_bridge_potential  p014,p050     potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=light_mist
  - Y27 life_trust_nudge       p014,p050     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=light_mist; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- `p030|p033` place=`tea_house` nudge_year=Y34
  - Y30 same_place_nearby      p030,p033     ゾル and ノア both near tea_house; weather=heavy_rain
  - Y30 life_contact           p030,p033     ゾル and ノア: shared a brief ordinary moment; place=tea_house; weather=heavy_rain
  - Y30 distant_social         p030,p033     ゾル and ノア: waved_from_a_distance; place=tea_house; weather=heavy_rain
  - Y30 conversation_shadow    p030,p033     ゾル and ノア: spoke_briefly; place=tea_house; weather=heavy_rain
  - Y30 familiarity_shadow     p030,p033     ゾル and ノア: repeated brief nearness; place=tea_house; weather=heavy_rain; source=conversation_shadow; score=6
  - Y34 memory_shadow          p033,p030     ノア: returned_after_brief_nearness; place=tea_house; weather=overcast; prior_year=30; prior_score=6
  - Y34 life_bridge_potential  p033,p030     potential=10.0; mark=1; source=memory_shadow; sources=conversation_shadow,distant_social,familiarity_shadow,memory_shadow; place=tea_house; weather=overcast
  - Y34 life_trust_nudge       p030,p033     potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=overcast; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005

## interpretation

All checked seeds contain RNG/body containment up to the nudge. The nudge year itself leaves the body snapshot and core RNG state aligned; only trust differs. Later divergence is therefore an intervention-driven branch, not a pre-existing RNG stream drift.

The interpretation path is delayed: trust changes first, then later death/birth/memory narration splits, and support/project differences appear after that.
