# trust nudge experiment comparison

## setup

- Experiment file: `society_lab_v1_4_life_bridge_trust_nudge_experiment.py`
- Observation-only shadow3 is preserved.
- Nudge writes directly to `Person.trust` and records only `life_trust_nudge` in life observations.
- Main ObservationLog is not directly written by the nudge.

## 3 variant comparison

| variant | threshold | delta | nudge avg/max | changed trust pairs avg/max | trust delta sum avg/max | summary diff keys avg/max |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `A_threshold10_delta001` | 10.0 | 0.001 | 0.42/5 | 22.35/433 | 0.4705/20.014 | 1.67/11 |
| `B_threshold12_delta001` | 12.0 | 0.001 | 0.19/4 | 13.76/288 | 0.0401/3.682 | 1.01/11 |
| `C_threshold10_delta0005` | 10.0 | 0.0005 | 0.42/5 | 22.35/433 | 0.4701/20.013 | 1.67/11 |

## A_threshold10_delta001

- Changed summary keys across 100 seeds: `support_chain_trace_count`=20, `memory_shared_count`=19, `proposal_count`=18, `shared_narrative_count`=17, `final_population`=15, `project_aftermath_trace_count`=14, `project_success_count`=13, `network_split_count`=13, `death_count`=12, `birth_count`=12, `project_failure_count`=10, `authority_pattern_count`=4
- seed1003: `life_bridge_potential=0`, `life_trust_nudge=0`, `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `time_shadow=8`; trust_delta={'trust_changed_pair_count': 0, 'trust_delta_sum': 0.0, 'trust_delta_max': 0.0}
  - nudge: none
- seed1061: `life_bridge_potential=1`, `life_trust_nudge=1`, `conversation_shadow=2`, `familiarity_shadow=2`, `memory_shadow=1`, `time_shadow=7`; trust_delta={'trust_changed_pair_count': 49, 'trust_delta_sum': 2.056318, 'trust_delta_max': 0.85}
  - Y60 `p007|p051` potential=10.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=rain_on_roof; trust_before=0.0000,0.0000; trust_after=0.0010,0.0010
- seed1042: `life_bridge_potential=5`, `life_trust_nudge=5`, `conversation_shadow=3`, `familiarity_shadow=5`, `memory_shadow=8`, `time_shadow=15`; trust_delta={'trust_changed_pair_count': 288, 'trust_delta_sum': -1.059154, 'trust_delta_max': 0.886}
  - Y12 `p007|p020` potential=10.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=dry_wind; trust_before=0.0000,0.0000; trust_after=0.0010,0.0010
  - Y18 `p025|p026` potential=12.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=storehouse; weather=dry_wind; trust_before=0.0000,0.8594; trust_after=0.0010,0.8604
  - Y33 `p025|p026` potential=16.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=storehouse; weather=overcast; trust_before=0.0010,0.8604; trust_after=0.0020,0.8614
  - Y47 `p025|p026` potential=20.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=storehouse; weather=light_mist; trust_before=0.0260,0.8614; trust_after=0.0270,0.8624
- seed1096: `life_bridge_potential=2`, `life_trust_nudge=2`, `conversation_shadow=6`, `familiarity_shadow=7`, `memory_shadow=3`, `time_shadow=9`; trust_delta={'trust_changed_pair_count': 131, 'trust_delta_sum': -1.909976, 'trust_delta_max': 0.958}
  - Y27 `p014|p050` potential=10.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=light_mist; trust_before=0.0000,0.0000; trust_after=0.0010,0.0010
  - Y34 `p030|p033` potential=10.0; delta=0.0010; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=overcast; trust_before=0.0000,0.0000; trust_after=0.0010,0.0010

## B_threshold12_delta001

- Changed summary keys across 100 seeds: `support_chain_trace_count`=12, `proposal_count`=11, `memory_shared_count`=11, `shared_narrative_count`=11, `project_aftermath_trace_count`=10, `final_population`=10, `project_success_count`=8, `death_count`=7, `network_split_count`=7, `birth_count`=7, `project_failure_count`=4, `authority_pattern_count`=3
- seed1003: `life_bridge_potential=0`, `life_trust_nudge=0`, `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `time_shadow=8`; trust_delta={'trust_changed_pair_count': 0, 'trust_delta_sum': 0.0, 'trust_delta_max': 0.0}
  - nudge: none
- seed1061: `life_bridge_potential=1`, `life_trust_nudge=0`, `conversation_shadow=2`, `familiarity_shadow=3`, `memory_shadow=1`, `time_shadow=7`; trust_delta={'trust_changed_pair_count': 0, 'trust_delta_sum': 0.0, 'trust_delta_max': 0.0}
  - nudge: none
- seed1042: `life_bridge_potential=5`, `life_trust_nudge=4`, `conversation_shadow=3`, `familiarity_shadow=5`, `memory_shadow=8`, `time_shadow=15`; trust_delta={'trust_changed_pair_count': 288, 'trust_delta_sum': -1.061154, 'trust_delta_max': 0.886}
  - Y18 `p025|p026` potential=12.0; delta=0.0010; threshold=12.0; cooldown=8; source=memory_shadow; place=storehouse; weather=dry_wind; trust_before=0.0000,0.8594; trust_after=0.0010,0.8604
  - Y33 `p025|p026` potential=16.0; delta=0.0010; threshold=12.0; cooldown=8; source=memory_shadow; place=storehouse; weather=overcast; trust_before=0.0010,0.8604; trust_after=0.0020,0.8614
  - Y47 `p025|p026` potential=20.0; delta=0.0010; threshold=12.0; cooldown=8; source=memory_shadow; place=storehouse; weather=light_mist; trust_before=0.0260,0.8614; trust_after=0.0270,0.8624
  - Y53 `p007|p020` potential=14.0; delta=0.0010; threshold=12.0; cooldown=8; source=memory_shadow; place=tea_house; weather=heavy_rain; trust_before=0.0000,0.0000; trust_after=0.0010,0.0010
- seed1096: `life_bridge_potential=2`, `life_trust_nudge=1`, `conversation_shadow=6`, `familiarity_shadow=7`, `memory_shadow=3`, `time_shadow=11`; trust_delta={'trust_changed_pair_count': 174, 'trust_delta_sum': 0.967075, 'trust_delta_max': 0.922}
  - Y28 `p014|p050` potential=14.0; delta=0.0010; threshold=12.0; cooldown=8; source=memory_shadow; place=tea_house; weather=clear; trust_before=0.0000,0.0000; trust_after=0.0010,0.0010

## C_threshold10_delta0005

- Changed summary keys across 100 seeds: `support_chain_trace_count`=20, `memory_shared_count`=19, `proposal_count`=18, `shared_narrative_count`=17, `final_population`=15, `project_aftermath_trace_count`=14, `project_success_count`=13, `network_split_count`=13, `death_count`=12, `birth_count`=12, `project_failure_count`=10, `authority_pattern_count`=4
- seed1003: `life_bridge_potential=0`, `life_trust_nudge=0`, `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `time_shadow=8`; trust_delta={'trust_changed_pair_count': 0, 'trust_delta_sum': 0.0, 'trust_delta_max': 0.0}
  - nudge: none
- seed1061: `life_bridge_potential=1`, `life_trust_nudge=1`, `conversation_shadow=2`, `familiarity_shadow=2`, `memory_shadow=1`, `time_shadow=7`; trust_delta={'trust_changed_pair_count': 49, 'trust_delta_sum': 2.055318, 'trust_delta_max': 0.85}
  - Y60 `p007|p051` potential=10.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=rain_on_roof; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- seed1042: `life_bridge_potential=5`, `life_trust_nudge=5`, `conversation_shadow=3`, `familiarity_shadow=5`, `memory_shadow=8`, `time_shadow=15`; trust_delta={'trust_changed_pair_count': 288, 'trust_delta_sum': -1.064154, 'trust_delta_max': 0.886}
  - Y12 `p007|p020` potential=10.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=dry_wind; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
  - Y18 `p025|p026` potential=12.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=storehouse; weather=dry_wind; trust_before=0.0000,0.8594; trust_after=0.0005,0.8599
  - Y33 `p025|p026` potential=16.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=storehouse; weather=overcast; trust_before=0.0005,0.8599; trust_after=0.0010,0.8604
  - Y47 `p025|p026` potential=20.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=storehouse; weather=light_mist; trust_before=0.0250,0.8604; trust_after=0.0255,0.8609
- seed1096: `life_bridge_potential=2`, `life_trust_nudge=2`, `conversation_shadow=6`, `familiarity_shadow=7`, `memory_shadow=3`, `time_shadow=9`; trust_delta={'trust_changed_pair_count': 131, 'trust_delta_sum': -1.911976, 'trust_delta_max': 0.958}
  - Y27 `p014|p050` potential=10.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=light_mist; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
  - Y34 `p030|p033` potential=10.0; delta=0.0005; threshold=10.0; cooldown=8; source=memory_shadow; place=tea_house; weather=overcast; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005

## recommendation

Initial read: this experiment is viable, but it is sensitive. A and C catch seed1061's bridge path, but they affect the same seeds because the threshold is unchanged; halving delta does not prevent downstream branch divergence. B is cleaner overall, but it misses seed1061 because `p007|p051` stops at potential 10.0.

Recommendation: keep the experiment file, do not adopt yet. The next serious candidate should be a narrower D variant: `threshold=10`, `delta=0.0005`, `cooldown=12`, and `one nudge per pair total` or `memory_shadow source only`. That preserves the seed1061 bridge while reducing repeated nudges in seeds like 1042.
