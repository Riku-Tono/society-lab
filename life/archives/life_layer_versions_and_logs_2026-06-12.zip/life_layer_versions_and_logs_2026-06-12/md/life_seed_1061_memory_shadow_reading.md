# Life Seed Reading: seed 1061

## Base Summary

- `seed`: 1061
- `years`: 80
- `initial_population`: 37
- `final_population`: 34
- `age_profile`: balanced
- `charisma_profile`: normal
- `initial_food_stock`: 202.432
- `initial_food_capacity`: 47.555
- `final_food_stock`: 123.819
- `avg_fear`: 0.001
- `avg_hunger`: 0.0
- `avg_voice_weight`: 0.001
- `max_voice_weight`: 0.021
- `crisis_count`: 0
- `problem_count`: 11
- `council_count`: 11
- `proposal_count`: 19
- `project_success_count`: 3
- `project_failure_count`: 3
- `shared_narrative_count`: 33
- `authority_pattern_count`: 0
- `faction_pattern_count`: 0
- `ritualization_pattern_count`: 0
- `network_split_count`: 6
- `narrative_divergence_count`: 17
- `interpretation_divergence_count`: 0
- `interpretation_convergence_count`: 0
- `interpretation_action_nudge_count`: 1
- `interpretation_support_nudge_count`: 41
- `avg_bias_spiritual`: 0.1201
- `avg_bias_practical`: 0.1116
- `avg_bias_blame`: 0.109
- `death_count`: 32
- `birth_count`: 29
- `memory_shared_count`: 338
- `behavior_copied_count`: 0
- `biography_subject_count`: 66
- `memory_lineage_trace_count`: 580
- `support_chain_trace_count`: 125
- `project_aftermath_trace_count`: 6

## Life Event Counts

- `place_presence`: 254
- `scent`: 111
- `weather`: 80
- `same_place_nearby`: 74
- `touch`: 68
- `sound`: 67
- `repeat_place`: 63
- `affect_object`: 50
- `gesture`: 50
- `tea_house`: 49
- `rainy_tea_house`: 45
- `well_water`: 31
- `brazier_presence`: 31
- `animal_presence`: 30
- `storehouse_bag`: 28
- `trace`: 24
- `distant_social`: 16
- `elder_sitting`: 15
- `world_gesture`: 11
- `conversation_shadow`: 8
- `familiarity_shadow`: 8
- `child_bowl`: 1
- `memory_shadow`: 1

## Repeated Place Presence

- `p026`: hearth:2, tea_house:2, well:2, path:2, gate:1
- `p033`: storehouse:2, hearth:2, well:2, tea_house:2, path:1
- `p020`: well:2, hearth:2, storehouse:2, tea_house:1, gate:1
- `p001`: well:2, path:1, tea_house:1, hearth:1, gate:1, storehouse:1
- `p002`: tea_house:2, storehouse:2, path:2, gate:1
- `p007`: storehouse:3, tea_house:3, hearth:1
- `p009`: storehouse:4, hearth:2, tea_house:1
- `p032`: tea_house:2, gate:1, hearth:1, path:1, well:1, storehouse:1
- `p006`: hearth:3, tea_house:2, storehouse:1
- `p014`: tea_house:3, storehouse:1, well:1, gate:1
- `p021`: well:2, tea_house:2, hearth:1, path:1
- `p023`: storehouse:3, tea_house:1, path:1, hearth:1

## Pair Threads

- `p004|p026`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p005|p021`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p007|p036`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p011|p017`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p013|p034`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p015|p052`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p023|p026`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p045|p046`: same_place_nearby:1, distant_social:1, conversation_shadow:1, familiarity_shadow:1
- `p000|p026`: same_place_nearby:1, distant_social:1
- `p000|p031`: same_place_nearby:1, distant_social:1
- `p001|p007`: same_place_nearby:1, distant_social:1
- `p005|p035`: same_place_nearby:1, distant_social:1

## Years To Read Closely

### Year 40
- `scent` -: scent=steam_from_cups; place=tea_house; weather=clear
- `touch` p006: レン; touch=straw_mat_under_knees; place=hearth; weather=clear
- `repeat_place` p007: イシュ appeared at tea_house again; count=2
- `memory_shadow` p007,p036: イシュ: returned_after_brief_nearness; place=tea_house; weather=clear; prior_year=22; prior_score=7
- `affect_object` p036: ゾル; object=childs_wooden_spoon; place=storehouse; weather=clear
- `same_place_nearby` p007,p001: イシュ and イシュ both near tea_house; weather=clear
- `distant_social` p007,p001: イシュ and イシュ: laughed_at_the_same_time; place=tea_house; weather=clear

### Year 33
- `scent` -: scent=wet_soil; place=well; weather=clear
- `touch` p013: カイ; touch=wind_on_neck; place=gate; weather=clear
- `scent` p038: ミラ; scent=dust_in_sacks; place=storehouse; weather=clear
- `touch` p038: ミラ; touch=small_splinter_in_palm; place=storehouse; weather=clear
- `repeat_place` p021: オルン appeared at tea_house again; count=2
- `affect_object` p021: オルン; object=cracked_ladle; place=tea_house; weather=clear
- `scent` p039: ファラ; scent=rain_on_dust; place=gate; weather=clear
- `repeat_place` p034: レン appeared at gate again; count=2
- `same_place_nearby` p013,p039: カイ and ファラ both near gate; weather=clear
- `same_place_nearby` p013,p034: カイ and レン both near gate; weather=clear
- `distant_social` p013,p034: カイ and レン: almost_called_out; place=gate; weather=clear
- `conversation_shadow` p013,p034: カイ and レン: talked_near_the_fire; place=gate; weather=clear
- `familiarity_shadow` p013,p034: カイ and レン: repeated brief nearness; place=gate; weather=clear; source=conversation_shadow; score=7
- `same_place_nearby` p039,p034: ファラ and レン both near gate; weather=clear
- `distant_social` p039,p034: ファラ and レン: almost_called_out; place=gate; weather=clear

### Year 22
- `scent` -: scent=cold_stone; place=well; weather=heavy_rain
- `repeat_place` p003: ヴァル appeared at tea_house again; count=2
- `scent` p007: イシュ; scent=smoke_in_cloth; place=tea_house; weather=heavy_rain
- `affect_object` p007: イシュ; object=burnt_rice_smell; place=tea_house; weather=heavy_rain
- `repeat_place` p032: ルト appeared at tea_house again; count=2
- `scent` p032: ルト; scent=smoke_in_cloth; place=tea_house; weather=heavy_rain
- `scent` p001: イシュ; scent=damp_straw; place=path; weather=heavy_rain
- `affect_object` p036: ゾル; object=chipped_cup; place=tea_house; weather=heavy_rain
- `same_place_nearby` p003,p007: ヴァル and イシュ both near tea_house; weather=heavy_rain
- `same_place_nearby` p003,p032: ヴァル and ルト both near tea_house; weather=heavy_rain
- `same_place_nearby` p003,p036: ヴァル and ゾル both near tea_house; weather=heavy_rain
- `same_place_nearby` p007,p032: イシュ and ルト both near tea_house; weather=heavy_rain
- `same_place_nearby` p007,p036: イシュ and ゾル both near tea_house; weather=heavy_rain
- `distant_social` p007,p036: イシュ and ゾル: almost_called_out; place=tea_house; weather=heavy_rain
- `conversation_shadow` p007,p036: イシュ and ゾル: spoke_briefly; place=tea_house; weather=heavy_rain
- `familiarity_shadow` p007,p036: イシュ and ゾル: repeated brief nearness; place=tea_house; weather=heavy_rain; source=conversation_shadow; score=7
- `same_place_nearby` p032,p036: ルト and ゾル both near tea_house; weather=heavy_rain

### Year 19
- `scent` -: scent=wind_from_fields; place=path; weather=light_mist
- `scent` p011: エリン; scent=steam_from_cups; place=tea_house; weather=light_mist
- `affect_object` p011: エリン; object=cracked_ladle; place=tea_house; weather=light_mist
- `gesture` p011: エリン stood_at_the_threshold; place=tea_house; weather=light_mist
- `scent` p013: カイ; scent=boiled_barley; place=tea_house; weather=light_mist
- `touch` p032: ルト; touch=warm_bowl_in_hands; place=hearth; weather=light_mist
- `repeat_place` p027: ミラ appeared at well again; count=2
- `same_place_nearby` p011,p013: エリン and カイ both near tea_house; weather=light_mist
- `same_place_nearby` p011,p017: エリン and ギル both near tea_house; weather=light_mist
- `distant_social` p011,p017: エリン and ギル: waved_from_a_distance; place=tea_house; weather=light_mist
- `conversation_shadow` p011,p017: エリン and ギル: spoke_briefly; place=tea_house; weather=light_mist
- `familiarity_shadow` p011,p017: エリン and ギル: repeated brief nearness; place=tea_house; weather=light_mist; source=conversation_shadow; score=7
- `same_place_nearby` p013,p017: カイ and ギル both near tea_house; weather=light_mist

### Year 34
- `scent` -: scent=steam_from_cups; place=tea_house; weather=light_mist
- `world_gesture` -: gesture=a_whisper_nearby; place=hearth; weather=light_mist
- `gesture` p015: サナ put_something_down_slowly; place=well; weather=light_mist
- `repeat_place` p022: レン appeared at tea_house again; count=2
- `gesture` p022: レン watched_the_fire; place=tea_house; weather=light_mist
- `scent` p018: ゾル; scent=old_wood; place=hearth; weather=light_mist
- `gesture` p018: ゾル put_something_down_slowly; place=hearth; weather=light_mist
- `gesture` p052: ファラ stood_at_the_threshold; place=well; weather=light_mist
- `same_place_nearby` p007,p018: イシュ and ゾル both near hearth; weather=light_mist
- `same_place_nearby` p015,p052: サナ and ファラ both near well; weather=light_mist
- `distant_social` p015,p052: サナ and ファラ: waited_without_speaking; place=well; weather=light_mist
- `conversation_shadow` p015,p052: サナ and ファラ: said_almost_nothing; place=well; weather=light_mist
- `familiarity_shadow` p015,p052: サナ and ファラ: repeated brief nearness; place=well; weather=light_mist; source=conversation_shadow; score=7

### Year 41
- `affect_object` p026: ルト; object=small_blanket; place=path; weather=rain_on_roof
- `affect_object` p034: レン; object=shared_umbrella; place=tea_house; weather=rain_on_roof
- `gesture` p034: レン watched_the_fire; place=tea_house; weather=rain_on_roof
- `scent` p005: エリン; scent=rain_on_dust; place=well; weather=rain_on_roof
- `repeat_place` p021: オルン appeared at well again; count=2
- `gesture` p021: オルン held_still_a_moment; place=well; weather=rain_on_roof
- `touch` p054: ルト; touch=rough_sackcloth; place=storehouse; weather=rain_on_roof
- `scent` p028: アルン; scent=dry_grass; place=gate; weather=rain_on_roof
- `same_place_nearby` p005,p021: エリン and オルン both near well; weather=rain_on_roof
- `distant_social` p005,p021: エリン and オルン: waved_from_a_distance; place=well; weather=rain_on_roof
- `conversation_shadow` p005,p021: エリン and オルン: talked_near_the_fire; place=well; weather=rain_on_roof
- `familiarity_shadow` p005,p021: エリン and オルン: repeated brief nearness; place=well; weather=rain_on_roof; source=conversation_shadow; score=7

### Year 67
- `scent` p023: リオ; scent=dry_grass; place=path; weather=clear
- `affect_object` p023: リオ; object=shared_umbrella; place=path; weather=clear
- `gesture` p023: リオ did_not_go_in; place=path; weather=clear
- `scent` p057: タロ; scent=steam_from_cups; place=tea_house; weather=clear
- `gesture` p057: タロ watched_the_fire; place=tea_house; weather=clear
- `repeat_place` p033: イシュ appeared at well again; count=2
- `affect_object` p033: イシュ; object=old_cloth; place=well; weather=clear
- `gesture` p033: イシュ looked_away; place=well; weather=clear
- `same_place_nearby` p023,p026: リオ and ルト both near path; weather=clear
- `distant_social` p023,p026: リオ and ルト: laughed_at_the_same_time; place=path; weather=clear
- `conversation_shadow` p023,p026: リオ and ルト: spoke_briefly; place=path; weather=clear
- `familiarity_shadow` p023,p026: リオ and ルト: repeated brief nearness; place=path; weather=clear; source=conversation_shadow; score=7

### Year 8
- `scent` p040: シオン; scent=ash_after_rain; place=hearth; weather=heavy_rain
- `touch` p040: シオン; touch=steam_on_face; place=hearth; weather=heavy_rain
- `affect_object` p040: シオン; object=shared_umbrella; place=hearth; weather=heavy_rain
- `affect_object` p026: ルト; object=burnt_rice_smell; place=tea_house; weather=heavy_rain
- `gesture` p026: ルト put_something_down_slowly; place=tea_house; weather=heavy_rain
- `affect_object` p004: カイ; object=damp_sleeve; place=tea_house; weather=heavy_rain
- `same_place_nearby` p040,p024: シオン and サナ both near hearth; weather=heavy_rain
- `same_place_nearby` p026,p004: ルト and カイ both near tea_house; weather=heavy_rain
- `distant_social` p026,p004: ルト and カイ: made_a_troubled_face_toward_someone; place=tea_house; weather=heavy_rain
- `conversation_shadow` p026,p004: ルト and カイ: mentioned_the_road; place=tea_house; weather=heavy_rain
- `familiarity_shadow` p026,p004: ルト and カイ: repeated brief nearness; place=tea_house; weather=heavy_rain; source=conversation_shadow; score=7

### Year 21
- `affect_object` p024: サナ; object=chipped_cup; place=storehouse; weather=dry_wind
- `scent` p017: ギル; scent=mended_rope; place=storehouse; weather=dry_wind
- `touch` p019: イシュ; touch=rough_sackcloth; place=storehouse; weather=dry_wind
- `scent` p045: ハナ; scent=rain_on_dust; place=well; weather=dry_wind
- `same_place_nearby` p024,p017: サナ and ギル both near storehouse; weather=dry_wind
- `same_place_nearby` p024,p019: サナ and イシュ both near storehouse; weather=dry_wind
- `same_place_nearby` p017,p019: ギル and イシュ both near storehouse; weather=dry_wind
- `same_place_nearby` p046,p045: ヴァル and ハナ both near well; weather=dry_wind
- `distant_social` p046,p045: ヴァル and ハナ: waited_without_speaking; place=well; weather=dry_wind
- `conversation_shadow` p046,p045: ヴァル and ハナ: talked_near_the_fire; place=well; weather=dry_wind
- `familiarity_shadow` p046,p045: ヴァル and ハナ: repeated brief nearness; place=well; weather=dry_wind; source=conversation_shadow; score=7

### Year 1
- `scent` -: scent=burnt_rice_smell; place=hearth; weather=heavy_rain
- `scent` p030: ミラ; scent=wet_soil; place=path; weather=heavy_rain
- `touch` p030: ミラ; touch=wind_on_neck; place=path; weather=heavy_rain
- `affect_object` p030: ミラ; object=chipped_cup; place=path; weather=heavy_rain
- `touch` p004: カイ; touch=damp_sleeve_on_skin; place=path; weather=heavy_rain
- `touch` p031: ユラ; touch=straw_mat_under_knees; place=tea_house; weather=heavy_rain
- `same_place_nearby` p001,p035: イシュ and ミラ both near well; weather=heavy_rain
- `same_place_nearby` p030,p004: ミラ and カイ both near path; weather=heavy_rain
- `same_place_nearby` p000,p031: シオン and ユラ both near tea_house; weather=heavy_rain
- `distant_social` p000,p031: シオン and ユラ: waved_from_a_distance; place=tea_house; weather=heavy_rain
