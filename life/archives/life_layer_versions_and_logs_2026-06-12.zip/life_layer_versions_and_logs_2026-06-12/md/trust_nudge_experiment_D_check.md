# trust nudge experiment D check

## implementation

- `society_lab_v1_4_life_senses_memory_shadow3.py` is fixed and was not modified.
- `society_lab_v1_4_life_bridge_trust_nudge_experiment.py` now defaults to D.
- D: `threshold=10`, `delta=0.0005`, `cooldown=16`, `max_per_year=1`, `max_per_pair_total=1`, `allowed_sources={memory_shadow}`.
- Trust nudge writes to `Person.trust` and records `life_trust_nudge` only in life observations.

## fixed shadow3 check

- shadow3 vs base pollution diffs: `0`

## A/B/C/D comparison

| variant | nudge seeds | no-nudge mismatches | nudge avg/max | summary diff keys avg/max | sources |
| --- | ---: | ---: | ---: | ---: | --- |
| `A_threshold10_delta001` | 28 | 0 | 0.42/5 | 1.67/11 | memory_shadow=42 |
| `B_threshold12_delta001` | 14 | 0 | 0.19/4 | 1.01/11 | memory_shadow=19 |
| `C_threshold10_delta0005` | 28 | 0 | 0.42/5 | 1.67/11 | memory_shadow=42 |
| `D_memory_shadow_once` | 28 | 0 | 0.35/2 | 1.67/11 | memory_shadow=35 |

## D seed list

- nudge seeds: 1006, 1009, 1014, 1015, 1019, 1021, 1022, 1026, 1032, 1035, 1036, 1041, 1042, 1043, 1059, 1060, 1061, 1064, 1072, 1075, 1080, 1085, 1090, 1091, 1094, 1096, 1097, 1098
- no-nudge shadow mismatches: none

## seed1003 D

- Counts: `life_bridge_potential=0`, `life_trust_nudge=0`, `conversation_shadow=0`, `familiarity_shadow=0`, `memory_shadow=0`, `time_shadow=8`
- Trust delta: `{'trust_changed_pair_count': 0, 'trust_delta_sum': 0.0, 'trust_delta_max': 0.0}`
- Summary diff keys: none
- Nudges: none
- Top potentials: `p001|p015=1.0`, `p003|p014=1.0`, `p005|p019=1.0`, `p006|p036=1.0`, `p012|p013=1.0`

## seed1061 D

- Counts: `life_bridge_potential=1`, `life_trust_nudge=1`, `conversation_shadow=2`, `familiarity_shadow=2`, `memory_shadow=1`, `time_shadow=7`
- Trust delta: `{'trust_changed_pair_count': 49, 'trust_delta_sum': 2.055318, 'trust_delta_max': 0.85}`
- Summary diff keys: final_population, death_count, birth_count, project_failure_count, proposal_count, memory_shared_count, support_chain_trace_count, project_aftermath_trace_count, network_split_count
- Nudges:
  - Y60 `p007|p051` potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=rain_on_roof; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- Top potentials: `p007|p051=10.0`, `p036|p044=6.0`, `p006|p053=1.0`, `p007|p027=1.0`, `p009|p023=1.0`

## seed1042 D

- Counts: `life_bridge_potential=5`, `life_trust_nudge=2`, `conversation_shadow=3`, `familiarity_shadow=5`, `memory_shadow=8`, `time_shadow=15`
- Trust delta: `{'trust_changed_pair_count': 288, 'trust_delta_sum': -1.067154, 'trust_delta_max': 0.886}`
- Summary diff keys: final_population, death_count, birth_count, project_success_count, project_failure_count, proposal_count, memory_shared_count, support_chain_trace_count, project_aftermath_trace_count, network_split_count, shared_narrative_count
- Nudges:
  - Y12 `p007|p020` potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=dry_wind; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
  - Y18 `p025|p026` potential=12.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=storehouse; weather=dry_wind; trust_before=0.0000,0.8594; trust_after=0.0005,0.8599
- Top potentials: `p025|p026=20.0`, `p007|p020=18.0`, `p020|p025=8.0`, `p012|p016=6.0`, `p044|p049=6.0`

## seed1096 D

- Counts: `life_bridge_potential=2`, `life_trust_nudge=2`, `conversation_shadow=6`, `familiarity_shadow=7`, `memory_shadow=3`, `time_shadow=9`
- Trust delta: `{'trust_changed_pair_count': 131, 'trust_delta_sum': -1.911976, 'trust_delta_max': 0.958}`
- Summary diff keys: final_population, death_count, birth_count, project_success_count, project_failure_count, proposal_count, memory_shared_count, support_chain_trace_count, project_aftermath_trace_count, network_split_count, shared_narrative_count
- Nudges:
  - Y27 `p014|p050` potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=light_mist; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
  - Y34 `p030|p033` potential=10.0; delta=0.0005; threshold=10.0; cooldown=16; max_per_year=1; max_per_pair_total=1; source=memory_shadow; place=tea_house; weather=overcast; trust_before=0.0000,0.0000; trust_after=0.0005,0.0005
- Top potentials: `p014|p050=14.0`, `p030|p033=10.0`, `p023|p026=6.0`, `p034|p051=6.0`, `p035|p040=6.0`

## judgment

D is the preferred experimental default. It keeps no-nudge seeds identical to shadow3, restricts all nudges to `memory_shadow`, preserves seed1003, catches seed1061's tea-house memory path, and reduces repeated nudges by allowing each pair only one lifetime nudge.

D is still a real body-intervention branch: when it nudges trust, downstream summary differences can appear. That is expected here. The improvement over A/C is not zero impact; it is cleaner attribution.
